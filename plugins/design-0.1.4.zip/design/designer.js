//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region plugins/design/pageName.ts
/**
* How the agent is told which page is beside the panel.
*
* A site by its address. A copy by its file: its address is the program's own
* scheme, which names nothing an agent can open, and the agent went looking
* for the file across the disk and asked for folders outside the project
* (night tester, 23 September, FM-DESIGN-107). The copies live in this
* plugin's own work folder, which the surface names.
*/
async function pageNamed(api, address) {
	const m = /^vobuda-design:\/\/localhost\/copy\/[^/]+\/([^/?#]+)/.exec(address);
	if (!m) return address;
	try {
		return `${(await api.workFolder("copies")).path}/${decodeURIComponent(m[1])}`;
	} catch {
		return address;
	}
}
//#endregion
//#region plugins/design/palette.ts
/**
* A full palette, for when the site's own colours are not the answer.
*
* The site's colours come first and always will — a picker that offers a
* rainbow to somebody working on a six-colour site produces a seventh. But
* Gary asked for the rest of it in as many words: «цвета тоже надо дать больше
* вариантов... сделать всю палитру». Somebody redesigning a page is choosing
* new colours, and the palette is where they choose them (FM-DESIGN-56).
*
* Built rather than listed: ten hues around the wheel, five steps of lightness
* each, and a row of greys from black to white. Written as `hsl` because that
* is the shape the grid is thought in; the page turns it into whatever it
* computes with.
*/
function spectrum() {
	const out = [];
	const hues = [
		0,
		22,
		45,
		90,
		140,
		170,
		200,
		225,
		265,
		310
	];
	for (const step of [
		92,
		78,
		60,
		44,
		28
	]) for (const hue of hues) {
		const sat = step > 80 ? 62 : step > 50 ? 72 : 58;
		out.push(`hsl(${hue}, ${sat}%, ${step}%)`);
	}
	for (const step of [
		100,
		96,
		88,
		72,
		52,
		34,
		20,
		10,
		0
	]) out.push(`hsl(220, 12%, ${step}%)`);
	return out;
}
var en_default = {
	"A site that is not yours is not edited. Copy the design and change the copy.": "A site that is not yours is not edited. Copy the design and change the copy.",
	"About the page open beside me, {0}: {1}": "About the page open beside me, {0}: {1}",
	Alignment: "Alignment",
	"Ask the agent": "Ask the agent",
	"Asked. The answer comes back here.": "Asked. The answer comes back here.",
	Background: "Background",
	Centre: "Centre",
	"Changes here are on the page in front of you. Copy the design to keep them.": "Changes here are on the page in front of you. Copy the design to keep them.",
	"Copied into {0}. It opens beside this, and it can be changed and kept.": "Copied into {0}. It opens beside this, and it can be changed and kept.",
	"Copy the design": "Copy the design",
	"Copy the design first — a copy is what you change.": "Copy the design first — a copy is what you change.",
	"Copying the design…": "Copying the design…",
	Edit: "Edit",
	"Everything changed here goes back to what the file has.": "Everything changed here goes back to what the file has.",
	"It is kept, and these are drawn differently from the draft. Something in the project's own styles is winning.": "It is kept, and these are drawn differently from the draft. Something in the project's own styles is winning.",
	"It will be told about {0} and about the page beside this one.": "It will be told about {0} and about the page beside this one.",
	"It will be told which page is beside this one. Point at something first if you mean one thing on it.": "It will be told which page is beside this one. Point at something first if you mean one thing on it.",
	Left: "Left",
	"Move over the page beside this and press what you want to change.": "Move over the page beside this and press what you want to change.",
	"No project folder — open the site's folder in this window first.": "No project folder — open the site's folder in this window first.",
	"Nothing has been changed yet.": "Nothing has been changed yet.",
	"Nothing on this computer says which folder this page is served from, so nothing is written.": "Nothing on this computer says which folder this page is served from, so nothing is written.",
	"Nothing open beside this yet": "Nothing open beside this yet",
	"Nothing was saved.": "Nothing was saved.",
	"Nothing was written.": "Nothing was written.",
	"One moment.": "One moment.",
	"Only here / everywhere": "Only here / everywhere",
	"Open a site in the page beside this one first.": "Open a site in the page beside this one first.",
	"Opened localhost:{0}, the server running in this window's folder.": "Opened localhost:{0}, the server running in this window's folder.",
	"Point at something": "Point at something",
	"Press “Copy the design”. The copy opens beside this one, and the copy is what you change.": "Press “Copy the design”. The copy opens beside this one, and the copy is what you change.",
	"Put back all edits of the page": "Put back all edits of the page",
	Right: "Right",
	"Running on this computer:": "Running on this computer:",
	Save: "Save",
	"Save changes": "Save changes",
	"Save {0} changes": "Save {0} change | Save {0} changes",
	"Saved into {0}.": "Saved into {0}.",
	"Say what you want": "Say what you want",
	Send: "Send",
	"Show in Finder": "Show in Finder",
	"Take the teaching back": "Take the teaching back",
	"Taken back out of {0}.": "Taken back out of {0}.",
	"Teach the build": "Teach the build",
	Text: "Text",
	"The agent": "The agent",
	"The agent closed before it was asked. Ask again to start it once more.": "The agent closed before it was asked. Ask again to start it once more.",
	"The block beside this one is an ordinary page block: type any address into it — your own dev server, or any site in the world — and this will see it.": "The block beside this one is an ordinary page block: type any address into it — your own dev server, or any site in the world — and this will see it.",
	"The build is taught, but nothing on this page is written in its page files — it is put together in code — so there is nothing to mark. Copy the design to change it.": "The build is taught, but nothing on this page is written in its page files — it is put together in code — so there is nothing to mark. Copy the design to change it.",
	"The build is taught. The dev server starts again by itself; if this page still says nothing after a few seconds, stop it and start it again.": "The build is taught. The dev server starts again by itself; if this page still says nothing after a few seconds, stop it and start it again.",
	"The build was already taught.": "The build was already taught.",
	"The copy carries what you changed. Point at it to keep going.": "The copy carries what you changed. Point at it to keep going.",
	"The copy was not kept.": "The copy was not kept.",
	"The copy {0} could not be read.": "The copy {0} could not be read.",
	"The design could not be copied — {0}": "The design could not be copied — {0}",
	"The gradient or picture on top of it was taken off, so the colour shows.": "The gradient or picture on top of it was taken off, so the colour shows.",
	"The page came back drawing what the draft promised.": "The page came back drawing what the draft promised.",
	"The page changed, so the draft went with it.": "The page changed, so the draft went with it.",
	"The page is {0}.": "The page is {0}.",
	"The words of this element": "The words of this element",
	"There was nothing to take back.": "There was nothing to take back.",
	"These words are made by the site's code, so they cannot be written from here. Ask the agent to change them.": "These words are made by the site's code, so they cannot be written from here. Ask the agent to change them.",
	"This is a {0} project open in this window.": "This is a {0} project open in this window.",
	"This is a {0} project, and its build does not yet say where its elements come from. Everything here changes the page in front of you; keeping it needs that.": "This is a {0} project, and its build does not yet say where its elements come from. Everything here changes the page in front of you; keeping it needs that.",
	"This page comes from the web, not from a folder on this computer, so nothing is written anywhere. Copy the design to change it.": "This page comes from the web, not from a folder on this computer, so nothing is written anywhere. Copy the design to change it.",
	"This page does not say where its elements come from, so nothing can be written back. Copy the design and change the copy.": "This page does not say where its elements come from, so nothing can be written back. Copy the design and change the copy.",
	"This page is not a project open in this window, so changes live in the copy rather than in anybody's source.": "This page is not a project open in this window, so changes live in the copy rather than in anybody's source.",
	"This page is served from {0}, and this window works in {1}, so nothing is written there.": "This page is served from {0}, and this window works in {1}, so nothing is written there.",
	"This page says where each of its elements came from, so a change can be written back into its source.": "This page says where each of its elements came from, so a change can be written back into its source.",
	Undo: "Undo",
	"What the page did not do": "What the page did not do",
	"What you want": "What you want",
	"Written into {0} by the {1} build.": "Written into {0} by the {1} build.",
	"Written into {0}. This cannot be undone from the panel yet.": "Written into {0}. This cannot be undone from the panel yet.",
	"drawn in {0} places": "drawn in {0} places",
	"folder not known": "folder not known",
	"source not known": "source not known",
	"this window's folder": "this window's folder",
	"{0} is asking you something in its own block. Answer it there, and the rest comes back here by itself.": "{0} is asking you something in its own block. Answer it there, and the rest comes back here by itself.",
	"{0} is drawn as {1}, not {2} — something nearer the element wins.": "{0} is drawn as {1}, not {2} — something nearer the element wins.",
	"✓ Saved": "✓ Saved",
	"✓ Saved to {0} / {1}": "✓ Saved to {0} / {1}"
};
//#endregion
//#region plugins/design/words.ts
/** The table in force. Empty until one is loaded, and English is the keys. */
var words = {};
/** The language actually in use, for a check and for a fault report. */
var using = "en";
/**
* Take a dictionary the page fetched.
*
* Anything that is not a string is dropped rather than drawn: the file is on
* disk beside the plugin and a person may edit it, and a number where a
* sentence was would be drawn as "[object Object]" in a panel.
*/
function useWords(code, table) {
	using = code;
	words = {};
	if (!table || typeof table !== "object") return;
	for (const [key, value] of Object.entries(table)) if (typeof value === "string" && value !== "") words[key] = value;
}
/** One sentence, translated if there is a translation and English if not. */
function say(key) {
	return words[key] ?? key;
}
/**
* A sentence with something of the person's own in it.
*
* The holes are numbered rather than named, so a translator moves them where
* their own language needs them: "drawn in {0} places" is "{0} местах" with
* the number first in some languages and last in others.
*/
function saying(key, ...parts) {
	return say(key).replace(/\{(\d)\}/g, (whole, at) => {
		const part = parts[Number(at)];
		return part === void 0 ? whole : String(part);
	});
}
/** CLDR's plural categories, in the order a translator writes the forms. */
var CATEGORIES = [
	"zero",
	"one",
	"two",
	"few",
	"many",
	"other"
];
/**
* A sentence with a count in it, in the form the language wants for that
* count: "Save 1 change", "Save 3 changes"; in Russian «1 правку», «3 правки»,
* «5 правок» (UX review of 23 September 2026, item 9, FM-DESIGN-111).
*
* The forms are written in one line, apart by " | ", in the order of the
* categories the language has; a line with fewer forms than categories
* lends its last form to the rest, and a line with one form is that form for
* every count.
*/
function counted(key, n) {
	const forms = say(key).split(" | ");
	let which = 0;
	try {
		const rules = new Intl.PluralRules(using);
		const has = rules.resolvedOptions().pluralCategories;
		const order = CATEGORIES.filter((c) => has.includes(c));
		which = Math.min(order.indexOf(rules.select(n)), forms.length - 1);
	} catch {
		which = n === 1 ? 0 : forms.length - 1;
	}
	return forms[Math.max(0, which)].replace(/\{0\}/g, String(n));
}
/**
* Fetch the dictionary for a language, falling back to English.
*
* The page is served by the program on its own scheme, so this is an ordinary
* relative fetch — and a language we do not carry is not a failure: English is
* the keys, and the panel reads in English rather than not at all.
*/
async function loadWords(code, get = fetch) {
	const wanted = code.split(/[-_]/)[0] || "en";
	if (wanted !== "en") try {
		const answer = await get(`./words/${wanted}.json`);
		if (!answer.ok) throw new Error(String(answer.status));
		useWords(wanted, await answer.json());
		return;
	} catch {}
	useWords("en", en_default);
}
//#endregion
//#region plugins/design/view.ts
/**
* The name of a copied design, when that is what this address is.
*
* One shape and nothing near it: the program writes these addresses itself.
*/
var copyNamed = (address) => {
	if (!address) return null;
	const m = /^vobuda-design:\/\/[^/]*\/copy\/[^/]+\/([^/?#]+)$/.exec(address.trim());
	return m ? decodeURIComponent(m[1]) : null;
};
/**
* What the panel shows, given everything.
*
* The order of the questions is the order a person meets them, and the first
* one that is not yet answered is the one on the screen.
*/
function shown(state) {
	const changes = state.rules.length;
	const keep = keepStanding(state, changes);
	const where = whereSaying(state);
	const notes = [.../* @__PURE__ */ new Set([...changes === 0 ? state.kept ?? [] : [], ...state.notes])];
	const tools = toolsStanding(state);
	if (state.moved.length) return {
		where,
		tools,
		section: {
			kind: "moved",
			moved: state.moved
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	if (!state.address) return {
		where,
		tools,
		section: {
			kind: "waiting",
			servers: state.servers ?? []
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	if (state.mode === "ask") return {
		where,
		tools,
		section: {
			kind: "ask",
			address: state.address,
			picked: state.picked,
			sent: state.sent
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	if (state.mode === "look" || !(state.stamped || state.framework !== null)) return {
		where,
		tools,
		section: {
			kind: "look",
			address: copyNamed(state.address) ?? state.address,
			framework: state.framework,
			stamped: state.stamped,
			taught: !!state.taught,
			whose: state.whose ?? null
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	if (!state.stamped) notes.push(state.framework ? saying("This is a {0} project, and its build does not yet say where its elements come from. Everything here changes the page in front of you; keeping it needs that.", state.framework) : say("This page is not a project open in this window, so changes live in the copy rather than in anybody's source."));
	if (!state.picked) return {
		where,
		tools,
		section: { kind: "point" },
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	return {
		where,
		tools,
		section: {
			kind: "element",
			picked: state.picked,
			drawn: state.drawn,
			palette: state.palette,
			behind: state.behind,
			spectrum: spectrum(),
			canKeep: state.stamped && state.picked.origin !== null
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
}
/**
* What the three can do right now.
*
* A button that cannot be pressed says why on itself rather than going quiet:
* every round of this plugin that a person lost an evening to was a control
* that looked pressable and did nothing.
*/
function toolsStanding(state) {
	const noPage = say("Open a site in the page beside this one first.");
	if (!state.address) return {
		copy: {
			can: false,
			why: noPage
		},
		edit: {
			can: false,
			on: false,
			why: noPage
		},
		ask: {
			can: false,
			on: false,
			why: noPage
		}
	};
	const mine = state.stamped || state.framework !== null;
	const copyFirst = say("A site that is not yours is not edited. Copy the design and change the copy.");
	if (state.working) return {
		copy: {
			can: false,
			why: say("One moment.")
		},
		edit: {
			can: mine,
			on: mine && state.mode === "edit",
			why: mine ? void 0 : copyFirst
		},
		ask: {
			can: true,
			on: state.mode === "ask"
		}
	};
	return {
		copy: { can: true },
		edit: {
			can: mine,
			on: mine && state.mode === "edit",
			why: mine ? void 0 : copyFirst
		},
		ask: {
			can: true,
			on: state.mode === "ask"
		}
	};
}
function keepStanding(state, changes) {
	if (changes === 0) {
		if (state.savedAt) {
			const [folder, file] = state.savedAt.split("/").slice(-2);
			return {
				can: false,
				why: saying("✓ Saved to {0} / {1}", folder ?? "", file ?? ""),
				changes,
				saved: true,
				at: state.savedAt
			};
		}
		if (state.wrote?.length) return {
			can: false,
			why: saying("Written into {0}. This cannot be undone from the panel yet.", state.wrote.join(", ")),
			changes,
			saved: true
		};
		return {
			can: false,
			why: say("Nothing has been changed yet."),
			changes
		};
	}
	if (!copyNamed(state.address) && state.whose) return {
		can: false,
		why: state.whose,
		changes
	};
	if (!state.stamped) return {
		can: false,
		why: say("This page does not say where its elements come from, so nothing can be written back. Copy the design and change the copy."),
		changes
	};
	if (state.working) return {
		can: false,
		why: say("One moment."),
		changes
	};
	return {
		can: true,
		changes
	};
}
function whereSaying(state) {
	const copy = copyNamed(state.address);
	if (copy) return copy;
	if (state.address) return state.address.replace(/^https?:\/\//, "");
	if (state.framework) return state.framework;
	return "";
}
/**
* The properties offered with a minus and a plus, and what they are now.
*
* Two filters, and the second one was found by a check rather than by thinking.
* The element must actually have a value — a nudge on a property it does not
* use moves nothing. And the value must be one a step means something to: a
* colour has a value and cannot be stepped, so offering it two buttons is
* offering two buttons that do nothing, which is the very thing the first
* filter was written to prevent. Colours belong to the palette.
*/
function nudgesFor(drawn, offered) {
	return offered.filter((p) => (drawn[p] ?? "").trim() && drawn[p] !== "none" && drawn[p] !== "normal").filter((p) => canStep(p, drawn[p])).map((property) => ({
		property,
		value: drawn[property]
	}));
}
/** Whether a minus and a plus would move this value at all. */
function canStep(property, value) {
	if (property === "font-weight") return Number.isFinite(Number(value.trim()));
	return /^-?\d*\.?\d+(px|rem|em|%|vh|vw|pt)$/.test(value.trim());
}
//#endregion
//#region plugins/design/mechanical.ts
/** What a person can change without anybody thinking about it. */
var MECHANICAL = [
	"color",
	"background-color",
	"font-size",
	"font-weight",
	"line-height",
	"letter-spacing",
	"margin",
	"padding",
	"gap",
	"border-radius",
	"border-color",
	"border-width",
	"box-shadow",
	"text-align",
	"opacity"
];
var isMechanical = (property) => MECHANICAL.includes(property);
/**
* Read a length the page gave us.
*
* `getComputedStyle` answers in pixels for most things, but a person may have
* typed `1.5rem` and a draft may hold it. Anything that is not a length — a
* keyword, a colour, `auto` — comes back as nothing rather than as zero, since
* nudging `auto` by two is not a change, it is a mistake.
*/
function lengthOf(value) {
	const m = /^(-?\d*\.?\d+)(px|rem|em|%|vh|vw|pt)$/.exec(value.trim());
	if (!m) return null;
	const amount = Number(m[1]);
	return Number.isFinite(amount) ? {
		amount,
		unit: m[2]
	} : null;
}
var printLength = (l) => `${Number(l.amount.toFixed(3))}${l.unit}`;
/**
* Nudge a length by one step of whatever unit it is in.
*
* The step is the unit's own: a pixel for pixels, a tenth for rem and em, a
* whole one for per cent. A single step size in pixels would move `1rem` by a
* sixteenth of nothing and `100%` clean off the screen.
*/
function nudge$1(value, by, coarse = false) {
	const l = lengthOf(value);
	if (!l) return null;
	const step = l.unit === "rem" || l.unit === "em" ? .1 : 1;
	const times = coarse ? 10 : 1;
	return printLength({
		...l,
		amount: l.amount + by * step * times
	});
}
/** Font weights a person steps through, rather than every number CSS allows. */
var WEIGHTS = [
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900
];
function nextWeight(value, by) {
	const now = Number(value.trim());
	if (!Number.isFinite(now)) return null;
	const at = WEIGHTS.findIndex((w) => w >= now);
	const i = at === -1 ? WEIGHTS.length - 1 : at;
	const next = WEIGHTS[Math.min(WEIGHTS.length - 1, Math.max(0, i + by))];
	return next === now ? null : String(next);
}
/**
* What the draft should say, or nothing.
*
* Nothing means one of two things and both are fine: the property is not one a
* person may change without thinking, or the step would not move it. Neither is
* an error and neither reaches an agent — the menu simply does not offer what
* this cannot do.
*/
function ruleFor(asked) {
	if (!isMechanical(asked.property)) return null;
	let value;
	if (asked.to.kind === "set") value = asked.to.value.trim() || null;
	else if (asked.property === "font-weight") value = nextWeight(asked.from, asked.to.by);
	else value = nudge$1(asked.from, asked.to.by, asked.to.coarse);
	if (!value) return null;
	return {
		origin: asked.origin,
		at: asked.at,
		index: asked.index,
		property: asked.property,
		value,
		everywhere: asked.origin ? asked.everywhere : false
	};
}
//#endregion
//#region plugins/design/draw.ts
var el = (doc, tag, className, text) => {
	const node = doc.createElement(tag);
	if (className) node.className = className;
	if (text !== void 0) node.textContent = text;
	return node;
};
function button(doc, label, onPress, className = "", named = "") {
	const b = el(doc, "button", className, label);
	if (named) b.setAttribute("aria-label", named);
	b.addEventListener("click", onPress);
	return b;
}
/** Put the whole panel on the page. */
function draw(doc, shown, on) {
	const root = doc.getElementById("designer");
	const body = doc.getElementById("body");
	const foot = doc.getElementById("foot");
	const where = doc.getElementById("where");
	if (!root || !body || !foot || !where) return;
	root.classList.toggle("working", shown.working);
	where.textContent = shown.where;
	const had = doc.activeElement;
	const wasIn = had?.getAttribute("aria-label") ?? null;
	const caret = had instanceof HTMLTextAreaElement || had instanceof HTMLInputElement ? {
		from: had.selectionStart,
		to: had.selectionEnd
	} : null;
	body.replaceChildren();
	foot.replaceChildren();
	body.appendChild(toolbar(doc, shown, on));
	body.appendChild(sectionOf(doc, shown, on));
	if (shown.section.kind !== "ask") for (const note of shown.notes) body.appendChild(el(doc, "p", "note plain", note));
	if (shown.keep.saved) {
		const done = button(doc, say("✓ Saved"), on.keep, "keep saved", say("Save changes"));
		done.disabled = true;
		done.setAttribute("data-id", "design.save");
		if (shown.keep.why) done.title = shown.keep.why;
		foot.appendChild(done);
		if (shown.keep.at && on.reveal) {
			const at = shown.keep.at;
			const show = button(doc, say("Show in Finder"), () => on.reveal?.(at), "reveal");
			show.setAttribute("data-id", "design.reveal");
			foot.appendChild(show);
		}
		if (shown.keep.why) foot.appendChild(el(doc, "span", "said saved", ` ${shown.keep.why}`));
	} else {
		const keep = button(doc, shown.keep.changes ? counted("Save {0} changes", shown.keep.changes) : say("Save"), on.keep, shown.keep.changes ? "keep primary" : "keep", say("Save changes"));
		keep.setAttribute("data-id", "design.save");
		keep.disabled = !shown.keep.can;
		if (shown.keep.why) keep.title = shown.keep.why;
		foot.appendChild(keep);
		if (shown.keep.changes) {
			const back = button(doc, say("Put back all edits of the page"), on.revert, "back", say("Put back all edits of the page"));
			back.setAttribute("data-id", "design.revert");
			back.title = say("Everything changed here goes back to what the file has.");
			foot.appendChild(back);
		}
		if (shown.keep.why) foot.appendChild(el(doc, "span", "said", ` ${shown.keep.why}`));
	}
	if (!shown.keep.saved) foot.appendChild(where);
	if (wasIn) {
		const again = root.querySelector(`[aria-label="${wasIn.replace(/["\\]/g, "\\$&")}"]`);
		if (again && again !== doc.activeElement) {
			again.focus();
			if (caret && (again instanceof HTMLTextAreaElement || again instanceof HTMLInputElement)) try {
				again.setSelectionRange(caret.from, caret.to);
			} catch {}
		}
	}
}
/**
* The three the whole tool is: copy the design, change it, ask the agent.
*
* Always drawn and always in the same order, whatever is happening below them.
* A toolbar that appears and disappears is a toolbar people learn twice, and
* each of the three is a whole way of working rather than a step of one.
*/
function toolbar(doc, shown, on) {
	const row = el(doc, "div", "tools");
	const one = (label, what, press, id) => {
		const b = button(doc, label, press, what.on ? "tool on" : "tool");
		b.setAttribute("data-id", id);
		b.disabled = !what.can;
		if (what.why) b.title = what.why;
		if (what.on) b.setAttribute("aria-pressed", "true");
		row.appendChild(b);
	};
	one(say("Copy the design"), shown.tools.copy, on.copy, "design.copy");
	one(say("Edit"), shown.tools.edit, on.edit, "design.edit");
	one(say("Ask the agent"), shown.tools.ask, on.talk, "design.ask");
	const whys = [
		shown.tools.copy,
		shown.tools.edit,
		shown.tools.ask
	].filter((w) => !w.can && w.why).map((w) => w.why);
	if (whys.length) row.appendChild(el(doc, "span", "said why", [...new Set(whys)].join(" ")));
	return row;
}
function sectionOf(doc, shown, on) {
	const card = el(doc, "section", "card");
	const s = shown.section;
	if (s.kind === "waiting") {
		card.appendChild(el(doc, "h2", void 0, say("Nothing open beside this yet")));
		if (s.servers.length) {
			card.appendChild(el(doc, "p", "said", say("Running on this computer:")));
			const row = el(doc, "div", "servers");
			for (const one of s.servers) {
				const where = one.mine ? say("this window's folder") : one.folder ? `…/${one.folder.split("/").slice(-2).join("/")}` : say("folder not known");
				row.appendChild(button(doc, `localhost:${one.port} · ${where}`, () => on.server(one.port), one.mine ? "mine" : "", `localhost:${one.port}`));
			}
			card.appendChild(row);
		}
		card.appendChild(el(doc, "p", "said", say("The block beside this one is an ordinary page block: type any address into it — your own dev server, or any site in the world — and this will see it.")));
		return card;
	}
	if (s.kind === "look") {
		card.appendChild(el(doc, "h2", void 0, s.address.replace(/^https?:\/\//, "")));
		card.appendChild(el(doc, "p", "said", s.stamped ? say("This page says where each of its elements came from, so a change can be written back into its source.") : say("Press “Copy the design”. The copy opens beside this one, and the copy is what you change.")));
		if (s.whose) card.appendChild(el(doc, "p", "said", s.whose));
		if (s.framework && !s.stamped && !s.taught) {
			card.appendChild(el(doc, "p", "said", saying("This is a {0} project open in this window.", s.framework)));
			const row = el(doc, "div", "row");
			row.appendChild(button(doc, say("Teach the build"), on.teach));
			card.appendChild(row);
		} else if (s.framework && s.taught) {
			if (!s.stamped) card.appendChild(el(doc, "p", "said", say("The build is taught. The dev server starts again by itself; if this page still says nothing after a few seconds, stop it and start it again.")));
			const row = el(doc, "div", "row");
			row.appendChild(button(doc, say("Take the teaching back"), on.untaught));
			card.appendChild(row);
		}
		return card;
	}
	if (s.kind === "ask") {
		card.appendChild(el(doc, "h2", void 0, say("Ask the agent")));
		card.appendChild(el(doc, "p", "said", s.picked ? saying("It will be told about {0} and about the page beside this one.", s.picked.what) : say("It will be told which page is beside this one. Point at something first if you mean one thing on it.")));
		for (const one of s.sent) card.appendChild(el(doc, "p", one.mine ? "note plain mine" : "note plain theirs", one.text));
		for (const note of shown.notes) card.appendChild(el(doc, "p", "note plain status", note));
		const said = el(doc, "textarea");
		said.placeholder = say("Say what you want");
		said.setAttribute("aria-label", say("What you want"));
		const send = () => {
			on.ask(said.value);
			said.value = "";
		};
		said.addEventListener("keydown", (e) => {
			const k = e;
			if (k.key === "Enter" && (k.metaKey || k.ctrlKey)) {
				e.preventDefault();
				send();
			}
		});
		card.appendChild(said);
		const row = el(doc, "div", "row");
		row.appendChild(button(doc, say("Send"), send, "asks"));
		card.appendChild(row);
		return card;
	}
	if (s.kind === "point") {
		card.appendChild(el(doc, "h2", void 0, say("Point at something")));
		card.appendChild(el(doc, "p", "said", say("Move over the page beside this and press what you want to change.")));
		return card;
	}
	if (s.kind === "moved") {
		card.appendChild(el(doc, "h2", void 0, say("What the page did not do")));
		card.appendChild(el(doc, "p", "said", say("It is kept, and these are drawn differently from the draft. Something in the project's own styles is winning.")));
		for (const m of s.moved) card.appendChild(el(doc, "p", "note warn", `${m.rule.origin ? `${m.rule.origin.file}:${m.rule.origin.line}` : m.rule.at} — ${m.rule.property} is ${m.given}, not ${m.promised}`));
		return card;
	}
	const chosen = el(doc, "div", "chosen");
	const runs = s.picked.words ?? [];
	if (runs.length) runs.forEach((run, i) => {
		const field = doc.createElement("textarea");
		field.className = "said";
		field.value = run.text;
		field.rows = 2;
		field.setAttribute("aria-label", runs.length > 1 ? `${say("The words of this element")} ${i + 1}` : say("The words of this element"));
		if (runs.length > 1) chosen.appendChild(el(doc, "span", "run-what", run.what));
		if (run.code) {
			field.readOnly = true;
			field.classList.add("code");
			chosen.appendChild(field);
			if (runs.findIndex((r) => r.code) === i) chosen.appendChild(el(doc, "span", "code-words", say("These words are made by the site's code, so they cannot be written from here. Ask the agent to change them.")));
			field.addEventListener("focus", () => on.hand(i));
			return;
		}
		field.addEventListener("input", () => on.word(field.value, i));
		field.addEventListener("focus", () => on.hand(i));
		if (runs.length > 1 && i === shown.hand) field.classList.add("in-hand");
		chosen.appendChild(field);
	});
	else chosen.appendChild(el(doc, "span", "what", s.picked.what));
	chosen.appendChild(el(doc, "span", "from", s.picked.origin ? `${s.picked.what} · ${s.picked.origin.file}:${s.picked.origin.line}` : `${s.picked.what} · ${say("source not known")}`));
	if (s.picked.siblings > 1) chosen.appendChild(el(doc, "span", "drawn", saying("drawn in {0} places", s.picked.siblings)));
	card.appendChild(chosen);
	const offered = nudgesFor(s.drawn, MECHANICAL);
	if (offered.length) {
		const nudges = el(doc, "div", "nudges");
		for (const { property, value } of offered) {
			nudges.appendChild(el(doc, "span", "name", property));
			const shownValue = el(doc, "span", "value", value);
			nudges.appendChild(shownValue);
			const row = el(doc, "span", "row");
			row.appendChild(button(doc, "−", () => on.nudge(property, -1), "", `${property} −`));
			row.appendChild(button(doc, "+", () => on.nudge(property, 1), "", `${property} +`));
			nudges.appendChild(row);
		}
		card.appendChild(nudges);
	}
	const aligned = el(doc, "div", "aligns");
	aligned.appendChild(el(doc, "span", "name", say("Alignment")));
	const alignRow = el(doc, "span", "row");
	const alignments = [
		["left", say("Left")],
		["center", say("Centre")],
		["right", say("Right")]
	];
	for (const [value, label] of alignments) {
		const b = button(doc, label, () => on.align(value), "", `align ${value}`);
		if (s.drawn["text-align"] === value) b.setAttribute("aria-pressed", "true");
		alignRow.appendChild(b);
	}
	aligned.appendChild(alignRow);
	card.appendChild(aligned);
	const paint = (target, label, mine) => {
		const rest = s.spectrum.filter((c) => !mine.includes(c));
		if (!mine.length && !rest.length) return;
		const band = el(doc, "div", "paint");
		band.appendChild(el(doc, "span", "name", label));
		const swatches = el(doc, "div", "swatches");
		const swatch = (colour) => {
			const b = button(doc, "", () => on.colour(colour, target), "swatch", `colour ${target === "color" ? "text" : "background"} ${colour}`);
			b.style.background = colour;
			b.title = colour;
			if (colour === (target === "color" && runs.length ? runs[Math.min(shown.hand, runs.length - 1)].colour : s.drawn[target])) b.setAttribute("aria-current", "true");
			swatches.appendChild(b);
		};
		for (const colour of mine) swatch(colour);
		if (mine.length && rest.length) swatches.appendChild(el(doc, "span", "seam"));
		for (const colour of rest) swatch(colour);
		band.appendChild(swatches);
		card.appendChild(band);
	};
	paint("color", say("Text"), s.palette);
	paint("background-color", say("Background"), s.behind);
	const row = el(doc, "div", "row");
	row.appendChild(button(doc, say("Undo"), on.undo));
	if (s.picked.siblings > 1 && s.canKeep) row.appendChild(button(doc, say("Only here / everywhere"), on.scope));
	card.appendChild(row);
	if (!s.canKeep) card.appendChild(el(doc, "p", "said", say("Changes here are on the page in front of you. Copy the design to keep them.")));
	return card;
}
/**
* The same card the window lays over the agent's block, drawn in the panel.
*
* The panel used to repeat the agent's raw lines — "Enter to confirm · Esc to
* cancel", "↓ 2. Yes, allow reading from /private/tmp/…" — under a sentence
* telling the person to answer somewhere else (UX review of 23 September
* 2026, item 2). The words come from the window, already in its language; a
* press goes back to the window, which sends the agent the keys a hand would
* (FM-AGENT-88).
*/
function questionCard(doc, card, answer) {
	const box = el(doc, "section", "card agent-question");
	box.appendChild(el(doc, "h2", void 0, card.heading));
	if (card.note) box.appendChild(el(doc, "p", card.trust ? "said" : "said mono", card.note));
	const row = el(doc, "div", "row");
	const one = (label, choice, id, className) => {
		const b = button(doc, label, () => answer(choice), className);
		b.setAttribute("data-id", id);
		row.appendChild(b);
	};
	one(card.yes, "yes", card.trust ? "trust.yes" : "permission.once", "primary");
	one(card.no, "no", card.trust ? "trust.no" : "permission.no", "");
	if (card.always) one(card.always, "always", "permission.always", "quiet");
	box.appendChild(row);
	return box;
}
//#endregion
//#region plugins/design/frameworks/boundary.ts
/**
* The frameworks this designer knows, in the order they are tried.
*
* A list rather than a lookup by name: the project is asked what it is, never
* the person. Registered here and nowhere else, so that the answer to "which
* frameworks does this work with" is one file to read.
*/
var KNOWN = [];
function register(framework) {
	if (KNOWN.some((f) => f.name === framework.name)) return;
	KNOWN.push(framework);
}
var known = () => KNOWN;
/**
* Which of a given set this project is, or none.
*
* Takes the set rather than reading the register, so that the decision can be
* driven by a check with exactly the frameworks the check means. A decision
* that can only be asked through a module-level list is a decision whose checks
* pollute each other, and the assertions go vacuous without anybody noticing.
*/
async function pick(frameworks, files) {
	for (const f of frameworks) if (await f.looksLikeMine(files)) return f;
	return null;
}
//#endregion
//#region plugins/design/page/draft.ts
/** The key one rule is remembered by: one property of one place. */
var keyOf = (r) => r.origin ? `${r.origin.file}:${r.origin.line}:${r.origin.column}:${r.index}:${r.everywhere}:${r.property}` : `at:${r.at}:${r.property}`;
/**
* The last word on each property of each place.
*
* A person changes a colour, changes their mind, changes it again: three
* changes and one decision. A stack that grows with every nudge is a stack that
* hands a hundred edits to whatever reads it next.
*/
function settle(rules) {
	const last = /* @__PURE__ */ new Map();
	for (const r of rules) last.set(keyOf(r), r);
	return [...last.values()];
}
/** The stylesheet, as one string. */
/** The property name a change of the words goes under. */
var WORDS = "#text";
//#endregion
//#region plugins/design/keep.ts
/** Every rule as a change a writer understands, newest word on each place. */
function changesOf(rules) {
	const out = [];
	for (const r of settle(rules)) {
		if (!r.origin) continue;
		out.push({
			origin: r.origin,
			property: r.property,
			value: r.value,
			everywhere: r.everywhere,
			part: r.part
		});
	}
	return out;
}
/**
* Put the draft into the project's own files.
*
* Nothing is written when nothing can be: a folder no framework here claims is
* a refusal with a reason, not a silent no-op.
*/
async function keepInto(files, rules, frameworks = known()) {
	const changes = changesOf(rules);
	if (changes.length === 0) return {
		files: [],
		refused: [],
		framework: null
	};
	const framework = await pick(frameworks, files);
	if (!framework) return {
		files: [],
		framework: null,
		refused: changes.map((c) => ({
			where: `${c.origin.file}:${c.origin.line}`,
			why: "no build here that this knows how to write to"
		}))
	};
	const written = await framework.write(files, changes);
	return {
		files: written.files,
		framework: framework.name,
		refused: written.refused.map((r) => ({
			where: `${r.origin.file}:${r.origin.line}`,
			why: r.why
		}))
	};
}
/**
* Teach this project's build to stamp its elements.
*
* The same road as keeping and for the same reason: a person's own config is
* edited, through the framework that owns its shape, through the one door the
* window granted. It used to be a message sent into the page being designed —
* which has no such case, so it fell through to "stop" and the button killed
* the designer instead of teaching anything (FM-DESIGN-24).
*/
async function teachIn(files, frameworks = known()) {
	const framework = await pick(frameworks, files);
	if (!framework) return {
		files: [],
		framework: null,
		why: "no build here that this knows how to teach"
	};
	try {
		const { files: changed } = await framework.stamp(files);
		return {
			files: changed,
			framework: framework.name,
			why: null
		};
	} catch (e) {
		return {
			files: [],
			framework: framework.name,
			why: String(e instanceof Error ? e.message : e)
		};
	}
}
/**
* Take the teaching back: what "Teach the build" wrote comes out, exactly.
*
* There because teaching once had no way back at all: the dev server did not
* start, and the panel had nothing to offer but the sentence that had caused it
* (FM-DESIGN-88).
*/
async function untaughtIn(files, frameworks = known()) {
	const framework = await pick(frameworks, files);
	if (!framework) return {
		files: [],
		framework: null,
		why: "no build here that this knows how to teach"
	};
	try {
		const { files: changed } = await framework.unstamp(files);
		return {
			files: changed,
			framework: framework.name,
			why: null
		};
	} catch (e) {
		return {
			files: [],
			framework: framework.name,
			why: String(e instanceof Error ? e.message : e)
		};
	}
}
/** Whether this project's build carries the stamper, asked of its own files. */
async function isTaught(files, frameworks = known()) {
	const framework = await pick(frameworks, files);
	return framework ? framework.isStamped(files) : false;
}
/**
* What build this project uses, or nothing.
*
* Asked of the project's own files, never of the person: somebody opening a
* folder should not have to know what their build is called. The answer drives
* the first screen, and with nobody asking the question the panel spent a live
* evening saying it did not know what this folder was (FM-DESIGN-26).
*/
async function whatProjectIsThis(files, frameworks = known()) {
	const framework = await pick(frameworks, files);
	return framework ? framework.name : null;
}
//#endregion
//#region plugins/design/frameworks/astroStamp.ts
/** The file the stamper lives in, beside the config. */
var STAMPER_FILE = "vobuda-stamp.mjs";
/** How the config names it. */
var STAMPER_NAME = "vobudaStamp";
/** The line that brings it into the config. */
var STAMPER_IMPORT = `import ${STAMPER_NAME} from "./${STAMPER_FILE}";\n`;
var STAMPER_SOURCE = `// Written by the vobuda designer ("Teach the build"). While \`astro dev\`
// runs, every element of every .astro file here is served marked with where it
// is written — file, line, column — so a change made with the mouse on the page
// can be put back into that place. \`astro build\` is left exactly as it was.
//
// To take it out: "Take the teaching back" in the designer, or delete this file
// and the two lines naming ${STAMPER_NAME} in astro.config.
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { join, relative, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

/** Elements that are not drawn, or that Astro treats specially when marked. */
const SKIP = new Set([
  "html", "head", "meta", "link", "title", "base", "script", "style",
  "slot", "template", "noscript",
]);

/** Where each line starts, so an offset becomes a line and a column. */
function lineStarts(source) {
  const starts = [0];
  for (let i = 0; i < source.length; i++) if (source[i] === "\\n") starts.push(i + 1);
  return starts;
}

function lineAndColumn(starts, offset) {
  let lo = 0;
  let hi = starts.length - 1;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (starts[mid] <= offset) lo = mid;
    else hi = mid - 1;
  }
  return { line: lo + 1, column: offset - starts[lo] + 1 };
}

const escape = (s) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;");

/**
 * The source with every element marked, or the source as it was.
 *
 * Only elements the compiler found where it says they are: an offset that does
 * not land on "<name" is left alone rather than trusted.
 */
export function stampSource(parse, source, file) {
  const { ast } = parse(source);
  const at = [];
  const walk = (node) => {
    if (!node || typeof node !== "object") return;
    if (Array.isArray(node)) {
      for (const n of node) walk(n);
      return;
    }
    if (node.type === "JSXElement" && node.openingElement) {
      const open = node.openingElement;
      const name = open.name;
      if (
        name &&
        name.type === "JSXIdentifier" &&
        /^[a-z][a-z0-9-]*$/.test(name.name) &&
        !SKIP.has(name.name) &&
        source[open.start] === "<" &&
        source.startsWith(name.name, open.start + 1) &&
        name.end === open.start + 1 + name.name.length
      ) {
        // Words the source does not hold as words: set:html, set:text, or an
        // expression among the children. Said on the element, so the designer
        // can say before the edit that such words cannot be written back —
        // the heading of rem-plastic took its text from code, and a changed
        // text was dropped at save without a word (run-in two, FM-DESIGN-99).
        const code =
          (open.attributes || []).some(
            (a) => a && a.name && (a.name.name === "set:html" || a.name.name === "set:text"),
          ) || (node.children || []).some((c) => c && c.type === "JSXExpressionContainer");
        at.push({ start: open.start, after: name.end, code });
      }
    }
    for (const key of Object.keys(node)) {
      if (key !== "frontmatter") walk(node[key]);
    }
  };
  walk(ast.body ?? ast);
  if (!at.length) return source;
  const starts = lineStarts(source);
  const where = escape(file);
  let out = source;
  for (const one of at.sort((a, b) => b.after - a.after)) {
    const { line, column } = lineAndColumn(starts, one.start);
    const mark =
      \` data-vobuda-file="\${where}" data-vobuda-line="\${line}" data-vobuda-column="\${column}"\` +
      (one.code ? ' data-vobuda-words="code"' : "");
    out = out.slice(0, one.after) + mark + out.slice(one.after);
  }
  return out;
}

/** The project's own Astro compiler, found the way Astro itself finds it. */
async function compilerOf(root) {
  const tries = [
    () => import("@astrojs/compiler-rs"),
    async () => {
      const require = createRequire(join(root, "node_modules", "astro", "package.json"));
      return import(pathToFileURL(require.resolve("@astrojs/compiler-rs")).href);
    },
  ];
  for (const t of tries) {
    try {
      const mod = await t();
      if (typeof mod.parse === "function") return mod.parse;
    } catch {
      // the next way
    }
  }
  return null;
}

export default function ${STAMPER_NAME}() {
  return {
    name: "vobuda-stamp",
    hooks: {
      "astro:config:setup": async ({ command, config, updateConfig, logger }) => {
        if (command !== "dev") return;
        const root = fileURLToPath(config.root);
        const parse = await compilerOf(root);
        if (!parse) {
          logger.warn("this Astro has no @astrojs/compiler-rs, so elements are not marked for the vobuda designer");
          return;
        }
        updateConfig({
          vite: {
            plugins: [
              {
                name: "vobuda-stamp",
                // Before Astro's own compile: marking is done on the source.
                enforce: "pre",
                async load(id) {
                  if (id.includes("?") || !id.endsWith(".astro") || id.includes("/node_modules/")) return null;
                  const file = relative(root, id);
                  if (file.startsWith("..")) return null;
                  const source = await readFile(id, "utf8");
                  try {
                    return stampSource(parse, source, file.split(sep).join("/"));
                  } catch (e) {
                    logger.warn(\`\${file} was not marked: \${e && e.message ? e.message : e}\`);
                    return null;
                  }
                },
              },
            ],
          },
        });
      },
    },
  };
}
`;
//#endregion
//#region plugins/design/frameworks/tag.ts
/** The index in `text` of a line and column, or -1. */
function indexAt(text, at) {
	if (at.line < 1 || at.column < 1) return -1;
	let i = 0;
	for (let line = 1; line < at.line; line++) {
		const nl = text.indexOf("\n", i);
		if (nl === -1) return -1;
		i = nl + 1;
	}
	const lineEnd = text.indexOf("\n", i);
	const end = lineEnd === -1 ? text.length : lineEnd;
	const want = i + at.column - 1;
	return want <= end ? want : -1;
}
/**
* The start tag beginning at a place, read to its real end.
*
* Quotes are honoured because `<a title="a > b">` is one tag and stopping at
* the first `>` makes it two. Nothing else about the markup is parsed: this is
* one tag, at one address, and the rest of the file is not its business.
*/
function tagAt(text, at) {
	const from = indexAt(text, at);
	if (from < 0 || text[from] !== "<") return null;
	let quote = null;
	for (let i = from + 1; i < text.length; i++) {
		const c = text[i];
		if (quote) {
			if (c === quote) quote = null;
			continue;
		}
		if (c === "\"" || c === "'") {
			quote = c;
			continue;
		}
		if (c === ">") return {
			text: text.slice(from, i + 1),
			from,
			to: i + 1
		};
	}
	return null;
}
/** Read an attribute by name out of a start tag. */
function attrIn(tag, name) {
	const re = new RegExp(`(^|[\\s])(${name})(\\s*=\\s*)?`, "gi");
	let m;
	while (m = re.exec(tag)) {
		const nameFrom = m.index + m[1].length;
		if (!isOutsideQuotes(tag, nameFrom)) continue;
		if (!m[3]) return {
			name: m[2],
			value: "",
			from: nameFrom,
			to: nameFrom + m[2].length,
			bare: true
		};
		let i = m.index + m[0].length;
		const q = tag[i];
		if (q === "\"" || q === "'") {
			const end = tag.indexOf(q, i + 1);
			if (end === -1) return null;
			return {
				name: m[2],
				value: tag.slice(i + 1, end),
				from: nameFrom,
				to: end + 1,
				bare: false
			};
		}
		let end = i;
		while (end < tag.length && !/[\s/>]/.test(tag[end])) end++;
		return {
			name: m[2],
			value: tag.slice(i, end),
			from: nameFrom,
			to: end,
			bare: false
		};
	}
	return null;
}
function isOutsideQuotes(tag, index) {
	let quote = null;
	for (let i = 0; i < index; i++) {
		const c = tag[i];
		if (quote) {
			if (c === quote) quote = null;
		} else if (c === "\"" || c === "'") quote = c;
	}
	return quote === null;
}
/** Declarations of a `style` attribute, in the order they were written. */
function readStyle(value) {
	const out = [];
	for (const part of value.split(";")) {
		const at = part.indexOf(":");
		if (at === -1) continue;
		const name = part.slice(0, at).trim();
		const v = part.slice(at + 1).trim();
		if (name && v) out.push([name, v]);
	}
	return out;
}
var printStyle = (decls) => decls.map(([k, v]) => `${k}: ${v}`).join("; ");
/**
* The same tag with one declaration set on its `style` attribute.
*
* The person's own order is kept and their own declarations are kept: a
* property they already set is replaced where it stood, and a new one is
* added at the end. Rewriting somebody's attribute into our own ordering is
* the kind of diff that makes a person stop trusting a tool.
*/
function withStyle(tag, property, value) {
	const attr = attrIn(tag, "style");
	if (!attr || attr.bare) {
		const tail = /(\s*\/?>)$/.exec(tag)?.[1] ?? ">";
		return `${tag.slice(0, tag.length - tail.length)} style="${property}: ${value}"${tail}`;
	}
	const decls = readStyle(attr.value);
	const at = decls.findIndex(([k]) => k.toLowerCase() === property.toLowerCase());
	if (at === -1) decls.push([property, value]);
	else decls[at] = [property, value];
	const quote = tag[attr.to - 1] === "'" ? "'" : "\"";
	const head = tag.slice(0, attr.from);
	const tail = tag.slice(attr.to);
	return `${head}style=${quote}${printStyle(decls)}${quote}${tail}`;
}
/**
* What a tag holds, from just past its `>` to the `<` of its own close.
*
* Counted, not guessed: a `<div>` inside a `<div>` closes first, and a writer
* that took the first `</div>` would cut the element in half. Self-closing
* tags and void elements hold nothing and say so.
*
* This is how the words of an element are found in a file — the one thing a
* stamp points at that is not an attribute (FM-DESIGN-55).
*/
function insideOf(text, tag) {
	const name = /^<\s*([a-zA-Z][-\w]*)/.exec(tag.text)?.[1];
	if (!name) return null;
	if (/\/\s*>$/.test(tag.text)) return null;
	const open = new RegExp(`<\\s*${name}(?=[\\s/>])`, "gi");
	const close = new RegExp(`<\\s*/\\s*${name}\\s*>`, "gi");
	let depth = 1;
	let at = tag.to;
	while (at < text.length) {
		open.lastIndex = at;
		close.lastIndex = at;
		const nextOpen = open.exec(text);
		const nextClose = close.exec(text);
		if (!nextClose) return null;
		if (nextOpen && nextOpen.index < nextClose.index) {
			depth += 1;
			at = nextOpen.index + nextOpen[0].length;
			continue;
		}
		depth -= 1;
		if (depth === 0) return {
			from: tag.to,
			to: nextClose.index
		};
		at = nextClose.index + nextClose[0].length;
	}
	return null;
}
//#endregion
//#region plugins/design/frameworks/write.ts
/**
* Where the nth piece of text sits inside an element's own content.
*
* Its own: text belonging to a nested tag belongs to that tag and is written
* against it. So the depth is counted and only what is written at depth zero
* is a run of this element — which is what makes it safe to replace one
* without touching what is around it (FM-DESIGN-62).
*/
function runAt(inside, want) {
	let depth = 0;
	let seen = -1;
	let from = 0;
	let i = 0;
	const runs = [];
	while (i < inside.length) {
		const open = inside.indexOf("<", i);
		if (open === -1) {
			if (depth === 0) runs.push({
				from,
				to: inside.length
			});
			break;
		}
		if (depth === 0) runs.push({
			from,
			to: open
		});
		const close = inside.indexOf(">", open);
		if (close === -1) break;
		const tag = inside.slice(open, close + 1);
		if (/^<\//.test(tag)) depth = Math.max(0, depth - 1);
		else if (!/\/>$/.test(tag) && !/^<(br|img|input|hr|meta|link)\b/i.test(tag)) depth += 1;
		i = close + 1;
		from = i;
	}
	for (const run of runs) {
		if (!inside.slice(run.from, run.to).trim()) continue;
		seen += 1;
		if (seen === want) return run;
	}
	return null;
}
/**
* Changes gathered by file, each file's in the order a writer must apply them.
*
* Last line first. Editing a file from the top moves every line below the edit,
* so the second change of a file would land at a line that no longer means what
* it meant when the person pointed at it — the same fault as search-and-replace,
* arriving by arithmetic instead of by luck.
*/
function byFile(changes) {
	const out = /* @__PURE__ */ new Map();
	for (const c of changes) {
		const at = out.get(c.origin.file) ?? [];
		at.push(c);
		out.set(c.origin.file, at);
	}
	for (const [file, list] of out) out.set(file, [...list].sort((a, b) => b.origin.line !== a.origin.line ? b.origin.line - a.origin.line : b.origin.column - a.origin.column));
	return out;
}
/**
* The last word on one property of one element.
*
* A person changes a colour, changes their mind, changes it again: three
* changes to one property of one element, and only the last is a change at all.
* Bolt learnt this in public — a stack that grows with every nudge is a stack
* that sends the model a hundred edits for one decision.
*/
function settled(changes) {
	const last = /* @__PURE__ */ new Map();
	for (const c of changes) last.set(`${c.origin.file}:${c.origin.line}:${c.origin.column}:${c.property}`, c);
	return [...last.values()];
}
/** A refusal a person can act on, rather than a stack trace. */
var cannot = (origin, why) => ({
	origin,
	why
});
/**
* What one file becomes, given the changes addressed to it.
*
* A pure function over text so a check can drive it with a file it wrote
* itself. Nothing here reads a disk, and the order is the one `byFile` decided:
* last line first, so an edit never moves the line a later change is addressed
* to.
*/
/** The words as a file may hold them: nothing that could start a tag. */
function escapeWords(text) {
	return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function fileAfter(text, changes) {
	const refused = [];
	let out = text;
	for (const c of changes) {
		if (c.value === null) {
			refused.push(cannot(c.origin, "taking a declaration away is not built yet"));
			continue;
		}
		if (!c.everywhere) {
			refused.push(cannot(c.origin, "this is drawn in more than one place and the change was meant for one of them — give that one a class of its own in the source, or choose “everywhere this appears”"));
			continue;
		}
		const tag = tagAt(out, {
			line: c.origin.line,
			column: c.origin.column
		});
		if (!tag) {
			refused.push(cannot(c.origin, "no tag begins there any more — the file has moved on since this was drawn"));
			continue;
		}
		if (c.property === "#text") {
			const inside = insideOf(out, tag);
			if (!inside) {
				refused.push(cannot(c.origin, /\bset:(html|text)\b/.test(tag.text) ? "these words are made by the site's code, so they were not written" : "this element holds nothing that can be written as words"));
				continue;
			}
			const kept = out.slice(inside.from, inside.to);
			const run = runAt(kept, c.part ?? 0);
			if (!run) {
				refused.push(cannot(c.origin, "the words that were changed are no longer in this element"));
				continue;
			}
			const piece = kept.slice(run.from, run.to);
			if (/[{}]/.test(piece)) {
				refused.push(cannot(c.origin, "these words are made by the site's code, so they were not written"));
				continue;
			}
			const pad = /^(\s*)/.exec(piece)?.[1] ?? "";
			const tail = /(\s*)$/.exec(piece)?.[1] ?? "";
			out = out.slice(0, inside.from + run.from) + pad + escapeWords(c.value) + tail + out.slice(inside.from + run.to);
			continue;
		}
		out = out.slice(0, tag.from) + withStyle(tag.text, c.property, c.value) + out.slice(tag.to);
	}
	return {
		text: out,
		refused
	};
}
/**
* Apply changes to a project's source.
*
* The reading and the writing are the caller's — a plugin is handed the one
* door the window granted it, not a filesystem — so this takes them. That also
* makes the whole of "keep it" drivable by a check with no disk at all. Every
* path is relative to the project's root, which the door already is.
*/
async function writeInto(changes, io) {
	const files = [];
	const refused = [];
	for (const [file, forFile] of byFile(settled(changes))) {
		const before = await io.read(file);
		if (before === null) {
			for (const c of forFile) refused.push(cannot(c.origin, `${file} could not be read`));
			continue;
		}
		const { text, refused: no } = fileAfter(before, forFile);
		refused.push(...no);
		if (text !== before) {
			await io.write(file, text);
			files.push(file);
		}
	}
	return {
		files,
		refused
	};
}
//#endregion
//#region plugins/design/frameworks/astro.ts
/** The config Astro is configured by, whichever spelling this project chose. */
var CONFIGS$1 = [
	"astro.config.mjs",
	"astro.config.ts",
	"astro.config.js",
	"astro.config.mts"
];
/** What goes into an `integrations` list that is already there. */
var ENTRY = `${STAMPER_NAME}(), `;
/** What goes into a config that has no `integrations` list at all. */
var LIST = `\n  integrations: [${STAMPER_NAME}()],`;
async function configOf$1(files) {
	const here = await files.list(".");
	return CONFIGS$1.find((c) => here.includes(c)) ?? null;
}
/**
* Whether this is an Astro project.
*
* Asked of the config file rather than of `package.json`: a dependency can sit
* in a repository that holds three projects, and the config is where a project
* actually is. A monorepo whose root has no config is not an Astro project even
* though it lists astro — which is the right answer, because there is nothing
* at the root to point at.
*/
async function looksLikeMine$1(files) {
	return await configOf$1(files) !== null;
}
/** Whether the build already writes origins into its elements. */
async function isStamped$1(files) {
	const config = await configOf$1(files);
	if (!config) return false;
	return (await files.read(config) ?? "").includes(STAMPER_IMPORT) && await files.read("vobuda-stamp.mjs") !== null;
}
/** Where the import goes: before the first import, so `// @ts-check` stays first. */
function importAt(text) {
	const first = /^import\s/m.exec(text);
	if (first) return first.index;
	const exported = /^export\s+default\b/m.exec(text);
	return exported ? exported.index : 0;
}
/**
* Teach this project's build to stamp, and say what was changed.
*
* The person's own config is edited, so the rules are the ones this program
* follows everywhere it touches somebody's file: never twice, never silently,
* never a guess about the shape, and never anything that is not in the project
* — the stamper is a file this writes beside the config, not a package that
* has to exist somewhere (FM-DESIGN-88). A config with an `integrations` list
* gains one entry at its head; a config without one — four of Gary's five
* sites — gains the list, right after `defineConfig({`. Anything else is
* refused with what to do, rather than rewritten into something the person
* did not write.
*/
async function stamp$1(files) {
	const config = await configOf$1(files);
	if (!config) throw new Error("no Astro config here");
	const before = await files.read(config) ?? "";
	if (before.includes(STAMPER_IMPORT)) {
		if (await files.read("vobuda-stamp.mjs") === null) {
			await files.write(STAMPER_FILE, STAMPER_SOURCE);
			return { files: [STAMPER_FILE] };
		}
		return { files: [] };
	}
	if (before.includes("vobudaStamp")) throw new Error(`${config} already names ${STAMPER_NAME} in a shape this did not write — look at it by hand`);
	let body;
	const list = before.match(/integrations\s*:\s*\[/);
	const config_ = before.match(/defineConfig\(\s*\{/) ?? before.match(/export\s+default\s*\{/);
	if (list && list.index !== void 0) {
		const cut = list.index + list[0].length;
		body = before.slice(0, cut) + ENTRY + before.slice(cut);
	} else if (config_ && config_.index !== void 0) {
		const cut = config_.index + config_[0].length;
		body = before.slice(0, cut) + LIST + before.slice(cut);
	} else throw new Error(`${config} is not written as defineConfig({ … }) or export default { … }, so there is nowhere certain to add the stamper — nothing was changed`);
	const at = importAt(body);
	const after = body.slice(0, at) + STAMPER_IMPORT + body.slice(at);
	await files.write(STAMPER_FILE, STAMPER_SOURCE);
	await files.write(config, after);
	return { files: [config, STAMPER_FILE] };
}
/**
* Take the teaching back: the config as it was before, and the stamper gone.
*
* Exactly what `stamp` put in comes out, and nothing else: the import line,
* then the entry or the list. If the person has since changed those lines, the
* config is left as it is and the refusal names it (FM-DESIGN-88).
*/
async function unstamp$1(files) {
	const config = await configOf$1(files);
	if (!config) throw new Error("no Astro config here");
	const before = await files.read(config) ?? "";
	const changed = [];
	if (before.includes("vobudaStamp")) {
		let after = before.replace(STAMPER_IMPORT, "");
		if (after.includes(LIST)) after = after.replace(LIST, "");
		else after = after.replace(ENTRY, "");
		if (after.includes("vobudaStamp")) throw new Error(`${config} names ${STAMPER_NAME} in a way this did not write — take it out by hand`);
		await files.write(config, after);
		changed.push(config);
	}
	if (await files.read("vobuda-stamp.mjs") !== null) {
		await files.remove(STAMPER_FILE);
		changed.push(STAMPER_FILE);
	}
	return { files: changed };
}
async function write$1(files, changes) {
	return writeInto(changes, files);
}
var astro = {
	name: "Astro",
	looksLikeMine: looksLikeMine$1,
	isStamped: isStamped$1,
	stamp: stamp$1,
	unstamp: unstamp$1,
	write: write$1
};
//#endregion
//#region plugins/design/frameworks/next.ts
var CONFIGS = [
	"next.config.js",
	"next.config.mjs",
	"next.config.ts",
	"next.config.cjs"
];
/** The addition that stamps, named once. */
var PLUGIN = "vobuda-design/stamp-babel";
async function configOf(files) {
	const here = await files.list(".");
	return CONFIGS.find((c) => here.includes(c)) ?? null;
}
var looksLikeMine = async (files) => await configOf(files) !== null;
/**
* Whether the build stamps.
*
* Asked of the Babel configuration rather than of Next's own, because that is
* where a stamping plugin goes — and a project that has one has a `.babelrc`
* even when its Next config says nothing at all.
*/
async function isStamped(files) {
	for (const name of [
		".babelrc",
		".babelrc.json",
		"babel.config.js",
		"babel.config.json"
	]) if ((await files.read(name) ?? "").includes(PLUGIN)) return true;
	return false;
}
/**
* Teach the build to stamp — refused until there is a stamper to teach it.
*
* This used to add `vobuda-design/stamp-babel` to a `.babelrc`: a Babel plugin
* that exists in no registry and no repository, so the next start of the dev
* server failed on it — the same fault as Astro's, found on 22 September 2026
* (FM-DESIGN-88). Until a stamper of our own is written for Next.js, teaching
* writes nothing and says why; a project already carrying the old line can
* still have it taken out.
*/
async function stamp(files) {
	if (!await configOf(files)) throw new Error("no Next config here");
	throw new Error("teaching a Next.js build is not built yet — nothing was changed. Copy the design, or ask the agent to make the change");
}
/** Take out the line the old teaching wrote, and nothing else. */
async function unstamp(files) {
	const at = ".babelrc";
	const text = await files.read(at);
	if (text === null || !text.includes(PLUGIN)) return { files: [] };
	let config;
	try {
		config = JSON.parse(text);
	} catch {
		throw new Error(`${at} is not JSON any more — take ${PLUGIN} out by hand`);
	}
	const plugins = Array.isArray(config.plugins) ? config.plugins : [];
	config.plugins = plugins.filter((p) => (Array.isArray(p) ? p[0] : p) !== PLUGIN);
	await files.write(at, `${JSON.stringify(config, null, 2)}\n`);
	return { files: [at] };
}
async function write(files, changes) {
	return writeInto(changes, files);
}
var next = {
	name: "Next.js",
	looksLikeMine,
	isStamped,
	stamp,
	unstamp,
	write
};
//#endregion
//#region plugins/design/frameworks/all.ts
var done = false;
/**
* Register them, once.
*
* Called from the designer's start rather than run on import, so that a check
* can drive the boundary with exactly the frameworks it means instead of
* whatever a module happened to load.
*/
function registerAll() {
	if (done) return;
	done = true;
	register(astro);
	register(next);
}
//#endregion
//#region plugins/design/ask.ts
/**
* The properties worth telling an agent about.
*
* Every computed property is four hundred lines of noise that pushes the
* question out of the agent's sight. These are the ones a person points at.
*/
var WORTH_SAYING = [
	"color",
	"background-color",
	"font-size",
	"font-weight",
	"line-height",
	"letter-spacing",
	"margin",
	"padding",
	"border-radius",
	"border",
	"box-shadow",
	"text-align",
	"display",
	"width",
	"height"
];
function worthSaying(style) {
	const out = {};
	for (const key of WORTH_SAYING) {
		const value = (style[key] ?? "").trim();
		if (value && value !== "none" && value !== "normal" && value !== "auto") out[key] = value;
	}
	return out;
}
/** Everything the agent needs, in one shape. */
function asking(said, picked, style, around, picture, scope) {
	return {
		said: said.trim(),
		scope,
		what: picked.what,
		origin: picked.origin,
		now: worthSaying(style),
		around,
		picture
	};
}
/**
* The message an agent actually reads.
*
* Plain sentences, because that is what an agent reads best and what a person
* would find in their own scrollback afterwards. The picture is named by its
* path, the way `page.to-agent` has named one since it was built.
*/
function wording(a) {
	const lines = [a.scope === "everywhere" ? `In the page I am designing, change every place this appears: ${a.what}.` : `In the page I am designing, change this one thing: ${a.what}.`, `What I want: ${a.said}`];
	if (a.origin) lines.push(`It comes from ${a.origin.file}, line ${a.origin.line}.`);
	else lines.push("Its source is not known — the build does not stamp its elements.");
	const now = Object.entries(a.now);
	if (now.length) lines.push(`It is drawn now as: ${now.map(([k, v]) => `${k}: ${v}`).join("; ")}.`);
	const near = [
		a.around.parent && `inside ${a.around.parent}`,
		a.around.before && `after ${a.around.before}`,
		a.around.after && `before ${a.around.after}`
	].filter(Boolean);
	if (near.length) lines.push(`It sits ${near.join(", ")}.`);
	if (a.picture) lines.push(`This is what I see: ${a.picture}`);
	lines.push(a.origin ? "Change it in that file yourself and save. The dev server reloads and I see it at once, so do not answer with a list of styles — nothing here reads one." : "Find it in the project by its text and change it in the source. The dev server reloads and I see it at once, so do not answer with a list of styles — nothing here reads one.");
	return lines.join("\n");
}
//#endregion
//#region plugins/design/look.ts
/** Window token → the variable this page draws with. */
var BORROWED = {
	"--app-bg": "--bg",
	"--app-fg": "--fg",
	"--app-accent": "--accent",
	"--app-warning": "--warning",
	"--line": "--line",
	"--block-radius": "--radius",
	"--panel-bg": "--card",
	"--panel-fg": "--card-fg",
	"--app-fg-muted": "--dim"
};
/**
* What to set on the root, out of what the window offered.
*
* A token the window did not name is left out rather than set empty: the
* stylesheet's own value is the fallback, and writing "" over it would paint
* the page with nothing. That is the same mistake the window's own looks make
* when a token is removed instead of decided, and it is written down there too.
*/
function borrowed(tokens) {
	const out = {};
	for (const [theirs, ours] of Object.entries(BORROWED)) {
		const value = tokens[theirs];
		if (typeof value === "string" && value.trim() !== "") out[ours] = value.trim();
	}
	return out;
}
/**
* Put the window's colours on the page, and take off the ones it no longer
* names. Worn again each time the window's theme or look changes: a panel
* that borrowed them once stayed on the theme it was opened under, white on
* a window gone dark (FM-PLUGIN-50). A token the new look does not name goes
* back to the stylesheet rather than staying on the old look's value.
*/
function wear(style, tokens) {
	const now = borrowed(tokens);
	for (const ours of Object.values(BORROWED)) if (ours in now) style.setProperty(ours, now[ours]);
	else style.removeProperty(ours);
}
//#endregion
//#region plugins/design/exported.ts
/** The line a saved file carries in its head. The core looks for this one. */
var GENERATOR = "<meta name=\"generator\" content=\"vobuda designer\">";
/** Every mark the designer puts on an element of a copy. */
var MARKS = / data-vobuda-(?:file|line|column|words)="[^"]*"/g;
/** One rule of the draft a copy was taken with, as `copied` writes it. */
var RULE = /^\[data-vobuda-line="(\d+)"\] \{ (.+?);? \}$/;
/** The copy as the file a person keeps. */
function exported(text) {
	const lines = text.split("\n");
	let out = text;
	const drop = /* @__PURE__ */ new Set();
	const rules = [];
	lines.forEach((l, i) => {
		const m = RULE.exec(l.trim());
		if (m) rules.push({
			line: Number(m[1]),
			decls: readStyle(m[2]),
			at: i
		});
	});
	for (const r of rules.sort((a, b) => b.line - a.line)) {
		const row = out.split("\n")[r.line - 1] ?? "";
		const column = row.length - row.trimStart().length + 1;
		const tag = tagAt(out, {
			line: r.line,
			column
		});
		if (!tag) continue;
		let now = tag.text;
		for (const [k, v] of r.decls) now = withStyle(now, k, v);
		out = out.slice(0, tag.from) + now + out.slice(tag.to);
		drop.add(r.at);
	}
	const kept = out.split("\n").filter((_, i) => !drop.has(i));
	const tidy = [];
	for (let i = 0; i < kept.length; i++) {
		if (kept[i].trim() === "<style>" && kept[i + 1]?.trim() === "</style>") {
			i += 1;
			continue;
		}
		tidy.push(kept[i]);
	}
	out = tidy.join("\n").replace(MARKS, "");
	if (!out.includes("<meta name=\"generator\" content=\"vobuda designer\">")) out = out.replace(/<meta charset="utf-8">/, (m) => `${m}\n${GENERATOR}`);
	return out;
}
//#endregion
//#region plugins/design/page/verify.ts
/**
* Whether two values mean the same thing on a page.
*
* A browser answers in its own spelling: `red` comes back as `rgb(255, 0, 0)`,
* `0.50` as `0.5`, `#fff` as `rgb(255, 255, 255)`. Comparing the strings would
* report every single change as having moved, and a warning that fires on
* correct work teaches people to ignore warnings — which this project has
* already learnt once tonight.
*/
function same(a, b) {
	const norm = (v) => v.trim().toLowerCase().replace(/\s+/g, " ").replace(/;$/, "");
	if (norm(a) === norm(b)) return true;
	const num = (v) => Number(v.replace(/[^\d.-]/g, ""));
	const unit = (v) => /[a-z%]+$/.exec(v.trim())?.[0] ?? "";
	if (unit(a) === unit(b) && Number.isFinite(num(a)) && Number.isFinite(num(b))) return Math.abs(num(a) - num(b)) < .001;
	return false;
}
//#endregion
//#region plugins/design/designer.ts
registerAll();
var state = {
	address: null,
	framework: null,
	stamped: false,
	mode: "look",
	picked: null,
	drawn: {},
	palette: [],
	behind: [],
	hand: 0,
	rules: [],
	working: false,
	moved: [],
	notes: [],
	sent: []
};
/** The block the bound page is in, as the window last said. */
var block = null;
/** The copy this panel is working on, when the page is one. */
var copyName = null;
var chosenIndex = 0;
var everywhere = true;
var surface = () => window.vobuda ?? null;
/** What the window was last told the panel holds unsaved. */
var toldUnsaved = 0;
/** Redraw, always through the same door, so the panel can never disagree with itself. */
function show() {
	const unsaved = state.rules.length;
	if (unsaved !== toldUnsaved) {
		toldUnsaved = unsaved;
		surface()?.unsaved?.(unsaved)?.catch(() => {});
	}
	try {
		drawTheLot();
	} catch (e) {
		surface()?.log(`the panel could not be drawn — ${String(e)}`);
		const body = document.getElementById("body");
		if (body) {
			const said = document.createElement("p");
			said.className = "note warn";
			said.setAttribute("aria-label", `panel error: ${String(e)}`);
			said.textContent = String(e);
			body.replaceChildren(said);
		}
	}
}
function drawTheLot() {
	draw(document, shown(state), {
		copy: () => void copyTheDesign(),
		edit: () => void setMode(state.mode === "edit" ? "look" : "edit"),
		talk: () => void setMode(state.mode === "ask" ? resting() : "ask"),
		teach: () => void teach(),
		untaught: () => void untaught(),
		nudge: (property, by) => void nudge(property, by),
		colour: (value, target) => void paint(value, target),
		hand: (run) => {
			if (state.hand === run) return;
			state.hand = run;
			const which = state.picked?.words[run];
			if (which) tell({
				do: "hand",
				at: which.at
			});
			show();
		},
		word: (text, run) => void word(text, run),
		server: (port) => void surface()?.openPage(`http://localhost:${port}/`),
		align: (value) => void set("text-align", value),
		ask: (said) => void ask(said),
		scope: () => {
			everywhere = !everywhere;
			show();
		},
		undo: () => {
			state.rules = state.rules.slice(0, -1);
			push();
		},
		revert: () => {
			state.rules = [];
			state.notes = [];
			state.moved = [];
			const at = state.picked?.at;
			push().then(() => at ? tell({
				do: "again",
				at
			}) : void 0);
		},
		keep: () => {
			if (!state.rules.length) return;
			keep();
		},
		reveal: surface()?.reveal ? (path) => void surface()?.reveal?.(path)?.catch(() => {}) : void 0,
		backTo: () => {}
	});
	const body = document.getElementById("body");
	if (question && body) body.prepend(questionCard(document, question, (choice) => {
		question = null;
		surface()?.answerAgent?.(choice)?.catch(() => {});
		show();
	}));
}
/**
* Everything the page is told goes through one shape, so nothing drifts.
*
* A block may be named, and then it is that page rather than the bound one:
* the only thing said to a page the designer is leaving is "stop".
*/
async function tell(message, at) {
	const api = surface();
	const where = at ?? block;
	if (!api || where === null) {
		api?.log("told the page nothing — no page block is bound to this plugin");
		return;
	}
	try {
		await api.runInPage(`window.__vobudaDesign && window.__vobudaDesign(${JSON.stringify(message)})`, where);
	} catch (e) {
		api?.log(`the page did not take it — ${String(e)}`);
	}
}
/** Put the draft the person has now onto the page. */
async function push() {
	state.rules = settle(state.rules);
	await tell({
		do: "draft",
		rules: state.rules
	});
	show();
}
/**
* Looking, changing, or talking — and the page is told which.
*
* Pointing is the page's to do and only while "Edit" is on: the block beside
* the panel is an ordinary page block a person browses in, and a script that
* swallowed every press would make it unusable as a page (FM-DESIGN-30).
*/
/**
* What this page rests in when a mode is turned off.
*
* A copy, and a project whose build stamps, are there to be changed; anything
* else is there to be looked at (FM-DESIGN-52).
*/
var resting = () => state.stamped || state.framework !== null ? "edit" : "look";
async function setMode(next) {
	if (next === "edit" && !state.stamped && state.framework === null) {
		state.notes = [say("Copy the design first — a copy is what you change.")];
		show();
		return;
	}
	state.mode = next;
	if (next !== "edit") {
		state.picked = null;
		state.drawn = {};
	}
	show();
	await tell({
		do: "point",
		on: next === "edit"
	});
}
/**
* Take the design of the page beside this one, and open the copy.
*
* The page writes the copy itself — it is the only thing that can see the
* rendered document — and posts it to the program, which keeps it and says
* where. Everything after that is an ordinary page block on an ordinary
* address, which is the whole point: a copy is a page of this program's own,
* so it can be pointed at, changed and kept (FM-DESIGN-29).
*/
async function copyTheDesign() {
	if (!surface() || !state.address) return;
	state.working = true;
	state.notes = [say("Copying the design…")];
	show();
	await tell({ do: "copy" });
}
async function nudge(property, by) {
	if (!state.picked) return;
	const rule = ruleFor({
		origin: state.picked.origin,
		at: state.picked.at,
		index: chosenIndex,
		everywhere,
		property,
		from: state.drawn[property] ?? "",
		to: {
			kind: "step",
			by
		}
	});
	if (!rule) return;
	state.rules.push(rule);
	state.drawn = {
		...state.drawn,
		[property]: rule.value
	};
	await push();
}
/**
* What the element says.
*
* A change of the words, not of a declaration: no stylesheet can carry it, so
* it travels as a rule of its own under one reserved name and is applied by
* the page directly. Gary, at a panel full of numbers: «там сейчас нельзя
* изменить выбранный текст например... мне надо полноценный конструктор»
* (FM-DESIGN-55).
*/
/** A name as the page gives it — `h1 “the words”` — with new words in it. */
function renamed(was, words) {
	const tag = /^[a-z][a-z0-9-]*/.exec(was)?.[0];
	const said = words.trim().replace(/\s+/g, " ");
	if (!tag || !said) return was;
	return said.length <= 24 ? `${tag} “${said}”` : `${tag} “${said.slice(0, 22)}…”`;
}
async function word(text, run) {
	const which = state.picked?.words[run];
	if (!which) return;
	which.text = text;
	if (state.picked) {
		if (which.at !== state.picked.at) which.what = renamed(which.what, text);
		state.picked.what = renamed(state.picked.what, state.picked.words.map((w) => w.text).join(" "));
	}
	state.rules.push({
		origin: which.origin,
		at: which.at,
		index: 0,
		part: which.part,
		property: WORDS,
		value: text,
		everywhere: which.siblings <= 1
	});
	await push();
}
/**
* A colour, on the piece of text in hand.
*
* The words of an element are not one thing: a heading whose second line is a
* span says two, in two colours, and a swatch pressed while the second field
* is in hand means that line. Gary, having coloured a heading and watched half
* of it change: «не весь текст меняет цвет… надо чтобы принималась палитра
* цвета в зависимости от выбранного текста» (FM-DESIGN-69).
*
* What is behind the words is the element's, not the run's — a piece of text
* has no background of its own — so that half goes where it always did.
*/
/** What a paint said about itself, to stand beside what the page reads back. */
var covered = [];
async function paint(value, target) {
	const runs = state.picked?.words ?? [];
	const run = target === "color" ? runs[Math.min(state.hand, runs.length - 1)] : void 0;
	if (!run) {
		if ((target === "background-color" ? state.picked?.drawn?.["background-image"] : void 0) && state.picked) {
			covered = [say("The gradient or picture on top of it was taken off, so the colour shows.")];
			const before = state.rules.length;
			await set(target, value);
			const made = state.rules[before];
			if (made) {
				state.rules.push({
					...made,
					property: "background-image",
					value: "none"
				});
				await push();
			}
			return;
		}
		set(target, value);
		return;
	}
	const rule = {
		origin: run.origin,
		at: run.at,
		index: 0,
		property: target,
		value,
		everywhere: run.siblings <= 1
	};
	state.rules.push(rule);
	if (seeThrough(run.fill)) state.rules.push({
		...rule,
		property: FILL,
		value
	});
	state.picked = {
		...state.picked,
		words: runs.map((w) => w === run ? {
			...w,
			colour: value
		} : w)
	};
	await push();
}
/** The property that says what the letters themselves are filled with. */
var FILL = "-webkit-text-fill-color";
/** Whether the letters are painted by something other than their colour. */
function seeThrough(fill) {
	const it = fill.trim().toLowerCase();
	if (!it) return false;
	if (it === "transparent") return true;
	const alpha = /^rgba?\([^)]*,\s*([\d.]+)\s*\)$/.exec(it);
	return alpha ? Number(alpha[1]) === 0 : false;
}
async function set(property, value) {
	if (!state.picked) return;
	const rule = ruleFor({
		origin: state.picked.origin,
		at: state.picked.at,
		index: chosenIndex,
		everywhere,
		property,
		from: state.drawn[property] ?? "",
		to: {
			kind: "set",
			value
		}
	});
	if (!rule) return;
	state.rules.push(rule);
	state.drawn = {
		...state.drawn,
		[property]: value
	};
	await push();
}
/**
* Ask the agent — the real one, in its own block.
*
* Gary, 20 September 2026: «эта кнопка должна именно делать тоже самое что
* делает чат тут где я сейчас пишу! она должна быть интегрирована в саму
* систему и знать что она работает со вторым окном».
*
* So this is not a chat of the plugin's own. It goes down the road every
* question in this program goes down — into the agent block of this tab, the
* way a key, a menu item and the command line send one — and the answer
* appears where the person already reads answers. What this adds is the second
* half of the sentence: the agent is told which page is beside the panel and
* what was pointed at on it, so "make this quieter" means something
* (FM-DESIGN-32).
*/
async function ask(said) {
	const api = surface();
	if (!api || !said.trim()) return;
	state.working = true;
	show();
	const where = await pageNamed(api, state.address ?? "");
	const question = state.picked ? wording(asking(said, state.picked, state.drawn, {
		before: null,
		after: null,
		parent: null
	}, null, everywhere ? "everywhere" : "this")) : saying("About the page open beside me, {0}: {1}", where, said.trim());
	const carried = state.picked ? `${question}\n${saying("The page is {0}.", where)}` : question;
	try {
		await api.askAgent(carried);
		state.sent = [...state.sent, {
			mine: true,
			text: said.trim()
		}];
		state.notes = [say("Asked. The answer comes back here.")];
	} catch (e) {
		state.notes = [String(e)];
	}
	state.working = false;
	show();
}
/**
* The person's own files, as the window lets this page reach them.
*
* Three calls and no more: the program holds the one folder that was granted
* and refuses anything outside it, and it writes a line to the log before every
* write (FM-PLUGIN-16). Nothing in this page knows a path outside the project.
*/
function filesFrom(api) {
	return {
		read: (path) => api.readSource(path),
		write: (path, text) => api.writeSource(path, text),
		list: (path) => api.listSource(path),
		remove: (path) => api.removeSource(path)
	};
}
/**
* The port of a dev server on this machine, when that is what the address is.
*
* The address as the bar shows it, `http://localhost:4460/`. Anything else —
* a site out on the web, a copy — has no folder on this computer to write to.
*/
function devPort(address) {
	if (!address) return null;
	try {
		const url = new URL(address);
		if (url.protocol !== "http:") return null;
		if (![
			"localhost",
			"127.0.0.1",
			"[::1]"
		].includes(url.hostname)) return null;
		return url.port ? Number(url.port) : 80;
	} catch {
		return null;
	}
}
/**
* Why nothing may be written from this page into this window's project — or
* null, when the page is that project's own.
*
* Asked of the system, not assumed: the server's own folder has to be the one
* the window granted. Above vobuda.com, and above a dev server started from
* another folder, "Teach the build" wrote into whatever folder the window's
* terminal was in (run-in of 22 September 2026, FM-DESIGN-88).
*/
async function whoseIs(api, address) {
	const port = devPort(address);
	if (port === null) return say("This page comes from the web, not from a folder on this computer, so nothing is written anywhere. Copy the design to change it.");
	const root = await api.project();
	if (!root) return say("No project folder — open the site's folder in this window first.");
	let folder = null;
	try {
		folder = await api.servedFrom(port);
	} catch {
		folder = null;
	}
	if (!folder) return say("Nothing on this computer says which folder this page is served from, so nothing is written.");
	if (folder !== root) return saying("This page is served from {0}, and this window works in {1}, so nothing is written there.", folder, root);
	return null;
}
/**
* Learn whose page this is, and only then what its project is.
*
* The framework used to be read once, from the window's folder, for whatever
* page was beside the panel — so over any site at all the panel said "This is
* an Astro project open in this window" and offered to teach it (FM-DESIGN-88).
*/
async function learnWhose(address) {
	const api = surface();
	if (!api) return;
	if (!address || copyIn(address)) {
		state.whose = null;
		state.framework = null;
		state.taught = false;
		show();
		return;
	}
	const why = await whoseIs(api, address);
	const framework = why ? null : await whatProjectIsThis(filesFrom(api));
	const taught = framework ? await isTaught(filesFrom(api)) : false;
	if (state.address !== address) return;
	state.whose = why;
	state.framework = framework;
	state.taught = taught;
	show();
}
/**
* "Keep it": the draft becomes the source.
*
* Three things happen and the person is told about all three — what was
* written, what could not be, and whether the page that came back looks like
* what they agreed to. The last one is the part almost nothing on the market
* has, and it is the one that matters: the draft won by being `!important`, and
* a written declaration has to win on its own (FM-DESIGN-2).
*/
async function keep() {
	const api = surface();
	if (!api) return;
	if (!state.rules.length) return;
	state.working = true;
	state.notes = [];
	state.moved = [];
	show();
	try {
		if (copyName) {
			await saveSomewhereElse(api, copyName);
			return;
		}
		const why = await whoseIs(api, state.address);
		if (why) {
			state.whose = why;
			state.notes = [why];
			return;
		}
		const kept = await keepInto(filesFrom(api), settle(state.rules));
		const notes = [];
		if (kept.files.length) notes.push(saying("Written into {0} by the {1} build.", kept.files.join(", "), kept.framework ?? ""));
		for (const r of kept.refused) notes.push(`${r.where} — ${r.why}`);
		if (!kept.files.length && !kept.refused.length) notes.push(say("Nothing was written."));
		state.kept = notes;
		state.wrote = kept.files;
		state.notes = notes;
		show();
		if (kept.files.length) {
			const written = state.rules;
			state.rules = [];
			await checkAgainstThePage(written);
		}
	} catch (e) {
		state.notes = [String(e)];
	} finally {
		state.working = false;
		show();
	}
}
/**
* Write the page, with the draft in it, wherever the person points.
*
* The file itself and not a road to it: what leaves here is one HTML file that
* opens in anything. The draft is applied to the copy's own text in memory —
* the same addressed write every other road here takes — and the window's
* chooser decides where the result lands. The copy in hand is untouched, so
* this is "save a version of it somewhere" rather than "move my work"
* (FM-DESIGN-79).
*/
async function saveSomewhereElse(api, name) {
	api.log(`saving ${name} somewhere else`);
	const text = await (await api.workFolder("copies")).read(name);
	if (text === null) {
		api.log(`saving stopped — ${name} is not in the copies folder`);
		state.notes = [saying("The copy {0} could not be read.", name)];
		return;
	}
	let out = text;
	const written = await writeInto(settle(state.rules).filter((r) => r.origin).map((r) => ({
		origin: r.origin,
		property: r.property,
		value: r.value,
		everywhere: true
	})), {
		read: async () => out,
		write: async (_path, next) => {
			out = next;
		},
		list: async () => [name],
		remove: async () => {}
	});
	const notes = [];
	for (const r of written.refused) notes.push(`${r.origin.file}:${r.origin.line} — ${r.why}`);
	try {
		api.log(`asking where ${name} should go`);
		const at = await api.saveAs(name, exported(out));
		notes.unshift(saying("Saved into {0}.", at));
		await api.keepCopy(name, out);
		state.rules = [];
		state.savedAt = at;
		await tell({ do: "drop" });
		if (block !== null) await api.reloadPage(block).catch(() => {});
	} catch (e) {
		notes.unshift(String(e).includes("cancelled") ? say("Nothing was saved.") : String(e));
	}
	state.notes = notes;
}
/**
* "Teach the build": the project's config gains the stamper.
*
* Afterwards the person is told to restart their dev server, because a config
* read at boot is a config read at boot — and a designer that said nothing
* there would look broken for exactly as long as it took them to notice.
*/
async function teach() {
	const api = surface();
	if (!api) return;
	state.working = true;
	state.notes = [];
	show();
	try {
		const why = await whoseIs(api, state.address);
		if (why) {
			state.whose = why;
			state.notes = [why];
			return;
		}
		const taught = await teachIn(filesFrom(api));
		if (taught.why) {
			state.notes = [taught.why];
			return;
		}
		state.taught = true;
		state.notes = taught.files.length ? [saying("Written into {0} by the {1} build.", taught.files.join(", "), taught.framework ?? "")] : [say("The build was already taught.")];
		show();
		untilStamped();
	} catch (e) {
		state.notes = [String(e)];
	} finally {
		state.working = false;
		show();
	}
}
/**
* Load the page again until it says its elements are stamped, for a while.
*
* Astro starts its dev server again on a changed config, which takes a few
* seconds; a page loaded in between is the old one, or no page at all.
*/
async function untilStamped() {
	const api = surface();
	const on = state.address;
	for (let i = 0; i < 8 && api && block !== null && !state.stamped; i++) {
		await new Promise((r) => setTimeout(r, 2500));
		if (state.stamped || block === null) break;
		try {
			await api.reloadPage(block);
		} catch {
			break;
		}
	}
	if (!state.stamped && state.taught && state.address === on && block !== null) {
		state.notes = [say("The build is taught, but nothing on this page is written in its page files — it is put together in code — so there is nothing to mark. Copy the design to change it.")];
		show();
	}
}
/**
* "Take the teaching back": the config as it was before, the stamper gone.
*
* Only on the page of this window's own project, the same as teaching, and
* then the page is read again so it stops claiming a place nothing marks.
*/
async function untaught() {
	const api = surface();
	if (!api) return;
	state.working = true;
	state.notes = [];
	show();
	try {
		const why = await whoseIs(api, state.address);
		if (why) {
			state.notes = [why];
			return;
		}
		const back = await untaughtIn(filesFrom(api));
		if (back.why) {
			state.notes = [back.why];
			return;
		}
		state.taught = false;
		state.stamped = false;
		state.notes = back.files.length ? [saying("Taken back out of {0}.", back.files.join(", "))] : [say("There was nothing to take back.")];
		if (block !== null) {
			await new Promise((r) => setTimeout(r, 2500));
			await api.reloadPage(block).catch(() => {});
		}
	} catch (e) {
		state.notes = [String(e)];
	} finally {
		state.working = false;
		show();
	}
}
/** Take the draft off, let the page come back, and see what it is drawing. */
async function checkAgainstThePage(rules) {
	await tell({ do: "drop" });
	await new Promise((r) => setTimeout(r, 1200));
	await tell({
		do: "check",
		rules: settle(rules)
	});
}
/**
* What a change came to, in the person's own terms.
*
* "25px" beside a page that did not move is worse than no number at all: it
* says the thing was done. A value asked for and a value in force are two
* different facts and the panel shows the second (FM-DESIGN-19).
*/
function whatCameOfIt(drawn) {
	const lost = drawn.filter((d) => d.given && !same(d.given, d.asked));
	if (!lost.length) return [];
	return lost.map((d) => saying("{0} is drawn as {1}, not {2} — something nearer the element wins.", d.property, d.given, d.asked));
}
/**
* What the page being designed says back.
*
* From the page this panel is bound to, and from no other. Every page the
* program serves speaks down the same road, and two of them are open side by
* side on purpose — the site and the copy taken from it. The site says "nothing
* here is stamped", which is true of it and false of the copy, and the panel
* believed whichever spoke last: Edit went dead on a copy that is stamped by
* construction, and closing the site did not bring it back because the word had
* already landed. Gary: «когда я закрываю сайт который я скопировал почему
* перестает работать раздел дизайн?» (FM-DESIGN-58).
*
* A message with no place on it is the program's own — the copy it wrote — and
* is always heard.
*/
function heard(detail) {
	if (detail.at != null && detail.at !== block) {
		surface()?.log(`not from the page in block ${block} — ${detail.what} from block ${detail.at}`);
		return;
	}
	if (detail.what === "copied") {
		const body = detail.body;
		state.working = false;
		if (!body?.address) {
			state.notes = [say("The copy was not kept.")];
			show();
			return;
		}
		state.notes = [saying("Copied into {0}. It opens beside this, and it can be changed and kept.", body.name ?? "")];
		justCopied = body.address;
		surface()?.openPage(body.address, true);
		show();
		return;
	}
	if (detail.what === "copy-failed") {
		state.working = false;
		state.notes = [saying("The design could not be copied — {0}", String(detail.body))];
		show();
		return;
	}
	if (detail.what === "moved") {
		const body = detail.body;
		state.moved = body.moved ?? [];
		state.notes = body.saying?.length ? [...state.notes, ...body.saying] : [...state.notes, say("The page came back drawing what the draft promised.")];
		show();
		return;
	}
	if (detail.what === "drawn") {
		const drawn = detail.body;
		const mine = state.picked?.at;
		for (const d of drawn) if (d.at === mine) state.drawn = {
			...state.drawn,
			[d.property]: d.given || d.asked
		};
		state.notes = [...whatCameOfIt(drawn), ...covered];
		covered = [];
		show();
		return;
	}
	if (detail.what === "ready") {
		state.stamped = !!detail.body.stamped;
		if (state.mode === "edit" && !state.picked) tell({ do: "first" });
		tell({
			do: "point",
			on: state.mode === "edit"
		});
		show();
		return;
	}
	if (detail.what === "picked" || detail.what === "hover") {
		const picked = detail.body;
		if (detail.what === "picked") {
			state.picked = picked;
			state.drawn = picked?.drawn ?? {};
			state.palette = picked?.palette ?? [];
			state.behind = picked?.behind ?? [];
			chosenIndex = 0;
			state.hand = 0;
			state.notes = [];
			show();
		}
	}
}
/**
* The window says which page is beside this panel and where it has got to.
*
* A new address is a new document, so everything about the old one goes: what
* was pointed at, what it was drawn with, and the draft, which lived in a page
* that no longer exists. Keeping them would be a panel showing an element of a
* page that is gone (FM-DESIGN-31).
*/
/** The copy this panel has just asked for, until the binding reaches it. */
var justCopied = null;
function hereIsThePage(next, address) {
	const moved = address !== state.address;
	if (block !== null && next !== block) tell({
		do: "point",
		on: false
	}, block);
	block = next;
	if (!moved) return;
	state.address = address;
	state.savedAt = null;
	state.wrote = [];
	state.kept = [];
	state.picked = null;
	state.drawn = {};
	state.moved = [];
	state.notes = [];
	if (foundNote && address === foundNote.address) {
		state.notes = [foundNote.text];
		foundNote = null;
	}
	if (state.rules.length) {
		state.rules = [];
		state.notes = address !== null && address === justCopied ? [say("The copy carries what you changed. Point at it to keep going.")] : [say("The page changed, so the draft went with it.")];
	}
	if (address === justCopied) justCopied = null;
	copyName = copyIn(address);
	state.stamped = copyName !== null;
	state.framework = null;
	state.taught = false;
	state.whose = null;
	learnWhose(address);
	if (!address) lookForServers();
	state.mode = copyName !== null ? "edit" : "look";
	tell({
		do: "point",
		on: state.mode === "edit"
	});
	tell({ do: "hello" });
	if (state.mode === "edit") tell({ do: "first" });
	show();
}
/** The name of a copy, when the address is one this program serves. */
function copyIn(address) {
	if (!address) return null;
	const m = /^vobuda-design:\/\/[^/]*\/copy\/[^/]+\/([^/?#]+\.html)$/.exec(address);
	return m ? decodeURIComponent(m[1]) : null;
}
/** Whether this panel has opened a server by itself already. Once is enough. */
var foundOnce = false;
/** What is said when that page arrives. */
var foundNote = null;
var looking = false;
/**
* The servers this computer runs that the page beside could show.
*
* Asked while the page beside shows nothing. The one server running in this
* window's own folder is opened by itself, with its address in the bar — one
* is not a guess; several are offered, never chosen among (FM-DESIGN-10); and
* every server is shown with the folder it runs in, so a person sees which is
* theirs (run-in two, morning 23, story 54-2, FM-DESIGN-105).
*/
async function lookForServers() {
	const api = surface();
	if (!api || looking) return;
	looking = true;
	try {
		while (!state.address) {
			const listening = await api.listeningPorts().catch(() => []);
			const ports = [...new Set(listening.flatMap((b) => b.ports))].sort((a, b) => a - b);
			const root = await api.project().catch(() => null);
			const found = [];
			for (const port of ports) {
				const folder = await api.servedFrom(port).catch(() => null);
				found.push({
					port,
					folder,
					mine: !!root && folder === root
				});
			}
			if (state.address) break;
			const before = JSON.stringify(state.servers ?? []);
			state.servers = found;
			const mine = found.filter((f) => f.mine);
			if (mine.length === 1 && !foundOnce) {
				foundOnce = true;
				foundNote = {
					address: `http://localhost:${mine[0].port}/`,
					text: saying("Opened localhost:{0}, the server running in this window's folder.", mine[0].port)
				};
				await api.openPage(foundNote.address);
				show();
				break;
			}
			if (JSON.stringify(found) !== before) show();
			await new Promise((r) => setTimeout(r, 3e3));
		}
	} finally {
		looking = false;
	}
}
async function begin() {
	const api = surface();
	if (!api) return;
	await loadWords(api.language);
	show();
	try {
		wear(document.documentElement.style, await api.tokens());
		api.onTokens?.((tokens) => wear(document.documentElement.style, tokens));
	} catch {}
	try {
		const at = await api.boundPage();
		hereIsThePage(at?.block ?? null, at?.address ?? null);
	} catch {}
	lookForServers();
	show();
}
window.addEventListener("vobuda-plugin-page", (e) => {
	const d = e.detail;
	hereIsThePage(d?.block ?? null, d?.address ?? null);
});
window.addEventListener("vobuda-design", (e) => {
	heard(e.detail);
});
window.addEventListener("vobuda-plugin-save", () => {
	keep();
});
window.addEventListener("vobuda-plugin-answer", (e) => {
	heardAnswer(e.detail ?? {});
});
/** The agent's question standing over this panel, until it is answered. */
var question = null;
/**
* An answer, or the agent's own question, or its leaving — each said as it is.
*
* The agent that was started for a question may stop on one of its own first:
* whether to trust this folder. Only the person can answer that, so the window
* opens its block and the panel says what it asks and where, instead of
* "the answer comes back here" standing over a question nobody could see
* (FM-DESIGN-89).
*/
function heardAnswer(d) {
	const text = d.text?.trim() ?? "";
	if (d.kind === "asks") {
		if (d.card && surface()?.answerAgent) {
			question = d.card;
			state.notes = [];
			show();
			return;
		}
		state.notes = [saying("{0} is asking you something in its own block. Answer it there, and the rest comes back here by itself.", d.agent || say("The agent")), ...text ? [text] : []];
		show();
		return;
	}
	question = null;
	if (d.kind === "sent") {
		state.notes = [say("Asked. The answer comes back here.")];
		show();
		return;
	}
	if (d.kind === "left") {
		state.notes = [say("The agent closed before it was asked. Ask again to start it once more.")];
		show();
		return;
	}
	if (!text) return;
	state.sent = [...state.sent, {
		mine: false,
		text
	}];
	state.notes = [];
	show();
}
show();
begin();
//#endregion
