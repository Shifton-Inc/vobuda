//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region plugins/design/pageName.ts
/**
* How the agent is told which page is beside the panel.
*
* A site by its address. A copy by its file: its address is the program's own
* scheme, which names nothing an agent can open, and the agent went looking
* for the file across the disk and asked for folders outside the project
* (night tester, 23 September, FM-DESIGN-107). The copies live in this
* plugin's own work folder, which the surface names.
*/
async function pageNamed(api, address) {
	const m = /^vobuda-design:\/\/localhost\/copy\/[^/]+\/([^/?#]+)/.exec(address);
	if (!m) return address;
	try {
		return `${(await api.workFolder("copies")).path}/${decodeURIComponent(m[1])}`;
	} catch {
		return address;
	}
}
//#endregion
//#region plugins/design/palette.ts
/**
* A full palette, for when the site's own colours are not the answer.
*
* The site's colours come first and always will — a picker that offers a
* rainbow to somebody working on a six-colour site produces a seventh. But
* Gary asked for the rest of it in as many words: «цвета тоже надо дать больше
* вариантов... сделать всю палитру». Somebody redesigning a page is choosing
* new colours, and the palette is where they choose them (FM-DESIGN-56).
*
* Built rather than listed: ten hues around the wheel, five steps of lightness
* each, and a row of greys from black to white. Written as `hsl` because that
* is the shape the grid is thought in; the page turns it into whatever it
* computes with.
*/
function spectrum() {
	const out = [];
	const hues = [
		0,
		22,
		45,
		90,
		140,
		170,
		200,
		225,
		265,
		310
	];
	for (const step of [
		92,
		78,
		60,
		44,
		28
	]) for (const hue of hues) {
		const sat = step > 80 ? 62 : step > 50 ? 72 : 58;
		out.push(`hsl(${hue}, ${sat}%, ${step}%)`);
	}
	for (const step of [
		100,
		96,
		88,
		72,
		52,
		34,
		20,
		10,
		0
	]) out.push(`hsl(220, 12%, ${step}%)`);
	return out;
}
//#endregion
//#region plugins/design/mechanical.ts
/** What a person can change without anybody thinking about it. */
var MECHANICAL = [
	"color",
	"background-color",
	"font-size",
	"font-weight",
	"line-height",
	"letter-spacing",
	"margin",
	"padding",
	"gap",
	"border-radius",
	"border-color",
	"border-width",
	"box-shadow",
	"text-align",
	"opacity"
];
var isMechanical = (property) => MECHANICAL.includes(property);
/**
* Read a length the page gave us.
*
* `getComputedStyle` answers in pixels for most things, but a person may have
* typed `1.5rem` and a draft may hold it. Anything that is not a length — a
* keyword, a colour, `auto` — comes back as nothing rather than as zero, since
* nudging `auto` by two is not a change, it is a mistake.
*/
function lengthOf(value) {
	const m = /^(-?\d*\.?\d+)(px|rem|em|%|vh|vw|pt)$/.exec(value.trim());
	if (!m) return null;
	const amount = Number(m[1]);
	return Number.isFinite(amount) ? {
		amount,
		unit: m[2]
	} : null;
}
var printLength = (l) => `${Number(l.amount.toFixed(3))}${l.unit}`;
/**
* Nudge a length by one step of whatever unit it is in.
*
* The step is the unit's own: a pixel for pixels, a tenth for rem and em, a
* whole one for per cent. A single step size in pixels would move `1rem` by a
* sixteenth of nothing and `100%` clean off the screen.
*/
function nudge$1(value, by, coarse = false) {
	const l = lengthOf(value);
	if (!l) return null;
	const step = l.unit === "rem" || l.unit === "em" ? .1 : 1;
	const times = coarse ? 10 : 1;
	return printLength({
		...l,
		amount: l.amount + by * step * times
	});
}
/** Font weights a person steps through, rather than every number CSS allows. */
var WEIGHTS = [
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900
];
function nextWeight(value, by) {
	const now = Number(value.trim());
	if (!Number.isFinite(now)) return null;
	const at = WEIGHTS.findIndex((w) => w >= now);
	const i = at === -1 ? WEIGHTS.length - 1 : at;
	const next = WEIGHTS[Math.min(WEIGHTS.length - 1, Math.max(0, i + by))];
	return next === now ? null : String(next);
}
/**
* What the draft should say, or nothing.
*
* Nothing means one of two things and both are fine: the property is not one a
* person may change without thinking, or the step would not move it. Neither is
* an error and neither reaches an agent — the menu simply does not offer what
* this cannot do.
*/
function ruleFor(asked) {
	if (!isMechanical(asked.property)) return null;
	let value;
	if (asked.to.kind === "set") value = asked.to.value.trim() || null;
	else if (asked.property === "font-weight") value = nextWeight(asked.from, asked.to.by);
	else value = nudge$1(asked.from, asked.to.by, asked.to.coarse);
	if (!value) return null;
	return {
		origin: asked.origin,
		at: asked.at,
		index: asked.index,
		property: asked.property,
		value,
		everywhere: asked.origin ? asked.everywhere : false
	};
}
//#endregion
//#region plugins/design/page/draft.ts
/** The key one rule is remembered by: one property of one place. */
var keyOf = (r) => r.origin ? `${r.origin.file}:${r.origin.line}:${r.origin.column}:${r.index}:${r.everywhere}:${r.property}` : `at:${r.at}:${r.property}`;
/**
* The last word on each property of each place.
*
* A person changes a colour, changes their mind, changes it again: three
* changes and one decision. A stack that grows with every nudge is a stack that
* hands a hundred edits to whatever reads it next.
*/
function settle(rules) {
	const last = /* @__PURE__ */ new Map();
	for (const r of rules) last.set(keyOf(r), r);
	return [...last.values()];
}
/** The stylesheet, as one string. */
/** The property name a change of the words goes under. */
var WORDS = "#text";
var en_default = {
	"A bakery in Lviv: the menu, opening hours and how to order": "A bakery in Lviv: the menu, opening hours and how to order",
	"A kind of site the designer knows: {0}.": "A kind of site the designer knows: {0}.",
	"A site that is not yours is not edited. Copy the design and change the copy.": "A site that is not yours is not edited. Copy the design and change the copy.",
	"About the page open beside me, {0}: {1}": "About the page open beside me, {0}: {1}",
	Alignment: "Alignment",
	"Another page is open, so the changes you had not saved stay with the last one: open it again and they come back.": "Another page is open, so the changes you had not saved stay with the last one: open it again and they come back.",
	"Ask the agent": "Ask the agent",
	"Ask the agent to take these out": "Ask the agent to take these out",
	"Asked. The answer comes back here.": "Asked. The answer comes back here.",
	Background: "Background",
	"Background colour": "Background colour",
	"Background picture": "Background picture",
	Boldness: "Boldness",
	"Border colour": "Border colour",
	"Border thickness": "Border thickness",
	"Brought back {0} unsaved changes from last time.": "Brought back {0} unsaved change from last time. | Brought back {0} unsaved changes from last time.",
	"Build a new website of my own in the folder {0}, using the page saved at {1} as a visual sample only. My site is about: {2}. Take from the sample its layout, spacing, text sizes and colour relations. Take none of its words, pictures, logos, icons, names or addresses: write new text for my site, and use plain placeholders for pictures. Make it a {3} project with a \"dev\" script in package.json unless that folder already holds a site of mine — then work in that one. Do not copy the sample's file into the folder. When it is done, say so in one line.": "Build a new website of my own in the folder {0}, using the page saved at {1} as a visual sample only. My site is about: {2}. Take from the sample its layout, spacing, text sizes and colour relations. Take none of its words, pictures, logos, icons, names or addresses: write new text for my site, and use plain placeholders for pictures. Make it a {3} project with a \"dev\" script in package.json unless that folder already holds a site of mine — then work in that one. Do not copy the sample's file into the folder. When it is done, say so in one line.",
	"Build my site from this": "Build my site from this",
	Centre: "Centre",
	"Changes here are on the page in front of you. Copy the design to keep them.": "Changes here are on the page in front of you. Copy the design to keep them.",
	"Changes, oldest first": "Changes, oldest first",
	"Checking what was built against this copy…": "Checking what was built against this copy…",
	"Choose my site's folder": "Choose my site's folder",
	"Choose where my site goes": "Choose where my site goes",
	"Copied into {0}. It opens beside this, and it can be changed and kept.": "Copied into {0}. It opens beside this, and it can be changed and kept.",
	"Copy the design": "Copy the design",
	"Copy the design first — a copy is what you change.": "Copy the design first — a copy is what you change.",
	"Copying the design…": "Copying the design…",
	Edit: "Edit",
	"Edit my new site": "Edit my new site",
	"Edit my site": "Edit my site",
	"Everything changed here goes back to what the file has.": "Everything changed here goes back to what the file has.",
	"Greyed steps were taken back. Press one to go forward to it; a new change drops them.": "Greyed steps were taken back. Press one to go forward to it; a new change drops them.",
	"It does not yet mark where each part of a page is written, so changes could be looked at but not saved. Teaching adds one small file beside its settings; it can be taken back.": "It does not yet mark where each part of a page is written, so changes could be looked at but not saved. Teaching adds one small file beside its settings; it can be taken back.",
	"It goes into {0}": "It goes into {0}",
	"It marks where each part of a page is written, so what you change can be saved into those files.": "It marks where each part of a page is written, so what you change can be saved into those files.",
	"It will be told about {0} and about the page beside this one.": "It will be told about {0} and about the page beside this one.",
	"It will be told which page is beside this one. Point at something first if you mean one thing on it.": "It will be told which page is beside this one. Point at something first if you mean one thing on it.",
	"Its preview is not running. The preview is the program that shows your site while you work on it.": "Its preview is not running. The preview is the program that shows your site while you work on it.",
	"Its preview is running at localhost:{0}. The preview is the program that shows your site while you work on it.": "Its preview is running at localhost:{0}. The preview is the program that shows your site while you work on it.",
	"Leave the building": "Leave the building",
	"Leave this first step": "Leave this first step",
	Left: "Left",
	"Letter spacing": "Letter spacing",
	"Line spacing": "Line spacing",
	"Looking at the folder…": "Looking at the folder…",
	"Move over the page beside this and press what you want to change.": "Move over the page beside this and press what you want to change.",
	"No folder of your site is open here. Press “Edit my site” and choose it.": "No folder of your site is open here. Press “Edit my site” and choose it.",
	"No folder yet: choose the folder your site is in.": "No folder yet: choose the folder your site is in.",
	"Not brought back, because it is no longer on the page: {0}": "Not brought back, because it is no longer on the page: {0}",
	"Not brought back, because the page's code changed since: {0}": "Not brought back, because the page's code changed since: {0}",
	"Nothing has been changed yet.": "Nothing has been changed yet.",
	"Nothing on this computer says which folder this page comes from, so nothing is saved.": "Nothing on this computer says which folder this page comes from, so nothing is saved.",
	"Nothing open beside this yet": "Nothing open beside this yet",
	"Nothing was saved.": "Nothing was saved.",
	"One moment.": "One moment.",
	"Only here / everywhere": "Only here / everywhere",
	"Open a site in the page beside this one first.": "Open a site in the page beside this one first.",
	"Open my site's preview": "Open my site's preview",
	"Opened your site's preview (localhost:{0}), the one running from this folder.": "Opened your site's preview (localhost:{0}), the one running from this folder.",
	"Other sites ({0})": "Other sites ({0})",
	"Point at something": "Point at something",
	"Press “Copy the design”. The copy opens beside this one, and the copy is what you change.": "Press “Copy the design”. The copy opens beside this one, and the copy is what you change.",
	"Put back all edits of the page": "Put back all edits of the page",
	Right: "Right",
	"Rounded corners": "Rounded corners",
	"Running on this computer:": "Running on this computer:",
	Save: "Save",
	"Save changes": "Save changes",
	"Save {0} changes": "Save {0} change | Save {0} changes",
	"Saved into {0}.": "Saved into {0}.",
	"Saved into {0}. The panel cannot take this back yet.": "Saved into {0}. The panel cannot take this back yet.",
	"Saved, but these look different on the page than before saving: a style already in your site takes precedence.": "Saved, but these look different on the page than before saving: a style already in your site takes precedence.",
	"Say what the site is about and where it goes first.": "Say what the site is about and where it goes first.",
	"Say what you want": "Say what you want",
	"See-through": "See-through",
	Send: "Send",
	Shadow: "Shadow",
	"Show in Finder": "Show in Finder",
	"Space around": "Space around",
	"Space between": "Space between",
	"Space inside": "Space inside",
	"Start building my site": "Start building my site",
	"Start my site's preview": "Start my site's preview",
	"Starting it with “{0}” in the block below. Once it is up the block folds into the strip at the bottom and the page opens here by itself; if it stops, the block opens again to show why.": "Starting it with “{0}” in the block below. Once it is up the block folds into the strip at the bottom and the page opens here by itself; if it stops, the block opens again to show why.",
	"Take the teaching back": "Take the teaching back",
	"Taken back out of {0}.": "Taken back out of {0}.",
	"Teach my site's build": "Teach my site's build",
	Text: "Text",
	"Text colour": "Text colour",
	"Text size": "Text size",
	"The agent": "The agent",
	"The agent builds a site of your own from this copy: its layout, spacing, text sizes and colours — and none of its words, pictures, logos or names.": "The agent builds a site of your own from this copy: its layout, spacing, text sizes and colours — and none of its words, pictures, logos or names.",
	"The agent closed before it was asked. Ask again to start it once more.": "The agent closed before it was asked. Ask again to start it once more.",
	"The agent is building it. Its answer comes back here, and then what it built is checked against this copy.": "The agent is building it. Its answer comes back here, and then what it built is checked against this copy.",
	"The block beside this one is an ordinary page: type any site's address into it to copy its design, or press “Edit my site” to work on your own.": "The block beside this one is an ordinary page: type any site's address into it to copy its design, or press “Edit my site” to work on your own.",
	"The copy carries what you changed. Point at it to keep going.": "The copy carries what you changed. Point at it to keep going.",
	"The copy was not kept.": "The copy was not kept.",
	"The copy {0} could not be read.": "The copy {0} could not be read.",
	"The design could not be copied — {0}": "The design could not be copied — {0}",
	"The designer does not know this kind of site. It knows {0}. Choose the folder that holds your site's settings file — or copy the design of any page instead.": "The designer does not know this kind of site. It knows {0}. Choose the folder that holds your site's settings file — or copy the design of any page instead.",
	"The gradient or picture on top of it was taken off, so the colour shows.": "The gradient or picture on top of it was taken off, so the colour shows.",
	"The page before any change": "The page before any change",
	"The page came back looking the way you made it.": "The page came back looking the way you made it.",
	"The page is {0}.": "The page is {0}.",
	"The site you built in {0} still carries these of the sample's own. Replace each with something of my site's own, then say so in one line:\n{1}": "The site you built in {0} still carries these of the sample's own. Replace each with something of my site's own, then say so in one line:\n{1}",
	"The words of what you picked": "The words of what you picked",
	"There was nothing to take back.": "There was nothing to take back.",
	"These words are made by the site's code, so they cannot be written from here. Ask the agent to change them.": "These words are made by the site's code, so they cannot be written from here. Ask the agent to change them.",
	"This is a {0} site that does not yet mark where each part is written. What you change shows on the page; saving it into the files needs “Teach my site's build”.": "This is a {0} site that does not yet mark where each part is written. What you change shows on the page; saving it into the files needs “Teach my site's build”.",
	"This is your {0} site.": "This is your {0} site.",
	"This page comes from the web, not from a folder on this computer, so nothing is saved anywhere. Copy the design to change it.": "This page comes from the web, not from a folder on this computer, so nothing is saved anywhere. Copy the design to change it.",
	"This page comes from {0}, but your site's folder here is {1}, so nothing is saved there. Press “Edit my site” to choose the right folder.": "This page comes from {0}, but your site's folder here is {1}, so nothing is saved there. Press “Edit my site” to choose the right folder.",
	"This page does not say where each part is written, so changes cannot be saved into files. Copy the design and change the copy.": "This page does not say where each part is written, so changes cannot be saved into files. Copy the design and change the copy.",
	"This page is not your site's folder open here, so changes stay in the copy, not in anybody's files.": "This page is not your site's folder open here, so changes stay in the copy, not in anybody's files.",
	"This page says where each part is written, so what you change can be saved into those files.": "This page says where each part is written, so what you change can be saved into those files.",
	"Three things are needed to change your site here and save the changes into its files.": "Three things are needed to change your site here and save the changes into its files.",
	Undo: "Undo",
	"What is your site about?": "What is your site about?",
	"What my site is about": "What my site is about",
	"What the page did not do": "What the page did not do",
	"What was built still carries these of the original's:": "What was built still carries these of the original's:",
	"What you want": "What you want",
	"Where does it go? Pick an empty folder, or the folder of a site of yours.": "Where does it go? Pick an empty folder, or the folder of a site of yours.",
	Words: "Words",
	"Your site already marks its parts.": "Your site already marks its parts.",
	"Your site is built, and it carries none of the original's words, pictures or names.": "Your site is built, and it carries none of the original's words, pictures or names.",
	"Your site now marks its parts ({0}). It can be taken back.": "Your site now marks its parts ({0}). It can be taken back.",
	"Your site now marks its parts, but this page is put together by code rather than written in its page files, so there is nothing here to mark. Copy the design to change it.": "Your site now marks its parts, but this page is put together by code rather than written in its page files, so there is nothing here to mark. Copy the design to change it.",
	"Your site now marks its parts. Its preview restarts by itself; if this page still has nothing to change after a few seconds, stop the preview in its block (Control-C) and start it again.": "Your site now marks its parts. Its preview restarts by itself; if this page still has nothing to change after a few seconds, stop the preview in its block (Control-C) and start it again.",
	"Your site's folder: {0}": "Your site's folder: {0}",
	"drawn in {0} places": "drawn in {0} places",
	"folder not known": "folder not known",
	name: "name",
	picture: "picture",
	"the designer does not know how to save into this kind of site": "the designer does not know how to save into this kind of site",
	"the designer does not know how to teach this kind of site": "the designer does not know how to teach this kind of site",
	"this window's folder": "this window's folder",
	"where it is written is not known": "where it is written is not known",
	words: "words",
	"{0} is asking you something in its own block. Answer it there, and the rest comes back here by itself.": "{0} is asking you something in its own block. Answer it there, and the rest comes back here by itself.",
	"{0} is {1} on the page, not {2}": "{0} is {1} on the page, not {2}",
	"{0} shows as {1}, not {2}: another style on this part takes precedence.": "{0} shows as {1}, not {2}: another style on this part takes precedence.",
	"{0} was changed once so that one of its uses can look different; every other use of it looks as before.": "{0} was changed once so that one of its uses can look different; every other use of it looks as before.",
	"✓ Saved": "✓ Saved",
	"✓ Saved to {0} / {1}": "✓ Saved to {0} / {1}",
	"The words of what you picked {0}": "The words of what you picked {0}"
};
//#endregion
//#region plugins/design/words.ts
/** The table in force. Empty until one is loaded, and English is the keys. */
var words = {};
/** The language actually in use, for a check and for a fault report. */
var using = "en";
/**
* Take a dictionary the page fetched.
*
* Anything that is not a string is dropped rather than drawn: the file is on
* disk beside the plugin and a person may edit it, and a number where a
* sentence was would be drawn as "[object Object]" in a panel.
*/
function useWords(code, table) {
	using = code;
	words = {};
	if (!table || typeof table !== "object") return;
	for (const [key, value] of Object.entries(table)) if (typeof value === "string" && value !== "") words[key] = value;
}
/** One sentence, translated if there is a translation and English if not. */
function say(key) {
	return words[key] ?? key;
}
/**
* A sentence with something of the person's own in it.
*
* The holes are numbered rather than named, so a translator moves them where
* their own language needs them: "drawn in {0} places" is "{0} местах" with
* the number first in some languages and last in others.
*/
function saying(key, ...parts) {
	return say(key).replace(/\{(\d)\}/g, (whole, at) => {
		const part = parts[Number(at)];
		return part === void 0 ? whole : String(part);
	});
}
/** CLDR's plural categories, in the order a translator writes the forms. */
var CATEGORIES = [
	"zero",
	"one",
	"two",
	"few",
	"many",
	"other"
];
/**
* A sentence with a count in it, in the form the language wants for that
* count: "Save 1 change", "Save 3 changes"; in Russian «1 правку», «3 правки»,
* «5 правок» (UX review of 23 September 2026, item 9, FM-DESIGN-111).
*
* The forms are written in one line, apart by " | ", in the order of the
* categories the language has; a line with fewer forms than categories
* lends its last form to the rest, and a line with one form is that form for
* every count.
*/
function counted(key, n) {
	const forms = say(key).split(" | ");
	let which = 0;
	try {
		const rules = new Intl.PluralRules(using);
		const has = rules.resolvedOptions().pluralCategories;
		const order = CATEGORIES.filter((c) => has.includes(c));
		which = Math.min(order.indexOf(rules.select(n)), forms.length - 1);
	} catch {
		which = n === 1 ? 0 : forms.length - 1;
	}
	return forms[Math.max(0, which)].replace(/\{0\}/g, String(n));
}
/**
* Fetch the dictionary for a language, falling back to English.
*
* The page is served by the program on its own scheme, so this is an ordinary
* relative fetch — and a language we do not carry is not a failure: English is
* the keys, and the panel reads in English rather than not at all.
*/
async function loadWords(code, get = fetch) {
	const wanted = code.split(/[-_]/)[0] || "en";
	if (wanted !== "en") try {
		const answer = await get(`./words/${wanted}.json`);
		if (!answer.ok) throw new Error(String(answer.status));
		useWords(wanted, await answer.json());
		return;
	} catch {}
	useWords("en", en_default);
}
//#endregion
//#region plugins/design/view.ts
/**
* The name of a copied design, when that is what this address is.
*
* One shape and nothing near it: the program writes these addresses itself.
*/
var copyNamed = (address) => {
	if (!address) return null;
	const m = /^vobuda-design:\/\/[^/]*\/copy\/[^/]+\/([^/?#]+)$/.exec(address.trim());
	return m ? decodeURIComponent(m[1]) : null;
};
/**
* What the panel shows, given everything.
*
* The order of the questions is the order a person meets them, and the first
* one that is not yet answered is the one on the screen.
*/
function shown(state) {
	const changes = settle(state.rules).length;
	const out = decided(state, changes);
	out.canBuild = !!copyNamed(state.address) && !state.build && !state.site;
	const done = state.steps ?? [];
	const ahead = state.ahead ?? [];
	if ((done.length || ahead.length) && ![
		"ask",
		"waiting",
		"site",
		"build"
	].includes(out.section.kind)) out.history = {
		names: [...done, ...ahead].map((s) => s.name),
		at: done.length
	};
	return out;
}
function decided(state, changes) {
	const keep = keepStanding(state, changes);
	const where = whereSaying(state);
	const notes = [.../* @__PURE__ */ new Set([...changes === 0 ? state.kept ?? [] : [], ...state.notes])];
	const tools = toolsStanding(state);
	if (state.moved.length) return {
		where,
		tools,
		section: {
			kind: "moved",
			moved: state.moved
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	if (state.build) return {
		where,
		tools,
		section: {
			kind: "build",
			build: state.build,
			canChoose: state.canChoose ?? false
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	if (!state.address || state.site) return {
		where,
		tools,
		section: state.site ? {
			kind: "site",
			site: state.site,
			servers: (state.servers ?? []).filter((one) => one.mine)
		} : {
			kind: "waiting",
			servers: state.servers ?? []
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	if (state.mode === "ask") return {
		where,
		tools,
		section: {
			kind: "ask",
			address: state.address,
			picked: state.picked,
			sent: state.sent
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	if (state.mode === "look" || !(state.stamped || state.framework !== null)) return {
		where,
		tools,
		section: {
			kind: "look",
			address: copyNamed(state.address) ?? state.address,
			framework: state.framework,
			stamped: state.stamped,
			taught: !!state.taught,
			whose: state.whose ?? null
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	if (!state.stamped) notes.push(state.framework ? saying("This is a {0} site that does not yet mark where each part is written. What you change shows on the page; saving it into the files needs “Teach my site's build”.", state.framework) : say("This page is not your site's folder open here, so changes stay in the copy, not in anybody's files."));
	if (!state.picked) return {
		where,
		tools,
		section: { kind: "point" },
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
	return {
		where,
		tools,
		section: {
			kind: "element",
			picked: state.picked,
			drawn: state.drawn,
			palette: state.palette,
			behind: state.behind,
			spectrum: spectrum(),
			canKeep: state.stamped && state.picked.origin !== null
		},
		keep,
		notes,
		working: state.working,
		hand: state.hand
	};
}
/**
* What the three can do right now.
*
* A button that cannot be pressed says why on itself rather than going quiet:
* every round of this plugin that a person lost an evening to was a control
* that looked pressable and did nothing.
*/
function toolsStanding(state) {
	const noPage = say("Open a site in the page beside this one first.");
	if (!state.address) return {
		copy: {
			can: false,
			why: noPage
		},
		edit: {
			can: false,
			on: false,
			why: noPage
		},
		ask: {
			can: false,
			on: false,
			why: noPage
		}
	};
	const mine = state.stamped || state.framework !== null;
	const copyFirst = say("A site that is not yours is not edited. Copy the design and change the copy.");
	if (state.working) return {
		copy: {
			can: false,
			why: say("One moment.")
		},
		edit: {
			can: mine,
			on: mine && state.mode === "edit",
			why: mine ? void 0 : copyFirst
		},
		ask: {
			can: true,
			on: state.mode === "ask"
		}
	};
	return {
		copy: { can: true },
		edit: {
			can: mine,
			on: mine && state.mode === "edit",
			why: mine ? void 0 : copyFirst
		},
		ask: {
			can: true,
			on: state.mode === "ask"
		}
	};
}
function keepStanding(state, changes) {
	if (changes === 0) {
		if (state.savedAt) {
			const [folder, file] = state.savedAt.split("/").slice(-2);
			return {
				can: false,
				why: saying("✓ Saved to {0} / {1}", folder ?? "", file ?? ""),
				changes,
				saved: true,
				at: state.savedAt
			};
		}
		if (state.wrote?.length) {
			const once = (state.passed ?? []).map((file) => saying("{0} was changed once so that one of its uses can look different; every other use of it looks as before.", file));
			return {
				can: false,
				why: [saying("Saved into {0}. The panel cannot take this back yet.", state.wrote.join(", ")), ...once].join(" "),
				changes,
				saved: true
			};
		}
		return {
			can: false,
			why: say("Nothing has been changed yet."),
			changes
		};
	}
	if (!copyNamed(state.address) && state.whose) return {
		can: false,
		why: state.whose,
		changes
	};
	if (!state.stamped) return {
		can: false,
		why: say("This page does not say where each part is written, so changes cannot be saved into files. Copy the design and change the copy."),
		changes
	};
	if (state.working) return {
		can: false,
		why: say("One moment."),
		changes
	};
	return {
		can: true,
		changes
	};
}
function whereSaying(state) {
	const copy = copyNamed(state.address);
	if (copy) return copy;
	if (state.address) return state.address.replace(/^https?:\/\//, "");
	if (state.framework) return state.framework;
	return "";
}
/**
* The properties offered with a minus and a plus, and what they are now.
*
* Two filters, and the second one was found by a check rather than by thinking.
* The element must actually have a value — a nudge on a property it does not
* use moves nothing. And the value must be one a step means something to: a
* colour has a value and cannot be stepped, so offering it two buttons is
* offering two buttons that do nothing, which is the very thing the first
* filter was written to prevent. Colours belong to the palette.
*/
function nudgesFor(drawn, offered) {
	return offered.filter((p) => (drawn[p] ?? "").trim() && drawn[p] !== "none" && drawn[p] !== "normal").filter((p) => canStep(p, drawn[p])).map((property) => ({
		property,
		value: drawn[property]
	}));
}
/** Whether a minus and a plus would move this value at all. */
function canStep(property, value) {
	if (property === "font-weight") return Number.isFinite(Number(value.trim()));
	return /^-?\d*\.?\d+(px|rem|em|%|vh|vw|pt)$/.test(value.trim());
}
//#endregion
//#region plugins/design/history.ts
/**
* The words a person would use for each property the panel changes.
*
* Each is a sentence of the plugin's own, asked for where the words check
* can read it, and translated the way every other line of the panel is
* (FM-DESIGN-16). A property nobody has
* put a word to is shown as it is.
*/
var PLAIN = {
	color: () => say("Text colour"),
	"-webkit-text-fill-color": () => say("Text colour"),
	"background-color": () => say("Background colour"),
	"background-image": () => say("Background picture"),
	"font-size": () => say("Text size"),
	"font-weight": () => say("Boldness"),
	"line-height": () => say("Line spacing"),
	"letter-spacing": () => say("Letter spacing"),
	margin: () => say("Space around"),
	padding: () => say("Space inside"),
	gap: () => say("Space between"),
	"border-radius": () => say("Rounded corners"),
	"border-color": () => say("Border colour"),
	"border-width": () => say("Border thickness"),
	"box-shadow": () => say("Shadow"),
	"text-align": () => say("Alignment"),
	opacity: () => say("See-through"),
	[WORDS]: () => say("Words")
};
/** A property in a person's words. */
function plainName(property) {
	return PLAIN[property]?.() ?? property;
}
/** What a step is called: the element, what changed on it, and to what. */
function stepName(what, rule) {
	const value = rule.property === "#text" ? `“${short(rule.value)}”` : rule.value;
	return `${what} — ${plainName(rule.property)} ${value}`;
}
var short = (s) => {
	const one = s.trim().replace(/\s+/g, " ");
	return one.length <= 24 ? one : `${one.slice(0, 22)}…`;
};
/** A new step: it goes on the end, and whatever was returned from is gone. */
function made(walk, step) {
	return {
		done: [...walk.done, step],
		ahead: []
	};
}
/**
* The session as it stood after `count` steps, from anywhere in it.
*
* Every step, drawn or returned from, stays in its place: going back to two of
* five and forward to four is the same list read to a different depth.
*/
function backTo(walk, count) {
	const all = [...walk.done, ...walk.ahead];
	const at = Math.max(0, Math.min(count, all.length));
	return {
		done: all.slice(0, at),
		ahead: all.slice(at)
	};
}
/** The draft the page is drawn with: every rule of every step drawn now. */
var drawnRules = (walk) => walk.done.flatMap((s) => s.rules);
//#endregion
//#region plugins/design/draw.ts
var el = (doc, tag, className, text) => {
	const node = doc.createElement(tag);
	if (className) node.className = className;
	if (text !== void 0) node.textContent = text;
	return node;
};
function button(doc, label, onPress, className = "", named = "") {
	const b = el(doc, "button", className, label);
	if (named) b.setAttribute("aria-label", named);
	b.addEventListener("click", onPress);
	return b;
}
/** Put the whole panel on the page. */
function draw(doc, shown, on) {
	const root = doc.getElementById("designer");
	const body = doc.getElementById("body");
	const foot = doc.getElementById("foot");
	const where = doc.getElementById("where");
	if (!root || !body || !foot || !where) return;
	root.classList.toggle("working", shown.working);
	where.textContent = shown.where;
	const had = doc.activeElement;
	const wasIn = had?.getAttribute("aria-label") ?? null;
	const caret = had instanceof HTMLTextAreaElement || had instanceof HTMLInputElement ? {
		from: had.selectionStart,
		to: had.selectionEnd
	} : null;
	body.replaceChildren();
	foot.replaceChildren();
	body.appendChild(toolbar(doc, shown, on));
	if (shown.canBuild) {
		const row = el(doc, "div", "row build-offer");
		const b = button(doc, say("Build my site from this"), on.build, "", say("Build my site from this"));
		b.setAttribute("data-id", "design.build");
		row.appendChild(b);
		body.appendChild(row);
	}
	body.appendChild(sectionOf(doc, shown, on));
	if (shown.section.kind !== "ask") for (const note of shown.notes) body.appendChild(el(doc, "p", "note plain", note));
	if (shown.history) body.appendChild(historyOf(doc, shown.history, on));
	if (shown.keep.saved) {
		const done = button(doc, say("✓ Saved"), on.keep, "keep saved", say("Save changes"));
		done.disabled = true;
		done.setAttribute("data-id", "design.save");
		if (shown.keep.why) done.title = shown.keep.why;
		foot.appendChild(done);
		if (shown.keep.at && on.reveal) {
			const at = shown.keep.at;
			const show = button(doc, say("Show in Finder"), () => on.reveal?.(at), "reveal");
			show.setAttribute("data-id", "design.reveal");
			foot.appendChild(show);
		}
		if (shown.keep.why) foot.appendChild(el(doc, "span", "said saved", ` ${shown.keep.why}`));
	} else {
		const keep = button(doc, shown.keep.changes ? counted("Save {0} changes", shown.keep.changes) : say("Save"), on.keep, shown.keep.changes ? "keep primary" : "keep", say("Save changes"));
		keep.setAttribute("data-id", "design.save");
		keep.disabled = !shown.keep.can;
		if (shown.keep.why) keep.title = shown.keep.why;
		foot.appendChild(keep);
		if (shown.keep.changes) {
			const back = button(doc, say("Put back all edits of the page"), on.revert, "back", say("Put back all edits of the page"));
			back.setAttribute("data-id", "design.revert");
			back.title = say("Everything changed here goes back to what the file has.");
			foot.appendChild(back);
		}
		if (shown.keep.why) foot.appendChild(el(doc, "span", "said", ` ${shown.keep.why}`));
	}
	foot.appendChild(where);
	where.hidden = !!shown.keep.saved;
	if (shown.keep.saved) where.textContent = "";
	if (wasIn) {
		const again = root.querySelector(`[aria-label="${wasIn.replace(/["\\]/g, "\\$&")}"]`);
		if (again && again !== doc.activeElement) {
			again.focus();
			if (caret && (again instanceof HTMLTextAreaElement || again instanceof HTMLInputElement)) try {
				again.setSelectionRange(caret.from, caret.to);
			} catch {}
		}
	}
}
/**
* Every change of the session, in a person's words, each one a way back to
* that moment — and forward again, for as long as nothing new is changed
* (story 54-3, FM-DESIGN-116).
*
* Each entry's name is its number and its words, so it can be pressed by name
* from the command line, and no name begins like one of the program's own.
*/
function historyOf(doc, history, on) {
	const box = el(doc, "section", "history");
	box.appendChild(el(doc, "h3", void 0, say("Changes, oldest first")));
	const list = el(doc, "ol", "steps");
	const entry = (count, label) => {
		const b = button(doc, label, () => on.backTo(count), count > history.at ? "step ahead" : "step", label);
		b.setAttribute("data-id", `design.step.${count}`);
		if (count === history.at) {
			b.setAttribute("aria-current", "step");
			b.classList.add("now");
		}
		const item = el(doc, "li");
		item.appendChild(b);
		list.appendChild(item);
	};
	entry(0, `0. ${say("The page before any change")}`);
	history.names.forEach((name, i) => entry(i + 1, `${i + 1}. ${name}`));
	box.appendChild(list);
	if (history.at < history.names.length) box.appendChild(el(doc, "p", "said", say("Greyed steps were taken back. Press one to go forward to it; a new change drops them.")));
	return box;
}
/**
* The first step on one's own site: the folder, then the three things the road
* needs — a kind of site the designer knows, its preview running, a build that
* marks where each part is written — each with its state in plain words and
* the one press that fixes it (story 54-1, CAP-10, FM-DESIGN-118).
*
* Every name here begins with words no control of the program's begins with,
* so a press by name from the command line lands on this panel.
*/
function siteOf(doc, card, s, on) {
	const { site } = s;
	const named = (label, press, id, className = "") => {
		const b = button(doc, label, press, className, label);
		b.setAttribute("data-id", id);
		return b;
	};
	card.appendChild(el(doc, "h2", void 0, say("Edit my site")));
	card.appendChild(el(doc, "p", "said", say("Three things are needed to change your site here and save the changes into its files.")));
	const folder = el(doc, "div", "row folder");
	folder.appendChild(el(doc, "p", "said", site.folder ? saying("Your site's folder: {0}", site.folder.split("/").slice(-2).join("/")) : say("No folder yet: choose the folder your site is in.")));
	if (site.canChoose) folder.appendChild(named(say("Choose my site's folder"), on.choose, "design.folder"));
	card.appendChild(folder);
	if (!site.checked) {
		card.appendChild(el(doc, "p", "said", say("Looking at the folder…")));
		return card;
	}
	const list = el(doc, "ol", "needs");
	const need = (ok, text, press) => {
		const item = el(doc, "li", ok ? "need ok" : "need");
		item.appendChild(el(doc, "span", "mark", ok ? "✓" : "!"));
		item.appendChild(el(doc, "span", "said", text));
		if (press) item.appendChild(press);
		list.appendChild(item);
	};
	need(!!site.framework, site.framework ? saying("A kind of site the designer knows: {0}.", site.framework) : saying("The designer does not know this kind of site. It knows {0}. Choose the folder that holds your site's settings file — or copy the design of any page instead.", site.known.join(", ")));
	const running = s.servers[0];
	if (running) need(true, saying("Its preview is running at localhost:{0}. The preview is the program that shows your site while you work on it.", running.port), named(say("Open my site's preview"), () => on.server(running.port), "design.preview"));
	else if (site.starting) need(false, saying("Starting it with “{0}” in the block below. Once it is up the block folds into the strip at the bottom and the page opens here by itself; if it stops, the block opens again to show why.", site.starting));
	else need(false, say("Its preview is not running. The preview is the program that shows your site while you work on it."), site.framework && site.canStart ? named(say("Start my site's preview"), on.serve, "design.serve", "primary") : void 0);
	need(site.taught, site.taught ? say("It marks where each part of a page is written, so what you change can be saved into those files.") : say("It does not yet mark where each part of a page is written, so changes could be looked at but not saved. Teaching adds one small file beside its settings; it can be taken back."), site.framework && !site.taught ? named(say("Teach my site's build"), on.teachSite, "design.teachsite") : void 0);
	card.appendChild(list);
	const back = el(doc, "div", "row");
	back.appendChild(named(say("Leave this first step"), on.leaveSite, "design.leavesite"));
	card.appendChild(back);
	return card;
}
/**
* "Build my site from this": what the site is about and where it goes, asked
* here and not in the agent's block; then the agent at work; then what the
* check found of the original's, or that it found nothing (story 54-5,
* CAP-9, FM-DESIGN-120).
*/
function buildOf(doc, card, s, on) {
	const { build } = s;
	const named = (label, press, id, className = "") => {
		const b = button(doc, label, press, className, label);
		b.setAttribute("data-id", id);
		return b;
	};
	card.appendChild(el(doc, "h2", void 0, say("Build my site from this")));
	card.appendChild(el(doc, "p", "said", say("The agent builds a site of your own from this copy: its layout, spacing, text sizes and colours — and none of its words, pictures, logos or names.")));
	if (build.stage === "asking") {
		const about = el(doc, "textarea", "said");
		about.value = build.about;
		about.placeholder = say("A bakery in Lviv: the menu, opening hours and how to order");
		about.setAttribute("aria-label", say("What my site is about"));
		about.addEventListener("input", () => on.buildAbout(about.value));
		card.appendChild(el(doc, "label", "said", say("What is your site about?")));
		card.appendChild(about);
		const where = el(doc, "div", "row folder");
		where.appendChild(el(doc, "p", "said", build.folder ? saying("It goes into {0}", build.folder.split("/").slice(-2).join("/")) : say("Where does it go? Pick an empty folder, or the folder of a site of yours.")));
		if (s.canChoose) where.appendChild(named(say("Choose where my site goes"), on.buildWhere, "design.buildwhere"));
		card.appendChild(where);
		const go = named(say("Start building my site"), on.buildGo, "design.buildgo", "primary");
		go.disabled = !build.about.trim() || !build.folder;
		if (go.disabled) go.title = say("Say what the site is about and where it goes first.");
		const row = el(doc, "div", "row");
		row.appendChild(go);
		row.appendChild(named(say("Leave the building"), on.buildLeave, "design.buildleave"));
		card.appendChild(row);
		return card;
	}
	if (build.stage === "building" || build.stage === "checking") {
		card.appendChild(el(doc, "p", "said", build.stage === "building" ? say("The agent is building it. Its answer comes back here, and then what it built is checked against this copy.") : say("Checking what was built against this copy…")));
		const row = el(doc, "div", "row");
		row.appendChild(named(say("Leave the building"), on.buildLeave, "design.buildleave"));
		card.appendChild(row);
		return card;
	}
	if (build.stage === "leaks") {
		card.appendChild(el(doc, "p", "note warn", say("What was built still carries these of the original's:")));
		const list = el(doc, "ul", "leaks");
		for (const leak of build.leaks) {
			const kind = leak.kind === "words" ? say("words") : leak.kind === "picture" ? say("picture") : say("name");
			list.appendChild(el(doc, "li", "said", `${kind}: “${leak.what}” — ${leak.file}`));
		}
		card.appendChild(list);
		const row = el(doc, "div", "row");
		row.appendChild(named(say("Ask the agent to take these out"), on.buildFix, "design.buildfix", "primary"));
		row.appendChild(named(say("Leave the building"), on.buildLeave, "design.buildleave"));
		card.appendChild(row);
		return card;
	}
	card.appendChild(el(doc, "p", "said", say("Your site is built, and it carries none of the original's words, pictures or names.")));
	const row = el(doc, "div", "row");
	row.appendChild(named(say("Edit my new site"), on.buildOpen, "design.buildopen", "primary"));
	card.appendChild(row);
	return card;
}
/**
* The three the whole tool is: copy the design, change it, ask the agent.
*
* Always drawn and always in the same order, whatever is happening below them.
* A toolbar that appears and disappears is a toolbar people learn twice, and
* each of the three is a whole way of working rather than a step of one.
*/
function toolbar(doc, shown, on) {
	const row = el(doc, "div", "tools");
	const one = (label, what, press, id) => {
		const b = button(doc, label, press, what.on ? "tool on" : "tool");
		b.setAttribute("data-id", id);
		b.disabled = !what.can;
		if (what.why) b.title = what.why;
		if (what.on) b.setAttribute("aria-pressed", "true");
		row.appendChild(b);
	};
	one(say("Copy the design"), shown.tools.copy, on.copy, "design.copy");
	one(say("Edit"), shown.tools.edit, on.edit, "design.edit");
	one(say("Ask the agent"), shown.tools.ask, on.talk, "design.ask");
	const whys = [
		shown.tools.copy,
		shown.tools.edit,
		shown.tools.ask
	].filter((w) => !w.can && w.why).map((w) => w.why);
	if (whys.length) row.appendChild(el(doc, "span", "said why", [...new Set(whys)].join(" ")));
	return row;
}
function sectionOf(doc, shown, on) {
	const card = el(doc, "section", "card");
	const s = shown.section;
	if (s.kind === "site") return siteOf(doc, card, s, on);
	if (s.kind === "build") return buildOf(doc, card, s, on);
	if (s.kind === "waiting") {
		card.appendChild(el(doc, "h2", void 0, say("Nothing open beside this yet")));
		const start = el(doc, "div", "row");
		const mine = button(doc, say("Edit my site"), on.mysite, "primary", say("Edit my site"));
		mine.setAttribute("data-id", "design.mysite");
		start.appendChild(mine);
		card.appendChild(start);
		const known = s.servers.filter((one) => one.mine || one.folder);
		const others = s.servers.filter((one) => !one.mine && !one.folder);
		const serverButton = (one) => {
			const where = one.mine ? say("this window's folder") : one.folder ? `…/${one.folder.split("/").slice(-2).join("/")}` : say("folder not known");
			return button(doc, `localhost:${one.port} · ${where}`, () => on.server(one.port), one.mine ? "mine" : "", `localhost:${one.port}`);
		};
		if (known.length) {
			card.appendChild(el(doc, "p", "said", say("Running on this computer:")));
			const row = el(doc, "div", "servers");
			for (const one of known) row.appendChild(serverButton(one));
			card.appendChild(row);
		}
		if (others.length) {
			const more = el(doc, "details", "servers-other");
			more.appendChild(el(doc, "summary", "said", counted("Other sites ({0})", others.length)));
			const row = el(doc, "div", "servers");
			for (const one of others) row.appendChild(serverButton(one));
			more.appendChild(row);
			card.appendChild(more);
		}
		card.appendChild(el(doc, "p", "said", say("The block beside this one is an ordinary page: type any site's address into it to copy its design, or press “Edit my site” to work on your own.")));
		return card;
	}
	if (s.kind === "look") {
		card.appendChild(el(doc, "h2", void 0, s.address.replace(/^https?:\/\//, "")));
		card.appendChild(el(doc, "p", "said", s.stamped ? say("This page says where each part is written, so what you change can be saved into those files.") : say("Press “Copy the design”. The copy opens beside this one, and the copy is what you change.")));
		if (s.whose) card.appendChild(el(doc, "p", "said", s.whose));
		if (!s.stamped && !copyNamed(s.address)) {
			const row = el(doc, "div", "row");
			const mine = button(doc, say("Edit my site"), on.mysite, "", say("Edit my site"));
			mine.setAttribute("data-id", "design.mysite");
			row.appendChild(mine);
			card.appendChild(row);
		}
		if (s.framework && !s.stamped && !s.taught) {
			card.appendChild(el(doc, "p", "said", saying("This is your {0} site.", s.framework)));
			const row = el(doc, "div", "row");
			row.appendChild(button(doc, say("Teach my site's build"), on.teach));
			card.appendChild(row);
		} else if (s.framework && s.taught) {
			if (!s.stamped) card.appendChild(el(doc, "p", "said", say("Your site now marks its parts. Its preview restarts by itself; if this page still has nothing to change after a few seconds, stop the preview in its block (Control-C) and start it again.")));
			const row = el(doc, "div", "row");
			row.appendChild(button(doc, say("Take the teaching back"), on.untaught));
			card.appendChild(row);
		}
		return card;
	}
	if (s.kind === "ask") {
		card.appendChild(el(doc, "h2", void 0, say("Ask the agent")));
		card.appendChild(el(doc, "p", "said", s.picked ? saying("It will be told about {0} and about the page beside this one.", s.picked.what) : say("It will be told which page is beside this one. Point at something first if you mean one thing on it.")));
		for (const one of s.sent) card.appendChild(el(doc, "p", one.mine ? "note plain mine" : "note plain theirs", one.text));
		for (const note of shown.notes) card.appendChild(el(doc, "p", "note plain status", note));
		const said = el(doc, "textarea");
		said.placeholder = say("Say what you want");
		said.setAttribute("aria-label", say("What you want"));
		const send = () => {
			on.ask(said.value);
			said.value = "";
		};
		said.addEventListener("keydown", (e) => {
			const k = e;
			if (k.key === "Enter" && (k.metaKey || k.ctrlKey)) {
				e.preventDefault();
				send();
			}
		});
		card.appendChild(said);
		const row = el(doc, "div", "row");
		row.appendChild(button(doc, say("Send"), send, "asks"));
		card.appendChild(row);
		return card;
	}
	if (s.kind === "point") {
		card.appendChild(el(doc, "h2", void 0, say("Point at something")));
		card.appendChild(el(doc, "p", "said", say("Move over the page beside this and press what you want to change.")));
		return card;
	}
	if (s.kind === "moved") {
		card.appendChild(el(doc, "h2", void 0, say("What the page did not do")));
		card.appendChild(el(doc, "p", "said", say("Saved, but these look different on the page than before saving: a style already in your site takes precedence.")));
		for (const m of s.moved) card.appendChild(el(doc, "p", "note warn", `${m.rule.origin ? `${m.rule.origin.file}:${m.rule.origin.line}` : m.rule.at} — ` + saying("{0} is {1} on the page, not {2}", plainName(m.rule.property), m.given, m.promised)));
		return card;
	}
	const chosen = el(doc, "div", "chosen");
	const runs = s.picked.words ?? [];
	if (runs.length) runs.forEach((run, i) => {
		const field = doc.createElement("textarea");
		field.className = "said";
		field.value = run.text;
		field.rows = 2;
		field.setAttribute("aria-label", runs.length > 1 ? saying("The words of what you picked {0}", i + 1) : say("The words of what you picked"));
		field.setAttribute("data-id", runs.length > 1 ? `design.words.${i + 1}` : "design.words");
		if (runs.length > 1) chosen.appendChild(el(doc, "span", "run-what", run.what));
		if (run.code) {
			field.readOnly = true;
			field.classList.add("code");
			chosen.appendChild(field);
			if (runs.findIndex((r) => r.code) === i) chosen.appendChild(el(doc, "span", "code-words", say("These words are made by the site's code, so they cannot be written from here. Ask the agent to change them.")));
			field.addEventListener("focus", () => on.hand(i));
			return;
		}
		field.addEventListener("input", () => on.word(field.value, i));
		field.addEventListener("focus", () => on.hand(i));
		if (runs.length > 1 && i === shown.hand) field.classList.add("in-hand");
		chosen.appendChild(field);
	});
	else chosen.appendChild(el(doc, "span", "what", s.picked.what));
	chosen.appendChild(el(doc, "span", "from", s.picked.origin ? `${s.picked.what} · ${s.picked.origin.file}:${s.picked.origin.line}` : `${s.picked.what} · ${say("where it is written is not known")}`));
	if (s.picked.siblings > 1) chosen.appendChild(el(doc, "span", "drawn", saying("drawn in {0} places", s.picked.siblings)));
	card.appendChild(chosen);
	const offered = nudgesFor(s.drawn, MECHANICAL);
	if (offered.length) {
		const nudges = el(doc, "div", "nudges");
		for (const { property, value } of offered) {
			const name = el(doc, "span", "name", plainName(property));
			name.setAttribute("data-property", property);
			nudges.appendChild(name);
			const shownValue = el(doc, "span", "value", value);
			nudges.appendChild(shownValue);
			const row = el(doc, "span", "row");
			row.appendChild(button(doc, "−", () => on.nudge(property, -1), "", `${property} −`));
			row.appendChild(button(doc, "+", () => on.nudge(property, 1), "", `${property} +`));
			nudges.appendChild(row);
		}
		card.appendChild(nudges);
	}
	const aligned = el(doc, "div", "aligns");
	aligned.appendChild(el(doc, "span", "name", say("Alignment")));
	const alignRow = el(doc, "span", "row");
	const alignments = [
		["left", say("Left")],
		["center", say("Centre")],
		["right", say("Right")]
	];
	for (const [value, label] of alignments) {
		const b = button(doc, label, () => on.align(value), "", `align ${value}`);
		if (s.drawn["text-align"] === value) b.setAttribute("aria-pressed", "true");
		alignRow.appendChild(b);
	}
	aligned.appendChild(alignRow);
	card.appendChild(aligned);
	const paint = (target, label, mine) => {
		const rest = s.spectrum.filter((c) => !mine.includes(c));
		if (!mine.length && !rest.length) return;
		const band = el(doc, "div", "paint");
		band.appendChild(el(doc, "span", "name", label));
		const swatches = el(doc, "div", "swatches");
		const swatch = (colour) => {
			const b = button(doc, "", () => on.colour(colour, target), "swatch", `colour ${target === "color" ? "text" : "background"} ${colour}`);
			b.style.background = colour;
			b.title = colour;
			if (colour === (target === "color" && runs.length ? runs[Math.min(shown.hand, runs.length - 1)].colour : s.drawn[target])) b.setAttribute("aria-current", "true");
			swatches.appendChild(b);
		};
		for (const colour of mine) swatch(colour);
		if (mine.length && rest.length) swatches.appendChild(el(doc, "span", "seam"));
		for (const colour of rest) swatch(colour);
		band.appendChild(swatches);
		card.appendChild(band);
	};
	paint("color", say("Text"), s.palette);
	paint("background-color", say("Background"), s.behind);
	const row = el(doc, "div", "row");
	row.appendChild(button(doc, say("Undo"), on.undo));
	if (s.picked.siblings > 1 && s.canKeep) row.appendChild(button(doc, say("Only here / everywhere"), on.scope));
	card.appendChild(row);
	if (!s.canKeep) card.appendChild(el(doc, "p", "said", say("Changes here are on the page in front of you. Copy the design to keep them.")));
	return card;
}
/**
* The same card the window lays over the agent's block, drawn in the panel.
*
* The panel used to repeat the agent's raw lines — "Enter to confirm · Esc to
* cancel", "↓ 2. Yes, allow reading from /private/tmp/…" — under a sentence
* telling the person to answer somewhere else (UX review of 23 September
* 2026, item 2). The words come from the window, already in its language; a
* press goes back to the window, which sends the agent the keys a hand would
* (FM-AGENT-88).
*/
function questionCard(doc, card, answer) {
	const box = el(doc, "section", "card agent-question");
	box.appendChild(el(doc, "h2", void 0, card.heading));
	if (card.note) box.appendChild(el(doc, "p", card.trust ? "said" : "said mono", card.note));
	const row = el(doc, "div", "row");
	const one = (label, choice, id, className) => {
		const b = button(doc, label, () => answer(choice), className);
		b.setAttribute("data-id", id);
		row.appendChild(b);
	};
	one(card.yes, "yes", card.trust ? "trust.yes" : "permission.once", "primary");
	one(card.no, "no", card.trust ? "trust.no" : "permission.no", "");
	if (card.always) one(card.always, "always", "permission.always", "quiet");
	box.appendChild(row);
	return box;
}
//#endregion
//#region plugins/design/frameworks/boundary.ts
/**
* The frameworks this designer knows, in the order they are tried.
*
* A list rather than a lookup by name: the project is asked what it is, never
* the person. Registered here and nowhere else, so that the answer to "which
* frameworks does this work with" is one file to read.
*/
var KNOWN = [];
function register(framework) {
	if (KNOWN.some((f) => f.name === framework.name)) return;
	KNOWN.push(framework);
}
var known = () => KNOWN;
/**
* Which of a given set this project is, or none.
*
* Takes the set rather than reading the register, so that the decision can be
* driven by a check with exactly the frameworks the check means. A decision
* that can only be asked through a module-level list is a decision whose checks
* pollute each other, and the assertions go vacuous without anybody noticing.
*/
async function pick(frameworks, files) {
	for (const f of frameworks) if (await f.looksLikeMine(files)) return f;
	return null;
}
//#endregion
//#region plugins/design/keep.ts
/** Every rule as a change a writer understands, newest word on each place. */
function changesOf(rules) {
	const out = [];
	for (const r of settle(rules)) {
		if (!r.origin) continue;
		out.push({
			origin: r.origin,
			property: r.property,
			value: r.value,
			everywhere: r.everywhere,
			part: r.part
		});
	}
	return out;
}
/**
* Put the draft into the project's own files.
*
* Nothing is written when nothing can be: a folder no framework here claims is
* a refusal with a reason, not a silent no-op.
*/
async function keepInto(files, rules, frameworks = known()) {
	const changes = changesOf(rules);
	if (changes.length === 0) return {
		files: [],
		refused: [],
		framework: null
	};
	const framework = await pick(frameworks, files);
	if (!framework) return {
		files: [],
		framework: null,
		refused: changes.map((c) => ({
			where: `${c.origin.file}:${c.origin.line}`,
			why: say("the designer does not know how to save into this kind of site")
		}))
	};
	const written = await framework.write(files, changes);
	return {
		files: written.files,
		passed: written.passed ?? [],
		framework: framework.name,
		refused: written.refused.map((r) => ({
			where: `${r.origin.file}:${r.origin.line}`,
			why: r.why
		}))
	};
}
/**
* Teach this project's build to stamp its elements.
*
* The same road as keeping and for the same reason: a person's own config is
* edited, through the framework that owns its shape, through the one door the
* window granted. It used to be a message sent into the page being designed —
* which has no such case, so it fell through to "stop" and the button killed
* the designer instead of teaching anything (FM-DESIGN-24).
*/
async function teachIn(files, frameworks = known()) {
	const framework = await pick(frameworks, files);
	if (!framework) return {
		files: [],
		framework: null,
		why: say("the designer does not know how to teach this kind of site")
	};
	try {
		const { files: changed } = await framework.stamp(files);
		return {
			files: changed,
			framework: framework.name,
			why: null
		};
	} catch (e) {
		return {
			files: [],
			framework: framework.name,
			why: String(e instanceof Error ? e.message : e)
		};
	}
}
/**
* Take the teaching back: what "Teach the build" wrote comes out, exactly.
*
* There because teaching once had no way back at all: the dev server did not
* start, and the panel had nothing to offer but the sentence that had caused it
* (FM-DESIGN-88).
*/
async function untaughtIn(files, frameworks = known()) {
	const framework = await pick(frameworks, files);
	if (!framework) return {
		files: [],
		framework: null,
		why: say("the designer does not know how to teach this kind of site")
	};
	try {
		const { files: changed } = await framework.unstamp(files);
		return {
			files: changed,
			framework: framework.name,
			why: null
		};
	} catch (e) {
		return {
			files: [],
			framework: framework.name,
			why: String(e instanceof Error ? e.message : e)
		};
	}
}
/** Whether this project's build carries the stamper, asked of its own files. */
async function isTaught(files, frameworks = known()) {
	const framework = await pick(frameworks, files);
	return framework ? framework.isStamped(files) : false;
}
/**
* What build this project uses, or nothing.
*
* Asked of the project's own files, never of the person: somebody opening a
* folder should not have to know what their build is called. The answer drives
* the first screen, and with nobody asking the question the panel spent a live
* evening saying it did not know what this folder was (FM-DESIGN-26).
*/
async function whatProjectIsThis(files, frameworks = known()) {
	const framework = await pick(frameworks, files);
	return framework ? framework.name : null;
}
//#endregion
//#region plugins/design/frameworks/astroStamp.ts
/** How the config names it. */
var STAMPER_NAME = "vobudaStamp";
var STAMPER_SOURCE = `// Written by the vobuda designer ("Teach the build"). While \`astro dev\`
// runs, every element of every .astro file here is served marked with where it
// is written — file, line, column — so a change made with the mouse on the page
// can be put back into that place. \`astro build\` is left exactly as it was.
//
// To take it out: "Take the teaching back" in the designer, or delete this file
// and the two lines naming ${STAMPER_NAME} in astro.config.
import { readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { join, relative, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

/** Elements that are not drawn, or that Astro treats specially when marked. */
const SKIP = new Set([
  "html", "head", "meta", "link", "title", "base", "script", "style",
  "slot", "template", "noscript",
]);

/** Where each line starts, so an offset becomes a line and a column. */
function lineStarts(source) {
  const starts = [0];
  for (let i = 0; i < source.length; i++) if (source[i] === "\\n") starts.push(i + 1);
  return starts;
}

function lineAndColumn(starts, offset) {
  let lo = 0;
  let hi = starts.length - 1;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (starts[mid] <= offset) lo = mid;
    else hi = mid - 1;
  }
  return { line: lo + 1, column: offset - starts[lo] + 1 };
}

const escape = (s) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;");

/**
 * The source with every element marked, or the source as it was.
 *
 * Only elements the compiler found where it says they are: an offset that does
 * not land on "<name" is left alone rather than trusted.
 */
export function stampSource(parse, source, file) {
  const { ast } = parse(source);
  const at = [];
  const walk = (node) => {
    if (!node || typeof node !== "object") return;
    if (Array.isArray(node)) {
      for (const n of node) walk(n);
      return;
    }
    if (node.type === "JSXElement" && node.openingElement) {
      const open = node.openingElement;
      const name = open.name;
      if (
        name &&
        name.type === "JSXIdentifier" &&
        /^[a-z][a-z0-9-]*$/.test(name.name) &&
        !SKIP.has(name.name) &&
        source[open.start] === "<" &&
        source.startsWith(name.name, open.start + 1) &&
        name.end === open.start + 1 + name.name.length
      ) {
        // Words the source does not hold as words: set:html, set:text, or an
        // expression among the children. Said on the element, so the designer
        // can say before the edit that such words cannot be written back —
        // the heading of rem-plastic took its text from code, and a changed
        // text was dropped at save without a word (run-in two, FM-DESIGN-99).
        const code =
          (open.attributes || []).some(
            (a) => a && a.name && (a.name.name === "set:html" || a.name.name === "set:text"),
          ) || (node.children || []).some((c) => c && c.type === "JSXExpressionContainer");
        at.push({ start: open.start, after: name.end, code });
      } else if (
        name &&
        name.type === "JSXIdentifier" &&
        /^[A-Z][A-Za-z0-9_]*$/.test(name.name) &&
        name.name !== "Fragment" &&
        source[open.start] === "<" &&
        source.startsWith(name.name, open.start + 1) &&
        name.end === open.start + 1 + name.name.length
      ) {
        // A use of a component: marked with where it is written, which the
        // component's own elements carry on — the place "only here" is written
        // to, since the component's line is shared by every use of it
        // (story 54-6).
        at.push({ start: open.start, after: name.end, use: true });
      }
    }
    for (const key of Object.keys(node)) {
      if (key !== "frontmatter") walk(node[key]);
    }
  };
  walk(ast.body ?? ast);
  if (!at.length) return source;
  const starts = lineStarts(source);
  const where = escape(file);
  let out = source;
  for (const one of at.sort((a, b) => b.after - a.after)) {
    const { line, column } = lineAndColumn(starts, one.start);
    // An element says which use of its component drew it — none, in a page;
    // an attribute whose value is undefined is not written at all.
    const mark = one.use
      ? \` data-vobuda-use="\${where}:\${line}:\${column}"\`
      : \` data-vobuda-file="\${where}" data-vobuda-line="\${line}" data-vobuda-column="\${column}"\` +
        (one.code ? ' data-vobuda-words="code"' : "") +
        ' data-vobuda-use={Astro.props["data-vobuda-use"]}';
    out = out.slice(0, one.after) + mark + out.slice(one.after);
  }
  return out;
}

/** The project's own Astro compiler, found the way Astro itself finds it. */
async function compilerOf(root) {
  const tries = [
    () => import("@astrojs/compiler-rs"),
    async () => {
      const require = createRequire(join(root, "node_modules", "astro", "package.json"));
      return import(pathToFileURL(require.resolve("@astrojs/compiler-rs")).href);
    },
  ];
  for (const t of tries) {
    try {
      const mod = await t();
      if (typeof mod.parse === "function") return mod.parse;
    } catch {
      // the next way
    }
  }
  return null;
}

export default function ${STAMPER_NAME}() {
  return {
    name: "vobuda-stamp",
    hooks: {
      "astro:config:setup": async ({ command, config, updateConfig, logger }) => {
        if (command !== "dev") return;
        const root = fileURLToPath(config.root);
        const parse = await compilerOf(root);
        if (!parse) {
          logger.warn("this Astro has no @astrojs/compiler-rs, so elements are not marked for the vobuda designer");
          return;
        }
        updateConfig({
          vite: {
            plugins: [
              {
                name: "vobuda-stamp",
                // Before Astro's own compile: marking is done on the source.
                enforce: "pre",
                async load(id) {
                  if (id.includes("?") || !id.endsWith(".astro") || id.includes("/node_modules/")) return null;
                  const file = relative(root, id);
                  if (file.startsWith("..")) return null;
                  const source = await readFile(id, "utf8");
                  try {
                    return stampSource(parse, source, file.split(sep).join("/"));
                  } catch (e) {
                    logger.warn(\`\${file} was not marked: \${e && e.message ? e.message : e}\`);
                    return null;
                  }
                },
              },
            ],
          },
        });
      },
    },
  };
}
`;
/** Eight hex characters that change whenever the text does (FNV-1a). */
function fingerprint$2(text) {
	let h = 2166136261;
	for (let i = 0; i < text.length; i++) {
		h ^= text.charCodeAt(i);
		h = Math.imul(h, 16777619) >>> 0;
	}
	return h.toString(16).padStart(8, "0");
}
/**
* The file the stamper lives in, beside the config, named by what is in it.
*
* A running `astro dev` keeps every module it imported under its path for as
* long as the process lives. With one name for every stamper, "Take the
* teaching back" and "Teach the build" with a newer one restarted the server
* by itself and it went on marking with the old module — only stopping it by
* hand picked the new one up (live run of FM-DESIGN-99, 22 September 2026). A
* new stamper is a new name, so the config names a file no process has seen
* (FM-DESIGN-113).
*/
var STAMPER_FILE = `vobuda-stamp-${fingerprint$2(STAMPER_SOURCE)}.mjs`;
/** The line that brings it into the config. */
var STAMPER_IMPORT = `import ${STAMPER_NAME} from "./${STAMPER_FILE}";\n`;
/**
* The line any teaching ever wrote, whichever stamper it named — the first
* ones were all `vobuda-stamp.mjs` — with that file's name as its group.
*/
var STAMPER_IMPORTED = new RegExp(`^import ${STAMPER_NAME} from "\\./(vobuda-stamp[\\w-]*\\.mjs)";\\n`, "m");
//#endregion
//#region plugins/design/frameworks/tag.ts
/** The index in `text` of a line and column, or -1. */
function indexAt(text, at) {
	if (at.line < 1 || at.column < 1) return -1;
	let i = 0;
	for (let line = 1; line < at.line; line++) {
		const nl = text.indexOf("\n", i);
		if (nl === -1) return -1;
		i = nl + 1;
	}
	const lineEnd = text.indexOf("\n", i);
	const end = lineEnd === -1 ? text.length : lineEnd;
	const want = i + at.column - 1;
	return want <= end ? want : -1;
}
/**
* The start tag beginning at a place, read to its real end.
*
* Quotes are honoured because `<a title="a > b">` is one tag and stopping at
* the first `>` makes it two. Nothing else about the markup is parsed: this is
* one tag, at one address, and the rest of the file is not its business.
*/
function tagAt(text, at) {
	const from = indexAt(text, at);
	if (from < 0 || text[from] !== "<") return null;
	let quote = null;
	for (let i = from + 1; i < text.length; i++) {
		const c = text[i];
		if (quote) {
			if (c === quote) quote = null;
			continue;
		}
		if (c === "\"" || c === "'") {
			quote = c;
			continue;
		}
		if (c === ">") return {
			text: text.slice(from, i + 1),
			from,
			to: i + 1
		};
	}
	return null;
}
/** Read an attribute by name out of a start tag. */
function attrIn(tag, name) {
	const re = new RegExp(`(^|[\\s])(${name})(\\s*=\\s*)?`, "gi");
	let m;
	while (m = re.exec(tag)) {
		const nameFrom = m.index + m[1].length;
		if (!isOutsideQuotes(tag, nameFrom)) continue;
		if (!m[3]) return {
			name: m[2],
			value: "",
			from: nameFrom,
			to: nameFrom + m[2].length,
			bare: true
		};
		let i = m.index + m[0].length;
		const q = tag[i];
		if (q === "\"" || q === "'") {
			const end = tag.indexOf(q, i + 1);
			if (end === -1) return null;
			return {
				name: m[2],
				value: tag.slice(i + 1, end),
				from: nameFrom,
				to: end + 1,
				bare: false
			};
		}
		let end = i;
		while (end < tag.length && !/[\s/>]/.test(tag[end])) end++;
		return {
			name: m[2],
			value: tag.slice(i, end),
			from: nameFrom,
			to: end,
			bare: false
		};
	}
	return null;
}
function isOutsideQuotes(tag, index) {
	let quote = null;
	for (let i = 0; i < index; i++) {
		const c = tag[i];
		if (quote) {
			if (c === quote) quote = null;
		} else if (c === "\"" || c === "'") quote = c;
	}
	return quote === null;
}
/** Declarations of a `style` attribute, in the order they were written. */
function readStyle(value) {
	const out = [];
	for (const part of value.split(";")) {
		const at = part.indexOf(":");
		if (at === -1) continue;
		const name = part.slice(0, at).trim();
		const v = part.slice(at + 1).trim();
		if (name && v) out.push([name, v]);
	}
	return out;
}
var printStyle = (decls) => decls.map(([k, v]) => `${k}: ${v}`).join("; ");
/**
* The same tag with one declaration set on its `style` attribute.
*
* The person's own order is kept and their own declarations are kept: a
* property they already set is replaced where it stood, and a new one is
* added at the end. Rewriting somebody's attribute into our own ordering is
* the kind of diff that makes a person stop trusting a tool.
*/
function withStyle(tag, property, value) {
	const attr = attrIn(tag, "style");
	if (!attr || attr.bare) {
		const tail = /(\s*\/?>)$/.exec(tag)?.[1] ?? ">";
		return `${tag.slice(0, tag.length - tail.length)} style="${property}: ${value}"${tail}`;
	}
	const decls = readStyle(attr.value);
	const at = decls.findIndex(([k]) => k.toLowerCase() === property.toLowerCase());
	if (at === -1) decls.push([property, value]);
	else decls[at] = [property, value];
	const quote = tag[attr.to - 1] === "'" ? "'" : "\"";
	const head = tag.slice(0, attr.from);
	const tail = tag.slice(attr.to);
	return `${head}style=${quote}${printStyle(decls)}${quote}${tail}`;
}
/**
* What a tag holds, from just past its `>` to the `<` of its own close.
*
* Counted, not guessed: a `<div>` inside a `<div>` closes first, and a writer
* that took the first `</div>` would cut the element in half. Self-closing
* tags and void elements hold nothing and say so.
*
* This is how the words of an element are found in a file — the one thing a
* stamp points at that is not an attribute (FM-DESIGN-55).
*/
function insideOf(text, tag) {
	const name = /^<\s*([a-zA-Z][-\w]*)/.exec(tag.text)?.[1];
	if (!name) return null;
	if (/\/\s*>$/.test(tag.text)) return null;
	const open = new RegExp(`<\\s*${name}(?=[\\s/>])`, "gi");
	const close = new RegExp(`<\\s*/\\s*${name}\\s*>`, "gi");
	let depth = 1;
	let at = tag.to;
	while (at < text.length) {
		open.lastIndex = at;
		close.lastIndex = at;
		const nextOpen = open.exec(text);
		const nextClose = close.exec(text);
		if (!nextClose) return null;
		if (nextOpen && nextOpen.index < nextClose.index) {
			depth += 1;
			at = nextOpen.index + nextOpen[0].length;
			continue;
		}
		depth -= 1;
		if (depth === 0) return {
			from: tag.to,
			to: nextClose.index
		};
		at = nextClose.index + nextClose[0].length;
	}
	return null;
}
//#endregion
//#region plugins/design/frameworks/write.ts
/**
* Where the nth piece of text sits inside an element's own content.
*
* Its own: text belonging to a nested tag belongs to that tag and is written
* against it. So the depth is counted and only what is written at depth zero
* is a run of this element — which is what makes it safe to replace one
* without touching what is around it (FM-DESIGN-62).
*/
function runAt(inside, want) {
	let depth = 0;
	let seen = -1;
	let from = 0;
	let i = 0;
	const runs = [];
	while (i < inside.length) {
		const open = inside.indexOf("<", i);
		if (open === -1) {
			if (depth === 0) runs.push({
				from,
				to: inside.length
			});
			break;
		}
		if (depth === 0) runs.push({
			from,
			to: open
		});
		const close = inside.indexOf(">", open);
		if (close === -1) break;
		const tag = inside.slice(open, close + 1);
		if (/^<\//.test(tag)) depth = Math.max(0, depth - 1);
		else if (!/\/>$/.test(tag) && !/^<(br|img|input|hr|meta|link)\b/i.test(tag)) depth += 1;
		i = close + 1;
		from = i;
	}
	for (const run of runs) {
		if (!inside.slice(run.from, run.to).trim()) continue;
		seen += 1;
		if (seen === want) return run;
	}
	return null;
}
/**
* Changes gathered by file, each file's in the order a writer must apply them.
*
* Last line first. Editing a file from the top moves every line below the edit,
* so the second change of a file would land at a line that no longer means what
* it meant when the person pointed at it — the same fault as search-and-replace,
* arriving by arithmetic instead of by luck.
*/
function byFile(changes) {
	const out = /* @__PURE__ */ new Map();
	for (const c of changes) {
		const at = out.get(c.origin.file) ?? [];
		at.push(c);
		out.set(c.origin.file, at);
	}
	for (const [file, list] of out) out.set(file, [...list].sort((a, b) => b.origin.line !== a.origin.line ? b.origin.line - a.origin.line : b.origin.column - a.origin.column));
	return out;
}
/**
* The last word on one property of one element.
*
* A person changes a colour, changes their mind, changes it again: three
* changes to one property of one element, and only the last is a change at all.
* Bolt learnt this in public — a stack that grows with every nudge is a stack
* that sends the model a hundred edits for one decision.
*/
function settled(changes) {
	const last = /* @__PURE__ */ new Map();
	for (const c of changes) last.set(`${c.origin.file}:${c.origin.line}:${c.origin.column}:${c.property}`, c);
	return [...last.values()];
}
/** A refusal a person can act on, rather than a stack trace. */
var cannot = (origin, why) => ({
	origin,
	why
});
/**
* What one file becomes, given the changes addressed to it.
*
* A pure function over text so a check can drive it with a file it wrote
* itself. Nothing here reads a disk, and the order is the one `byFile` decided:
* last line first, so an edit never moves the line a later change is addressed
* to.
*/
/** The words as a file may hold them: nothing that could start a tag. */
function escapeWords(text) {
	return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function fileAfter(text, changes) {
	const refused = [];
	let out = text;
	for (const c of changes) {
		if (c.value === null) {
			refused.push(cannot(c.origin, "taking a declaration away is not built yet"));
			continue;
		}
		if (!c.everywhere) {
			refused.push(cannot(c.origin, "this is drawn in more than one place and the change was meant for one of them — give that one a class of its own in the source, or choose “everywhere this appears”"));
			continue;
		}
		const tag = tagAt(out, {
			line: c.origin.line,
			column: c.origin.column
		});
		if (!tag) {
			refused.push(cannot(c.origin, "no tag begins there any more — the file has moved on since this was drawn"));
			continue;
		}
		if (c.property === "#text") {
			const inside = insideOf(out, tag);
			if (!inside) {
				refused.push(cannot(c.origin, /\bset:(html|text)\b/.test(tag.text) ? "these words are made by the site's code, so they were not written" : "this element holds nothing that can be written as words"));
				continue;
			}
			const kept = out.slice(inside.from, inside.to);
			const run = runAt(kept, c.part ?? 0);
			if (!run) {
				refused.push(cannot(c.origin, "the words that were changed are no longer in this element"));
				continue;
			}
			const piece = kept.slice(run.from, run.to);
			if (/[{}]/.test(piece)) {
				refused.push(cannot(c.origin, "these words are made by the site's code, so they were not written"));
				continue;
			}
			const pad = /^(\s*)/.exec(piece)?.[1] ?? "";
			const tail = /(\s*)$/.exec(piece)?.[1] ?? "";
			out = out.slice(0, inside.from + run.from) + pad + escapeWords(c.value) + tail + out.slice(inside.from + run.to);
			continue;
		}
		out = out.slice(0, tag.from) + withStyle(tag.text, c.property, c.value) + out.slice(tag.to);
	}
	return {
		text: out,
		refused
	};
}
/**
* Apply changes to a project's source.
*
* The reading and the writing are the caller's — a plugin is handed the one
* door the window granted it, not a filesystem — so this takes them. That also
* makes the whole of "keep it" drivable by a check with no disk at all. Every
* path is relative to the project's root, which the door already is.
*/
async function writeInto(changes, io) {
	const files = [];
	const refused = [];
	for (const [file, forFile] of byFile(settled(changes))) {
		const before = await io.read(file);
		if (before === null) {
			for (const c of forFile) refused.push(cannot(c.origin, `${file} could not be read`));
			continue;
		}
		const { text, refused: no } = fileAfter(before, forFile);
		refused.push(...no);
		if (text !== before) {
			await io.write(file, text);
			files.push(file);
		}
	}
	return {
		files,
		refused
	};
}
//#endregion
//#region plugins/design/frameworks/astroInstance.ts
/** Eight hex characters that change whenever the text does (FNV-1a). */
function fingerprint$1(text) {
	let h = 2166136261;
	for (let i = 0; i < text.length; i++) {
		h ^= text.charCodeAt(i);
		h = Math.imul(h, 16777619) >>> 0;
	}
	return h.toString(16).padStart(8, "0");
}
var key = (p) => `${p.file}:${p.line}:${p.column}`;
/** The end of a `{…}` value that starts at `open`, braces and quotes counted. */
function braceEnd(text, open) {
	let depth = 0;
	let quote = null;
	for (let i = open; i < text.length; i++) {
		const c = text[i];
		if (quote) {
			if (c === "\\") i++;
			else if (c === quote) quote = null;
			continue;
		}
		if (c === "\"" || c === "'" || c === "`") quote = c;
		else if (c === "{") depth++;
		else if (c === "}" && --depth === 0) return i;
	}
	return -1;
}
/** Where an attribute written as `name={…}` sits in a tag, outside quotes. */
function exprAttr(tag, name) {
	const re = new RegExp(`(^|\\s)${name.replace(/[:]/g, "\\:")}\\s*=\\s*\\{`, "g");
	let quote = null;
	let m;
	while (m = re.exec(tag)) {
		quote = null;
		for (let i = 0; i < m.index; i++) {
			const c = tag[i];
			if (quote) {
				if (c === quote) quote = null;
			} else if (c === "\"" || c === "'") quote = c;
		}
		if (quote) continue;
		const open = m.index + m[0].length - 1;
		const end = braceEnd(tag, open);
		if (end < 0) return null;
		return {
			from: m.index + m[1].length,
			open,
			end
		};
	}
	return null;
}
/** The prop this element already takes a class from, when it was taught before. */
function passedProp(tag) {
	return /Astro\.props\.([A-Za-z][A-Za-z0-9]*Class\d*)/.exec(tag)?.[1] ?? null;
}
/**
* The element's start tag, taking a class from `prop` besides its own.
*
* `class="a b"` becomes `class:list={["a b", Astro.props.prop]}`, `class={x}`
* becomes `class:list={[x, Astro.props.prop]}`, a `class:list` array gains one
* item, and a tag with no class gets `class={Astro.props.prop}` — which Astro
* leaves out while the prop is not given, so every other use renders as it did.
*/
function passingClass(tag, prop) {
	const from = `Astro.props.${prop}`;
	const list = exprAttr(tag, "class:list");
	if (list) {
		const inner = tag.slice(list.open + 1, list.end).trim();
		const next = /^\[[\s\S]*\]$/.test(inner) ? `${inner.slice(0, -1).replace(/[\s,]*$/, "")}${inner.length > 2 ? ", " : ""}${from}]` : `[${inner}, ${from}]`;
		return tag.slice(0, list.open + 1) + next + tag.slice(list.end);
	}
	const expr = exprAttr(tag, "class");
	if (expr) {
		const inner = tag.slice(expr.open + 1, expr.end).trim();
		return `${tag.slice(0, expr.from)}class:list={[${inner}, ${from}]}${tag.slice(expr.end + 1)}`;
	}
	const plain = attrIn(tag, "class");
	if (plain && !plain.bare) return `${tag.slice(0, plain.from)}class:list={[${JSON.stringify(plain.value)}, ${from}]}${tag.slice(plain.to)}`;
	const tail = /(\s*\/?>)$/.exec(tag)?.[1] ?? ">";
	return `${tag.slice(0, tag.length - tail.length)} class={${from}}${tail}`;
}
/** The use's start tag with `prop="cls"`, or as it was when it already carries it. */
function givingClass(tag, prop, cls) {
	if (attrIn(tag, prop)) return tag;
	const tail = /(\s*\/?>)$/.exec(tag)?.[1] ?? ">";
	return `${tag.slice(0, tag.length - tail.length)} ${prop}="${cls}"${tail}`;
}
/** The rule for one class: three times the class, so it wins over a component's scoped rule of two. */
var selectorOf = (cls) => `:global(.${cls}.${cls}.${cls})`;
/**
* The file with the declarations set on the class's rule — the rule where it
* stands, else a new one in the file's first plain `<style>`, else a new
* `<style>` at the end of the file.
*/
function withRule(text, cls, decls) {
	const selector = selectorOf(cls);
	const at = text.indexOf(selector);
	if (at >= 0) {
		const open = text.indexOf("{", at);
		const close = text.indexOf("}", open);
		if (open > 0 && close > open) {
			const had = readStyle(text.slice(open + 1, close));
			for (const [k, v] of decls) {
				const i = had.findIndex(([h]) => h.toLowerCase() === k.toLowerCase());
				if (i === -1) had.push([k, v]);
				else had[i] = [k, v];
			}
			return `${text.slice(0, open + 1)} ${had.map(([k, v]) => `${k}: ${v};`).join(" ")} ${text.slice(close)}`;
		}
	}
	const rule = `  /* Changed with the vobuda designer: this use only. */\n  ${selector} { ${decls.map(([k, v]) => `${k}: ${v};`).join(" ")} }\n`;
	const style = /<style(\s[^>]*)?>/g;
	let m;
	while (m = style.exec(text)) {
		if (/\bis:inline\b/.test(m[1] ?? "")) continue;
		const end = text.indexOf("</style>", m.index);
		if (end < 0) break;
		const before = text.slice(0, end);
		return `${before}${before.endsWith("\n") ? "" : "\n"}${rule}${text.slice(end)}`;
	}
	const block = `<style>\n${rule}</style>\n`;
	for (const close of ["</head>", "</body>"]) {
		const at = text.search(new RegExp(close.replace("/", "\\/"), "i"));
		if (at >= 0) return `${text.slice(0, at)}${block}${text.slice(at)}`;
	}
	return `${text}${text.endsWith("\n") ? "" : "\n"}\n${block}`;
}
/**
* Write "only here" changes: the component taught once to pass a class, the
* use given the class, the rule written beside the use.
*/
async function writeOnlyHere(files, changes) {
	const refused = [];
	const groups = /* @__PURE__ */ new Map();
	for (const c of changes) {
		const use = c.origin.use;
		if (!use || c.value === null) {
			refused.push(cannot(c.origin, "this use of the part could not be told apart from the others — choose “everywhere this appears”"));
			continue;
		}
		if (use.file === c.origin.file) {
			refused.push(cannot(c.origin, "this part is used inside its own file, so one use of it cannot be written apart"));
			continue;
		}
		const k = `${key(c.origin)}|${key(use)}`;
		const g = groups.get(k) ?? {
			element: c.origin,
			use,
			decls: [],
			origin: c.origin
		};
		const i = g.decls.findIndex(([p]) => p === c.property);
		if (i === -1) g.decls.push([c.property, c.value]);
		else g.decls[i] = [c.property, c.value];
		groups.set(k, g);
	}
	const written = /* @__PURE__ */ new Set();
	const passed = [];
	const texts = /* @__PURE__ */ new Map();
	const read = async (file) => {
		if (!texts.has(file)) {
			const t = await files.read(file);
			if (t !== null) texts.set(file, t);
		}
		return texts.get(file) ?? null;
	};
	const props = /* @__PURE__ */ new Map();
	const elements = [...new Map([...groups.values()].map((g) => [key(g.element), g])).values()].sort((a, b) => b.element.line - a.element.line || b.element.column - a.element.column);
	for (const g of elements) {
		const text = await read(g.element.file);
		const tag = text === null ? null : tagAt(text, g.element);
		if (!text || !tag) {
			refused.push(cannot(g.origin, "no tag begins there any more — the file has moved on since this was drawn"));
			continue;
		}
		let prop = passedProp(tag.text);
		if (!prop) {
			const name = /^<\s*([a-zA-Z][-\w]*)/.exec(tag.text)?.[1]?.replace(/-/g, "") ?? "part";
			prop = `${name}Class`;
			for (let n = 2; text.includes(`Astro.props.${prop}`); n++) prop = `${name}Class${n}`;
			texts.set(g.element.file, text.slice(0, tag.from) + passingClass(tag.text, prop) + text.slice(tag.to));
			written.add(g.element.file);
			if (!passed.includes(g.element.file)) passed.push(g.element.file);
		}
		props.set(key(g.element), prop);
	}
	const byUse = /* @__PURE__ */ new Map();
	for (const g of groups.values()) {
		if (!props.has(key(g.element))) continue;
		byUse.set(g.use.file, [...byUse.get(g.use.file) ?? [], g]);
	}
	for (const [file, list] of byUse) {
		let text = await read(file);
		if (text === null) {
			for (const g of list) refused.push(cannot(g.origin, `${file} could not be read`));
			continue;
		}
		const rules = [];
		for (const g of [...list].sort((a, b) => b.use.line - a.use.line || b.use.column - a.use.column)) {
			const tag = tagAt(text, g.use);
			if (!tag) {
				refused.push(cannot(g.origin, "the place this part is used no longer begins there — the file has moved on"));
				continue;
			}
			const prop = props.get(key(g.element));
			const cls = attrIn(tag.text, prop)?.value || `vd-${fingerprint$1(`${key(g.use)}|${key(g.element)}`)}`;
			text = text.slice(0, tag.from) + givingClass(tag.text, prop, cls) + text.slice(tag.to);
			rules.push({
				cls,
				decls: g.decls
			});
		}
		for (const r of rules) text = withRule(text, r.cls, r.decls);
		texts.set(file, text);
		written.add(file);
	}
	const out = [];
	for (const file of written) {
		const text = texts.get(file);
		if (text !== await files.read(file)) {
			await files.write(file, text);
			out.push(file);
		}
	}
	return {
		files: out,
		refused,
		passed: passed.filter((f) => out.includes(f))
	};
}
//#endregion
//#region plugins/design/frameworks/astro.ts
/** The config Astro is configured by, whichever spelling this project chose. */
var CONFIGS$1 = [
	"astro.config.mjs",
	"astro.config.ts",
	"astro.config.js",
	"astro.config.mts"
];
/** What goes into an `integrations` list that is already there. */
var ENTRY = `${STAMPER_NAME}(), `;
/** What goes into a config that has no `integrations` list at all. */
var LIST = `\n  integrations: [${STAMPER_NAME}()],`;
async function configOf$1(files) {
	const here = await files.list(".");
	return CONFIGS$1.find((c) => here.includes(c)) ?? null;
}
/**
* Whether this is an Astro project.
*
* Asked of the config file rather than of `package.json`: a dependency can sit
* in a repository that holds three projects, and the config is where a project
* actually is. A monorepo whose root has no config is not an Astro project even
* though it lists astro — which is the right answer, because there is nothing
* at the root to point at.
*/
async function looksLikeMine$1(files) {
	return await configOf$1(files) !== null;
}
/**
* Whether the build already writes origins into its elements — with this
* stamper. One taught by an older one says no, so "Teach the build" is offered
* again and brings it up to date (FM-DESIGN-113).
*/
async function isStamped$1(files) {
	const config = await configOf$1(files);
	if (!config) return false;
	return (await files.read(config) ?? "").includes(STAMPER_IMPORT) && await files.read(STAMPER_FILE) === STAMPER_SOURCE;
}
/** Where the import goes: before the first import, so `// @ts-check` stays first. */
function importAt(text) {
	const first = /^import\s/m.exec(text);
	if (first) return first.index;
	const exported = /^export\s+default\b/m.exec(text);
	return exported ? exported.index : 0;
}
/**
* Teach this project's build to stamp, and say what was changed.
*
* The person's own config is edited, so the rules are the ones this program
* follows everywhere it touches somebody's file: never twice, never silently,
* never a guess about the shape, and never anything that is not in the project
* — the stamper is a file this writes beside the config, not a package that
* has to exist somewhere (FM-DESIGN-88). A config with an `integrations` list
* gains one entry at its head; a config without one — four of Gary's five
* sites — gains the list, right after `defineConfig({`. Anything else is
* refused with what to do, rather than rewritten into something the person
* did not write.
*/
async function stamp$1(files) {
	const config = await configOf$1(files);
	if (!config) throw new Error("no Astro config here");
	const before = await files.read(config) ?? "";
	const taught = STAMPER_IMPORTED.exec(before);
	if (taught) {
		if (taught[1] === STAMPER_FILE) {
			if (await files.read(STAMPER_FILE) === STAMPER_SOURCE) return { files: [] };
			await files.write(STAMPER_FILE, STAMPER_SOURCE);
			return { files: [STAMPER_FILE] };
		}
		await files.write(STAMPER_FILE, STAMPER_SOURCE);
		await files.write(config, before.replace(taught[0], STAMPER_IMPORT));
		const changed = [config, STAMPER_FILE];
		if (await files.read(taught[1]) !== null) {
			await files.remove(taught[1]);
			changed.push(taught[1]);
		}
		return { files: changed };
	}
	if (before.includes("vobudaStamp")) throw new Error(`${config} already names ${STAMPER_NAME} in a shape this did not write — look at it by hand`);
	let body;
	const list = before.match(/integrations\s*:\s*\[/);
	const config_ = before.match(/defineConfig\(\s*\{/) ?? before.match(/export\s+default\s*\{/);
	if (list && list.index !== void 0) {
		const cut = list.index + list[0].length;
		body = before.slice(0, cut) + ENTRY + before.slice(cut);
	} else if (config_ && config_.index !== void 0) {
		const cut = config_.index + config_[0].length;
		body = before.slice(0, cut) + LIST + before.slice(cut);
	} else throw new Error(`${config} is not written as defineConfig({ … }) or export default { … }, so there is nowhere certain to add the stamper — nothing was changed`);
	const at = importAt(body);
	const after = body.slice(0, at) + STAMPER_IMPORT + body.slice(at);
	await files.write(STAMPER_FILE, STAMPER_SOURCE);
	await files.write(config, after);
	return { files: [config, STAMPER_FILE] };
}
/**
* Take the teaching back: the config as it was before, and the stamper gone.
*
* Exactly what `stamp` put in comes out, and nothing else: the import line,
* then the entry or the list. If the person has since changed those lines, the
* config is left as it is and the refusal names it (FM-DESIGN-88).
*/
async function unstamp$1(files) {
	const config = await configOf$1(files);
	if (!config) throw new Error("no Astro config here");
	const before = await files.read(config) ?? "";
	const changed = [];
	const named = STAMPER_IMPORTED.exec(before)?.[1];
	if (before.includes("vobudaStamp")) {
		let after = before.replace(STAMPER_IMPORTED, "");
		if (after.includes(LIST)) after = after.replace(LIST, "");
		else after = after.replace(ENTRY, "");
		if (after.includes("vobudaStamp")) throw new Error(`${config} names ${STAMPER_NAME} in a way this did not write — take it out by hand`);
		await files.write(config, after);
		changed.push(config);
	}
	for (const file of /* @__PURE__ */ new Set([named ?? STAMPER_FILE, STAMPER_FILE])) {
		if (await files.read(file) === null) continue;
		await files.remove(file);
		changed.push(file);
	}
	return { files: changed };
}
/**
* Put changes into the project. "Only here" on an element a component draws
* more than once goes through the use it was drawn by: the component passes a
* class, that one use gives it (story 54-6, FM-DESIGN-126). Words stay with the
* general writer, which refuses them by name for one use of several.
*/
async function write$1(files, changes) {
	const here = changes.filter((c) => !c.everywhere && c.property !== "#text");
	const general = await writeInto(changes.filter((c) => !here.includes(c)), files);
	if (!here.length) return general;
	const one = await writeOnlyHere(files, here);
	return {
		files: [.../* @__PURE__ */ new Set([...general.files, ...one.files])],
		refused: [...general.refused, ...one.refused],
		passed: one.passed
	};
}
var astro = {
	name: "Astro",
	looksLikeMine: looksLikeMine$1,
	isStamped: isStamped$1,
	stamp: stamp$1,
	unstamp: unstamp$1,
	write: write$1
};
//#endregion
//#region plugins/design/frameworks/next.ts
var CONFIGS = [
	"next.config.js",
	"next.config.mjs",
	"next.config.ts",
	"next.config.cjs"
];
/** The addition that stamps, named once. */
var PLUGIN = "vobuda-design/stamp-babel";
async function configOf(files) {
	const here = await files.list(".");
	return CONFIGS.find((c) => here.includes(c)) ?? null;
}
var looksLikeMine = async (files) => await configOf(files) !== null;
/**
* Whether the build stamps.
*
* Asked of the Babel configuration rather than of Next's own, because that is
* where a stamping plugin goes — and a project that has one has a `.babelrc`
* even when its Next config says nothing at all.
*/
async function isStamped(files) {
	for (const name of [
		".babelrc",
		".babelrc.json",
		"babel.config.js",
		"babel.config.json"
	]) if ((await files.read(name) ?? "").includes(PLUGIN)) return true;
	return false;
}
/**
* Teach the build to stamp — refused until there is a stamper to teach it.
*
* This used to add `vobuda-design/stamp-babel` to a `.babelrc`: a Babel plugin
* that exists in no registry and no repository, so the next start of the dev
* server failed on it — the same fault as Astro's, found on 22 September 2026
* (FM-DESIGN-88). Until a stamper of our own is written for Next.js, teaching
* writes nothing and says why; a project already carrying the old line can
* still have it taken out.
*/
async function stamp(files) {
	if (!await configOf(files)) throw new Error("no Next config here");
	throw new Error("teaching a Next.js build is not built yet — nothing was changed. Copy the design, or ask the agent to make the change");
}
/** Take out the line the old teaching wrote, and nothing else. */
async function unstamp(files) {
	const at = ".babelrc";
	const text = await files.read(at);
	if (text === null || !text.includes(PLUGIN)) return { files: [] };
	let config;
	try {
		config = JSON.parse(text);
	} catch {
		throw new Error(`${at} is not JSON any more — take ${PLUGIN} out by hand`);
	}
	const plugins = Array.isArray(config.plugins) ? config.plugins : [];
	config.plugins = plugins.filter((p) => (Array.isArray(p) ? p[0] : p) !== PLUGIN);
	await files.write(at, `${JSON.stringify(config, null, 2)}\n`);
	return { files: [at] };
}
async function write(files, changes) {
	return writeInto(changes, files);
}
var next = {
	name: "Next.js",
	looksLikeMine,
	isStamped,
	stamp,
	unstamp,
	write
};
//#endregion
//#region plugins/design/frameworks/all.ts
var done$1 = false;
/**
* Register them, once.
*
* Called from the designer's start rather than run on import, so that a check
* can drive the boundary with exactly the frameworks it means instead of
* whatever a module happened to load.
*/
function registerAll() {
	if (done$1) return;
	done$1 = true;
	register(astro);
	register(next);
}
//#endregion
//#region plugins/design/ask.ts
/**
* The properties worth telling an agent about.
*
* Every computed property is four hundred lines of noise that pushes the
* question out of the agent's sight. These are the ones a person points at.
*/
var WORTH_SAYING = [
	"color",
	"background-color",
	"font-size",
	"font-weight",
	"line-height",
	"letter-spacing",
	"margin",
	"padding",
	"border-radius",
	"border",
	"box-shadow",
	"text-align",
	"display",
	"width",
	"height"
];
function worthSaying(style) {
	const out = {};
	for (const key of WORTH_SAYING) {
		const value = (style[key] ?? "").trim();
		if (value && value !== "none" && value !== "normal" && value !== "auto") out[key] = value;
	}
	return out;
}
/** Everything the agent needs, in one shape. */
function asking(said, picked, style, around, picture, scope) {
	return {
		said: said.trim(),
		scope,
		what: picked.what,
		origin: picked.origin,
		now: worthSaying(style),
		around,
		picture
	};
}
/**
* The message an agent actually reads.
*
* Plain sentences, because that is what an agent reads best and what a person
* would find in their own scrollback afterwards. The picture is named by its
* path, the way `page.to-agent` has named one since it was built.
*/
function wording(a) {
	const lines = [a.scope === "everywhere" ? `In the page I am designing, change every place this appears: ${a.what}.` : `In the page I am designing, change this one thing: ${a.what}.`, `What I want: ${a.said}`];
	if (a.origin) lines.push(`It comes from ${a.origin.file}, line ${a.origin.line}.`);
	else lines.push("Its source is not known — the build does not stamp its elements.");
	const now = Object.entries(a.now);
	if (now.length) lines.push(`It is drawn now as: ${now.map(([k, v]) => `${k}: ${v}`).join("; ")}.`);
	const near = [
		a.around.parent && `inside ${a.around.parent}`,
		a.around.before && `after ${a.around.before}`,
		a.around.after && `before ${a.around.after}`
	].filter(Boolean);
	if (near.length) lines.push(`It sits ${near.join(", ")}.`);
	if (a.picture) lines.push(`This is what I see: ${a.picture}`);
	lines.push(a.origin ? "Change it in that file yourself and save. The dev server reloads and I see it at once, so do not answer with a list of styles — nothing here reads one." : "Find it in the project by its text and change it in the source. The dev server reloads and I see it at once, so do not answer with a list of styles — nothing here reads one.");
	return lines.join("\n");
}
//#endregion
//#region plugins/design/look.ts
/** Window token → the variable this page draws with. */
var BORROWED = {
	"--app-bg": "--bg",
	"--app-fg": "--fg",
	"--app-accent": "--accent",
	"--app-warning": "--warning",
	"--line": "--line",
	"--block-radius": "--radius",
	"--panel-bg": "--card",
	"--panel-fg": "--card-fg",
	"--app-fg-muted": "--dim"
};
/**
* What to set on the root, out of what the window offered.
*
* A token the window did not name is left out rather than set empty: the
* stylesheet's own value is the fallback, and writing "" over it would paint
* the page with nothing. That is the same mistake the window's own looks make
* when a token is removed instead of decided, and it is written down there too.
*/
function borrowed(tokens) {
	const out = {};
	for (const [theirs, ours] of Object.entries(BORROWED)) {
		const value = tokens[theirs];
		if (typeof value === "string" && value.trim() !== "") out[ours] = value.trim();
	}
	return out;
}
/**
* Put the window's colours on the page, and take off the ones it no longer
* names. Worn again each time the window's theme or look changes: a panel
* that borrowed them once stayed on the theme it was opened under, white on
* a window gone dark (FM-PLUGIN-50). A token the new look does not name goes
* back to the stylesheet rather than staying on the old look's value.
*/
function wear(style, tokens) {
	const now = borrowed(tokens);
	for (const ours of Object.values(BORROWED)) if (ours in now) style.setProperty(ours, now[ours]);
	else style.removeProperty(ours);
}
//#endregion
//#region plugins/design/exported.ts
/** The line a saved file carries in its head. The core looks for this one. */
var GENERATOR = "<meta name=\"generator\" content=\"vobuda designer\">";
/** Every mark the designer puts on an element of a copy. */
var MARKS = / data-vobuda-(?:file|line|column|words)="[^"]*"/g;
/** One rule of the draft a copy was taken with, as `copied` writes it. */
var RULE = /^\[data-vobuda-line="(\d+)"\] \{ (.+?);? \}$/;
/** The copy as the file a person keeps. */
function exported(text) {
	const lines = text.split("\n");
	let out = text;
	const drop = /* @__PURE__ */ new Set();
	const rules = [];
	lines.forEach((l, i) => {
		const m = RULE.exec(l.trim());
		if (m) rules.push({
			line: Number(m[1]),
			decls: readStyle(m[2]),
			at: i
		});
	});
	for (const r of rules.sort((a, b) => b.line - a.line)) {
		const row = out.split("\n")[r.line - 1] ?? "";
		const column = row.length - row.trimStart().length + 1;
		const tag = tagAt(out, {
			line: r.line,
			column
		});
		if (!tag) continue;
		let now = tag.text;
		for (const [k, v] of r.decls) now = withStyle(now, k, v);
		out = out.slice(0, tag.from) + now + out.slice(tag.to);
		drop.add(r.at);
	}
	const kept = out.split("\n").filter((_, i) => !drop.has(i));
	const tidy = [];
	for (let i = 0; i < kept.length; i++) {
		if (kept[i].trim() === "<style>" && kept[i + 1]?.trim() === "</style>") {
			i += 1;
			continue;
		}
		tidy.push(kept[i]);
	}
	out = tidy.join("\n").replace(MARKS, "");
	if (!out.includes("<meta name=\"generator\" content=\"vobuda designer\">")) out = out.replace(/<meta charset="utf-8">/, (m) => `${m}\n${GENERATOR}`);
	return out;
}
//#endregion
//#region plugins/design/lasting.ts
/** Eight hex characters that change whenever the text does (FNV-1a). */
function fingerprint(text) {
	let h = 2166136261;
	for (let i = 0; i < text.length; i++) {
		h ^= text.charCodeAt(i);
		h = Math.imul(h, 16777619) >>> 0;
	}
	return h.toString(16).padStart(8, "0");
}
/** The work file one page's draft is kept in: plain letters only, the core refuses others. */
var fileFor = (address) => `draft-${fingerprint(address)}.json`;
/** Every file the steps point into. */
function filesOf(steps) {
	const out = /* @__PURE__ */ new Set();
	for (const s of steps) for (const r of s.rules) if (r.origin) out.add(r.origin.file);
	return [...out];
}
/** Read a kept draft, or null for none or for anything that is not one. */
function readKept(text, address) {
	if (!text) return null;
	try {
		const kept = JSON.parse(text);
		if (kept?.address !== address || !Array.isArray(kept.steps) || typeof kept.sources !== "object") return null;
		return kept;
	} catch {
		return null;
	}
}
/**
* Which kept steps may be put back at all, given the files as they are now.
*
* A step with no place in the source was addressed by a handle the page gave
* the element when it was picked, and a page loaded again has none of those —
* so it is gone. A step pointing into a file that changed is left, whole: its
* line may hold something else now.
*/
function sortOut(kept, now) {
	const out = {
		candidates: [],
		left: []
	};
	for (const step of kept.steps) {
		if (step.rules.some((r) => !r.origin)) {
			out.left.push({
				name: step.name,
				why: "gone"
			});
			continue;
		}
		if (step.rules.some((r) => {
			const then = kept.sources[r.origin.file];
			const text = now[r.origin.file];
			return then === void 0 || text == null || fingerprint(text) !== then;
		})) out.left.push({
			name: step.name,
			why: "changed"
		});
		else out.candidates.push(step);
	}
	return out;
}
/** Split the candidates by what the page says is still on it, one answer per rule in order. */
function onThePage(candidates, there) {
	const out = {
		candidates: [],
		left: []
	};
	let i = 0;
	for (const step of candidates) if (step.rules.every(() => there[i++] === true)) out.candidates.push(step);
	else out.left.push({
		name: step.name,
		why: "gone"
	});
	return out;
}
//#endregion
//#region plugins/design/sample.ts
/** A run of words shorter than this is common to any site ("Contact us"). */
var RUN = 16;
var plain = (s) => s.replace(/\s+/g, " ").trim();
/** The file name at the end of an address, when it is one worth looking for. */
function fileOf(address) {
	const bare = address.trim().split(/[?#]/)[0];
	if (!bare || bare.startsWith("data:")) return null;
	const last = decodeURIComponent(bare.split("/").pop() ?? "");
	return /\.[a-z0-9]{2,5}$/i.test(last) && last.length >= 5 ? last : null;
}
/** Read the copy for what may not travel. */
function originalOf(doc) {
	const words = /* @__PURE__ */ new Set();
	const walker = doc.createTreeWalker(doc.body ?? doc.documentElement, 4);
	for (let node = walker.nextNode(); node; node = walker.nextNode()) {
		const holder = node.parentElement;
		if (holder && /^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/.test(holder.tagName)) continue;
		const run = plain(node.textContent ?? "");
		if (run.length >= RUN) words.add(run);
	}
	const pictures = /* @__PURE__ */ new Set();
	const addresses = [];
	for (const el of Array.from(doc.querySelectorAll("img[src], source[srcset], img[srcset], link[rel~=icon][href], image[href], use[href]"))) for (const attr of [
		"src",
		"srcset",
		"href"
	]) {
		const v = el.getAttribute(attr);
		if (v) addresses.push(...v.split(",").map((part) => part.trim().split(/\s+/)[0]));
	}
	for (const style of Array.from(doc.querySelectorAll("style"))) for (const m of (style.textContent ?? "").matchAll(/url\(\s*["']?([^"')]+)["']?\s*\)/g)) addresses.push(m[1]);
	for (const a of addresses) {
		const name = fileOf(a);
		if (name && !/\.(woff2?|ttf|otf|eot)$/i.test(name)) pictures.add(name);
	}
	const names = /* @__PURE__ */ new Set();
	const site = doc.querySelector("meta[property=\"og:site_name\"]")?.getAttribute("content");
	if (site && plain(site).length >= 3) names.add(plain(site));
	const parts = (doc.title ?? "").split(/\s[|–—·:-]\s/).map(plain).filter(Boolean);
	const last = parts.length > 1 ? parts[parts.length - 1] : "";
	if (last.length >= 3 && last.split(" ").length <= 4) names.add(last);
	for (const img of Array.from(doc.querySelectorAll("img[alt]"))) {
		const alt = plain(img.getAttribute("alt") ?? "");
		const marks = `${img.getAttribute("src") ?? ""} ${img.getAttribute("class") ?? ""} ${img.parentElement?.className ?? ""}`;
		if (alt.length >= 3 && /logo/i.test(marks)) names.add(alt);
	}
	const base = doc.querySelector("base[href]")?.getAttribute("href");
	if (base) try {
		const host = new URL(base).hostname.replace(/^www\./, "");
		if (host && host !== "localhost" && !/^[\d.]+$/.test(host)) {
			names.add(host);
			const label = host.split(".")[0];
			if (label.length >= 4) names.add(label);
		}
	} catch {}
	return {
		words: [...words],
		pictures: [...pictures],
		names: [...names]
	};
}
/**
* Which built files are text worth reading, by name: anything that is not a
* picture, a font, a sound, an archive or a lockfile. Said by what is left
* out, so no kind of site's own file names are known here (the boundary,
* FM-DESIGN-22).
*/
var readable = (path) => !/\.(png|jpe?g|gif|webp|avif|ico|bmp|tiff?|woff2?|ttf|otf|eot|mp[34]|webm|mov|wav|ogg|pdf|zip|gz|tgz|br|lockb|wasm|map)$/i.test(path) && !/(^|\/)(package-lock\.json|pnpm-lock\.yaml|yarn\.lock|bun\.lock)$/.test(path);
/** Folders that are not the person's site but what it is built with or into. */
var skipped = (name) => name.startsWith(".") || [
	"node_modules",
	"dist",
	"build",
	"out"
].includes(name);
/** Everything of the original's found in the built files. */
function leaksOf(original, files) {
	const out = [];
	const low = Object.entries(files).map(([file, text]) => [file, plain(text).toLowerCase()]);
	const find = (kind, what, whole = false) => {
		const needle = what.toLowerCase();
		for (const [file, text] of low) {
			const at = text.indexOf(needle);
			if (at < 0) continue;
			if (whole) {
				const before = text[at - 1] ?? " ";
				const after = text[at + needle.length] ?? " ";
				if (/[\p{L}\p{N}]/u.test(before) || /[\p{L}\p{N}]/u.test(after)) continue;
			}
			out.push({
				kind,
				what,
				file
			});
			return;
		}
	};
	for (const w of original.words) find("words", w);
	for (const p of original.pictures) find("picture", p);
	for (const n of original.names) find("name", n, true);
	return out;
}
//#endregion
//#region plugins/design/page/verify.ts
/**
* Whether two values mean the same thing on a page.
*
* A browser answers in its own spelling: `red` comes back as `rgb(255, 0, 0)`,
* `0.50` as `0.5`, `#fff` as `rgb(255, 255, 255)`. Comparing the strings would
* report every single change as having moved, and a warning that fires on
* correct work teaches people to ignore warnings — which this project has
* already learnt once tonight.
*/
function same(a, b) {
	const norm = (v) => v.trim().toLowerCase().replace(/\s+/g, " ").replace(/;$/, "");
	if (norm(a) === norm(b)) return true;
	const num = (v) => Number(v.replace(/[^\d.-]/g, ""));
	const unit = (v) => /[a-z%]+$/.exec(v.trim())?.[0] ?? "";
	if (unit(a) === unit(b) && Number.isFinite(num(a)) && Number.isFinite(num(b))) return Math.abs(num(a) - num(b)) < .001;
	return false;
}
//#endregion
//#region plugins/design/designer.ts
registerAll();
var state = {
	address: null,
	framework: null,
	stamped: false,
	mode: "look",
	picked: null,
	drawn: {},
	palette: [],
	behind: [],
	hand: 0,
	rules: [],
	working: false,
	moved: [],
	notes: [],
	sent: [],
	steps: [],
	ahead: []
};
/** The session's steps as they stand, and the draft they draw (FM-DESIGN-116). */
function walked(walk) {
	state.steps = walk.done;
	state.ahead = walk.ahead;
	state.rules = drawnRules(walk);
}
var walk = () => ({
	done: state.steps ?? [],
	ahead: state.ahead ?? []
});
/** One press's rules, as a step of its own, named for what it did to what. */
function took(rules, what) {
	if (!rules.length) return;
	const step = {
		name: stepName(what, rules[0]),
		rules
	};
	walked(made(walk(), step));
	remember();
}
/** Nothing drawn and nothing to go forward to: saved, put back, or another page. */
var forget = () => walked({
	done: [],
	ahead: []
});
/** Saved or put back: nothing is left to keep for this page either (FM-DESIGN-117). */
function done() {
	forget();
	remember();
}
/** The last keeping, so two changes a moment apart are written in order. */
var keeping = Promise.resolve();
/**
* Keep what this page has unsaved, beside the person's settings, so closing
* the program does not lose it — with what each file it points into held
* then, so nothing is put back over code that changed (story 54-7,
* FM-DESIGN-117).
*/
function remember() {
	const api = surface();
	const address = state.address;
	if (!api || !address) return;
	const steps = state.steps ?? [];
	keeping = keeping.then(async () => {
		try {
			const folder = await api.workFolder("drafts");
			if (!steps.length) return void await folder.remove(fileFor(address));
			const sources = {};
			for (const file of filesOf(steps)) {
				const text = await readOrigin(api, file);
				if (text != null) sources[file] = fingerprint(text);
			}
			await folder.write(fileFor(address), JSON.stringify({
				address,
				steps,
				sources
			}));
		} catch (e) {
			api.log(`the unsaved changes could not be kept — ${String(e)}`);
		}
	});
}
/** The text a stamp points into: the copy's own file, or the project's. */
async function readOrigin(api, file) {
	if (copyName) return (await api.workFolder("copies")).read(copyName);
	return filesFrom(api).read(file);
}
/** The page whose kept changes are to be brought back once it says it is there. */
var recallFor = null;
/** Waiting on the page's answer to "which of these are still here". */
var presentWait = null;
/**
* Bring back what was left unsaved on this page last time: applied where the
* file is as it was and the element is still on the page, named where not
* (story 54-7, FM-DESIGN-117).
*/
async function recall(address) {
	const api = surface();
	if (!api || (state.steps ?? []).length) return;
	const kept = readKept(await (await api.workFolder("drafts")).read(fileFor(address)).catch(() => null), address);
	if (!kept || !kept.steps.length) return;
	if (!copyName && await whoseIs(api, address)) return;
	const now = {};
	for (const file of Object.keys(kept.sources)) now[file] = await readOrigin(api, file).catch(() => null);
	const sorted = sortOut(kept, now);
	let found = {
		candidates: [],
		left: []
	};
	if (sorted.candidates.length) {
		const there = await new Promise((resolve) => {
			presentWait = resolve;
			setTimeout(() => resolve([]), 4e3);
			tell({
				do: "present",
				rules: sorted.candidates.flatMap((s) => s.rules)
			});
		});
		presentWait = null;
		found = onThePage(sorted.candidates, there);
	}
	if (state.address !== address || (state.steps ?? []).length) return;
	const left = [...sorted.left, ...found.left];
	const notes = [];
	if (found.candidates.length) {
		walked({
			done: found.candidates,
			ahead: []
		});
		notes.push(counted("Brought back {0} unsaved changes from last time.", found.candidates.length));
		await push();
	}
	const changed = left.filter((l) => l.why === "changed").map((l) => l.name);
	const gone = left.filter((l) => l.why === "gone").map((l) => l.name);
	if (changed.length) notes.push(saying("Not brought back, because the page's code changed since: {0}", changed.join("; ")));
	if (gone.length) notes.push(saying("Not brought back, because it is no longer on the page: {0}", gone.join("; ")));
	state.notes = [...notes, ...state.notes];
	remember();
	show();
}
/** The block the bound page is in, as the window last said. */
var block = null;
/** The copy this panel is working on, when the page is one. */
var copyName = null;
var chosenIndex = 0;
var everywhere = true;
/** The surface this panel first got; the window sets it once and keeps it. */
var mine = null;
/**
* The surface, while it is the one this panel started with.
*
* The window never replaces it, so in the program this is `window.vobuda`.
* A check does — a fresh surface for each drive — and a designer left from an
* earlier drive went on drawing into the next one's panel and writing into its
* work folder: under a loaded machine a different drive failed each run, with
* a server on the panel that its own surface never listed (26 September 2026).
* One whose surface was replaced is left with none, and draws nothing.
*/
var surface = () => {
	const now = window.vobuda ?? null;
	if (!now) return null;
	mine ??= now;
	return now === mine ? now : null;
};
/** Whether this panel's surface has been replaced under it, which only a check does. */
var replaced = () => mine !== null && (window.vobuda ?? null) !== mine;
/** What the window was last told the panel holds unsaved. */
var toldUnsaved = 0;
/** Redraw, always through the same door, so the panel can never disagree with itself. */
function show() {
	if (replaced()) return;
	const unsaved = settle(state.rules).length;
	if (unsaved !== toldUnsaved) {
		toldUnsaved = unsaved;
		surface()?.unsaved?.(unsaved)?.catch(() => {});
	}
	try {
		drawTheLot();
	} catch (e) {
		surface()?.log(`the panel could not be drawn — ${String(e)}`);
		const body = document.getElementById("body");
		if (body) {
			const said = document.createElement("p");
			said.className = "note warn";
			said.setAttribute("aria-label", `panel error: ${String(e)}`);
			said.textContent = String(e);
			body.replaceChildren(said);
		}
	}
}
function drawTheLot() {
	draw(document, shown(state), {
		copy: () => void copyTheDesign(),
		edit: () => void setMode(state.mode === "edit" ? "look" : "edit"),
		talk: () => void setMode(state.mode === "ask" ? resting() : "ask"),
		teach: () => void teach(),
		untaught: () => void untaught(),
		nudge: (property, by) => void nudge(property, by),
		colour: (value, target) => void paint(value, target),
		hand: (run) => {
			if (state.hand === run) return;
			state.hand = run;
			const which = state.picked?.words[run];
			if (which) tell({
				do: "hand",
				at: which.at
			});
			show();
		},
		word: (text, run) => void word(text, run),
		server: (port) => void surface()?.openPage(`http://localhost:${port}/`),
		align: (value) => void set("text-align", value),
		ask: (said) => void ask(said),
		scope: () => {
			everywhere = !everywhere;
			show();
		},
		undo: () => {
			walked(backTo(walk(), walk().done.length - 1));
			remember();
			push();
		},
		revert: () => {
			done();
			state.notes = [];
			state.moved = [];
			const at = state.picked?.at;
			push().then(() => at ? tell({
				do: "again",
				at
			}) : void 0);
		},
		keep: () => {
			if (!state.rules.length) return;
			keep();
		},
		reveal: surface()?.reveal ? (path) => void surface()?.reveal?.(path)?.catch(() => {}) : void 0,
		mysite: () => void mySite(),
		choose: () => void chooseFolder(),
		serve: () => void startTheServer(),
		teachSite: () => void teachSite(),
		leaveSite: () => {
			state.site = null;
			show();
		},
		build: () => {
			state.build = {
				stage: "asking",
				about: "",
				folder: null,
				leaks: []
			};
			state.canChoose = !!surface()?.chooseProject;
			show();
		},
		buildAbout: (text) => {
			if (!state.build) return;
			state.build = {
				...state.build,
				about: text
			};
			show();
		},
		buildWhere: () => void buildWhere(),
		buildGo: () => void buildGo(),
		buildFix: () => void buildFix(),
		buildOpen: () => {
			state.build = null;
			mySite();
		},
		buildLeave: () => {
			state.build = null;
			show();
		},
		backTo: (count) => {
			walked(backTo(walk(), count));
			remember();
			const at = state.picked?.at;
			push().then(() => at ? tell({
				do: "again",
				at
			}) : void 0);
		}
	});
	const body = document.getElementById("body");
	if (question && body) body.prepend(questionCard(document, question, (choice) => {
		question = null;
		surface()?.answerAgent?.(choice)?.catch(() => {});
		show();
	}));
}
/**
* Everything the page is told goes through one shape, so nothing drifts.
*
* A block may be named, and then it is that page rather than the bound one:
* the only thing said to a page the designer is leaving is "stop".
*/
async function tell(message, at) {
	const api = surface();
	const where = at ?? block;
	if (!api || where === null) {
		api?.log("told the page nothing — no page block is bound to this plugin");
		return;
	}
	try {
		await api.runInPage(`window.__vobudaDesign && window.__vobudaDesign(${JSON.stringify(message)})`, where);
	} catch (e) {
		api?.log(`the page did not take it — ${String(e)}`);
	}
}
/** Put the draft the person has now onto the page. */
async function push() {
	await tell({
		do: "draft",
		rules: settle(state.rules)
	});
	show();
}
/**
* Looking, changing, or talking — and the page is told which.
*
* Pointing is the page's to do and only while "Edit" is on: the block beside
* the panel is an ordinary page block a person browses in, and a script that
* swallowed every press would make it unusable as a page (FM-DESIGN-30).
*/
/**
* What this page rests in when a mode is turned off.
*
* A copy, and a project whose build stamps, are there to be changed; anything
* else is there to be looked at (FM-DESIGN-52).
*/
var resting = () => state.stamped || state.framework !== null ? "edit" : "look";
async function setMode(next) {
	if (next === "edit" && !state.stamped && state.framework === null) {
		state.notes = [say("Copy the design first — a copy is what you change.")];
		show();
		return;
	}
	state.mode = next;
	if (next !== "edit") {
		state.picked = null;
		state.drawn = {};
	}
	show();
	await tell({
		do: "point",
		on: next === "edit"
	});
}
/**
* Take the design of the page beside this one, and open the copy.
*
* The page writes the copy itself — it is the only thing that can see the
* rendered document — and posts it to the program, which keeps it and says
* where. Everything after that is an ordinary page block on an ordinary
* address, which is the whole point: a copy is a page of this program's own,
* so it can be pointed at, changed and kept (FM-DESIGN-29).
*/
async function copyTheDesign() {
	if (!surface() || !state.address) return;
	state.working = true;
	state.notes = [say("Copying the design…")];
	show();
	await tell({ do: "copy" });
}
async function nudge(property, by) {
	if (!state.picked) return;
	const rule = ruleFor({
		origin: state.picked.origin,
		at: state.picked.at,
		index: chosenIndex,
		everywhere,
		property,
		from: state.drawn[property] ?? "",
		to: {
			kind: "step",
			by
		}
	});
	if (!rule) return;
	took([rule], state.picked.what);
	state.drawn = {
		...state.drawn,
		[property]: rule.value
	};
	await push();
}
/**
* What the element says.
*
* A change of the words, not of a declaration: no stylesheet can carry it, so
* it travels as a rule of its own under one reserved name and is applied by
* the page directly. Gary, at a panel full of numbers: «там сейчас нельзя
* изменить выбранный текст например... мне надо полноценный конструктор»
* (FM-DESIGN-55).
*/
/** A name as the page gives it — `h1 “the words”` — with new words in it. */
function renamed(was, words) {
	const tag = /^[a-z][a-z0-9-]*/.exec(was)?.[0];
	const said = words.trim().replace(/\s+/g, " ");
	if (!tag || !said) return was;
	return said.length <= 24 ? `${tag} “${said}”` : `${tag} “${said.slice(0, 22)}…”`;
}
async function word(text, run) {
	const which = state.picked?.words[run];
	if (!which) return;
	which.text = text;
	if (state.picked) {
		if (which.at !== state.picked.at) which.what = renamed(which.what, text);
		state.picked.what = renamed(state.picked.what, state.picked.words.map((w) => w.text).join(" "));
	}
	took([{
		origin: which.origin,
		at: which.at,
		index: 0,
		part: which.part,
		property: WORDS,
		value: text,
		everywhere: which.siblings <= 1
	}], state.picked?.what ?? which.what);
	await push();
}
/**
* A colour, on the piece of text in hand.
*
* The words of an element are not one thing: a heading whose second line is a
* span says two, in two colours, and a swatch pressed while the second field
* is in hand means that line. Gary, having coloured a heading and watched half
* of it change: «не весь текст меняет цвет… надо чтобы принималась палитра
* цвета в зависимости от выбранного текста» (FM-DESIGN-69).
*
* What is behind the words is the element's, not the run's — a piece of text
* has no background of its own — so that half goes where it always did.
*/
/** What a paint said about itself, to stand beside what the page reads back. */
var covered = [];
async function paint(value, target) {
	const runs = state.picked?.words ?? [];
	const run = target === "color" ? runs[Math.min(state.hand, runs.length - 1)] : void 0;
	if (!run) {
		if ((target === "background-color" ? state.picked?.drawn?.["background-image"] : void 0) && state.picked) {
			covered = [say("The gradient or picture on top of it was taken off, so the colour shows.")];
			const before = state.rules.length;
			await set(target, value);
			const colour = state.rules[before];
			if (colour) {
				const steps = [...state.steps ?? []];
				const last = steps.pop();
				if (last) walked({
					done: [...steps, {
						...last,
						rules: [...last.rules, {
							...colour,
							property: "background-image",
							value: "none"
						}]
					}],
					ahead: []
				});
				remember();
				await push();
			}
			return;
		}
		set(target, value);
		return;
	}
	const rule = {
		origin: run.origin,
		at: run.at,
		index: 0,
		property: target,
		value,
		everywhere: run.siblings <= 1
	};
	took(seeThrough(run.fill) ? [rule, {
		...rule,
		property: FILL,
		value
	}] : [rule], run.what);
	state.picked = {
		...state.picked,
		words: runs.map((w) => w === run ? {
			...w,
			colour: value
		} : w)
	};
	await push();
}
/** The property that says what the letters themselves are filled with. */
var FILL = "-webkit-text-fill-color";
/** Whether the letters are painted by something other than their colour. */
function seeThrough(fill) {
	const it = fill.trim().toLowerCase();
	if (!it) return false;
	if (it === "transparent") return true;
	const alpha = /^rgba?\([^)]*,\s*([\d.]+)\s*\)$/.exec(it);
	return alpha ? Number(alpha[1]) === 0 : false;
}
async function set(property, value) {
	if (!state.picked) return;
	const rule = ruleFor({
		origin: state.picked.origin,
		at: state.picked.at,
		index: chosenIndex,
		everywhere,
		property,
		from: state.drawn[property] ?? "",
		to: {
			kind: "set",
			value
		}
	});
	if (!rule) return;
	took([rule], state.picked.what);
	state.drawn = {
		...state.drawn,
		[property]: value
	};
	await push();
}
/**
* Ask the agent — the real one, in its own block.
*
* Gary, 20 September 2026: «эта кнопка должна именно делать тоже самое что
* делает чат тут где я сейчас пишу! она должна быть интегрирована в саму
* систему и знать что она работает со вторым окном».
*
* So this is not a chat of the plugin's own. It goes down the road every
* question in this program goes down — into the agent block of this tab, the
* way a key, a menu item and the command line send one — and the answer
* appears where the person already reads answers. What this adds is the second
* half of the sentence: the agent is told which page is beside the panel and
* what was pointed at on it, so "make this quieter" means something
* (FM-DESIGN-32).
*/
async function ask(said) {
	const api = surface();
	if (!api || !said.trim()) return;
	state.working = true;
	show();
	const where = await pageNamed(api, state.address ?? "");
	const question = state.picked ? wording(asking(said, state.picked, state.drawn, {
		before: null,
		after: null,
		parent: null
	}, null, everywhere ? "everywhere" : "this")) : saying("About the page open beside me, {0}: {1}", where, said.trim());
	const carried = state.picked ? `${question}\n${saying("The page is {0}.", where)}` : question;
	try {
		await api.askAgent(carried);
		state.sent = [...state.sent, {
			mine: true,
			text: said.trim()
		}];
		state.notes = [say("Asked. The answer comes back here.")];
	} catch (e) {
		state.notes = [String(e)];
	}
	state.working = false;
	show();
}
/**
* The person's own files, as the window lets this page reach them.
*
* Three calls and no more: the program holds the one folder that was granted
* and refuses anything outside it, and it writes a line to the log before every
* write (FM-PLUGIN-16). Nothing in this page knows a path outside the project.
*/
function filesFrom(api) {
	const at = (path) => served ? path === "." ? served : `${served}/${path}` : path;
	return {
		read: (path) => api.readSource(at(path)),
		write: (path, text) => api.writeSource(at(path), text),
		list: (path) => api.listSource(at(path)),
		remove: (path) => api.removeSource(at(path))
	};
}
/** The folder under the window's that the page's server serves, or "" for the window's own. */
var served = "";
/** Where the server's folder sits under the window's, or null when it is not under it. */
function under(folder, root) {
	const top = root.replace(/\/+$/, "");
	if (folder === top) return "";
	return folder.startsWith(`${top}/`) ? folder.slice(top.length + 1) : null;
}
/**
* The port of a dev server on this machine, when that is what the address is.
*
* The address as the bar shows it, `http://localhost:4460/`. Anything else —
* a site out on the web, a copy — has no folder on this computer to write to.
*/
function devPort(address) {
	if (!address) return null;
	try {
		const url = new URL(address);
		if (url.protocol !== "http:") return null;
		if (![
			"localhost",
			"127.0.0.1",
			"[::1]"
		].includes(url.hostname)) return null;
		return url.port ? Number(url.port) : 80;
	} catch {
		return null;
	}
}
/**
* Why nothing may be written from this page into this window's project — or
* null, when the page is that project's own.
*
* Asked of the system, not assumed: the server's own folder has to be the one
* the window granted. Above vobuda.com, and above a dev server started from
* another folder, "Teach my site's build" wrote into whatever folder the window's
* terminal was in (run-in of 22 September 2026, FM-DESIGN-88).
*/
async function whoseIs(api, address) {
	served = "";
	const port = devPort(address);
	if (port === null) return say("This page comes from the web, not from a folder on this computer, so nothing is saved anywhere. Copy the design to change it.");
	const root = await api.project();
	if (!root) return say("No folder of your site is open here. Press “Edit my site” and choose it.");
	let folder = null;
	try {
		folder = await api.servedFrom(port);
	} catch {
		folder = null;
	}
	if (!folder) return say("Nothing on this computer says which folder this page comes from, so nothing is saved.");
	const inside = under(folder, root);
	if (inside === null) return saying("This page comes from {0}, but your site's folder here is {1}, so nothing is saved there. Press “Edit my site” to choose the right folder.", folder, root);
	served = inside;
	return null;
}
/**
* Learn whose page this is, and only then what its project is.
*
* The framework used to be read once, from the window's folder, for whatever
* page was beside the panel — so over any site at all the panel said "This is
* an Astro project open in this window" and offered to teach it (FM-DESIGN-88).
*/
async function learnWhose(address) {
	const api = surface();
	if (!api) return;
	if (!address || copyIn(address)) {
		state.whose = null;
		state.framework = null;
		state.taught = false;
		show();
		return;
	}
	const why = await whoseIs(api, address);
	const framework = why ? null : await whatProjectIsThis(filesFrom(api));
	const taught = framework ? await isTaught(filesFrom(api)) : false;
	if (state.address !== address) return;
	state.whose = why;
	state.framework = framework;
	state.taught = taught;
	show();
}
/**
* "Keep it": the draft becomes the source.
*
* Three things happen and the person is told about all three — what was
* written, what could not be, and whether the page that came back looks like
* what they agreed to. The last one is the part almost nothing on the market
* has, and it is the one that matters: the draft won by being `!important`, and
* a written declaration has to win on its own (FM-DESIGN-2).
*/
async function keep() {
	const api = surface();
	if (!api) return;
	if (!state.rules.length) return;
	state.working = true;
	state.notes = [];
	state.moved = [];
	show();
	try {
		if (copyName) {
			await saveSomewhereElse(api, copyName);
			return;
		}
		const why = await whoseIs(api, state.address);
		if (why) {
			state.whose = why;
			state.notes = [why];
			return;
		}
		const kept = await keepInto(filesFrom(api), settle(state.rules));
		const notes = [];
		if (kept.files.length) notes.push(saying("Saved into {0}.", kept.files.join(", ")));
		state.passed = kept.passed ?? [];
		for (const r of kept.refused) notes.push(`${r.where} — ${r.why}`);
		if (!kept.files.length && !kept.refused.length) notes.push(say("Nothing was saved."));
		state.kept = notes;
		state.wrote = kept.files;
		state.notes = notes;
		show();
		if (kept.files.length) {
			const written = state.rules;
			done();
			await checkAgainstThePage(written);
		}
	} catch (e) {
		state.notes = [String(e)];
	} finally {
		state.working = false;
		show();
	}
}
/**
* Write the page, with the draft in it, wherever the person points.
*
* The file itself and not a road to it: what leaves here is one HTML file that
* opens in anything. The draft is applied to the copy's own text in memory —
* the same addressed write every other road here takes — and the window's
* chooser decides where the result lands. The copy in hand is untouched, so
* this is "save a version of it somewhere" rather than "move my work"
* (FM-DESIGN-79).
*/
async function saveSomewhereElse(api, name) {
	api.log(`saving ${name} somewhere else`);
	const text = await (await api.workFolder("copies")).read(name);
	if (text === null) {
		api.log(`saving stopped — ${name} is not in the copies folder`);
		state.notes = [saying("The copy {0} could not be read.", name)];
		return;
	}
	let out = text;
	const written = await writeInto(settle(state.rules).filter((r) => r.origin).map((r) => ({
		origin: r.origin,
		property: r.property,
		value: r.value,
		everywhere: true
	})), {
		read: async () => out,
		write: async (_path, next) => {
			out = next;
		},
		list: async () => [name],
		remove: async () => {}
	});
	const notes = [];
	for (const r of written.refused) notes.push(`${r.origin.file}:${r.origin.line} — ${r.why}`);
	try {
		api.log(`asking where ${name} should go`);
		const at = await api.saveAs(name, exported(out));
		notes.unshift(saying("Saved into {0}.", at));
		await api.keepCopy(name, out);
		done();
		state.savedAt = at;
		await tell({ do: "drop" });
		if (block !== null) await api.reloadPage(block).catch(() => {});
	} catch (e) {
		notes.unshift(String(e).includes("cancelled") ? say("Nothing was saved.") : String(e));
	}
	state.notes = notes;
}
/**
* "Teach my site's build": the project's config gains the stamper.
*
* Afterwards the person is told to restart their dev server, because a config
* read at boot is a config read at boot — and a designer that said nothing
* there would look broken for exactly as long as it took them to notice.
*/
async function teach() {
	const api = surface();
	if (!api) return;
	state.working = true;
	state.notes = [];
	show();
	try {
		const why = await whoseIs(api, state.address);
		if (why) {
			state.whose = why;
			state.notes = [why];
			return;
		}
		const taught = await teachIn(filesFrom(api));
		if (taught.why) {
			state.notes = [taught.why];
			return;
		}
		state.taught = true;
		state.notes = taught.files.length ? [saying("Your site now marks its parts ({0}). It can be taken back.", taught.files.join(", "))] : [say("Your site already marks its parts.")];
		show();
		untilStamped();
	} catch (e) {
		state.notes = [String(e)];
	} finally {
		state.working = false;
		show();
	}
}
/**
* Load the page again until it says its elements are stamped, for a while.
*
* Astro starts its dev server again on a changed config, which takes a few
* seconds; a page loaded in between is the old one, or no page at all.
*/
async function untilStamped() {
	const api = surface();
	const on = state.address;
	for (let i = 0; i < 8 && api && block !== null && !state.stamped; i++) {
		await new Promise((r) => setTimeout(r, 2500));
		if (state.stamped || block === null) break;
		try {
			await api.reloadPage(block);
		} catch {
			break;
		}
	}
	if (!state.stamped && state.taught && state.address === on && block !== null) {
		state.notes = [say("Your site now marks its parts, but this page is put together by code rather than written in its page files, so there is nothing here to mark. Copy the design to change it.")];
		show();
	}
}
/**
* "Take the teaching back": the config as it was before, the stamper gone.
*
* Only on the page of this window's own project, the same as teaching, and
* then the page is read again so it stops claiming a place nothing marks.
*/
async function untaught() {
	const api = surface();
	if (!api) return;
	state.working = true;
	state.notes = [];
	show();
	try {
		const why = await whoseIs(api, state.address);
		if (why) {
			state.notes = [why];
			return;
		}
		const back = await untaughtIn(filesFrom(api));
		if (back.why) {
			state.notes = [back.why];
			return;
		}
		state.taught = false;
		state.stamped = false;
		state.notes = back.files.length ? [saying("Taken back out of {0}.", back.files.join(", "))] : [say("There was nothing to take back.")];
		if (block !== null) {
			await new Promise((r) => setTimeout(r, 2500));
			await api.reloadPage(block).catch(() => {});
		}
	} catch (e) {
		state.notes = [String(e)];
	} finally {
		state.working = false;
		show();
	}
}
/** Take the draft off, let the page come back, and see what it is drawing. */
async function checkAgainstThePage(rules) {
	await tell({ do: "drop" });
	await new Promise((done) => {
		const stop = setTimeout(() => {
			reloaded = null;
			done();
		}, 6e3);
		reloaded = () => {
			clearTimeout(stop);
			reloaded = null;
			setTimeout(done, 300);
		};
	});
	await tell({
		do: "check",
		rules: settle(rules)
	});
}
/** Waiting on the page's "ready" after a save, to read it only once it has loaded again. */
var reloaded = null;
/**
* What a change came to, in the person's own terms.
*
* "25px" beside a page that did not move is worse than no number at all: it
* says the thing was done. A value asked for and a value in force are two
* different facts and the panel shows the second (FM-DESIGN-19).
*/
function whatCameOfIt(drawn) {
	const lost = drawn.filter((d) => d.given && !same(d.given, d.asked));
	if (!lost.length) return [];
	return lost.map((d) => saying("{0} shows as {1}, not {2}: another style on this part takes precedence.", plainName(d.property), d.given, d.asked));
}
/**
* What the page being designed says back.
*
* From the page this panel is bound to, and from no other. Every page the
* program serves speaks down the same road, and two of them are open side by
* side on purpose — the site and the copy taken from it. The site says "nothing
* here is stamped", which is true of it and false of the copy, and the panel
* believed whichever spoke last: Edit went dead on a copy that is stamped by
* construction, and closing the site did not bring it back because the word had
* already landed. Gary: «когда я закрываю сайт который я скопировал почему
* перестает работать раздел дизайн?» (FM-DESIGN-58).
*
* A message with no place on it is the program's own — the copy it wrote — and
* is always heard.
*/
function heard(detail) {
	if (detail.at != null && detail.at !== block) {
		surface()?.log(`not from the page in block ${block} — ${detail.what} from block ${detail.at}`);
		return;
	}
	if (detail.what === "copied") {
		const body = detail.body;
		state.working = false;
		if (!body?.address) {
			state.notes = [say("The copy was not kept.")];
			show();
			return;
		}
		state.notes = [saying("Copied into {0}. It opens beside this, and it can be changed and kept.", body.name ?? "")];
		justCopied = body.address;
		surface()?.openPage(body.address, true);
		show();
		return;
	}
	if (detail.what === "copy-failed") {
		state.working = false;
		state.notes = [saying("The design could not be copied — {0}", String(detail.body))];
		show();
		return;
	}
	if (detail.what === "moved") {
		state.moved = detail.body.moved ?? [];
		state.notes = state.moved.length ? state.notes : [...state.notes, say("The page came back looking the way you made it.")];
		show();
		return;
	}
	if (detail.what === "drawn") {
		const drawn = detail.body;
		const mine = state.picked?.at;
		for (const d of drawn) if (d.at === mine) state.drawn = {
			...state.drawn,
			[d.property]: d.given || d.asked
		};
		state.notes = [...whatCameOfIt(drawn), ...covered];
		covered = [];
		show();
		return;
	}
	if (detail.what === "present") {
		presentWait?.(Array.isArray(detail.body) ? detail.body : []);
		return;
	}
	if (detail.what === "ready") {
		state.stamped = !!detail.body.stamped;
		reloaded?.();
		if (state.address && !copyName && state.whose) learnWhose(state.address);
		if (recallFor && recallFor === state.address) {
			const address = recallFor;
			recallFor = null;
			recall(address);
		}
		if (state.mode === "edit" && !state.picked) tell({ do: "first" });
		tell({
			do: "point",
			on: state.mode === "edit"
		});
		show();
		return;
	}
	if (detail.what === "picked" || detail.what === "hover") {
		const picked = detail.body;
		if (detail.what === "picked") {
			state.picked = picked;
			state.drawn = picked?.drawn ?? {};
			state.palette = picked?.palette ?? [];
			state.behind = picked?.behind ?? [];
			chosenIndex = picked?.index ?? 0;
			state.hand = 0;
			state.notes = [];
			show();
		}
	}
}
/**
* The window says which page is beside this panel and where it has got to.
*
* A new address is a new document, so everything about the old one goes: what
* was pointed at, what it was drawn with, and the draft, which lived in a page
* that no longer exists. Keeping them would be a panel showing an element of a
* page that is gone (FM-DESIGN-31).
*/
/** The copy this panel has just asked for, until the binding reaches it. */
var justCopied = null;
function hereIsThePage(next, address) {
	const moved = address !== state.address;
	if (block !== null && next !== block) tell({
		do: "point",
		on: false
	}, block);
	block = next;
	if (!moved) return;
	state.address = address;
	if (address) state.site = null;
	state.savedAt = null;
	state.wrote = [];
	state.passed = [];
	state.kept = [];
	state.picked = null;
	state.drawn = {};
	state.moved = [];
	state.notes = [];
	if (foundNote && address === foundNote.address) {
		state.notes = [foundNote.text];
		foundNote = null;
	}
	if (!state.rules.length) forget();
	if (state.rules.length) {
		forget();
		state.notes = address !== null && address === justCopied ? [say("The copy carries what you changed. Point at it to keep going.")] : [say("Another page is open, so the changes you had not saved stay with the last one: open it again and they come back.")];
	}
	if (address === justCopied) justCopied = null;
	copyName = copyIn(address);
	state.stamped = copyName !== null;
	recallFor = address;
	state.framework = null;
	state.taught = false;
	state.whose = null;
	learnWhose(address);
	if (!address) lookForServers();
	state.mode = copyName !== null ? "edit" : "look";
	tell({
		do: "point",
		on: state.mode === "edit"
	});
	tell({ do: "hello" });
	if (state.mode === "edit") tell({ do: "first" });
	show();
}
/** The name of a copy, when the address is one this program serves. */
function copyIn(address) {
	if (!address) return null;
	const m = /^vobuda-design:\/\/[^/]*\/copy\/[^/]+\/([^/?#]+\.html)$/.exec(address);
	return m ? decodeURIComponent(m[1]) : null;
}
/**
* "Edit my site": the folder, and what the road needs, looked at in it
* (story 54-1, FM-DESIGN-118).
*/
async function mySite() {
	const api = surface();
	if (!api) return;
	state.site = {
		folder: null,
		framework: null,
		known: known().map((f) => f.name),
		taught: false,
		checked: false,
		starting: null,
		canStart: !!api.startServer,
		canChoose: !!api.chooseProject
	};
	show();
	await checkSite();
	lookForServers();
}
/** Look at the folder again: its kind, and whether its build marks. */
async function checkSite() {
	const api = surface();
	if (!api || !state.site) return;
	const folder = await api.project().catch(() => null);
	served = "";
	const framework = folder ? await whatProjectIsThis(filesFrom(api)).catch(() => null) : null;
	const taught = framework ? await isTaught(filesFrom(api)).catch(() => false) : false;
	if (!state.site) return;
	state.site = {
		...state.site,
		folder,
		framework,
		taught,
		checked: true
	};
	show();
}
async function chooseFolder() {
	const api = surface();
	if (!api?.chooseProject || !state.site) return;
	try {
		await api.chooseProject();
	} catch (e) {
		if (!String(e).includes("cancelled")) state.notes = [String(e)];
		show();
		return;
	}
	if (state.site) state.site = {
		...state.site,
		starting: null,
		checked: false
	};
	foundOnce = false;
	await checkSite();
}
/**
* Start the site's preview with the project's own command, in a block the
* person sees; the page opens by itself once the server is seen (story 54-2).
*/
async function startTheServer() {
	const api = surface();
	if (!api?.startServer || !state.site) return;
	try {
		const line = await api.startServer();
		state.site = {
			...state.site,
			starting: line
		};
		state.notes = [];
		foundOnce = false;
	} catch (e) {
		state.notes = [String(e)];
	}
	show();
	lookForServers();
}
/** Teach the build of the site's folder, from the first step. */
async function teachSite() {
	const api = surface();
	if (!api || !state.site?.framework) return;
	served = "";
	const taught = await teachIn(filesFrom(api));
	state.notes = taught.why ? [taught.why] : taught.files.length ? [saying("Your site now marks its parts ({0}). It can be taken back.", taught.files.join(", "))] : [say("Your site already marks its parts.")];
	await checkSite();
}
/** Where the new site goes: the person's pick with the system's chooser (54-5). */
async function buildWhere() {
	const api = surface();
	if (!api?.chooseProject || !state.build) return;
	try {
		const folder = await api.chooseProject();
		if (state.build) state.build = {
			...state.build,
			folder
		};
	} catch (e) {
		if (!String(e).includes("cancelled")) state.notes = [String(e)];
	}
	show();
}
/** The copy's own file, as the agent can open it. */
async function copyFile(api) {
	if (!copyName) return null;
	return `${(await api.workFolder("copies")).path}/${copyName}`;
}
/**
* Hand the copy and the two answers to the person's own agent, in its block,
* as an ordinary message (story 54-5, FM-DESIGN-120).
*/
async function buildGo() {
	const api = surface();
	const build = state.build;
	if (!api || !build?.about.trim() || !build.folder) return;
	const file = await copyFile(api);
	if (!file) return;
	const asked = saying("Build a new website of my own in the folder {0}, using the page saved at {1} as a visual sample only. My site is about: {2}. Take from the sample its layout, spacing, text sizes and colour relations. Take none of its words, pictures, logos, icons, names or addresses: write new text for my site, and use plain placeholders for pictures. Make it a {3} project with a \"dev\" script in package.json unless that folder already holds a site of mine — then work in that one. Do not copy the sample's file into the folder. When it is done, say so in one line.", build.folder, file, build.about.trim(), known()[0]?.name ?? "");
	try {
		await api.askAgent(asked);
		state.build = {
			...build,
			stage: "building"
		};
		state.notes = [];
	} catch (e) {
		state.notes = [String(e)];
	}
	show();
}
/** What the check found, sent back to the agent to take out. */
async function buildFix() {
	const api = surface();
	const build = state.build;
	if (!api || !build?.leaks.length) return;
	const list = build.leaks.map((l) => `- ${l.kind} “${l.what}” in ${l.file}`).join("\n");
	try {
		await api.askAgent(saying("The site you built in {0} still carries these of the sample's own. Replace each with something of my site's own, then say so in one line:\n{1}", build.folder ?? "", list));
		state.build = {
			...build,
			stage: "building",
			leaks: []
		};
	} catch (e) {
		state.notes = [String(e)];
	}
	show();
}
/**
* Read back what the agent built and compare it with the copy: any run of the
* original's words, any of its pictures, any of its names is named (story
* 54-5, FM-DESIGN-120).
*/
async function checkBuilt() {
	const api = surface();
	const build = state.build;
	if (!api || !build || !copyName) return;
	state.build = {
		...build,
		stage: "checking"
	};
	show();
	try {
		const html = await (await api.workFolder("copies")).read(copyName) ?? "";
		const original = originalOf(new DOMParser().parseFromString(html, "text/html"));
		const files = {};
		const walk = async (dir, depth) => {
			if (depth > 6 || Object.keys(files).length > 400) return;
			for (const name of await api.listSource(dir).catch(() => [])) {
				if (skipped(name)) continue;
				const path = dir === "." ? name : `${dir}/${name}`;
				const text = readable(path) ? await api.readSource(path).catch(() => null) : null;
				if (text != null) files[path] = text;
				else await walk(path, depth + 1);
			}
		};
		await walk(".", 0);
		const leaks = leaksOf(original, files);
		if (!state.build) return;
		state.build = {
			...state.build,
			stage: leaks.length ? "leaks" : "done",
			leaks
		};
	} catch (e) {
		if (state.build) state.build = {
			...state.build,
			stage: "asking"
		};
		state.notes = [String(e)];
	}
	show();
}
/** Whether this panel has opened a server by itself already. Once is enough. */
var foundOnce = false;
/** What is said when that page arrives. */
var foundNote = null;
var looking = false;
/**
* The servers this computer runs that the page beside could show.
*
* Asked while the page beside shows nothing. The one server running in this
* window's own folder is opened by itself, with its address in the bar — one
* is not a guess; several are offered, never chosen among (FM-DESIGN-10); and
* every server is shown with the folder it runs in, so a person sees which is
* theirs (run-in two, morning 23, story 54-2, FM-DESIGN-105).
*/
async function lookForServers() {
	const api = surface();
	if (!api || looking) return;
	looking = true;
	try {
		while (!state.address || state.site) {
			const listening = await api.listeningPorts().catch(() => []);
			const ports = [...new Set(listening.flatMap((b) => b.ports))].sort((a, b) => a - b);
			const root = await api.project().catch(() => null);
			const found = [];
			for (const port of ports) {
				const folder = await api.servedFrom(port).catch(() => null);
				found.push({
					port,
					folder,
					mine: !!root && !!folder && under(folder, root) !== null
				});
			}
			if (state.address && !state.site) break;
			const before = JSON.stringify(state.servers ?? []);
			state.servers = found;
			const mine = found.filter((f) => f.mine);
			if (mine.length === 1 && !foundOnce) {
				foundOnce = true;
				foundNote = {
					address: `http://localhost:${mine[0].port}/`,
					text: saying("Opened your site's preview (localhost:{0}), the one running from this folder.", mine[0].port)
				};
				state.site = null;
				if (state.address === foundNote.address && block !== null) {
					const here = foundNote;
					foundNote = null;
					state.notes = [here.text];
					await api.reloadPage(block).catch(() => {});
				} else await api.openPage(foundNote.address);
				show();
				break;
			}
			if (JSON.stringify(found) !== before) show();
			await new Promise((r) => setTimeout(r, 3e3));
		}
	} finally {
		looking = false;
	}
}
async function begin() {
	const api = surface();
	if (!api) return;
	await loadWords(api.language);
	show();
	try {
		wear(document.documentElement.style, await api.tokens());
		api.onTokens?.((tokens) => wear(document.documentElement.style, tokens));
	} catch {}
	try {
		const at = await api.boundPage();
		hereIsThePage(at?.block ?? null, at?.address ?? null);
	} catch {}
	lookForServers();
	show();
}
window.addEventListener("vobuda-plugin-page", (e) => {
	const d = e.detail;
	hereIsThePage(d?.block ?? null, d?.address ?? null);
});
window.addEventListener("vobuda-design", (e) => {
	heard(e.detail);
});
window.addEventListener("vobuda-plugin-save", () => {
	keep();
});
window.addEventListener("vobuda-plugin-answer", (e) => {
	heardAnswer(e.detail ?? {});
});
/** The agent's question standing over this panel, until it is answered. */
var question = null;
/**
* An answer, or the agent's own question, or its leaving — each said as it is.
*
* The agent that was started for a question may stop on one of its own first:
* whether to trust this folder. Only the person can answer that, so the window
* opens its block and the panel says what it asks and where, instead of
* "the answer comes back here" standing over a question nobody could see
* (FM-DESIGN-89).
*/
function heardAnswer(d) {
	const text = d.text?.trim() ?? "";
	if (d.kind === "asks") {
		if (d.card && surface()?.answerAgent) {
			question = d.card;
			state.notes = [];
			show();
			return;
		}
		state.notes = [saying("{0} is asking you something in its own block. Answer it there, and the rest comes back here by itself.", d.agent || say("The agent")), ...text ? [text] : []];
		show();
		return;
	}
	question = null;
	if (d.kind === "sent") {
		state.notes = [say("Asked. The answer comes back here.")];
		show();
		return;
	}
	if (d.kind === "left") {
		state.notes = [say("The agent closed before it was asked. Ask again to start it once more.")];
		show();
		return;
	}
	if (!text) return;
	state.sent = [...state.sent, {
		mine: false,
		text
	}];
	state.notes = [];
	show();
	if (state.build?.stage === "building") checkBuilt();
}
show();
begin();
//#endregion
