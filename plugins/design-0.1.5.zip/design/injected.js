var __vobudaDesignBundle = (function(exports) {
	Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
	//#region plugins/design/mechanical.ts
	/** What a person can change without anybody thinking about it. */
	var MECHANICAL = [
		"color",
		"background-color",
		"font-size",
		"font-weight",
		"line-height",
		"letter-spacing",
		"margin",
		"padding",
		"gap",
		"border-radius",
		"border-color",
		"border-width",
		"box-shadow",
		"text-align",
		"opacity"
	];
	//#endregion
	//#region plugins/design/palette.ts
	/** The properties worth looking at: what a person actually points at. */
	var LOOK_AT = [
		"color",
		"backgroundColor",
		"borderTopColor",
		"outlineColor"
	];
	var EMPTY = /* @__PURE__ */ new Set([
		"rgba(0, 0, 0, 0)",
		"transparent",
		"none",
		"currentcolor",
		""
	]);
	/**
	* Every colour the page draws with, most used first.
	*
	* Counted rather than collected: a site's text colour is on a thousand
	* elements and its accent on three, and a person looking for "the blue one"
	* wants them in that order — but wants both.
	*/
	function paletteOf(doc, computed, limit = 12, look = LOOK_AT) {
		const seen = /* @__PURE__ */ new Map();
		for (const el of Array.from(doc.body.querySelectorAll("*"))) {
			const style = computed(el);
			for (const key of look) {
				const raw = String(style[key] ?? "").trim();
				if (!raw || EMPTY.has(raw.toLowerCase())) continue;
				seen.set(raw, (seen.get(raw) ?? 0) + 1);
			}
		}
		return [...seen.entries()].map(([colour, times]) => ({
			colour,
			times
		})).sort((a, b) => b.times !== a.times ? b.times - a.times : a.colour.localeCompare(b.colour)).slice(0, limit);
	}
	/**
	* The palette with what is in force on one element brought to the front.
	*
	* A person changing a colour is usually replacing one, and the one they are
	* replacing is the one they want to see first — to compare against, or to put
	* back.
	*/
	function paletteFor(doc, computed, el, property = "color") {
		const all = paletteOf(doc, computed, 12, [property]);
		if (!el) return all;
		const now = String(computed(el)[property] ?? "").trim();
		if (!now || EMPTY.has(now.toLowerCase())) return all;
		return [all.find((u) => u.colour === now) ?? {
			colour: now,
			times: 1
		}, ...all.filter((u) => u.colour !== now)];
	}
	//#endregion
	//#region plugins/design/page/pick.ts
	/** The handle the designer puts on whatever was picked. */
	var AT = "data-vobuda-at";
	var PATH = "data-vobuda-file";
	var LINE = "data-vobuda-line";
	var COLUMN = "data-vobuda-column";
	/** Said by the build on an element whose words its source makes with code. */
	var WORDS_FROM = "data-vobuda-words";
	/**
	* The origin of an element, or of the nearest ancestor that has one.
	*
	* Nearest ancestor because a stamp lands on what the source wrote, and the
	* pointer lands on whatever is under it — a `<span>` the framework inserted, a
	* text node's parent, an icon inside a button. A person pointing at the icon
	* means the button.
	*/
	function originOf(el) {
		for (let at = el; at; at = at.parentElement) {
			const file = at.getAttribute(PATH);
			if (!file) continue;
			const line = Number(at.getAttribute(LINE));
			const column = Number(at.getAttribute(COLUMN));
			if (!Number.isFinite(line) || line <= 0) continue;
			const origin = {
				file,
				line,
				column: Number.isFinite(column) && column > 0 ? column : 1
			};
			const use = useOf(at);
			if (use) origin.use = use;
			return origin;
		}
		return null;
	}
	/** A value as an attribute selector may hold it. */
	var quoted = (v) => (v ?? "").replace(/["\\]/g, "\\$&");
	/** Where the use of a component that drew this element is written, as the build marks it. */
	var USE = "data-vobuda-use";
	/**
	* The one use of a component that drew this element — when the build marks
	* it, and when no other element drawn from the same place was drawn by the
	* same use. A list that draws a card three times from one line of a `map`
	* is one use for three cards, and "only here" cannot be written to it
	* (story 54-6, FM-DESIGN-126).
	*/
	function useOf(el) {
		const said = el.getAttribute(USE);
		const m = said ? /^(.+):(\d+):(\d+)$/.exec(said) : null;
		if (!m) return void 0;
		if (Array.from(el.ownerDocument.querySelectorAll(`[${PATH}="${quoted(el.getAttribute(PATH))}"][${LINE}="${quoted(el.getAttribute(LINE))}"]`)).filter((other) => other.getAttribute("data-vobuda-use") === said).length !== 1) return void 0;
		return {
			file: m[1],
			line: Number(m[2]),
			column: Number(m[3])
		};
	}
	/** The element a stamp belongs to, which is what a person means by "this". */
	function stampedAncestor(el) {
		for (let at = el; at; at = at.parentElement) if (at.getAttribute(PATH)) return at;
		return el;
	}
	/**
	* Tags that dress a piece of text rather than being a thing of their own.
	*
	* A `<span>` around the second line of a heading is how the heading is
	* coloured; nobody looking at it thinks "a span". `<a>` and `<button>` are not
	* here on purpose: those a person does point at and does mean.
	*/
	var DRESSING = /* @__PURE__ */ new Set([
		"SPAN",
		"B",
		"I",
		"EM",
		"STRONG",
		"U",
		"S",
		"SMALL",
		"MARK",
		"SUB",
		"SUP",
		"FONT",
		"BDI",
		"BDO",
		"ABBR",
		"TIME"
	]);
	/**
	* What a person means by pointing at a piece of text.
	*
	* The thing it is part of, not the tag that colours it. Gary, having pointed
	* at the second line of a heading and been handed the span holding it: «этого
	* не должно быть! изменения должны быть в этом поле» — with a picture of the
	* card naming the block around it. A copy this program writes stamps every
	* element, so without this the nearest stamp is always the innermost tag
	* (FM-DESIGN-64).
	*/
	function meantBy(el) {
		const icon = el?.closest?.("svg");
		let at = icon && icon.parentElement ? icon.parentElement : el;
		while (at && DRESSING.has(at.tagName) && at.parentElement) at = at.parentElement;
		return at;
	}
	/**
	* A short name for an element, as a person would say it.
	*
	* The tag, then whatever most distinguishes it. Not a CSS selector: a person
	* reading `div.grid > div:nth-child(3) > button.btn-primary` learns nothing
	* they did not already know by looking at the screen.
	*/
	function nameOf(el) {
		const tag = el.tagName.toLowerCase();
		const text = (el.textContent ?? "").trim().replace(/\s+/g, " ");
		if (text && text.length <= 24) return `${tag} “${text}”`;
		if (text) return `${tag} “${text.slice(0, 22)}…”`;
		const id = el.getAttribute("id");
		if (id) return `${tag}#${id}`;
		const cls = (el.getAttribute("class") ?? "").trim().split(/\s+/)[0];
		return cls ? `${tag}.${cls}` : tag;
	}
	/**
	* How many places the same source line is drawn in.
	*
	* The number decides whether the menu offers "only here" against "everywhere
	* this appears" at all: offering the choice when there is nothing to choose is
	* a question that teaches people to stop reading questions. Counted off the
	* page rather than out of the source, because the page is what the person is
	* looking at.
	*/
	/** Which of the elements drawn from one place this one is, in the page's order. */
	function placeOf(doc, origin, el) {
		if (!origin) return 0;
		const escaped = origin.file.replace(/["\\]/g, "\\$&");
		const all = Array.from(doc.querySelectorAll(`[${PATH}="${escaped}"][${LINE}="${origin.line}"]`));
		return Math.max(0, all.indexOf(el));
	}
	function drawnTimes(doc, origin) {
		if (!origin) return 1;
		const escaped = origin.file.replace(/["\\]/g, "\\$&");
		return doc.querySelectorAll(`[${PATH}="${escaped}"][${LINE}="${origin.line}"]`).length;
	}
	/**
	* The first thing on the page that says something, as if it were pointed at.
	*
	* Gary, looking at a panel that had just copied a whole site and was asking
	* him to point at something: «вместо этой надписи тут должно быть первое слово
	* уже со скопированного сайта». A copy opens to be changed, so it opens with
	* something in hand — the first words a reader would meet (FM-DESIGN-66).
	*
	* Read top to bottom and taken by what it says, not by where it sits: the
	* first text on a page is usually a logo's alt or a skip link, so anything
	* hidden and anything of the designer's own is passed over.
	*/
	var SEEN = 8;
	/** Whether the middle of the element is under an element with words of its own. */
	function coveredByWords(doc, el, box) {
		if (typeof doc.elementFromPoint !== "function" || box.width <= 0 || box.height <= 0) return false;
		const top = doc.elementFromPoint(box.left + box.width / 2, box.top + box.height / 2);
		if (!top || top === el || el.contains(top) || top.contains(el)) return false;
		if (/^(STYLE|SCRIPT|IMG|SVG|PICTURE|VIDEO|CANVAS)$/i.test(top.tagName) || top.closest("svg")) return false;
		if (top.closest(`[data-vobuda-design]`)) return false;
		return (top.textContent ?? "").trim().length > 0;
	}
	/** Whether a box around the element hides overflow and holds none of it. */
	function clippedAway(el, box, view) {
		for (let up = el.parentElement; up && up !== el.ownerDocument.body; up = up.parentElement) {
			const style = view.getComputedStyle(up);
			if (!/(hidden|clip)/.test(style.overflow + style.overflowX + style.overflowY)) continue;
			const around = up.getBoundingClientRect();
			if (!(box.left < around.left + around.width && box.left + box.width > around.left && box.top < around.top + around.height && box.top + box.height > around.top)) return true;
		}
		return false;
	}
	function firstWords(doc) {
		const walker = doc.createTreeWalker(doc.body, 4);
		for (let node = walker.nextNode(); node; node = walker.nextNode()) {
			if (!(node.textContent ?? "").trim()) continue;
			const holder = node.parentElement;
			if (!holder || holder.closest("[data-vobuda-ours]")) continue;
			if (/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/.test(holder.tagName)) continue;
			if (!seen(doc, holder)) continue;
			const picked = pickOf(doc, holder);
			if (picked && picked.words.length) return picked;
		}
		return null;
	}
	/**
	* Whether a person can see this element on the screen now — the question the
	* first words are chosen by, asked again when the page is laid out anew
	* (FM-DESIGN-123).
	*/
	function seen(doc, holder) {
		const box = holder.getBoundingClientRect();
		if (box.width < SEEN || box.height < SEEN) return false;
		const view = doc.defaultView;
		if (view) {
			if (box.bottom <= 0 || box.top >= view.innerHeight) return false;
			if (box.right <= 0 || box.left >= view.innerWidth) return false;
			const style = view.getComputedStyle(holder);
			if (style.visibility === "hidden" || Number(style.opacity) < .05) return false;
			if (/rect\(\s*0(px)?[\s,]+0(px)?[\s,]+0(px)?[\s,]+0(px)?\s*\)/.test(style.clip) || /inset\(\s*50%/.test(style.clipPath)) return false;
		}
		if (view && clippedAway(holder, box, view)) return false;
		if (coveredByWords(doc, holder, box)) return false;
		const asks = holder;
		if (typeof asks.checkVisibility === "function" && !asks.checkVisibility({
			opacityProperty: true,
			visibilityProperty: true,
			contentVisibilityAuto: true
		})) return false;
		return true;
	}
	/** Everything about what is under a point, in the page's own coordinates. */
	var handed = 0;
	function pickAt(doc, x, y) {
		const under = doc.elementFromPoint(x, y);
		if (!under) return null;
		return pickOf(doc, under);
	}
	/**
	* Everything about one element, whoever chose it.
	*
	* Taken apart from `pickAt` so that a choice made any other way — the first
	* words of a page, a thing an agent named — comes back in exactly the same
	* shape. Asking by coordinates instead lands on whatever is drawn at that
	* point, which is how "the first words of this page" came back as the logo
	* sitting over them (FM-DESIGN-66).
	*/
	function pickOf(doc, of) {
		const el = meantBy(stampedAncestor(of) ?? of) ?? of;
		const origin = originOf(el);
		const r = el.getBoundingClientRect();
		let at = el.getAttribute(AT);
		if (!at) {
			at = String(handed += 1);
			el.setAttribute(AT, at);
		}
		const view = doc.defaultView;
		const handle = (e) => {
			let has = e.getAttribute(AT);
			if (!has) {
				has = String(handed += 1);
				e.setAttribute(AT, has);
			}
			return has;
		};
		return {
			at,
			what: nameOf(el),
			origin,
			box: {
				x: r.left,
				y: r.top,
				width: r.width,
				height: r.height
			},
			siblings: drawnTimes(doc, origin),
			index: placeOf(doc, origin, el),
			drawn: drawnWith(doc, el),
			palette: view ? paletteFor(doc, (e) => view.getComputedStyle(e), el, "color").map((u) => u.colour) : [],
			behind: view ? paletteFor(doc, (e) => view.getComputedStyle(e), el, "backgroundColor").map((u) => u.colour) : [],
			words: runsIn(el, handle)
		};
	}
	/** How many runs a container offers at once. */
	var RUNS = 24;
	/**
	* Every run of words inside an element, each on the element that holds it.
	*
	* A run is a piece of text, not an element. That distinction is the whole
	* lesson: `<h1>Employee Scheduling Software<span>for Shift-Based Teams</span>
	* </h1>` says two things, and the first belongs to the h1 itself — it is a
	* text node with no element of its own, so a walk over elements never sees it.
	* Gary, having picked that very heading and been offered the span's half
	* alone: «этого не должно быть! изменения должны быть в этом поле»
	* (FM-DESIGN-62).
	*
	* Handles are put on as the runs are found, the same handle the pick itself
	* uses, so a rule written against a run addresses one element and one piece of
	* text inside it.
	*/
	function runsIn(el, handle) {
		const out = [];
		const doc = el.ownerDocument;
		const walker = doc.createTreeWalker(el, 4);
		const seen = /* @__PURE__ */ new Map();
		for (let node = walker.nextNode(); node; node = walker.nextNode()) {
			if (out.length >= RUNS) break;
			const text = (node.textContent ?? "").trim();
			if (!text) continue;
			const holder = node.parentElement;
			if (!holder) continue;
			if (holder.closest("[data-vobuda-ours]")) continue;
			if (/^(SCRIPT|STYLE|NOSCRIPT|TEMPLATE)$/.test(holder.tagName)) continue;
			const part = seen.get(holder) ?? 0;
			seen.set(holder, part + 1);
			const origin = originOf(holder);
			const view = doc.defaultView;
			out.push({
				at: handle(holder),
				origin,
				what: nameOf(holder),
				part,
				siblings: drawnTimes(doc, origin),
				colour: view ? view.getComputedStyle(holder).color.trim() : "",
				fill: view ? view.getComputedStyle(holder).getPropertyValue("-webkit-text-fill-color").trim() : "",
				text,
				code: stampedAncestor(holder)?.getAttribute(WORDS_FROM) === "code"
			});
		}
		return out;
	}
	/**
	* The values a person can move, as the page computes them this second.
	*
	* Computed and not declared: what a person sees is the value in force, and the
	* value in force is the one a nudge steps from. Read here because only here
	* can it be read — the panel is a webview of its own, and asking
	* `getComputedStyle` there answers about the panel.
	*/
	function drawnWith(doc, el) {
		const view = doc.defaultView;
		if (!view) return {};
		const style = view.getComputedStyle(el);
		const out = {};
		for (const property of MECHANICAL) {
			const value = style.getPropertyValue(property).trim();
			if (!value || value === "none" || value === "normal" || value === "auto") continue;
			out[property] = tidy(shortened(value));
		}
		const over = style.getPropertyValue("background-image").trim();
		if (over && over !== "none") out["background-image"] = over;
		return out;
	}
	/**
	* Numbers a person reads: `-0.171875px` is `-0.17px`, `27.540001px` is
	* `27.54px` — the engine's arithmetic, not anybody's design (run-in, item 20).
	* Two places after the point, trailing zeros off.
	*/
	function tidy(value) {
		return value.replace(/-?\d*\.\d+/g, (n) => String(Math.round(Number(n) * 100) / 100));
	}
	/** `12px 12px 12px 12px` is one number wearing four hats. */
	function shortened(value) {
		const parts = value.split(/\s+/);
		if (parts.length === 4 && parts.every((p) => p === parts[0])) return parts[0];
		if (parts.length === 2 && parts[0] === parts[1]) return parts[0];
		return value;
	}
	/**
	* Whether this element is the designer's own drawing rather than the site's.
	*
	* The outline is a node in the page, so without this the first thing the
	* pointer would find is the outline itself, and pointing would select the
	* pointer.
	*/
	var OURS$1 = "data-vobuda-design";
	var isOurs = (el) => !!el?.closest(`[${OURS$1}]`);
	//#endregion
	//#region plugins/design/page/draft.ts
	var SHEET = "vobuda-design-draft";
	var MARK = "data-vobuda-draft";
	var escape = (s) => s.replace(/["\\]/g, "\\$&");
	/** Every element carrying one stamp, in the order the page draws them. */
	function carrying(doc, origin) {
		return Array.from(doc.querySelectorAll(`[data-vobuda-file="${escape(origin.file)}"][data-vobuda-line="${origin.line}"]`));
	}
	/** The key one rule is remembered by: one property of one place. */
	var keyOf = (r) => r.origin ? `${r.origin.file}:${r.origin.line}:${r.origin.column}:${r.index}:${r.everywhere}:${r.property}` : `at:${r.at}:${r.property}`;
	/**
	* The last word on each property of each place.
	*
	* A person changes a colour, changes their mind, changes it again: three
	* changes and one decision. A stack that grows with every nudge is a stack that
	* hands a hundred edits to whatever reads it next.
	*/
	function settle(rules) {
		const last = /* @__PURE__ */ new Map();
		for (const r of rules) last.set(keyOf(r), r);
		return [...last.values()];
	}
	/** The mark an "only here" rule needs, since a stamp cannot say which one. */
	var markOf = (r) => r.origin ? `${r.origin.file}|${r.origin.line}|${r.index}` : `at|${r.at}`;
	/**
	* Put the marks back on the elements that need them.
	*
	* Called after every reload, and after any change to the page: the element may
	* be a new one, but it is the same one by stamp and by position among its
	* siblings, which is what the person pointed at.
	*/
	function remark(doc, rules) {
		for (const old of Array.from(doc.querySelectorAll(`[${MARK}]`))) old.removeAttribute(MARK);
		for (const r of rules) {
			if (r.everywhere) continue;
			const el = r.origin ? carrying(doc, r.origin)[r.index] : doc.querySelector(`[${AT}="${escape(r.at)}"]`);
			if (el) el.setAttribute(MARK, markOf(r));
		}
	}
	/** The stylesheet, as one string. */
	/** The property name a change of the words goes under. */
	var WORDS = "#text";
	/** Whether a rule changes what an element says rather than how it looks. */
	var isWords = (r) => r.property === WORDS;
	function sheetOf(rules) {
		const lines = [];
		for (const r of settle(rules)) {
			if (isWords(r)) continue;
			const where = r.everywhere && r.origin ? `[data-vobuda-file="${escape(r.origin.file)}"][data-vobuda-line="${r.origin.line}"]` : `[${MARK}="${escape(markOf(r))}"]`;
			lines.push(`${where} { ${r.property}: ${r.value} !important; }`);
		}
		return lines.join("\n");
	}
	/**
	* Apply the draft to the page.
	*
	* Idempotent on purpose: it is called after every reload, after every change,
	* and whenever anything is unsure — and calling it twice must cost nothing but
	* the work of writing one string.
	*/
	/**
	* Put the words a person typed onto the elements they belong to.
	*
	* Separate from the stylesheet because text is not a declaration: CSS can
	* decorate an element and cannot say what it says. Addressed the same way
	* everything else is — the stamp when there is one, the handle otherwise — so
	* it survives a re-render exactly as the rest of the draft does.
	*/
	function applyWords(doc, rules) {
		for (const r of settle(rules)) {
			if (!isWords(r)) continue;
			const el = r.origin ? carrying(doc, r.origin)[r.index] : doc.querySelector(`[${AT}="${escape(r.at)}"]`);
			if (!el) continue;
			const run = runsOf(el)[r.part ?? 0];
			if (run) {
				if (run.data.trim() !== r.value) run.data = r.value;
				continue;
			}
			if (el.textContent !== r.value) el.textContent = r.value;
		}
	}
	/**
	* The text nodes an element says directly, in the order they are read.
	*
	* Direct children only: what a nested element says belongs to that element and
	* is addressed against it. Whitespace between tags is layout rather than words.
	*/
	function runsOf(el) {
		return Array.from(el.childNodes).filter((n) => n.nodeType === 3 && (n.textContent ?? "").trim() !== "");
	}
	function apply(doc, rules) {
		remark(doc, rules);
		applyWords(doc, rules);
		let style = doc.getElementById(SHEET);
		if (!style) {
			style = doc.createElement("style");
			style.id = SHEET;
			style.setAttribute(OURS$1, "draft");
			doc.head.appendChild(style);
		}
		const next = sheetOf(rules);
		if (style.textContent !== next) style.textContent = next;
	}
	/** Take the draft off the page, leaving the site as its own files say. */
	function drop(doc) {
		doc.getElementById(SHEET)?.remove();
		for (const el of Array.from(doc.querySelectorAll(`[${MARK}]`))) el.removeAttribute(MARK);
	}
	//#endregion
	//#region plugins/design/page/copy.ts
	/** Tags whose content is not markup and must be emitted as it stands. */
	var RAW = /* @__PURE__ */ new Set([
		"STYLE",
		"TEXTAREA",
		"TITLE"
	]);
	/** Tags with no closing half. */
	var VOID = /* @__PURE__ */ new Set([
		"AREA",
		"BASE",
		"BR",
		"COL",
		"EMBED",
		"HR",
		"IMG",
		"INPUT",
		"LINK",
		"META",
		"PARAM",
		"SOURCE",
		"TRACK",
		"WBR"
	]);
	/** Tags a copy never carries. */
	var DROP = /* @__PURE__ */ new Set([
		"SCRIPT",
		"NOSCRIPT",
		"TEMPLATE"
	]);
	/**
	* Elements that bring somebody else's program with them.
	*
	* A copy keeps their box, because the design has a hole that shape, and loses
	* what loads inside it. An advertisement's frame in a copy of walla.co.il
	* carried its own scripts and moved the whole page to an article — a copy is a
	* design somebody is changing, and a design that walks away while they look at
	* it is not one (FM-DESIGN-50).
	*/
	var HOLLOW = /* @__PURE__ */ new Set([
		"IFRAME",
		"FRAME",
		"OBJECT",
		"EMBED",
		"PORTAL"
	]);
	/** What is taken off them, so the box is all that is left. */
	var LOADS = /^(src|srcdoc|data|allow|allowfullscreen|loading|csp|credentialless)$/i;
	var escapeText = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	var escapeAttr = (s) => s.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;");
	/** The mark this program leaves on nothing but its own work. */
	var OURS = /^data-vobuda-/;
	/**
	* Every stylesheet of this page, as text.
	*
	* Read through the DOM where the browser lets us — a same-origin sheet, or one
	* served with the header that allows it — and left as a link where it does
	* not. A link that stays is still a working link, because the copy carries a
	* base: the copy then looks right and simply cannot be edited through that
	* sheet, which is a smaller loss than a copy that looks wrong.
	*/
	function stylesOf(doc) {
		const inline = [];
		const linked = /* @__PURE__ */ new Set();
		const read = /* @__PURE__ */ new Set();
		for (const sheet of Array.from(doc.styleSheets)) {
			const owner = sheet.ownerNode;
			if (owner && (owner.id === "vobuda-design-draft" || owner.hasAttribute?.("data-vobuda-ours"))) continue;
			let rules = null;
			try {
				rules = sheet.cssRules;
			} catch {
				rules = null;
			}
			if (rules) {
				const text = Array.from(rules).map((r) => r.cssText).join("\n");
				if (text.trim()) inline.push(text);
				if (sheet.href) read.add(sheet.href);
				continue;
			}
			if (sheet.href) linked.add(sheet.href);
		}
		for (const link of Array.from(doc.querySelectorAll("link[rel~=stylesheet][href]"))) {
			const href = link.href || link.getAttribute("href") || "";
			if (href && !read.has(href)) linked.add(href);
		}
		return {
			inline,
			linked: [...linked]
		};
	}
	/**
	* What the person has changed, as rules a copy can carry on its own.
	*
	* The draft is a stylesheet the designer owns inside the page, and its
	* selectors are the marks and stamps of the page it was drawn on. Those go:
	* the copy is a new file with stamps of its own, so each rule is re-addressed
	* to the element it was about, by the handle that element has *in the copy*.
	*/
	function draftIn(doc, placed) {
		const text = doc.getElementById("vobuda-design-draft")?.textContent ?? "";
		if (!text.trim()) return [];
		const out = [];
		for (const line of text.split("\n")) {
			const m = /^(.+?)\s*\{\s*(.+?)\s*!important;?\s*\}$/.exec(line.trim());
			if (!m) continue;
			let hit = [];
			try {
				hit = [...doc.querySelectorAll(m[1])];
			} catch {
				hit = [];
			}
			for (const el of hit) {
				const line = placed.get(el);
				if (line) out.push(`[data-vobuda-line="${line}"] { ${m[2]}; }`);
			}
		}
		return out;
	}
	/**
	* The page as a file this program wrote, with every element told where it is.
	*
	* One start tag per line on purpose. A stamp is a line and a column, and a
	* serialiser that wrapped or packed tags would have to compute where each one
	* landed; emitting one per line makes the answer the line counter itself, and
	* a thing that cannot be got wrong does not need a check to say it was not.
	*/
	function copied(doc, name) {
		const out = [];
		const base = asTyped(doc.baseURI || doc.location?.href || "");
		const { inline, linked } = stylesOf(doc);
		out.push("<!doctype html>");
		out.push(`<html lang="${escapeAttr(doc.documentElement.lang || "en")}">`);
		out.push("<head>");
		if (base) out.push(`<base href="${escapeAttr(base)}">`);
		out.push("<meta charset=\"utf-8\">");
		const title = doc.title ? escapeText(doc.title) : name;
		out.push(`<title>${title}</title>`);
		for (const href of linked) out.push(`<link rel="stylesheet" href="${escapeAttr(href)}">`);
		for (const text of inline) {
			out.push("<style>");
			out.push(...text.split("\n"));
			out.push("</style>");
		}
		out.push("</head>");
		const placed = /* @__PURE__ */ new Map();
		writeInto(doc.body, out, 1, name, placed);
		const kept = draftIn(doc, placed);
		if (kept.length) {
			out.push("<style>");
			out.push(...kept);
			out.push("</style>");
		}
		out.push("</html>");
		return out.join("\n") + "\n";
	}
	/**
	* Write one element and everything under it, stamping as it goes.
	*
	* `out.length + 1` is the line this tag is about to land on, and the
	* indentation decides the column — both known before the line is pushed, which
	* is why the stamp is exact rather than estimated.
	*/
	function writeInto(el, out, depth, file, placed) {
		if (!el) return;
		const tag = el.tagName;
		if (DROP.has(tag)) return;
		if (el.id === "vobuda-design-draft" || el.hasAttribute("data-vobuda-ours")) return;
		const pad = "  ".repeat(depth);
		const line = out.length + 1;
		const column = pad.length + 1;
		const hollow = HOLLOW.has(tag);
		const attrs = [];
		for (const a of Array.from(el.attributes)) {
			if (OURS.test(a.name)) continue;
			if (/^on/i.test(a.name)) continue;
			if (hollow && LOADS.test(a.name)) continue;
			attrs.push(`${a.name}="${escapeAttr(a.value)}"`);
		}
		if (hollow) attrs.push("sandbox=\"\"");
		attrs.push(`data-vobuda-file="${escapeAttr(file)}"`);
		attrs.push(`data-vobuda-line="${line}"`);
		attrs.push(`data-vobuda-column="${column}"`);
		placed.set(el, line);
		const name = tag.toLowerCase();
		const open = `${pad}<${name}${attrs.length ? " " + attrs.join(" ") : ""}>`;
		if (VOID.has(tag)) {
			out.push(open);
			return;
		}
		out.push(open);
		if (RAW.has(tag)) out.push(...(el.textContent ?? "").split("\n"));
		else for (const node of Array.from(el.childNodes)) if (node.nodeType === 1) writeInto(node, out, depth + 1, file, placed);
		else if (node.nodeType === 3) {
			const text = (node.textContent ?? "").replace(/\s+/g, " ");
			if (text.trim()) out.push(`${pad}  ${escapeText(text.trim())}`);
		}
		out.push(`${pad}</${name}>`);
	}
	/**
	* An address on the program's own scheme, written back as the site's own.
	*
	* `vobuda-design://vobuda.com/ru/prices` → `https://vobuda.com/ru/prices`. The
	* host is the site's own name — a site reads its own name, so the program does
	* not rename it (FM-DESIGN-48) — and https is the assumption here, because
	* what the scheme really was is the window's to remember rather than the
	* page's. `localhost` is the program's own host and is left alone: that one is
	* a copy, and a copy's base is already written into it.
	*/
	function asTyped(address) {
		try {
			const url = new URL(address);
			if (url.protocol !== "vobuda-design:" || !url.hostname) return address;
			if (url.hostname === "localhost" || url.hostname === "127.0.0.1") return address;
			return `https://${url.host}${url.pathname}${url.search}`;
		} catch {
			return address;
		}
	}
	/** A name for a copy, from where it came from and when. */
	function nameFor(address, when) {
		let host = "page";
		try {
			host = new URL(address).host.replace(/[^a-z0-9.-]/gi, "-") || "page";
		} catch {
			host = "page";
		}
		const two = (n) => String(n).padStart(2, "0");
		const stamp = `${when.getFullYear()}${two(when.getMonth() + 1)}${two(when.getDate())}-${two(when.getHours())}${two(when.getMinutes())}${two(when.getSeconds())}`;
		return `${host}-${stamp}.html`;
	}
	//#endregion
	//#region plugins/design/page/verify.ts
	/**
	* Read what the page computes for the elements a rule was about.
	*
	* `everywhere` means every element carrying the stamp; otherwise the one at the
	* index the person pointed at. The reading is handed in rather than taken from
	* the global, so a check can drive this with a page it made up.
	*/
	function asDrawn(doc, rule, computed) {
		if (!rule.origin) return [];
		const all = carrying(doc, rule.origin);
		const which = rule.everywhere ? all : all.slice(rule.index, rule.index + 1);
		if (isWords(rule)) return which.map((el) => {
			const run = runsOf(el)[rule.part ?? 0];
			return (run ? run.data : el.textContent ?? "").trim();
		});
		const key = rule.property.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
		return which.map((el) => String(computed(el)[key] ?? "").trim());
	}
	/**
	* Whether two values mean the same thing on a page.
	*
	* A browser answers in its own spelling: `red` comes back as `rgb(255, 0, 0)`,
	* `0.50` as `0.5`, `#fff` as `rgb(255, 255, 255)`. Comparing the strings would
	* report every single change as having moved, and a warning that fires on
	* correct work teaches people to ignore warnings — which this project has
	* already learnt once tonight.
	*/
	function same$1(a, b) {
		const norm = (v) => v.trim().toLowerCase().replace(/\s+/g, " ").replace(/;$/, "");
		if (norm(a) === norm(b)) return true;
		const num = (v) => Number(v.replace(/[^\d.-]/g, ""));
		const unit = (v) => /[a-z%]+$/.exec(v.trim())?.[0] ?? "";
		if (unit(a) === unit(b) && Number.isFinite(num(a)) && Number.isFinite(num(b))) return Math.abs(num(a) - num(b)) < .001;
		return false;
	}
	/**
	* What moved between the draft and the page that came back.
	*
	* Empty is the good answer and is the one a person should usually see. What is
	* not empty is named — which element, which property, what was promised and
	* what is drawn — because a difference absorbed in silence is a preview that
	* lied, and a preview that lied is worse than no preview at all: it was
	* believed.
	*/
	function whatMoved(doc, rules, computed) {
		const moved = [];
		for (const rule of rules) for (const given of asDrawn(doc, rule, computed)) if (!same$1(given, rule.value)) moved.push({
			rule,
			promised: rule.value,
			given
		});
		return moved;
	}
	/** One sentence per thing that moved, for the person rather than for a log. */
	function saying(moved) {
		return moved.map((m) => `${m.rule.origin ? `${m.rule.origin.file}:${m.rule.origin.line}` : m.rule.property} — ${m.rule.property} was drawn as ${m.given}, not ${m.promised}. Something in the project's own styles is winning.`);
	}
	//#endregion
	//#region plugins/design/page/outline.ts
	var HOVER = "vobuda-design-hover";
	var HELD = "vobuda-design-held";
	/** The style those two nodes are drawn with, kept in one place. */
	var STYLE = `
[${OURS$1}] {
  position: fixed;
  pointer-events: none;
  z-index: 2147483646;
  border-radius: 3px;
  transition: all 90ms cubic-bezier(0.2, 0, 0, 1);
}
/* A line around it, and nothing over it. A wash of colour across the element
   covers the very thing somebody is looking at — the design — and on a page
   of large type it reads as the tool having selected the whole site rather
   than as a pointer resting on one heading (FM-DESIGN-49). */
[${OURS$1}="hover"] { outline: 1px solid rgba(90, 150, 255, 0.75); }
[${OURS$1}="held"]  { outline: 2px solid rgba(90, 150, 255, 1); }
[${OURS$1}="name"] {
  position: fixed; pointer-events: none; z-index: 2147483647;
  font: 10px/1.4 ui-sans-serif, system-ui, sans-serif;
  padding: 1px 5px; border-radius: 3px;
  background: rgba(20, 28, 46, 0.82); color: #eaf1ff; white-space: nowrap;
  max-width: 40vw; overflow: hidden; text-overflow: ellipsis;
}
`;
	function node(doc, kind) {
		const id = kind === "hover" ? HOVER : kind === "held" ? HELD : `vobuda-design-${kind}`;
		let el = doc.getElementById(id);
		if (!el) {
			el = doc.createElement("div");
			el.id = id;
			el.setAttribute(OURS$1, kind);
			doc.body.appendChild(el);
		}
		return el;
	}
	/** Put the designer's own stylesheet into the page, once. */
	function dress(doc) {
		if (doc.getElementById("vobuda-design-style")) return;
		const style = doc.createElement("style");
		style.id = "vobuda-design-style";
		style.setAttribute(OURS$1, "style");
		style.textContent = STYLE;
		doc.head.appendChild(style);
	}
	/** Show one of the two outlines around a box, with a name beside it. */
	function show(doc, kind, picked) {
		dress(doc);
		const box = node(doc, kind);
		const { x, y, width, height } = picked.box;
		box.style.left = `${x}px`;
		box.style.top = `${y}px`;
		box.style.width = `${width}px`;
		box.style.height = `${height}px`;
		box.style.display = "block";
		if (kind !== "held") return;
		const name = node(doc, "name");
		name.textContent = picked.what;
		const above = y >= 22;
		name.style.left = `${x}px`;
		name.style.top = above ? `${y - 20}px` : `${y + height + 4}px`;
		name.style.display = "block";
	}
	/** Take one away. */
	function hide(doc, kind) {
		const el = doc.getElementById(kind === "hover" ? HOVER : HELD);
		if (el) el.style.display = "none";
		if (kind === "held") {
			const name = doc.getElementById("vobuda-design-name");
			if (name) name.style.display = "none";
		}
	}
	/**
	* Take every trace of the designer out of the page.
	*
	* Called when the session ends or the plugin is removed. A page left with the
	* designer's nodes in it after the designer is gone is the same litter
	* FM-PLUGIN-2 forbids, one level down.
	*/
	function undress(doc) {
		for (const el of Array.from(doc.querySelectorAll(`[${OURS$1}]`))) el.remove();
	}
	//#endregion
	//#region plugins/design/page/listen.ts
	/**
	* Start pointing.
	*
	* The press is taken on `pointerdown` and the site's own handler is stopped:
	* a person choosing a button does not want the button's link followed. That is
	* the whole reason this is a mode a person turns on rather than something the
	* page carries all the time.
	*
	* Stopping `pointerdown` is not stopping the click. They are different events,
	* and a link is followed on the click — so choosing a headline in a copy of a
	* news site opened the article and the copy was gone. Gary: «при нажатии тут
	* на картинке на какое то словосочетание вместо изменения я перехожу на другую
	* страницу. оно должно оставаться всегда на одной странице которую
	* скопировало» (FM-DESIGN-51). While pointing, every way a page has of going
	* somewhere by a press is swallowed.
	*/
	function pointAt(doc, report) {
		let last = null;
		const move = (e) => {
			if (isOurs(doc.elementFromPoint(e.clientX, e.clientY))) return;
			const picked = pickAt(doc, e.clientX, e.clientY);
			if (!picked) {
				hide(doc, "hover");
				last = null;
				return;
			}
			if (last && same(last, picked)) return;
			last = picked;
			show(doc, "hover", picked);
			report("hover", picked);
		};
		/** When the last press picked something, so the menu after it is not a second pick. */
		let pressedAt = -Infinity;
		const press = (e) => {
			if (isOurs(doc.elementFromPoint(e.clientX, e.clientY))) return;
			const picked = pickAt(doc, e.clientX, e.clientY);
			if (!picked) return;
			e.preventDefault();
			e.stopPropagation();
			pressedAt = e.timeStamp;
			show(doc, "held", picked);
			follow(picked);
			report("picked", picked);
		};
		/**
		* A right-click picks, the same as a press, and opens nothing of its own.
		*
		* The card in the panel is the menu (54-8): the site's own context menu and
		* the engine's "Reload / Inspect" are swallowed while pointing, the way a
		* press's click is (FM-DESIGN-51). The right button's own `pointerdown`
		* already picked; a menu that comes without one — the keyboard's menu key,
		* a Control-click that sent no press — picks here (FM-DESIGN-115).
		*/
		const menu = (e) => {
			const target = e.target;
			if (typeof target?.closest === "function" && isOurs(target)) return;
			e.preventDefault();
			e.stopPropagation();
			if (e.timeStamp - pressedAt < 1e3) return;
			press(e);
		};
		const follow = (picked) => holdOn(doc, picked);
		const leave = () => {
			hide(doc, "hover");
			last = null;
		};
		/** Everything a press turns into after the pointer is down. */
		const GOING = [
			"click",
			"auxclick",
			"dblclick",
			"submit",
			"dragstart"
		];
		const swallow = (e) => {
			if (isOurs(e.target)) return;
			e.preventDefault();
			e.stopPropagation();
		};
		doc.addEventListener("pointermove", move, true);
		doc.addEventListener("pointerdown", press, true);
		doc.addEventListener("pointerleave", leave, true);
		doc.addEventListener("contextmenu", menu, true);
		for (const kind of GOING) doc.addEventListener(kind, swallow, true);
		return { stop() {
			doc.removeEventListener("pointermove", move, true);
			doc.removeEventListener("pointerdown", press, true);
			doc.removeEventListener("pointerleave", leave, true);
			doc.removeEventListener("contextmenu", menu, true);
			for (const kind of GOING) doc.removeEventListener(kind, swallow, true);
			letGo(doc);
			undress(doc);
		} };
	}
	var same = (a, b) => a.what === b.what && a.box.x === b.box.x && a.box.y === b.box.y && a.box.width === b.box.width && a.box.height === b.box.height;
	/** What each page is following: the element in hand and what watches it. */
	var following = /* @__PURE__ */ new WeakMap();
	/**
	* Keep the held outline on its element, whatever moves it.
	*
	* The outline stays on the element as the page moves under it: a block made
	* narrower, a scroll, a change of size from the draft itself (run-in, item 15,
	* FM-DESIGN-96). It was set up only for a press of the mouse, so an element in
	* hand by any other road — the first words a page opens on, a field chosen in
	* the panel — kept an outline drawn once; and the hover outline stayed at the
	* old size beside the new one, the faint second frame of run-in two
	* (morning 15, small 19, FM-DESIGN-103). Now every road holds on through this,
	* a change of words re-reads it too, and the hover outline goes with any change.
	*/
	function holdOn(doc, picked) {
		letGo(doc);
		const el = picked.at ? doc.querySelector(`[data-vobuda-at="${picked.at.replace(/["\\]/g, "\\$&")}"]`) : null;
		if (!el) return;
		const again = () => {
			if (!el.isConnected) return;
			hide(doc, "hover");
			const now = pickOf(doc, el);
			if (now) show(doc, "held", now);
		};
		const view = doc.defaultView;
		const sized = view?.ResizeObserver ? new view.ResizeObserver(again) : null;
		sized?.observe(el);
		sized?.observe(doc.documentElement);
		const worded = view?.MutationObserver ? new view.MutationObserver(again) : null;
		worded?.observe(el, {
			characterData: true,
			childList: true,
			subtree: true
		});
		const draft = doc.getElementById("vobuda-design-draft");
		if (draft && worded) worded.observe(draft, {
			characterData: true,
			childList: true,
			subtree: true
		});
		view?.addEventListener("resize", again);
		doc.addEventListener("scroll", again, true);
		following.set(doc, {
			el,
			stop: () => {
				sized?.disconnect();
				worded?.disconnect();
				view?.removeEventListener("resize", again);
				doc.removeEventListener("scroll", again, true);
			}
		});
	}
	/** Stop following whatever this page was holding. */
	function letGo(doc) {
		following.get(doc)?.stop();
		following.delete(doc);
	}
	//#endregion
	//#region plugins/design/page/ready.ts
	function standing(doc) {
		return {
			parsed: doc.readyState !== "loading",
			stamped: doc.querySelector("[data-vobuda-file]") !== null
		};
	}
	/**
	* Wait until the page is worth drawing on, or say why it never was.
	*
	* The timeout is a last word rather than a wait: everything before it is the
	* condition. A page that never stamps is a real answer — the build was not
	* taught — and saying it is better than a draft that goes on and does nothing
	* (FM-DESIGN-9, FM-DESIGN-11).
	*/
	function whenReady(doc, opts) {
		return new Promise((resolve) => {
			const started = opts.now();
			let stop = null;
			const look = () => {
				const at = standing(doc);
				if (at.parsed && at.stamped) {
					stop?.();
					resolve(at);
					return;
				}
				if (opts.now() - started >= opts.giveUpAfterMs) {
					stop?.();
					resolve(at);
				}
			};
			stop = opts.watch(look);
			(opts.after ?? ((ms, fire) => {
				if (typeof setTimeout === "function") setTimeout(fire, ms);
			}))(opts.giveUpAfterMs, look);
			look();
		});
	}
	//#endregion
	//#region plugins/design/page/inject.ts
	var running = null;
	/** Stops following the first words handed over, once the person picks for themselves. */
	var firstWatch = null;
	/** Where the program answers a page that has something to say. */
	var SAY_AT = "/-vobuda/say";
	/** Where the program takes a copied design. */
	var COPY_AT = "/-vobuda/copy-write";
	/**
	* The one way this page reaches the window it belongs to.
	*
	* Two roads, and which one is taken is not a preference. A page this program
	* serves — the panel, a copied design — has the program's bridge and uses it.
	* A page holding somebody else's site does not, and must not: a capability
	* with `remote` on it hands whatever is loaded there every command this
	* program has, the one that writes files among them. So a site talks by
	* fetching a URL on the program's own scheme, which carries no privilege at
	* all: it can put a message on the designer's event and nothing else
	* (FM-DESIGN-28).
	*/
	function sayThrough(doc) {
		const w = doc.defaultView;
		return (what, body) => {
			const bridge = w?.__TAURI_INTERNALS__;
			if (bridge) {
				bridge.invoke("design_said", {
					what,
					body
				}).catch(() => {});
				return;
			}
			const text = JSON.stringify(body ?? null);
			const url = new URL(`${SAY_AT}?what=${encodeURIComponent(what)}`, doc.location?.origin ?? "").toString();
			let posted = null;
			try {
				posted = w?.fetch?.(url, {
					method: "POST",
					mode: "cors",
					body: text
				}) ?? null;
			} catch {
				posted = null;
			}
			if (!posted) {
				byPicture(doc, url, text);
				return;
			}
			posted.catch(() => {
				byPicture(doc, url, text);
			});
		};
	}
	/**
	* Start the designer in this page.
	*
	* Waits on the page rather than on a clock, then says what it found: which is
	* how the first screen learns whether this project's build stamps, without the
	* designer having to guess from the other side of a webview.
	*/
	async function start(doc, watch, say = sayThrough(doc), giveUpAfterMs = 15e3) {
		if (running) running.pointing.stop();
		running = {
			rules: [],
			pointing: { stop: () => {} },
			found: null
		};
		const ready = await whenReady(doc, {
			watch,
			giveUpAfterMs,
			now: () => Date.now()
		});
		if (running) running.found = ready;
		say("ready", ready);
	}
	/** What the designer tells this page to do. */
	function told(doc, message, say = sayThrough(doc)) {
		try {
			doAsTold(doc, message, say);
		} catch (e) {
			say("pressed", `the page could not take "${message.do}" — ${String(e)}`);
		}
	}
	function doAsTold(doc, message, say) {
		if (!running) return;
		if (message.do === "draft") {
			running.rules = message.rules;
			apply(doc, running.rules);
			say("drawn", drawnNow(doc, running.rules));
			return;
		}
		if (message.do === "present") {
			say("present", message.rules.map((r) => r.origin ? carrying(doc, r.origin).length > (r.everywhere ? 0 : r.index) : false));
			return;
		}
		if (message.do === "point") {
			running.pointing.stop();
			if (message.on) running.pointing = pointAt(doc, (what, picked) => say(what, picked));
			else undress(doc);
			return;
		}
		if (message.do === "hello") {
			if (running.found) say("ready", running.found);
			return;
		}
		if (message.do === "hand") {
			const one = doc.querySelector(`[data-vobuda-at="${message.at.replace(/["\\]/g, "\\$&")}"]`);
			if (one) {
				const held = pickOf(doc, one);
				show(doc, "held", held ?? { box: one.getBoundingClientRect() });
				if (held) holdOn(doc, held);
				one.scrollIntoView({
					block: "nearest",
					inline: "nearest"
				});
			}
			return;
		}
		if (message.do === "again") {
			const one = doc.querySelector(`[data-vobuda-at="${message.at.replace(/["\\]/g, "\\$&")}"]`);
			const picked = one ? pickOf(doc, one) : null;
			if (picked) say("picked", picked);
			return;
		}
		if (message.do === "first") {
			let picked = firstWords(doc);
			if (picked) {
				show(doc, "held", picked);
				holdOn(doc, picked);
				say("picked", picked);
			}
			firstWatch?.();
			const view = doc.defaultView;
			if (view) {
				const again = () => {
					const el = picked?.at ? doc.querySelector(`[${AT}="${picked.at.replace(/["\\]/g, "\\$&")}"]`) : null;
					if (el && seen(doc, el)) return;
					const next = firstWords(doc);
					if (!next || next.at === picked?.at) return;
					picked = next;
					show(doc, "held", next);
					holdOn(doc, next);
					say("picked", next);
				};
				const stop = () => {
					view.removeEventListener("resize", again);
					doc.removeEventListener("pointerdown", stop, true);
					firstWatch = null;
				};
				view.addEventListener("resize", again);
				doc.addEventListener("pointerdown", stop, true);
				firstWatch = stop;
			}
			return;
		}
		if (message.do === "copy") {
			handOverACopy(doc, say);
			return;
		}
		if (message.do === "drop") {
			running.rules = [];
			drop(doc);
			return;
		}
		if (message.do === "check") {
			const view = doc.defaultView;
			if (!view) return;
			drop(doc);
			remark(doc, message.rules);
			const moved = whatMoved(doc, message.rules, (el) => view.getComputedStyle(el));
			say("moved", {
				moved,
				saying: saying(moved)
			});
			return;
		}
		running.pointing.stop();
		drop(doc);
		undress(doc);
		running = null;
	}
	/**
	* What each rule's element is drawn with, now that the draft is on.
	*
	* Read off the page rather than believed, because the draft is a request and
	* the page is the answer. A rule that lost — to a child's own declaration, to
	* a neighbour's selector, to a shorthand — is a rule the person has to be told
	* about, in the place they are looking (FM-DESIGN-19, FM-DESIGN-5).
	*/
	function drawnNow(doc, rules) {
		const view = doc.defaultView;
		if (!view) return [];
		const out = [];
		for (const r of rules) {
			const el = r.at ? doc.querySelector(`[data-vobuda-at="${r.at.replace(/["\\]/g, "\\$&")}"]`) : null;
			if (!el) continue;
			out.push({
				at: r.at,
				property: r.property,
				asked: r.value,
				given: tidy(view.getComputedStyle(el).getPropertyValue(r.property).trim())
			});
		}
		return out;
	}
	/**
	* The other road out: a picture nobody looks at.
	*
	* No content policy stops an image load, and no engine refuses one for being
	* on a scheme it does not know — which is exactly what a `fetch` may do. No
	* answer is needed either: the program is listening at the other end of the
	* address, not replying to it (FM-DESIGN-36).
	*/
	function byPicture(doc, url, text) {
		try {
			const img = doc.createElement("img");
			img.setAttribute("data-vobuda-ours", "beacon");
			img.width = 0;
			img.height = 0;
			img.src = `${url}&body=${encodeURIComponent(text)}`;
			img.onload = img.onerror = () => img.remove();
			doc.documentElement.appendChild(img);
		} catch {}
	}
	/**
	* Take this page's design and hand it to the program.
	*
	* Posted rather than said, because a page is a great deal more than fits in a
	* URL. The program writes it into the plugin's own copies folder and tells the
	* designer where it went — the designer never sees the text at all, which is
	* the right shape: it is a file from the moment it exists.
	*/
	async function handOverACopy(doc, say) {
		const w = doc.defaultView;
		const ours = (path) => new URL(path, doc.location?.origin ?? "").toString();
		const name = nameFor(doc.location?.href ?? "", /* @__PURE__ */ new Date());
		let html;
		try {
			html = copied(doc, name);
		} catch (e) {
			say("copy-failed", String(e));
			return;
		}
		try {
			const answer = await w?.fetch?.(ours(`${COPY_AT}?name=${encodeURIComponent(name)}`), {
				method: "POST",
				mode: "cors",
				body: html
			});
			if (answer && !answer.ok) say("copy-failed", `the program refused the copy (${answer.status})`);
		} catch (e) {
			say("copy-failed", String(e));
		}
	}
	/** Whether anything of the designer is in this page. Used by the check. */
	var isRunning = () => running !== null;
	if (typeof window !== "undefined" && typeof document !== "undefined") {
		const watch = (fire) => {
			const observer = new MutationObserver(fire);
			observer.observe(document.documentElement, {
				childList: true,
				subtree: true,
				attributes: true
			});
			document.addEventListener("readystatechange", fire);
			return () => {
				observer.disconnect();
				document.removeEventListener("readystatechange", fire);
			};
		};
		window.__vobudaDesign = (message) => {
			if (message.do === "start") {
				start(document, watch);
				return;
			}
			told(document, message);
		};
		start(document, watch);
	}
	//#endregion
	exports.COPY_AT = COPY_AT;
	exports.SAY_AT = SAY_AT;
	exports.drawnNow = drawnNow;
	exports.handOverACopy = handOverACopy;
	exports.isRunning = isRunning;
	exports.start = start;
	exports.told = told;
	return exports;
})({});
