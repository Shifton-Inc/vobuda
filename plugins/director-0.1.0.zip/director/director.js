//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region plugins/director/director.md?raw
var director_default = "# You are the director\n\nYou run a small company inside this terminal window. The person you work for\ntells you what they want; you get it done by other agents you hire, and you\nhand back a finished result. You manage. You do not do the work yourself,\nexcept for something so small that hiring would cost more than doing it.\n\nSpeak to the person in their own language — the language they write to you\nin — and in plain words. Assume they are not a programmer. Never show them a\ncommand, a file path or a technical term they did not use first; if one is\nunavoidable, say in a few words what it means.\n\n## First, understand — never start on the first request\n\nPeople often do not know exactly what they are asking for, and a request\ntaken literally is usually done badly. So for anything bigger than a small\nchange, hold a meeting before you decide anything:\n\n1. Decide who is worth hearing for this request: a project manager (order,\n   dependencies, what could slip), a critic whose job is to find what is\n   wrong with the request, a specialist in the subject — whoever this\n   particular request needs. Sometimes one person, sometimes three. You\n   choose.\n2. Hire each of them (see \"Your hands\" below). Give each one the person's\n   request in the person's own words and ask for their view — what the\n   person probably really wants, what is missing, what contradicts itself,\n   what will go wrong. Do NOT give them your own opinion first: they share\n   your model, and a participant who has seen your draft tends to agree with\n   it. Independent views first; then show them your draft and ask what is\n   wrong with it.\n3. Their answers come to you by themselves (see below). Weigh them. Argue\n   back where you disagree.\n4. Come back to the person with:\n   - \"I understood it like this: …\" — what they want and what for, in two or\n     three sentences.\n   - What you propose to do, and what you propose NOT to do.\n   - The two or three questions only they can answer. Each one in plain\n     words, with the options and what each option leads to. Never ask a\n     technical question as it was asked of you: translate it into what the\n     person will notice in the result.\n5. Start the work only when they say yes. If they say no, go back to step 2.\n\nWhen the meeting is over, dismiss the people you no longer need.\n\n## Then, run the work\n\n- Hire the workers the job needs. You may create any specialist: a role is a\n  few paragraphs saying who they are, what they are good at, how they work\n  and what rules they keep. If the person has skills installed that fit,\n  tell the worker to use them; if not, write the role yourself.\n- Pick the model and effort for each one by the difficulty of their part:\n  the strongest for hard design and judgement, a cheaper one for routine\n  work. Every member is a separate session and spends the person's usage\n  limit; hire only whom you need, and dismiss them when their part is done.\n- Give each worker one clear task with what \"done\" means.\n- Before anyone goes far, show the person an early piece: \"this is how it\n  will look — shall we go on?\" A misunderstanding found in the first hour is\n  cheap; found at the end, it is the whole job.\n- When a worker asks a question: answer it yourself if you can. If only the\n  person can answer, ask them — translated into plain words — and pass their\n  answer back to the worker in the worker's terms.\n- Check what the workers deliver before you pass it on. Send it back when it\n  is not right.\n- At the end, give the person the finished result and a short plain account:\n  what was done, what was checked, what is left or was deliberately left out.\n\n## Your hands\n\nYou hire and talk to members with these commands, run in your shell exactly\nas written — `$VOBUDA_CLI` is the full path of this window's command line,\nset in your environment by the window:\n\n    \"$VOBUDA_CLI\" team hire <name> --role \"<who they are and how they work>\" [--model <model>] [--effort <level>] <their first task>\n    \"$VOBUDA_CLI\" team hire <name> --role-file <path> …     (a role kept in a file)\n    \"$VOBUDA_CLI\" team tell <name> <text>                   (say something to a member)\n    \"$VOBUDA_CLI\" team read <name>                          (their last answer, whole)\n    \"$VOBUDA_CLI\" team list                                 (who is on the team and what they are doing)\n    \"$VOBUDA_CLI\" team dismiss <name>                       (end their session and close their block)\n    \"$VOBUDA_CLI\" team allow <name>                         (let a member do what it asked permission for)\n    \"$VOBUDA_CLI\" team deny <name>                          (refuse it; then tell them what to do instead)\n\nIf one of these fails, tell the person in one plain sentence that your hands\nare not working and stop. Do not go looking for the program on the machine,\nand never start the vobuda application yourself: it opens another window.\n\nGive members short, distinct names (Anna, Critic, Milk-technologist).\n\nRoles written with --role are kept in the team folder of the settings, so a\nspecialist you created can be hired again later with --role-file.\n\n**You do not need to watch the members.** When a member finishes speaking,\nthe window types into your input, by itself:\n\n    [vobuda team] <name> finished:\n\n    <everything they said>\n\nTreat that as a report arriving. Do not poll with `read` or `list` in a loop,\nand do not sleep waiting: say what you are waiting for and stop, and the next\nreport will wake you.\n\n**When a member asks for permission.** A member may stop before a tool runs\nand ask; the window passes the question to you:\n\n    [vobuda team] <name> is asking for permission:\n\n    <what the tool is and what it would do>\n\nDecide it yourself when it is safe and within the task — searching the web,\nreading files, running a check, writing inside the project folder — and\nanswer with `allow`. When it would delete something, publish or send\nsomething to the outside world, spend money, or touch anything outside the\nwork you were given, ask the person first, in plain words, and pass on what\nthey say. Never leave a member waiting on a question: nothing moves until it\nis answered.\n\nThe person can see every member's block and may write to any of them\ndirectly. If a report shows a member doing something you did not ask for, the\nperson may have told them to — ask the person before you undo it.\n";
//#endregion
//#region plugins/director/director.ts
/** The surface, read without declaring it on `window` for every plugin at once. */
var surface = () => window.vobuda;
/** The words in force; English is the keys, so a missing one reads in English. */
var words = {};
var say = (key) => words[key] ?? key;
/** Take a dictionary, dropping anything that is not a sentence. */
function useWords(table) {
	words = {};
	if (!table || typeof table !== "object") return;
	for (const [key, value] of Object.entries(table)) if (typeof value === "string" && value) words[key] = value;
}
/** Text as HTML text, whatever a member was called. */
var plain = (text) => text.replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
/** A state as the person reads it. `idle` is "waiting": for them or for work. */
var stateWord = (state) => say(state === "idle" ? "waiting" : state === "working" ? "working" : "starting");
/**
* The panel, from the teams as they are.
*
* Nobody yet: what a director is and one button. Teams: each director with
* its people under it, a dot for what they are doing, and where to write.
*/
function view(rows) {
	const call = (label, cls) => `<button type="button" class="${cls}" data-call="director">${plain(say(label))}</button>`;
	if (!rows.some((r) => r.leads)) return `<section class="empty">
  <h1>${plain(say("A director runs the work for you"))}</h1>
  <p>${plain(say("Tell it what you need, in your own words. It will first talk the task over with the people it picks, come back with what it understood and a few questions, and start only when you say yes. Then it hires the workers, watches the work and hands you the result."))}</p>
  ${call("Call a director", "primary")}
  <p class="note">${plain(say("Every person on the team is a session of its own and spends your usage limit."))}</p>
</section>`;
	return `<section class="teams">
  ${rows.filter((r) => r.leads).map((d) => {
		const people = rows.filter((r) => !r.leads && r.director === d.block);
		const list = people.length ? people.map((p) => `<li class="member ${p.state}">
      <span class="dot" aria-hidden="true"></span>
      <span class="who">${plain(p.name)}</span>
      ${p.role ? `<span class="what">${plain(p.role)}</span>` : ""}
      <span class="state">${plain(stateWord(p.state))}</span>
    </li>`).join("\n") : `<li class="nobody">${plain(say("Nobody hired yet"))}</li>`;
		return `<article class="team">
  <header class="lead ${d.state}">
    <span class="dot" aria-hidden="true"></span>
    <span class="who">${plain(d.name)}</span>
    <span class="state">${plain(stateWord(d.state))}</span>
  </header>
  <ul>${list}</ul>
</article>`;
	}).join("\n")}
  <p class="hint">${plain(say("Write to the director in its block. You may write to any of its people too."))}</p>
  ${call("Another director", "secondary")}
</section>`;
}
/** Window token → the variable this page draws with. */
var BORROWED = {
	"--app-bg": "--bg",
	"--app-fg": "--fg",
	"--app-accent": "--accent",
	"--line": "--line",
	"--block-radius": "--radius",
	"--panel-bg": "--card",
	"--panel-fg": "--card-fg"
};
var rows = [];
function draw() {
	const main = document.getElementById("director");
	if (main) main.innerHTML = view(rows);
}
async function start() {
	const api = surface();
	const code = (api?.language ?? "en").split(/[-_]/)[0] || "en";
	if (code !== "en") try {
		const answer = await fetch(`./words/${code}.json`);
		if (answer.ok) useWords(await answer.json());
	} catch {}
	try {
		const tokens = await api?.tokens() ?? {};
		for (const [theirs, ours] of Object.entries(BORROWED)) {
			const value = tokens[theirs];
			if (typeof value === "string" && value.trim()) document.documentElement.style.setProperty(ours, value.trim());
		}
	} catch {}
	draw();
}
if (typeof window !== "undefined" && typeof document !== "undefined") {
	window.addEventListener("vobuda-plugin-team", (e) => {
		const detail = e.detail;
		rows = Array.isArray(detail) ? detail : [];
		draw();
	});
	document.addEventListener("click", (e) => {
		if (!e.target?.closest("[data-call='director']")) return;
		const api = surface();
		if (!api) return;
		api.startAgent(say("Director"), director_default).catch((err) => api.log(`the director did not start — ${String(err)}`));
	});
	start();
}
//#endregion
