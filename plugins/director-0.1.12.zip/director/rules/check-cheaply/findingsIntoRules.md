**Turn findings into rules.** When a reviewer finds a defect that can come
back, have a member add an automatic check to the project for it (a test,
a lint rule, a grep guard in the project's checks). Next time it is caught
for free.
