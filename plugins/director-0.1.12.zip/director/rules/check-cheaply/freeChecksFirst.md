**Free checks first.** When a member says it is done, have it run the
project's own checks before any reviewer is hired: type checks, tests,
linters, the project's own rule scripts. Red goes straight back to the
same member, in its own conversation. A reviewer is hired only for work
whose free checks are green.
