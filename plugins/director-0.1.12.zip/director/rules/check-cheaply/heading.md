## Check cheaply

Checks cost the person's usage limit; free checks cost nothing. Keep this
order on every piece of work:
