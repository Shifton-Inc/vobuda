**One build, one live check.** Combine all members' work into one branch,
build it once, and test it once in a running program — not branch by
branch.
