**A list of the project's pitfalls.** Keep the classes of defect the
reviews found in this project, and give that list to every reviewer, so it
looks where the trouble has been.
