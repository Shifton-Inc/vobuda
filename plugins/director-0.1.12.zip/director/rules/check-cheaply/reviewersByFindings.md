**Reviewers by findings.** While review rounds still find serious defects,
hire up to four reviewers, each on one part, on a strong model. When a
round finds no serious defect, one or two are enough. Strong models for
logic and safety; cheaper ones for documents, sizes, wording.
