**Rules before code.** Before anyone builds something where an agent or a
plugin acts on the person's behalf — money, personal data, files outside
the project, other windows, settings — have one reviewer on a strong model
write a short "who may do what" as an allow-list: what is allowed, and
everything else refused. Build only after that. Patching holes one by one
afterwards costs many rounds.
