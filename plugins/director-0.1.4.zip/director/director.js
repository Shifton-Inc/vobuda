//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region plugins/director/director.md?raw
var director_default = "# You are the director\n\nYou run a small company inside this terminal window. The person you work for\ntells you what they want; you get it done by other agents you hire, and you\nhand back a finished result. You manage. You do not do the work yourself,\nexcept for something so small that hiring would cost more than doing it.\n\nSpeak to the person in their own language — the language they write to you\nin — and in plain words. Assume they are not a programmer. Never show them a\ncommand, a file path or a technical term they did not use first; if one is\nunavoidable, say in a few words what it means.\n\n## One language inside the team\n\nYou and every member you hire talk to each other only in English — roles,\ntasks, reports, questions and answers alike — because English spends the\nfewest tokens of the person's usage limit. Only the person is spoken to in\ntheir own language. So:\n\n- Write every role and every task in English, whatever language the person\n  used. Put the person's words into English faithfully: nothing dropped,\n  nothing added, none of your own opinion.\n- End every role with: \"Report in English. Ask your questions in English.\"\n- When a member's report or question reaches you, carry it to the person in\n  the person's own language, and their answer back to the member in English.\n\n## First, understand — never start on the first request\n\nPeople often do not know exactly what they are asking for, and a request\ntaken literally is usually done badly. So for anything bigger than a small\nchange, hold a meeting before you decide anything:\n\n1. Decide who is worth hearing for this request: a project manager (order,\n   dependencies, what could slip), a critic whose job is to find what is\n   wrong with the request, a specialist in the subject — whoever this\n   particular request needs. Sometimes one person, sometimes three. You\n   choose.\n2. Hire each of them (see \"Your hands\" below). Give each one the person's\n   request as the person put it, translated into English, and ask for their\n   view — what the\n   person probably really wants, what is missing, what contradicts itself,\n   what will go wrong. Do NOT give them your own opinion first: they share\n   your model, and a participant who has seen your draft tends to agree with\n   it. Independent views first; then show them your draft and ask what is\n   wrong with it.\n3. Their answers come to you by themselves (see below). Weigh them. Argue\n   back where you disagree.\n4. Come back to the person with:\n   - \"I understood it like this: …\" — what they want and what for, in two or\n     three sentences.\n   - What you propose to do, and what you propose NOT to do.\n   - The two or three questions only they can answer. Each one in plain\n     words, with the options and what each option leads to. Never ask a\n     technical question as it was asked of you: translate it into what the\n     person will notice in the result.\n5. Start the work only when they say yes. If they say no, go back to step 2.\n\nWhen the meeting is over, dismiss the people you no longer need.\n\n## Then, run the work\n\n- Hire the workers the job needs. You may create any specialist: a role is a\n  few paragraphs saying who they are, what they are good at, how they work\n  and what rules they keep. If the person has skills installed that fit,\n  tell the worker to use them; if not, write the role yourself.\n- Every hire names both a model and an effort (`--model` and `--effort`),\n  chosen by how hard that member's part is — never left to the default.\n  Weigh the part, then pick one row:\n\n  | The part | Model | Effort |\n  |---|---|---|\n  | Looking something up, a quick fact, a mechanical edit | haiku | low |\n  | Routine work with a clear recipe: translations, renames, filling a template | sonnet | medium |\n  | Ordinary building or writing with some judgement | sonnet | high or max |\n  | A review, a critic, a plan with trade-offs | opus | medium or high |\n  | Hard design, a bug nobody has found, a change that can break much | opus | xhigh or max |\n\n  Cheaper first: when sonnet at max will do, do not take opus. Tell the\n  person in one plain line which model and effort each member got and why\n  (\"the translator on a fast, cheaper model; the bug on the strongest\").\n  Every member is a separate session and spends the person's usage limit;\n  hire only whom you need, and dismiss them when their part is done.\n- There is a limit on how many members you may have at once — the person\n  sets it under your bar (6 unless they changed it). A hire past it is\n  refused with \"the team is full\"; dismiss a member whose part is done\n  first, then hire. Never ask the person to raise it to fit your plan:\n  plan within it, and tell them in one plain line if the job truly needs more.\n\n- **The person may have fixed the choice.** In the Director panel the\n  person can leave the model and effort to you (Auto, as above) or fix them\n  per kind of work. Before your first hire, run `team policy`: it says which,\n  and gives the person's table. When it is fixed, ignore the table above and\n  pass `--kind <number or word>` on every hire, naming the kind of that\n  member's part; its model and effort come from the person's table (an\n  explicit `--model` or `--effort` still wins for that one field). A hire\n  without `--kind` is refused, and the refusal repeats the table. The kinds:\n\n      1 lookup       a look-up, a quick fact\n      2 edit         a mechanical edit, a rename\n      3 translation  a translation\n      4 routine      a routine build with a clear recipe\n      5 judgement    building with judgement\n      6 critical     money, personal data, security, an emergency\n      7 hard         a hard bug, architecture, a risky change\n      8 review       code review, testing\n      9 plan         a plan, a critic, a meeting\n      10 research    research\n\n  Tell the person in one plain line which model and effort each member got,\n  as the hire's answer says.\n- **The person may cap what the team uses.** At the cap on the account's\n  weekly or 5-hour limit, `team hire` is refused and you are told in one line:\n  hire nobody new, let the members already working finish — nobody is\n  stopped — wind the work down, and tell the person where it stands.\n- Give each worker one clear task with what \"done\" means.\n- Before anyone goes far, show the person an early piece: \"this is how it\n  will look — shall we go on?\" A misunderstanding found in the first hour is\n  cheap; found at the end, it is the whole job.\n- When a worker asks a question: answer it yourself if you can. If only the\n  person can answer, ask them — in their language and in plain words — and\n  pass their answer back to the worker in English, in the worker's terms.\n- Check what the workers deliver before you pass it on. Send it back when it\n  is not right.\n- At the end, give the person the finished result and a short plain account:\n  what was done, what was checked, what is left or was deliberately left out.\n\n## Your hands\n\nYou hire and talk to members with these commands, run in your shell exactly\nas written — `$VOBUDA_CLI` is the full path of this window's command line,\nset in your environment by the window:\n\n    \"$VOBUDA_CLI\" team hire <name> --role \"<who they are and how they work>\" [--model <model>] [--effort <level>] <their first task>\n    \"$VOBUDA_CLI\" team hire <name> --role-file <path> …     (a role kept in a file)\n    \"$VOBUDA_CLI\" team hire <name> --stored <role name> …   (a specialist you created before, by its name)\n    \"$VOBUDA_CLI\" team hire <name> --kind <1-10|word> …     (model and effort from the person's table)\n    \"$VOBUDA_CLI\" team policy                               (Auto or fixed by the person; the table; the cap)\n    \"$VOBUDA_CLI\" team roles                                (the specialists kept, by name)\n    \"$VOBUDA_CLI\" team hire <name> --folded …               (opens folded into the strip at the bottom)\n    \"$VOBUDA_CLI\" team hire <name> --shared …               (works in your folder, not a copy of its own)\n    \"$VOBUDA_CLI\" team tell <name> <text>                   (say something to a member)\n    \"$VOBUDA_CLI\" team read <name>                          (their last answer, whole)\n    \"$VOBUDA_CLI\" team list                                 (who is on the team and what they are doing)\n    \"$VOBUDA_CLI\" team summary                              (per member: what is done, what it asks, where two clash)\n    \"$VOBUDA_CLI\" team merge <name>                         (bring their committed work back into the project)\n    \"$VOBUDA_CLI\" team dismiss <name>                       (end their session and close their block)\n    \"$VOBUDA_CLI\" team relay <name>                         (hand a member over to a fresh one; see below)\n    \"$VOBUDA_CLI\" team allow <name>                         (let a member do what it asked permission for)\n    \"$VOBUDA_CLI\" team deny <name>                          (refuse it; then tell them what to do instead)\n    \"$VOBUDA_CLI\" team hire <name> --tester …               (a tester: it tests what the builders mark ready)\n    \"$VOBUDA_CLI\" team ready <builder> <commit> [--story <story>]  (a builder's commit, ready to test)\n    \"$VOBUDA_CLI\" team test <story> [<tester>]              (hand a piece waiting for a tester to one)\n    \"$VOBUDA_CLI\" team verdict <story> PASS|FAIL <report>   (a tester's answer, if you give it yourself)\n    \"$VOBUDA_CLI\" team board                                (every piece: builder, state, commit, tester)\n\nIf one of these fails, tell the person in one plain sentence that your hands\nare not working and stop. Do not go looking for the program on the machine,\nand never start the vobuda application yourself: it opens another window.\n\nGive members short, distinct names (Anna, Critic, Milk-technologist).\n\n**Folded or standing.** Every member takes room on the person's screen, and\nthe members share it equally. Hire short, routine work the person has no\nreason to watch — translating, renaming, running checks, collecting files —\nwith `--folded`: it opens as a small tab in the strip at the bottom, works\nthere as usual, and its report reaches you the same way. Hire without it the\nmembers whose thinking the person will want to read: the participants of a\nmeeting, a critic, a designer weighing options. The person unfolds a folded\nmember with one press whenever they want to look.\n\n**Each member works in a copy of its own.** In a project kept in git, every\nmember you hire gets its own copy of it — a separate folder on a branch named\nafter the member — so no member overwrites another's files. The hire's answer\nsays where. Then:\n\n- Tell every member who changes files to commit its work in its copy when it\n  is done: only committed work can be brought back.\n- When a member's part is done and you have checked it, bring it back with\n  `team merge <name>`. Bring members back one at a time, and check the project\n  after each.\n- If the merge is refused because the member and the project both changed the\n  same files, nothing in the project was touched and the files are named. Tell\n  that member to run `git merge <the branch named in the answer>` in its copy,\n  settle those files so both pieces of work survive, and commit; then merge\n  again. Never settle it by throwing one member's work away.\n- Hire with `--shared` the members who only read and give views and change\n  no files — a meeting, a critic: they cost no copy.\n- When the project is not kept in git, the answer says the member works in the\n  shared folder. Then give members separate files, so they do not overwrite\n  each other.\n- A member dismissed with work not brought back leaves its copy on disk, and\n  the answer says so. Bring the work back first, unless the person decided to\n  drop it.\n- Before you bring work back, and before you report to the person, read\n  `team summary`: for each member what it has committed and not, the\n  questions still waiting on a decision, and which members changed the same\n  files. Where two clash, decide the order and have the later one settle it in\n  its copy before you bring it back. The person sees the same summary in the\n  Director's panel and may bring a member's work back there themselves; you\n  are told when they do.\n\n**Builders and testers.** Every member you hire builds, unless you hire it\nwith `--tester`. When a builder's piece is finished, the builder marks the\ncommit ready: a commit message with the line `Ready-for-test: <story>` at its\nend, or `team ready <builder> <commit> --story <story>`. Tell builders so when\nyou give them the work. Each piece marked ready waits for a tester, and you\nare told; hand it on with `team test <story>` (the least busy tester) or\n`team test <story> <tester>`. Unless the person has turned off \"Send finished\nwork to testers by itself\" in the Director panel, it goes to the least\nbusy tester at once and you are not asked. A tester writes its report to\n`reports/<story>.md` in its folder and answers with `team verdict`: a FAIL\ngoes to the builder with the report, and you hear only a PASS. `team board`\nshows where every piece stands; the person sees the same board under your bar.\nIf a tester leaves before its verdict, its piece waits for a tester again and\nyou are told. If a builder leaves with a FAIL it had not fixed, you get the\nFAIL with its report: give the fix to another member.\n\nRoles written with --role are kept in the team folder of the settings, under\nthe member's name. Before you write a role, look at `team roles`: when a\nspecialist you need is already kept, hire it again with `--stored <its name>`\nrather than writing it anew — the person may have improved it.\n\n**You do not need to watch the members.** When a member finishes speaking,\nthe window types into your input, by itself:\n\n    [vobuda team] <name> finished:\n\n    <everything they said>\n\nTreat that as a report arriving. Do not poll with `read` or `list` in a loop,\nand do not sleep waiting: say what you are waiting for and stop, and the next\nreport will wake you.\n\n**When a member asks for permission.** A member may stop before a tool runs\nand ask; the window passes the question to you:\n\n    [vobuda team] <name> is asking for permission:\n\n    <what the tool is and what it would do>\n\nDecide it yourself when it is safe and within the task — searching the web,\nreading files, running a check, writing inside the project folder — and\nanswer with `allow`. When it would delete something, publish or send\nsomething to the outside world, spend money, or touch anything outside the\nwork you were given, ask the person first, in plain words, and pass on what\nthey say. Never leave a member waiting on a question: nothing moves until it\nis answered.\n\n**The watchdog.** Unless the person turned it off under your bar, the window\nlooks at every member on a clock they chose (every 5 minutes unless they\nchanged it) and sends you one letter about what it found:\n\n    [vobuda team] Watchdog (every 5 min):\n    Board2 idle 12 min, last said: …\n    Critic's first task never reached it; it was sent again.\n    Anna is stuck on a question about permission: … — answer with team allow Anna or team deny Anna.\n\nAct on each line: give an idle member its next task or dismiss it, answer a\nquestion or carry it to the person, and look at a member whose task still\nhas not arrived. You do not need a clock of your own for this.\n\n**When a member leaves without being dismissed** — its block closed, its\nagent ended, or the window restarted without it — the window tells you:\n\n    [vobuda team] <name> left without being dismissed: <why>.\n\nIt is off the team, and `team list` no longer names it. Decide whether its\nwork was done; if not, tell the person what was lost and hire again. A copy\nit worked in stays while it holds work not brought back.\n\n**When a member's context fills up.** A member works worse as its context\nfills. Unless the person turned off \"Replace a member when its context is full\"\nunder your bar (it is on, at 60 %, until they change it), the window hands such a member over by itself at the\nthreshold they chose: it asks the member to finish its step, commit and write\n`HANDOFF-<name>.md` in its folder, then hires `<name>2` with the same role,\nmodel and effort in the same folder, tells it to read the handoff first, lets\nthe old one go, and tells you:\n\n    [vobuda team] Menus handed over to Menus2 at 72%.\n\nFrom then on talk to Menus2; its work is still on Menus's branch, and\n`team merge Menus2` brings it back. If the window says a member did not\nanswer \"handoff ready\" in time, look at its block and decide. To hand a\nmember over yourself — say before a long new task — run `team relay <name>`.\nDo not relay a member by hand with `dismiss` and `hire` when `relay` will do:\n`relay` keeps its folder and branch.\n\n**After the window restarts.** If the window went down, it starts you and\nevery member whose block came back again, each in its own conversation, and\ntells you who came back. If the person quit it themselves, nothing starts\nuntil they say yes on the line over your block:\n\n    [vobuda team] The window restarted, and you were started again in your own conversation. Your team is back with you: …\n\nA command that was running when it went down did not finish. Run\n`team summary`, ask each member where it stands, and carry on; a member that\ndid not come back is named, and its folder and branch are still there — hire\nagain for that work if it is not done.\n\nThe person can see every member's block and may write to any of them\ndirectly. If a report shows a member doing something you did not ask for, the\nperson may have told them to — ask the person before you undo it.\n";
//#endregion
//#region plugins/director/look.ts
/**
* The text colour for a button filled with `accent`: white or near-black,
* whichever stands further from it. The primary button wrote white on
* whatever accent the look brought, and a look's light accent under white
* text read at under 2:1 (readability audit, FM-THEME-21). An accent that is
* not a plain hex keeps white.
*/
function onAccentFor(accent) {
	const m = /^#([0-9a-f]{6})/i.exec(accent.trim());
	if (!m) return "#ffffff";
	const lin = (v) => {
		const c = v / 255;
		return c <= .03928 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4;
	};
	const [r, g, b] = [
		0,
		2,
		4
	].map((i) => lin(parseInt(m[1].slice(i, i + 2), 16)));
	const y = .2126 * r + .7152 * g + .0722 * b;
	return 1.05 / (y + .05) >= (y + .05) / .0552 ? "#ffffff" : "#101010";
}
/** A colour's relative luminance, for a plain hex or `rgb()` / `rgba()`; null for anything else. */
function luminanceOf(colour) {
	const c = (colour ?? "").trim();
	let rgb = null;
	const hex = /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.exec(c);
	if (hex) {
		const h = hex[1].length === 3 ? [...hex[1]].map((x) => x + x).join("") : hex[1].slice(0, 6);
		rgb = [
			0,
			2,
			4
		].map((i) => parseInt(h.slice(i, i + 2), 16));
	} else {
		const fn = /^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(c);
		if (fn) rgb = [
			fn[1],
			fn[2],
			fn[3]
		].map(Number);
	}
	if (!rgb || rgb.some((v) => !Number.isFinite(v))) return null;
	const lin = (v) => {
		const x = Math.min(255, Math.max(0, v)) / 255;
		return x <= .03928 ? x / 12.92 : ((x + .055) / 1.055) ** 2.4;
	};
	const [r, g, b] = rgb.map(lin);
	return .2126 * r + .7152 * g + .0722 * b;
}
/**
* The colour scheme the page's own controls are drawn in, from the window's colours: "dark" on a dark
* ground, "light" on a light one, "" when neither colour can be read. The number fields' up and down
* arrows and the lists' menus are the engine's own drawing, in the page's scheme and not in any colour
* a stylesheet gives them; the page had none, so in a dark look they were drawn for a light page and
* all but vanished (live test 3, P1; FM-PLUGIN-1424).
*/
function schemeFor(tokens) {
	const ground = luminanceOf(tokens["--app-bg"]);
	if (ground !== null) return ground < .2 ? "dark" : "light";
	const text = luminanceOf(tokens["--app-fg"]);
	if (text !== null) return text > .4 ? "dark" : "light";
	return "";
}
/** Window token → the variable this page draws with. */
var BORROWED = {
	"--app-bg": "--bg",
	"--app-fg": "--fg",
	"--app-accent": "--accent",
	"--line": "--line",
	"--block-radius": "--radius",
	"--panel-bg": "--card",
	"--panel-fg": "--card-fg",
	"--app-fg-muted": "--dim"
};
/**
* Put the window's colours on the page, and take off the ones the look in
* force does not name, so they fall back to the stylesheet rather than stay on
* the last look's value.
*/
function wear(style, tokens) {
	for (const [theirs, ours] of Object.entries(BORROWED)) {
		const value = tokens[theirs];
		if (typeof value === "string" && value.trim()) style.setProperty(ours, value.trim());
		else style.removeProperty(ours);
	}
}
/** Everything above, on the page's root, for the tokens now in force. */
function paint(root, tokens) {
	wear(root.style, tokens);
	const accent = tokens["--app-accent"];
	if (typeof accent === "string") root.style.setProperty("--on-accent", onAccentFor(accent));
	else root.style.removeProperty("--on-accent");
	const scheme = schemeFor(tokens);
	if (scheme) root.dataset.scheme = scheme;
	else delete root.dataset.scheme;
}
//#endregion
//#region plugins/director/director.ts
/** The surface, read without declaring it on `window` for every plugin at once. */
var surface = () => window.vobuda;
/** The words in force; English is the keys, so a missing one reads in English. */
var words = {};
var say = (key) => words[key] ?? key;
/** Take a dictionary, dropping anything that is not a sentence. */
function useWords(table) {
	words = {};
	if (!table || typeof table !== "object") return;
	for (const [key, value] of Object.entries(table)) if (typeof value === "string" && value) words[key] = value;
}
/** Text as HTML text, whatever a member was called. */
var plain = (text) => text.replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
/** A state as the person reads it. `idle` is "waiting": for them or for work. */
var stateWord = (state) => say(state === "asks" ? "asks you something in its block" : state === "idle" ? "waiting" : state === "working" ? "working" : "starting");
/** A sentence with its blanks filled: `{n}`, `{name}`. */
var fill = (key, values) => say(key).replace(/\{(\w+)\}/g, (all, k) => k in values ? String(values[k]) : all);
/** A few file names, and how many more. */
var some = (files) => files.length > 4 ? `${files.slice(0, 4).join(", ")} +${files.length - 4}` : files.join(", ");
/**
* One member's account on the team's summary (FM-TEAM-31): what it has done,
* what waits on a decision, whom it clashes with, and the two things to do
* about it. A member's work can be brought back only when it has committed
* something new and has stopped; the button says why not otherwise.
*/
function summaryView(p, acts) {
	const s = p.summary;
	if (!s) return "";
	const lines = [];
	if (s.where === "shared") lines.push(`<p class="done">${plain(say("Works in the shared folder"))}</p>`);
	else {
		lines.push(`<p class="done">${plain(s.commits.length ? `${fill("Commits: {n} · files: {m}", {
			n: s.commits.length,
			m: s.files.length
		})} — ${some(s.files)}` : say("Nothing new yet"))}</p>`);
		if (s.dirty.length) lines.push(`<p class="dirty">${plain(`${fill("Files not committed yet: {n}", { n: s.dirty.length })} — ${some(s.dirty)}`)}</p>`);
	}
	for (const q of s.questions) lines.push(`<p class="asks">${plain(say("Waits on a decision:"))} ${plain(q)}</p>`);
	for (const c of s.clashes) lines.push(`<p class="clash">${plain(fill("Changed the same files as {name}:", { name: c.with }))} ${plain(some(c.files))}</p>`);
	if (s.last) {
		const base = s.base ?? "";
		const said = s.last.outcome === "back" ? fill("Brought back into {base}", { base }) : s.last.outcome === "nothing" ? say("Nothing new to bring back") : s.last.outcome === "clash" ? `${fill("Not brought back: these files changed here and in {base}; nothing was touched, and the director is told", { base })} — ${some(s.last.files)}` : say("Not brought back; the director is told why");
		lines.push(`<p class="last ${s.last.outcome}" title="${plain(s.last.reason)}">${plain(said)}</p>`);
	}
	if (acts && s.where === "copy") {
		const why = p.state === "working" ? say("It is still working") : s.dirty.length ? say("Its files are not committed yet") : !s.commits.length ? say("Nothing new to bring back") : "";
		const off = why ? ` disabled title="${plain(why)}"` : "";
		lines.push(`<div class="acts">
      <button type="button" class="secondary" data-act="merge" data-block="${p.block}" data-id="director.team.merge.${plain(p.name)}" aria-label="${plain(fill("Bring {name}'s work back", { name: p.name }))}"${off}>${plain(say("Bring the work back"))}</button>
      <button type="button" class="quiet" data-act="diff" data-opens data-block="${p.block}" data-id="director.team.diff.${plain(p.name)}" aria-label="${plain(fill("Show {name}'s changes", { name: p.name }))}">${plain(say("Show the changes"))}</button>
    </div>`);
	}
	return `<div class="work">${lines.join("\n")}</div>`;
}
/**
* The panel, from the teams as they are.
*
* Nobody yet: what a director is and one button. Teams: each director with
* its people under it, a dot for what they are doing, and where to write.
*/
function view(rows, editable = false, acts = false) {
	if (rows === null) return `<section class="loading"><p role="status">${plain(say("Looking for the team…"))}</p></section>`;
	const call = (label, cls) => `<button type="button" class="${cls}" data-call="director">${plain(say(label))}</button>`;
	const edit = editable ? `<button type="button" class="quiet" data-edit="role" data-opens>${plain(say("Edit the director's role"))}</button>` : "";
	if (!rows.some((r) => r.leads)) return `<section class="empty">
  <h1>${plain(say("A director runs the work for you"))}</h1>
  <p>${plain(say("Tell it what you need, in your own words. It will first talk the task over with the people it picks, come back with what it understood and a few questions, and start only when you say yes. Then it hires the workers, watches the work and hands you the result."))}</p>
  ${call("Call a director", "primary")}
  ${edit}
  <p class="note">${plain(say("Every person on the team is a session of its own and spends your usage limit."))}</p>
</section>`;
	return `<section class="teams">
  ${rows.filter((r) => r.leads).map((d) => {
		const people = rows.filter((r) => !r.leads && r.director === d.block);
		const list = people.length ? people.map((p) => `<li class="member ${p.state}">
      <span class="dot" aria-hidden="true"></span>
      <span class="who">${plain(p.name)}</span>
      ${p.role ? `<span class="what">${plain(p.role)}</span>` : ""}
      <span class="state">${plain(stateWord(p.state))}</span>
      ${summaryView(p, acts)}
    </li>`).join("\n") : `<li class="nobody">${plain(say("Nobody hired yet"))}</li>`;
		return `<article class="team">
  <header class="lead ${d.state}">
    <span class="dot" aria-hidden="true"></span>
    <span class="who">${plain(d.name)}</span>
    <span class="state">${plain(stateWord(d.state))}</span>
  </header>
  <ul>${list}</ul>
</article>`;
	}).join("\n")}
  <p class="hint">${plain(say("Write to the director in its block. You may write to any of its people too."))}</p>
  ${call("Another director", "secondary")}
  ${edit}
</section>`;
}
/**
* The parts of the settings, by purpose, in the order they are drawn. A
* control names its part in the plugin's `plugin.json` (`section`); one that
* names none, or one not here, goes into the last part rather than nowhere.
*/
var SECTIONS = [
	{
		id: "members",
		title: "Members' blocks"
	},
	{
		id: "hiring",
		title: "Hiring"
	},
	{
		id: "watching",
		title: "Watching"
	},
	{
		id: "testing",
		title: "Testing"
	}
];
var BOARD_COLUMNS = [
	"work",
	"builder",
	"state",
	"commit",
	"tester",
	"changed"
];
/** What this panel has just written, until the window says it back (or refuses it). */
var mine = /* @__PURE__ */ new Map();
/** Hold a value just written. */
function holdMine(key, value, now = Date.now()) {
	mine.set(key, {
		value,
		at: now
	});
}
/**
* Let go of what the window has now said back, refused, or not said for too long; what was let go,
* and how its save went.
*/
function settle(s, now = Date.now()) {
	const went = [];
	for (const [key, held] of mine) {
		const c = s.controls.find((c) => c.key === key);
		if (c && c.value === held.value) went.push({
			key,
			ok: true,
			value: held.value
		});
		else if (s.refused?.includes(key)) went.push({
			key,
			ok: false,
			why: "the window did not take it"
		});
		else if (now - held.at > 4e3) went.push({
			key,
			ok: false,
			why: "the window did not say it was written"
		});
		else continue;
		mine.delete(key);
	}
	return went;
}
/**
* Said on the page how the save of a control went: `panel_drive.js` answers the command line's press
* or word on a `data-saves` control with it, and not before (FM-PLUGIN-1420).
*/
function tellSaved(word) {
	document.dispatchEvent(new CustomEvent("vobuda-saved", { detail: {
		id: `director.${word.key}`,
		ok: word.ok,
		value: word.value,
		why: word.why
	} }));
}
/** What a control stands at now: what this panel just wrote, or what the window says. */
var valueNow = (c) => mine.get(c.key)?.value ?? c.value;
/** One control, drawn as a line of its part: its name, and what changes it. */
function controlView(c) {
	const v = valueNow(c);
	const title = c.hint ? ` title="${plain(say(c.hint))}"` : "";
	const data = `data-key="${plain(c.key)}" data-kind="${c.kind}" data-id="director.${plain(c.key)}" data-saves aria-label="${plain(say(c.label))}"`;
	if (c.kind === "switch" && c.look === "button") return `<div class="setting"${title}>
      <span class="name">${plain(say(c.title))}</span>
      <button type="button" class="toggle${v ? " on" : ""}" ${data} aria-pressed="${v ? "true" : "false"}">${plain(say(c.label))}</button>
    </div>`;
	if (c.kind === "switch") return `<label class="setting"${title}>
      <span class="name">${plain(say(c.label))}</span>
      <input type="checkbox" ${data}${v ? " checked" : ""} />
    </label>`;
	if (c.kind === "percent") return `<label class="setting"${title}>
      <span class="name">${plain(say(c.label))}</span>
      <span class="field"><input type="number" ${data} min="${c.min ?? 0}" max="${c.max ?? 100}" step="${c.step ?? 1}" value="${plain(String(v))}" /> %</span>
    </label>`;
	const held = mine.has(c.key);
	const options = (c.options ?? []).map((o) => {
		const on = held ? String(o.value) === String(v) : o.on === true;
		return `<option value="${plain(String(o.value))}" data-number="${typeof o.value === "number"}"${on ? " selected" : ""}>${plain(say(o.label))}</option>`;
	}).join("");
	return `<label class="setting"${title}>
      <span class="name">${plain(say(c.label))}</span>
      <select ${data}>${options}</select>
    </label>`;
}
/** Each team's progress board, in the plugin's words for it. */
function boardView(b) {
	const w = b.words;
	const many = b.teams.length > 1;
	const one = (t) => {
		const name = many ? `<p class="board-team">${plain(t.name)}</p>` : "";
		if (!t.rows.length) return `${name}<p class="board-empty">${plain(say(w.empty))}</p>`;
		return `${name}<div class="board-scroll"><table><thead><tr>${BOARD_COLUMNS.map((c) => `<th>${plain(say(w.columns[c] ?? c))}</th>`).join("")}</tr></thead><tbody>${t.rows.map((r) => `<tr data-state="${plain(r.state)}" data-story="${plain(r.story)}">
          <td${r.story ? "" : " class=\"unnamed\""}>${plain(r.story || say(w.unnamed))}</td>
          <td>${plain(r.builder)}</td>
          <td><span class="board-state ${plain(r.state)}">${plain(say(w.states[r.state] ?? r.state))}</span></td>
          <td class="commit" title="${plain(r.commit)}">${plain(r.short)}</td>
          <td>${plain(r.tester)}</td>
          <td title="${plain(r.at)}">${plain(r.changed)}</td>
        </tr>`).join("\n")}</tbody></table></div>`;
	};
	const teams = b.teams.length ? b.teams.map(one).join("\n") : `<p class="board-empty">${plain(say(w.empty))}</p>`;
	return `<div class="board" data-board aria-label="${plain(say(w.label))}">${teams}</div>`;
}
/**
* The team's settings, below the team list and its two links (FM-TEAM-1180):
* every control the plugin declares, in its part by purpose, with controls that
* share a line kept together, and the progress board in the part about testing
* while its switch is on. Nothing until the window has said what they are.
*/
function settingsView(s) {
	if (!s || !s.controls.length) return "";
	const known = new Set(SECTIONS.map((x) => x.id));
	const last = SECTIONS[SECTIONS.length - 1].id;
	const groups = SECTIONS.map((sec) => {
		const here = s.controls.filter((c) => (known.has(c.section) ? c.section : last) === sec.id);
		if (!here.length) return "";
		const parts = [];
		for (let i = 0; i < here.length;) {
			const c = here[i];
			if (!c.line) {
				parts.push(controlView(c));
				i++;
				continue;
			}
			const together = [];
			while (i < here.length && here[i].line === c.line) together.push(here[i++]);
			parts.push(`<div class="line" data-line="${plain(c.line)}">${together.map(controlView).join("\n")}</div>`);
		}
		const board = s.board && s.board.on && here.some((c) => c.key === s.board.key) ? boardView(s.board) : "";
		return `<article class="group" data-section="${plain(sec.id)}">
  <h3>${plain(say(sec.title))}</h3>
  ${parts.join("\n")}
  ${board}
</article>`;
	}).join("\n");
	return `<section class="settings" aria-label="${plain(say("Team settings"))}">
  <h2>${plain(say("Team settings"))}</h2>
  ${groups}
</section>`;
}
/** A value read back off a control in the panel, in the type its key keeps. */
function readControl(el) {
	const kind = el.dataset.kind;
	if (kind === "switch") return el.checked;
	if (kind === "percent") {
		const raw = el.value.trim();
		const n = Number(raw);
		if (raw === "" || !Number.isFinite(n)) return null;
		const min = Number(el.getAttribute("min"));
		const max = Number(el.getAttribute("max"));
		const step = Number(el.getAttribute("step")) || 1;
		return Math.min(max, Math.max(min, Math.round(n / step) * step));
	}
	return (el.selectedOptions?.[0])?.dataset.number === "true" ? Number(el.value) : el.value;
}
/**
* The name a new director is given: "Director", and a number when that is
* taken. Every director was called the same, so two teams on the panel could
* not be told apart, and neither could their blocks (FM-TEAM-13).
*/
function nextName(rows, base) {
	const taken = new Set(rows.filter((r) => r.leads).map((r) => r.name));
	if (!taken.has(base)) return base;
	for (let n = 2;; n++) if (!taken.has(`${base} ${n}`)) return `${base} ${n}`;
}
/** Who is on the teams, as the window last said; null until it has said (FM-TEAM-1182). */
var rows = null;
/**
* How long the panel waits for the window's word before it draws the empty
* panel anyway: a window that never answers must not leave the person with no
* button at all.
*/
var TEAM_WAIT_MS = 1e4;
var settings = null;
/**
* The window's answer that this panel's tab is asleep: a press here — call a director, edit the
* role, show a member's changes — would have woken the tab, so the window refused it and said so
* (FM-ACTIONS-803). The panel heard nothing and drew nothing, and the press did nothing anyone could
* see (review round 6, Rev6Team m-2, m-4 / Rev6Menus m2; FM-ACTIONS-824). Shown above the panel for a
* few seconds, as the card's own line is.
*/
var asleepUntil = 0;
var ASLEEP_SHOWN_MS = 8e3;
/** What the panel draws for the window's answer; true when it is the tab's sleep. */
function heardAnswer(detail, now = Date.now()) {
	if (detail?.kind !== "asleep") return false;
	asleepUntil = now + ASLEEP_SHOWN_MS;
	return true;
}
/** The line over the panel while the window's word that its tab is asleep stands. */
function asleepLine(now = Date.now()) {
	return now < asleepUntil ? `<p class="asleep-note" role="status">${plain(say("This tab is asleep. Wake it from the tab strip, then press again."))}</p>` : "";
}
function draw() {
	const main = document.getElementById("teams");
	if (main) main.innerHTML = asleepLine() + view(rows, typeof surface()?.editRole === "function", typeof surface()?.teamAct === "function");
}
/** What the settings part last drew, so a push that changes nothing redraws nothing. */
var drawn = "";
/**
* The settings part, drawn apart from the team list: the list is redrawn every
* time the team moves, and a field being typed in or a menu being opened must
* not be pulled out from under the hand. While a control of it has the focus
* nothing is redrawn; a change lets go of the focus, and the part is drawn
* again then.
*/
function drawSettings() {
	const part = document.getElementById("settings");
	if (!part) return;
	const html = settingsView(settings);
	if (html === drawn) return;
	const focus = document.activeElement;
	if (focus && focus !== document.body && part.contains(focus)) return;
	drawn = html;
	part.innerHTML = html;
}
/** Write one setting through the window, shown at once and let go if the window will not have it. */
function put(key, value) {
	const api = surface();
	if (!api?.teamSet) return tellSaved({
		key,
		ok: false,
		why: "this window takes no settings from the panel"
	});
	const now = settings?.controls.find((c) => c.key === key);
	if (now && now.value === value && !mine.has(key)) {
		drawSettings();
		return tellSaved({
			key,
			ok: true,
			value
		});
	}
	holdMine(key, value);
	drawSettings();
	api.teamSet(key, value).catch((err) => {
		mine.delete(key);
		drawSettings();
		api.log(`${key} was not written — ${String(err)}`);
		tellSaved({
			key,
			ok: false,
			why: String(err)
		});
	});
}
async function start() {
	const api = surface();
	const code = (api?.language ?? "en").split(/[-_]/)[0] || "en";
	if (code !== "en") try {
		const answer = await fetch(`./words/${code}.json`);
		if (answer.ok) useWords(await answer.json());
	} catch {}
	try {
		const paintFrom = (tokens) => paint(document.documentElement, tokens);
		paintFrom(await api?.tokens() ?? {});
		api?.onTokens?.(paintFrom);
	} catch {}
	draw();
	api?.onTeamSettings?.((detail) => {
		if (!detail || typeof detail !== "object" || !Array.isArray(detail.controls)) return;
		settings = detail;
		const went = settle(settings);
		drawSettings();
		went.forEach(tellSaved);
	});
	if (typeof api?.teamSettings !== "function") {
		if (rows === null) rows = [];
		draw();
		return;
	}
	api.teamSettings().catch(() => {});
	setTimeout(() => {
		if (rows !== null) return;
		rows = [];
		draw();
	}, TEAM_WAIT_MS);
}
if (typeof window !== "undefined" && typeof document !== "undefined") {
	window.addEventListener("vobuda-plugin-team", (e) => {
		const detail = e.detail;
		rows = Array.isArray(detail) ? detail : [];
		draw();
	});
	window.addEventListener("vobuda-plugin-answer", (e) => {
		if (!heardAnswer(e.detail)) return;
		draw();
		setTimeout(draw, 8050);
	});
	document.addEventListener("change", (e) => {
		const el = e.target?.closest("#settings [data-key]");
		if (!el || el.tagName === "BUTTON") return;
		const value = readControl(el);
		const key = el.dataset.key;
		el.blur();
		if (value === null) {
			drawSettings();
			return tellSaved({
				key,
				ok: false,
				why: "the field takes a number"
			});
		}
		put(key, value);
	});
	document.addEventListener("keydown", (e) => {
		const el = e.target;
		if (e.key === "Enter" && el?.matches("#settings input[type='number']")) el.blur();
	});
	document.addEventListener("focusout", () => setTimeout(drawSettings, 0));
	document.addEventListener("click", (e) => {
		const toggle = e.target?.closest("#settings button[data-key]");
		if (toggle) {
			const c = settings?.controls.find((c) => c.key === toggle.dataset.key);
			if (c) put(c.key, !valueNow(c));
			toggle.blur();
			return;
		}
		if (e.target?.closest("[data-edit='role']")) {
			const api = surface();
			api?.editRole?.(director_default).catch((err) => api.log(`the role did not open — ${String(err)}`));
			return;
		}
		const acted = e.target?.closest("[data-act]");
		if (acted) {
			const api = surface();
			const act = acted.dataset.act;
			const block = Number(acted.dataset.block);
			if (api?.teamAct && (act === "merge" || act === "diff") && Number.isFinite(block)) api.teamAct(block, act).catch((err) => api.log(`${act} did not go — ${String(err)}`));
			return;
		}
		if (!e.target?.closest("[data-call='director']")) return;
		const api = surface();
		if (!api) return;
		if (rows === null) return;
		api.startAgent(nextName(rows, say("Director")), director_default).catch((err) => api.log(`the director did not start — ${String(err)}`));
	});
	start();
}
//#endregion
