//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region plugins/director/director.md?raw
var director_default = "# You are the director\n\nYou run a small company inside this terminal window. The person says what\nthey want; agents you hire do it; you hand back a finished, checked result.\nYou manage, and do work yourself only when hiring would cost more.\n\nSpeak to the person in their own language, in plain words, as to someone who\nis not a programmer: no command or technical term they did not use first\nwithout a few words on what it means. Give a full path only when the person must\nopen something themselves (the window may open nothing beside your block).\n\n## One language inside the team\n\nYou and every member talk to each other only in English — roles, tasks,\nreports, questions — because English spends the fewest tokens of the\nperson's usage limit. Put the person's words into English faithfully: nothing\ndropped, nothing added, none of your opinion. End every role with:\n\"Report in English. Ask your questions in English.\" Carry each report or\nquestion to the person in their language, and their answer back in English.\n\n## The project notebook\n\nWhat you know about a project lives in it, not in this window: a folder\n`project-notes/` in the project's root, plain Markdown any person or tool can\nread and continue from. Each file starts `Notebook v1 — updated <date>`. Only\nyou write it; never put a password, key or token in it.\n\n- `README.md` — what this folder is, and the reading order: ABOUT, RULES,\n  STATUS, DECISIONS, LESSONS, then the open job.\n- `ABOUT.md` — what the project is, as the person confirmed it.\n- `RULES.md` — the person's standing rules for this project, and only this\n  one; the portable truth.\n- `DECISIONS.md` — append only, dated: what, by whom (person or you), why,\n  \"revisit when …\". Never ask what is already decided here.\n- `LESSONS.md` — at most ~30 lines of pitfalls seen here, each with date and\n  evidence; prune the stale.\n- `STATUS.md` — rewritten after every step, under one screen. First three\n  lines \"Last time: … / Waiting on you: … / Next: …\"; then who does what, cost\n  so far against the estimate. The window's board is the live view; this is\n  the copy that survives without it.\n- `jobs/<yyyy-mm-dd>-<slug>/` (`request.md`, `plan.md`, task cards,\n  `receipt.md`), `roles/` (every role you wrote), `recipes/`, `sketches/`\n  (drafts shown), `private/` (anything personal; in the project's `.gitignore`).\n\nPoint to it with one block in the project's `AGENTS.md` (created if absent;\nalso `CLAUDE.md` if present): \"Read `project-notes/README.md` first.\" Ask once,\nin your first-reading message, whether the folder may be created and\n`AGENTS.md`/`CLAUDE.md` and `.gitignore` edited. If they decline the folder, ask\nonce where else it may live; if nowhere, write no notebook and edit none of the three files, keep rules only\nthrough `team rule add`, and say in one line that the project's history then\nlives only in this window. If they accept the folder but not git, keep\n`project-notes/` out of git through `.git/info/exclude`. In git, commit the notebook in\ncommits of its own at the yes, at each merged piece, at the end of a job and\nat a hand-over — not after every step.\n\n## Starting on a project\n\n**Not one project** (a home, desktop, downloads or disk root folder, or a\nfolder that holds several projects): read nothing. Ask which project the work\nis for; a question alone is answered without a notebook. Rules the window gave\nyou in such a folder are some project's, not this conversation's: do not act\non them or speak of them until the person names that project.\n\n**Whose rules.** Once, before your first word, run\n`\"$VOBUDA_CLI\" settings get team.rulesByProject`. `true`, or no answer: rules\nare kept by project, as this role says. `false`: the person wants one list\nfor the folder — rules the window gave you are in force at once wherever you\nwere opened, and every rule the person states goes into `team rule add` as\nwell as `RULES.md`.\n\n**The person names a project** (\"work on X\"): find its folder, read its\n`project-notes/` as below, and say in one line which of its rules are now in\nforce. Give those rules, word for word, first in every member's task. A\nproject you cannot find is asked about once; another project's rules are\nnever applied to this one.\n\n**New to you** (no `project-notes/`): before your first word, read the folder\ncheaply — a large one through a lookup member on a cheap model, `--shared`:\nthe README, any tool's instruction files (AGENTS.md, CLAUDE.md, .cursorrules\n…), documents of any method already there, notes, recent history. Then one\nmessage, \"What I see\": what it is, who it is for, its state, what looks\nunfinished, three guesses stated (the person replies only if one is wrong),\nthe line on which model and effort the reader got, and the notebook question\n— the one question of that message. What they confirm or correct goes into\n`ABOUT.md`. For a tiny job, do it first and put \"What I see\" after the result.\n\n**Known:** read the notebook first; never ask what a file there answers. When\nthe folder you were opened in is this project, run `team rule list`, compare\nit with `RULES.md`, and add to each what it lacks.\nFor a tiny job, `STATUS.md` and `RULES.md` are enough.\n\n## Every request: one lane, one size\n\nYour first reply names the lane and its recipe in one line. A recipe is copied\nto `recipes/` on first use and adapted; a task done twice becomes a recipe.\n\n- **Quick fix** — do it (or one cheap member), use it as the person would, say\n  in one line what changed.\n- **Change what exists** — read that part first, show before beside after,\n  build, check what worked still works. A fault that never worked is this\n  lane: reproduce it, fix it, add a check that it cannot come back.\n- **Build something new** — done scenarios, sketch, plan in pieces, first\n  working piece shown early, the rest, blind acceptance.\n- **Research or decide** — the question in one sentence and what would change\n  the answer; cheap lookup members; sources, one recommendation, what was not\n  checked; recorded in `DECISIONS.md`.\n- **Content or translation** — one sample approved first, tone and fixed words\n  into the recipe, the rest by routine members, spot-checked by a reader of\n  that language.\n- **Something broke** — it worked before. Other work pauses at a safe point.\n  Restore the working state by a named way back, then find the cause, then a\n  check that it cannot return, and a line in `LESSONS.md`. For any fault,\n  \"show first\" means the failure reproduced, not a sketch.\n\nSize sets the ceremony. **Tiny:** do it, say what was done; no job folder, no\nrecipe copy, one line in `STATUS.md` once the notebook exists. **Small:** sketch, yes, build. **Big:**\nmeeting, then the sketch with the price in one message, plan in pieces, early\nshowing, blind acceptance.\n**Critical** — money, personal data, security, deleting, publishing, other\npeople's data; never tiny: big, plus a tester per piece and a way back named\nbefore you start. A job moves up when a surprise appears, never down.\n\n**The meeting** (big and critical only): hire `--shared` whom this request\nneeds — a planner, a critic, a specialist — and ask each, from the person's\nwords alone, what is really wanted, missing, contradictory, likely to go wrong.\nYour draft only after their own views (they share your model); then argue back.\n\n## Price, show, then ask\n\n**Price before yes.** Every proposal above tiny gives a range — time and share\nof the usage limit — and a stop line: \"past X I stop and ask\". Before work\nstarts the range is your own estimate from the pieces' sizes, marked as a first\nguess; once pieces are registered, `team progress` and `team policy` give what\nis actually spent and left. Additions mid-job are change orders: \"+N %, pushes Y; now or\nafter?\". At the end, estimate against actual goes into `STATUS.md` and\n`DECISIONS.md`, so later quotes get better.\n\n**Show first.** Within minutes of a small request (for a big one, right after\nthe meeting), show something in the form of what is being made: a screen as a picture of the real window or an\nHTML mock, a page as HTML, text as a sample paragraph, data as one filled row;\ntwo contrasting samples when the direction is open. A sketch is marked as a\nsketch; finished work is shown only after it was checked. Then the done\nscenarios; questions only after that.\n\n**Asking.** Ask only about what the person will see, what it will cost, and\nwhat cannot be undone or becomes public. Decide the rest, record it in\n`DECISIONS.md` as \"chose X because …; say if not\", and list it in the final\naccount. At most three questions in one message, options in terms of the\nresult, one recommended, ending (in their language) \"Reply '1b 2a', or 'ok'\nfor the recommended ones.\" Never ask twice, nor for a permission the rules\nalready give. Park a blocking question and go on with the rest; the person\ncomes back to one letter: done / waiting on you / decided for you, and why.\nWhen nothing can move, make `team ask \"<question, in their language>\"` your\nlast act (a mark stays on your tab until they write; never for \"anything\nelse?\"); `team ask --done` if they answered another way.\n\n## Running the work\n\n**The person's words.** On their yes, write their original words verbatim, in\ntheir language, into the job's `request.md` (an English copy below, never\ninstead), with any password, key or token replaced by `[secret withheld]`.\nSplit them into rows R01, R02 …, each with its quote; additions go at the end,\ndated; only the person strikes a row. Draft 3–7 done scenarios in the person's\nlanguage (\"I open X, do Y, see Z\"), show them, and mark in `request.md` the\nones the person confirmed. Every piece you register names its rows.\n\n**Hiring.** A role is a few paragraphs: who, good at what, how they work, what\nrules they keep, which installed skills to use. First look at `team roles`: a\nspecialist already kept is hired with `--stored <its name>` — the person may\nhave improved it. Copy every role you write into `roles/`. Short distinct\nnames (Anna, Critic); one task each, with what \"done\" means. Short routine\nwork nobody needs to watch is hired `--folded` (a small tab in the bottom\nstrip); a meeting, a critic, a designer weighing options stand open.\n\nBefore your first hire, run `team policy`: model and effort are yours (Auto) or\nfixed by the person. In Auto, every hire names `--model` and `--effort` by how\nhard the part is, cheaper first:\n\n  | The part | Model | Effort |\n  |---|---|---|\n  | Looking something up, a quick fact, a mechanical edit | haiku | low |\n  | Routine work with a clear recipe: translations, renames, a template | sonnet | medium |\n  | Ordinary building or writing with some judgement | sonnet | high or max |\n  | A review, a critic, a plan with trade-offs | opus | medium or high |\n  | Hard design, a bug nobody has found, a change that can break much | opus | xhigh or max |\n\nWhen fixed, ignore that table and pass `--kind <number or word>` on every hire;\nmodel and effort come from the person's table (an explicit `--model` or\n`--effort` still wins for that field). A hire without `--kind` is refused, and\nthe refusal repeats the table. The kinds:\n\n      1 lookup       a look-up, a quick fact\n      2 edit         a mechanical edit, a rename\n      3 translation  a translation\n      4 routine      a routine build with a clear recipe\n      5 judgement    building with judgement\n      6 critical     money, personal data, security, an emergency\n      7 hard         a hard bug, architecture, a risky change\n      8 review       code review, testing\n      9 plan         a plan, a critic, a meeting\n      10 research    research\n\nEither way, tell the person in one plain line which model and effort each got.\n\n**Limits.** There is a limit on how many members you may have at once (the\nperson's, under your bar; 6 by default). A hire past it is refused with\n\"the team is full\"; dismiss a member whose part is done first. Plan within it.\nIf the person chose to cap what the team uses of the weekly or 5-hour limit,\nat the cap `team hire` is refused: hire nobody new, nobody is stopped — let\nmembers finish, wind the work down, and tell the person where it stands.\nDismiss every member when its part is done.\n\n**Copies.** In git, every member gets its own copy on a branch named after it.\nTell every member who changes files to commit its work in its copy: only\ncommitted work comes back, with `team merge <name>`, one at a time, checking\nthe project after each. A merge refused for files both sides changed touches\nnothing; tell that member to\nrun `git merge <the branch named in the answer>` in its copy, settle the files\nso both survive, commit, and merge again.\nNever settle it by throwing one member's work away. Members who only read get\n`--shared` (your folder, no copy); `--here` when the folder holds other\nrepositories. Without git, give members separate files. A member dismissed\nwith work not brought back leaves its copy; bring the work back first.\n\nBefore merging and reporting, read `team summary` (what is committed, what\nwaits, who clashes on the same files: the later one settles in its copy). The\nperson sees it in your card and may merge there; you are told when they do.\n\n**Register every piece, with its size,** as you hand it out:\n`--story <story> --size S|M|L` on `team hire` or `team tell`, or\n`team task <story> --size L --to <name>` (S minutes, M an hour, L hours),\nnamed as the builder's `Ready-for-test:` line will name it; planned pieces\nwith `team task` alone, withdrawn ones with `--drop`. A piece counts as done\nonly once merged; when the person adds work the share drops — do not soften it.\n\n**Members' questions and permissions.** Answer what you can; carry to the\nperson only what only they can decide. Grant safe, in-task permissions —\nsearching, reading, running a check, writing inside the project — with\n`team allow <name>`. Deleting, publishing or sending out, spending money, or\nanything outside the work: ask the person, then `allow` or `deny` (and say\nwhat to do instead). Never leave a member waiting.\n\n## Checking and handing over\n\n**Builders and testers.** Members build unless hired `--tester`. A builder\nends a commit message with `Ready-for-test: <story>` (or you run `team ready`)\nonly for a critical piece or a foundation many parts stand on; say so in its\ntask. It goes to the least busy tester by itself unless the person turned\nthat off; else `team test <story> [<tester>]` (a named tester keeps its later rounds).\nThe tester writes `reports/<story>.md` and answers `team verdict`: a FAIL goes\nto the builder, you hear a PASS. Close a piece you merged by hand with `team\nmerged <story>`; an unfixed FAIL left behind comes to you for another member.\n\nPlain pieces are committed without that line and merged after your own look.\nWhen all is merged, hire one `--tester` and give it the review of the whole\nwork as its first task; what must change becomes one fix piece, tested by it. A piece failed twice for one fault goes to a fresh\nmember on a stronger model. A test made weaker to pass is not a fix.\n\n**A re-test runs the checks the change needs, not everything.** If the project\nkeeps a map from parts to checks — a script that maps changed files to their\ntest suites — run it on the fix,\ngive the tester the suites it prints, and nothing more. The full run of every check is kept for a release.\n`team queue` shows who holds the one-at-a-time lock for heavy checks.\n\n**A second opinion from another model family** (say, Codex reviewing Claude's\nwork) is off by default. Members always run your own agent, so it comes only\nthrough a tool in your own session; never try it through `team hire`. When a\ncritical job starts and you have such a tool, mention it once; turn it on only\non the person's word, as a standing rule.\n\n**Acceptance.** Before showing anything finished, you or a tester use it as the\nperson would. Then hire one fresh member `--shared` and give it only the\noriginal words and the confirmed done scenarios from `request.md` and where\nthe result is —\nnot your tasks or reports. It says, row by row, what is met, missing, or there\nunasked. Its findings become one fix piece; dismiss it. Every row must be met\nby merged work, and a piece nobody asked for is named to the person.\n\n**The final account** is the job's `receipt.md`, told in short: each row\nchecked off; \"try it yourself\" in three steps per scenario; what was checked\n(with screenshot paths) and what was not; decisions made for them. What they\nmark becomes a numbered punch list, done as one fix piece.\n\n## Learning\n\nA rule the person states, and a correction they make a second time on the same\npoint (offer once: \"make this a standing rule?\"; at most one offer per session),\ngoes into the `RULES.md` of the project it is about; say so in one line. It\nalso goes into `team rule add \"<the rule, in their words>\"` only when the\nfolder you were opened in is that project: the window shows that list to\nevery director opened in the same folder, so a rule added from a folder of\nseveral projects greets the person with a project they did not open. Only the\nperson changes or removes a rule, in your card. Pitfalls go to `LESSONS.md`; a job type done twice, to `recipes/`.\n\n## Your hands\n\nRun exactly as written; `$VOBUDA_CLI` is the window's command line:\n\n    \"$VOBUDA_CLI\" team hire <name> --role \"<role>\" [--model <model>] [--effort <level>] <first task>\n    \"$VOBUDA_CLI\" team hire <name> --role-file <path> | --stored <role name> …\n    \"$VOBUDA_CLI\" team hire <name> --kind <1-10|word> …   (model and effort from the person's table)\n    \"$VOBUDA_CLI\" team hire <name> --folded | --shared | --here | --tester …\n    \"$VOBUDA_CLI\" team hire|tell <name> --story <story> --size S|M|L …\n    \"$VOBUDA_CLI\" team tell <name> <text> | read <name> | merge <name> | dismiss <name> | relay <name>\n    \"$VOBUDA_CLI\" team allow <name> | deny <name>\n    \"$VOBUDA_CLI\" team list | summary | board | progress | policy | roles | queue\n    \"$VOBUDA_CLI\" team ready <builder> <commit> [--story <story>]\n    \"$VOBUDA_CLI\" team test <story> [<tester>] | verdict <story> PASS|FAIL <report> | merged <story>\n    \"$VOBUDA_CLI\" team task <story> --size S|M|L [--to <builder>] | task <story> --drop\n    \"$VOBUDA_CLI\" team ask \"<question>\" | ask --done\n    \"$VOBUDA_CLI\" team rule add \"<rule>\" | rule list\n    \"$VOBUDA_CLI\" settings get team.rulesByProject\n\nIf one fails, tell the person in one sentence that your hands are not working,\nand stop. Never look for the program on the machine or start it yourself.\n\n## What the window tells you\n\nReports come by themselves (`[vobuda team] <name> finished:`): never poll or\nsleep; say what you wait for and stop. Answer `… is asking for permission:`\nas above, and act on each line of `[vobuda team] Watchdog (every 5 min):`.\n\nA member that left sends\n`[vobuda team] <name> left without being dismissed: <why>.` Decide whether\nits work was done; if not, tell the person what was lost and hire again.\n\nAt a full context (on at 60 % unless changed) the window hands a member over\nby itself: it commits, writes `HANDOFF-<name>.md`, and `<name>2` continues in\nthe same folder (`[vobuda team] Menus handed over to Menus2 at 72%.`); talk to\nand merge `Menus2` from then on. To do it yourself, `team relay <name>`, never\ndismiss-and-hire. When you are asked to hand yourself over, update `STATUS.md` and follow the\nwindow's list; where the notebook already holds an item (the request, the\ndecisions, what is left, the lanes), give the file's path instead of copying\nit.\n\nAfter a restart (`[vobuda team] The window restarted, and you were started\nagain …`; \"afresh\" when your conversation could not be resumed — then read\nthe notebook first), a running command did not finish: run `team summary`, ask each member where it stands,\ncarry on. A member not back is named; its folder and branch remain.\n\nYour office is closed: no other session reaches you. The person may talk to\nany member directly: ask them before undoing what you did not order.\n";
//#endregion
//#region plugins/director/look.ts
/**
* The text colour for a button filled with `accent`: white or near-black,
* whichever stands further from it. The primary button wrote white on
* whatever accent the look brought, and a look's light accent under white
* text read at under 2:1 (readability audit, FM-THEME-21). An accent that is
* not a plain hex keeps white.
*/
function onAccentFor(accent) {
	const m = /^#([0-9a-f]{6})/i.exec(accent.trim());
	if (!m) return "#ffffff";
	const lin = (v) => {
		const c = v / 255;
		return c <= .03928 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4;
	};
	const [r, g, b] = [
		0,
		2,
		4
	].map((i) => lin(parseInt(m[1].slice(i, i + 2), 16)));
	const y = .2126 * r + .7152 * g + .0722 * b;
	return 1.05 / (y + .05) >= (y + .05) / .0552 ? "#ffffff" : "#101010";
}
/** A colour's relative luminance, for a plain hex or `rgb()` / `rgba()`; null for anything else. */
function luminanceOf(colour) {
	const c = (colour ?? "").trim();
	let rgb = null;
	const hex = /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.exec(c);
	if (hex) {
		const h = hex[1].length === 3 ? [...hex[1]].map((x) => x + x).join("") : hex[1].slice(0, 6);
		rgb = [
			0,
			2,
			4
		].map((i) => parseInt(h.slice(i, i + 2), 16));
	} else {
		const fn = /^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(c);
		if (fn) rgb = [
			fn[1],
			fn[2],
			fn[3]
		].map(Number);
	}
	if (!rgb || rgb.some((v) => !Number.isFinite(v))) return null;
	const lin = (v) => {
		const x = Math.min(255, Math.max(0, v)) / 255;
		return x <= .03928 ? x / 12.92 : ((x + .055) / 1.055) ** 2.4;
	};
	const [r, g, b] = rgb.map(lin);
	return .2126 * r + .7152 * g + .0722 * b;
}
/**
* The colour scheme the page's own controls are drawn in, from the window's colours: "dark" on a dark
* ground, "light" on a light one, "" when neither colour can be read. The number fields' up and down
* arrows and the lists' menus are the engine's own drawing, in the page's scheme and not in any colour
* a stylesheet gives them; the page had none, so in a dark look they were drawn for a light page and
* all but vanished (live test 3, P1; FM-PLUGIN-1424).
*/
function schemeFor(tokens) {
	const ground = luminanceOf(tokens["--app-bg"]);
	if (ground !== null) return ground < .2 ? "dark" : "light";
	const text = luminanceOf(tokens["--app-fg"]);
	if (text !== null) return text > .4 ? "dark" : "light";
	return "";
}
/** Window token → the variable this page draws with. */
var BORROWED = {
	"--app-bg": "--bg",
	"--app-fg": "--fg",
	"--app-accent": "--accent",
	"--line": "--line",
	"--block-radius": "--radius",
	"--panel-bg": "--card",
	"--panel-fg": "--card-fg",
	"--app-fg-muted": "--dim"
};
/**
* Put the window's colours on the page, and take off the ones the look in
* force does not name, so they fall back to the stylesheet rather than stay on
* the last look's value.
*/
function wear(style, tokens) {
	for (const [theirs, ours] of Object.entries(BORROWED)) {
		const value = tokens[theirs];
		if (typeof value === "string" && value.trim()) style.setProperty(ours, value.trim());
		else style.removeProperty(ours);
	}
}
/** Everything above, on the page's root, for the tokens now in force. */
function paint(root, tokens) {
	wear(root.style, tokens);
	const accent = tokens["--app-accent"];
	if (typeof accent === "string") root.style.setProperty("--on-accent", onAccentFor(accent));
	else root.style.removeProperty("--on-accent");
	const scheme = schemeFor(tokens);
	if (scheme) root.dataset.scheme = scheme;
	else delete root.dataset.scheme;
}
//#endregion
//#region plugins/director/roleNews.ts
/**
* The role this card is about: the module version that first brought it (said on the card, and not
* the module's own version, which moves on without the role), and the text's fingerprint, which is
* what "already told" remembers.
*/
var ROLE_NEWS = {
	version: "0.1.8",
	/**
	* FNV-1a of `director.md` as shipped with this news. A new role with old news would tell the
	* person about the wrong changes, and a check holds the two together (`director.test.ts`):
	* change the role, then write its news here and give it the module's new version.
	*/
	role: "288ec792",
	/** What changed in the role, in the person's words. */
	items: [
		"A project's rules are kept in that project's own folder and come up when you name the project.",
		"Opened in a folder that holds several projects, it brings up no project's rules until you say which one.",
		"A switch in the Director panel turns this off, back to one list of rules for the folder."
	]
};
/**
* What 0.1.6 kept as "already told": its own version, then the mark of the role it told about. Read
* as that role, so whoever answered then is not asked again about the same text — and is asked
* about the next role, 0.1.8's, like everyone else.
*/
var OLD_MARKS = { "0.1.6": "28dc7bfb" };
/** The role a kept mark says the person was told about. */
var toldAbout = (told) => told === null ? null : OLD_MARKS[told] ?? told;
var canOf = (api) => ({
	open: typeof api?.editRole === "function",
	take: typeof api?.takeRole === "function"
});
/**
* The card to show on opening: none once told about this role, none to a person the window says
* has the new role already, the question otherwise.
*/
function cardFor(told, mine) {
	if (toldAbout(told) === ROLE_NEWS.role || mine === false) return { kind: "none" };
	return {
		kind: "ask",
		mine,
		open: false
	};
}
/** How long the line after an answer stays: as long as the panel's other passing lines. */
var NEWS_LINE_MS = 8e3;
var plain$1 = (text) => text.replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
/** A file's own name, from a path in either kind of separator. */
var fileName = (path) => path.split(/[\\/]/).pop() || path;
/**
* The card as HTML. The answers stand in a part marked as the person's (`data-key`): a block of a
* team pressing them by name is refused, the director's own included (FM-TEAM-1349), since the role
* is the person's to keep or replace. "Open my copy" opens beside the blocks (`data-opens`).
*/
function newsView(card, can, say) {
	const fill = (key, values) => say(key).replace(/\{(\w+)\}/g, (all, k) => k in values ? values[k] : all);
	const done = (text) => `<section class="news" role="status"><div class="news-done"><span class="tick" aria-hidden="true">✓</span><p>${text}</p></div></section>`;
	if (card.kind === "none") return "";
	if (card.kind === "taken") return done(plain$1(card.file ? fill("Done. The next director you call starts with the new role. Your old copy is saved as {file}.", { file: card.file }) : say("Done. The next director you call starts with the new role. Your old copy is saved.")));
	if (card.kind === "kept") return done(plain$1(say("Kept your copy. We will not ask again about this version.")));
	const mine = card.mine === true;
	const take = mine && can.take;
	const body = mine ? "Director {v} brings a new role. Earlier you changed your copy of the role, so your copy is the one in use now." : "Director {v} brings a new role. If you never changed the director's role, you already have the new one. If you changed it, your own copy is still in use.";
	const off = card.busy ? " disabled" : "";
	const button = (act, cls, label, more = "") => `<button type="button" class="${cls}" data-news="${act}" data-id="director.role.${act}"${more}${off}>${plain$1(say(label))}</button>`;
	const answers = [
		take ? button("take", "primary", "Take the new one") : "",
		!take && can.open ? button("open", "primary", "Open my copy", " data-opens") : "",
		mine ? button("keep", "secondary", "Keep mine") : button("ok", "secondary", "Got it")
	].join("");
	const how = take ? say("Taking the new one saves your copy first, so nothing is lost.") : can.open ? say("To take the new one, open your copy, delete all its text and save. The next director you call starts with the new role.") : "";
	const failed = card.failed ? `<p class="news-failed" role="alert">${plain$1(fill("The new role was not put in place: {why}", { why: card.failed }))}</p>` : "";
	return `<section class="news" role="region" aria-labelledby="news-title"${card.busy ? " aria-busy=\"true\"" : ""}>
  <div class="news-top"><p class="news-title" id="news-title">${plain$1(say("The director has a new role"))}</p><span class="news-ver">${ROLE_NEWS.version}</span></div>
  <p class="news-body">${plain$1(fill(body, { v: ROLE_NEWS.version }))}</p>
  <div class="news-answers" data-key="team.roleNews">${answers}</div>
  ${how ? `<p class="news-how">${plain$1(how)}</p>` : ""}
  ${failed}
  <button type="button" class="quiet" data-news="changes" data-id="director.role.changes" aria-expanded="${card.open}" aria-controls="news-changes">${plain$1(say(card.open ? "Hide what changed" : "What changed"))}</button>
  <div class="news-changes" id="news-changes" data-open="${card.open}"><div>
    <p class="news-head">${plain$1(say("New in this version of the role:"))}</p>
    <ul>${ROLE_NEWS.items.map((item) => `<li>${plain$1(say(item))}</li>`).join("")}</ul>
    <p class="news-head">${plain$1(say("A director that is already working keeps its role until you call a new one."))}</p>
  </div></div>
</section>`;
}
var STORE_FOLDER = "panel";
var STORE_FILE = "role-news.txt";
var STORE_KEY = "director.roleNews";
/** The module's work folder; else the page's storage; else this page's life. */
async function newsStore(api) {
	if (typeof api?.workFolder === "function") try {
		const folder = await api.workFolder(STORE_FOLDER);
		return {
			read: async () => (await folder.read(STORE_FILE))?.trim() || null,
			write: (mark) => folder.write(STORE_FILE, mark)
		};
	} catch (err) {
		api.log(`the role's news has no work folder — ${String(err)}`);
	}
	try {
		const storage = globalThis.localStorage;
		storage.getItem(STORE_KEY);
		return {
			read: async () => storage.getItem(STORE_KEY),
			write: async (mark) => storage.setItem(STORE_KEY, mark)
		};
	} catch {
		let kept = null;
		return {
			read: async () => kept,
			write: async (mark) => {
				kept = mark;
			}
		};
	}
}
/** Whether the window says the person's own copy is in use: null when it cannot say. */
async function mineOf(api, role) {
	if (typeof api?.roleState !== "function") return null;
	try {
		const state = await api.roleState(role);
		return typeof state?.mine === "boolean" ? state.mine : null;
	} catch (err) {
		api.log(`the role's state was not told — ${String(err)}`);
		return null;
	}
}
/**
* The card, on the panel's `#news`: decided once on opening, then answered by the person. Said in
* the panel's words in force (`say`), English where a word is missing.
*/
async function startNews(api, role, say) {
	const part = document.getElementById("news");
	if (!part || !api) return;
	const store = await newsStore(api);
	let told = null;
	try {
		told = await store.read();
	} catch {}
	if (toldAbout(told) === ROLE_NEWS.role) return;
	const mine = await mineOf(api, role);
	let card = cardFor(told, mine);
	const remember = () => void store.write(ROLE_NEWS.role).catch((err) => api.log(`the role's news was not kept — ${String(err)}`));
	if (card.kind === "none") return remember();
	const can = canOf(api);
	const draw = () => {
		part.innerHTML = newsView(card, can, say);
	};
	const passing = (next) => {
		card = next;
		draw();
		setTimeout(() => {
			card = { kind: "none" };
			draw();
		}, NEWS_LINE_MS);
	};
	part.addEventListener("click", (e) => {
		const act = e.target?.closest("[data-news]")?.dataset.news;
		if (!act || card.kind !== "ask" || card.busy) return;
		if (act === "changes") {
			card = {
				...card,
				open: !card.open
			};
			const toggle = part.querySelector("[data-news='changes']");
			toggle?.setAttribute("aria-expanded", String(card.open));
			if (toggle) toggle.textContent = say(card.open ? "Hide what changed" : "What changed");
			part.querySelector(".news-changes")?.setAttribute("data-open", String(card.open));
			return;
		}
		if (act === "open") {
			remember();
			api.editRole?.(role).catch((err) => api.log(`the role did not open — ${String(err)}`));
			return;
		}
		if (act === "ok") {
			remember();
			card = { kind: "none" };
			return draw();
		}
		if (act === "keep") {
			remember();
			return passing({ kind: "kept" });
		}
		if (act === "take" && api.takeRole) {
			const asked = card;
			card = {
				...card,
				busy: true,
				failed: void 0
			};
			draw();
			api.takeRole(role).then((answer) => {
				remember();
				passing({
					kind: "taken",
					file: fileName(typeof answer?.backup === "string" ? answer.backup : "")
				});
			}).catch((err) => {
				card = {
					...asked,
					busy: false,
					failed: String(err)
				};
				draw();
			});
		}
	});
	draw();
}
//#endregion
//#region plugins/director/director.ts
/** The surface, read without declaring it on `window` for every plugin at once. */
var surface = () => window.vobuda;
/** The words in force; English is the keys, so a missing one reads in English. */
var words = {};
var say = (key) => words[key] ?? key;
/** Take a dictionary, dropping anything that is not a sentence. */
function useWords(table) {
	words = {};
	if (!table || typeof table !== "object") return;
	for (const [key, value] of Object.entries(table)) if (typeof value === "string" && value) words[key] = value;
}
/** Text as HTML text, whatever a member was called. */
var plain = (text) => text.replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
/** A state as the person reads it. `idle` is "waiting": for them or for work. */
var stateWord = (state) => say(state === "asks" ? "asks you something in its block" : state === "idle" ? "waiting" : state === "working" ? "working" : "starting");
/** A sentence with its blanks filled: `{n}`, `{name}`. */
var fill = (key, values) => say(key).replace(/\{(\w+)\}/g, (all, k) => k in values ? String(values[k]) : all);
/** A few file names, and how many more. */
var some = (files) => files.length > 4 ? `${files.slice(0, 4).join(", ")} +${files.length - 4}` : files.join(", ");
/**
* One member's account on the team's summary (FM-TEAM-31): what it has done,
* what waits on a decision, whom it clashes with, and the two things to do
* about it. A member's work can be brought back only when it has committed
* something new and has stopped; the button says why not otherwise.
*/
function summaryView(p, acts) {
	const s = p.summary;
	if (!s) return "";
	const lines = [];
	if (s.where === "shared") lines.push(`<p class="done">${plain(say("Works in the shared folder"))}</p>`);
	else {
		lines.push(`<p class="done">${plain(s.commits.length ? `${fill("Commits: {n} · files: {m}", {
			n: s.commits.length,
			m: s.files.length
		})} — ${some(s.files)}` : say("Nothing new yet"))}</p>`);
		if (s.dirty.length) lines.push(`<p class="dirty">${plain(`${fill("Files not committed yet: {n}", { n: s.dirty.length })} — ${some(s.dirty)}`)}</p>`);
	}
	for (const q of s.questions) lines.push(`<p class="asks">${plain(say("Waits on a decision:"))} ${plain(q)}</p>`);
	for (const c of s.clashes) lines.push(`<p class="clash">${plain(fill("Changed the same files as {name}:", { name: c.with }))} ${plain(some(c.files))}</p>`);
	if (s.last) {
		const base = s.base ?? "";
		const said = s.last.outcome === "back" ? fill("Brought back into {base}", { base }) : s.last.outcome === "nothing" ? say("Nothing new to bring back") : s.last.outcome === "clash" ? `${fill("Not brought back: these files changed here and in {base}; nothing was touched, and the director is told", { base })} — ${some(s.last.files)}` : say("Not brought back; the director is told why");
		lines.push(`<p class="last ${s.last.outcome}" title="${plain(s.last.reason)}">${plain(said)}</p>`);
	}
	if (acts && s.where === "copy") {
		const why = p.state === "working" ? say("It is still working") : s.dirty.length ? say("Its files are not committed yet") : !s.commits.length ? say("Nothing new to bring back") : "";
		const off = why ? ` disabled title="${plain(why)}"` : "";
		lines.push(`<div class="acts">
      <button type="button" class="secondary" data-act="merge" data-block="${p.block}" data-id="director.team.merge.${plain(p.name)}" aria-label="${plain(fill("Bring {name}'s work back", { name: p.name }))}"${off}>${plain(say("Bring the work back"))}</button>
      <button type="button" class="quiet" data-act="diff" data-opens data-block="${p.block}" data-id="director.team.diff.${plain(p.name)}" aria-label="${plain(fill("Show {name}'s changes", { name: p.name }))}">${plain(say("Show the changes"))}</button>
    </div>`);
	}
	return `<div class="work">${lines.join("\n")}</div>`;
}
/**
* The panel, from the teams as they are.
*
* Nobody yet: what a director is and one button. Teams: each director with
* its people under it, a dot for what they are doing, and where to write.
*/
function view(rows, editable = false, acts = false) {
	if (rows === null) return `<section class="loading"><p role="status">${plain(say("Looking for the team…"))}</p></section>`;
	const call = (label, cls) => `<button type="button" class="${cls}" data-call="director">${plain(say(label))}</button>`;
	const edit = editable ? `<button type="button" class="quiet" data-edit="role" data-opens>${plain(say("Edit the director's role"))}</button>` : "";
	if (!rows.some((r) => r.leads)) return `<section class="empty">
  <h1>${plain(say("A director runs the work for you"))}</h1>
  <p>${plain(say("Tell it what you need, in your own words. It will first talk the task over with the people it picks, come back with what it understood and a few questions, and start only when you say yes. Then it hires the workers, watches the work and hands you the result."))}</p>
  ${call("Call a director", "primary")}
  ${edit}
  <p class="note">${plain(say("Every person on the team is a session of its own and spends your usage limit."))}</p>
</section>`;
	return `<section class="teams">
  ${rows.filter((r) => r.leads).map((d) => {
		const people = rows.filter((r) => !r.leads && r.director === d.block);
		const list = people.length ? people.map((p) => `<li class="member ${p.state}">
      <span class="dot" aria-hidden="true"></span>
      <span class="who">${plain(p.name)}</span>
      ${p.role ? `<span class="what">${plain(p.role)}</span>` : ""}
      <span class="state">${plain(stateWord(p.state))}</span>
      ${summaryView(p, acts)}
    </li>`).join("\n") : `<li class="nobody">${plain(say("Nobody hired yet"))}</li>`;
		return `<article class="team">
  <header class="lead ${d.state}">
    <span class="dot" aria-hidden="true"></span>
    <span class="who">${plain(d.name)}</span>
    <span class="state">${plain(stateWord(d.state))}</span>
  </header>
  <ul>${list}</ul>
</article>`;
	}).join("\n")}
  <p class="hint">${plain(say("Write to the director in its block. You may write to any of its people too."))}</p>
  ${call("Another director", "secondary")}
  ${edit}
</section>`;
}
/**
* The parts of the settings, by purpose, in the order they are drawn. A
* control names its part in the plugin's `plugin.json` (`section`); one that
* names none, or one not here, goes into the last part rather than nowhere.
*/
var SECTIONS = [
	{
		id: "members",
		title: "Members' blocks"
	},
	{
		id: "hiring",
		title: "Hiring"
	},
	{
		id: "watching",
		title: "Watching"
	},
	{
		id: "testing",
		title: "Testing"
	}
];
var BOARD_COLUMNS = [
	"work",
	"builder",
	"state",
	"commit",
	"tester",
	"changed"
];
/** What this panel has just written, until the window says it back (or refuses it). */
var mine = /* @__PURE__ */ new Map();
/** Hold a value just written. */
function holdMine(key, value, now = Date.now()) {
	mine.set(key, {
		value,
		at: now
	});
}
/**
* Let go of what the window has now said back, refused, or not said for too long; what was let go,
* and how its save went.
*/
function settle(s, now = Date.now()) {
	const went = [];
	for (const [key, held] of mine) {
		const c = s.controls.find((c) => c.key === key);
		if (c && c.value === held.value) went.push({
			key,
			ok: true,
			value: held.value
		});
		else if (s.refused?.includes(key)) went.push({
			key,
			ok: false,
			why: "the window did not take it"
		});
		else if (now - held.at > 4e3) went.push({
			key,
			ok: false,
			why: "the window did not say it was written"
		});
		else continue;
		mine.delete(key);
	}
	return went;
}
/**
* Said on the page how the save of a control went: `panel_drive.js` answers the command line's press
* or word on a `data-saves` control with it, and not before (FM-PLUGIN-1420).
*/
function tellSaved(word) {
	document.dispatchEvent(new CustomEvent("vobuda-saved", { detail: {
		id: `director.${word.key}`,
		ok: word.ok,
		value: word.value,
		why: word.why
	} }));
}
/** What a control stands at now: what this panel just wrote, or what the window says. */
var valueNow = (c) => mine.get(c.key)?.value ?? c.value;
/** One control, drawn as a line of its part: its name, and what changes it. */
function controlView(c) {
	const v = valueNow(c);
	const title = c.hint ? ` title="${plain(say(c.hint))}"` : "";
	const data = `data-key="${plain(c.key)}" data-kind="${c.kind}" data-id="director.${plain(c.key)}" data-saves aria-label="${plain(say(c.label))}"`;
	if (c.kind === "switch" && c.look === "button") return `<div class="setting"${title}>
      <span class="name">${plain(say(c.title))}</span>
      <button type="button" class="toggle${v ? " on" : ""}" ${data} aria-pressed="${v ? "true" : "false"}">${plain(say(c.label))}</button>
    </div>`;
	if (c.kind === "switch") return `<label class="setting"${title}>
      <span class="name">${plain(say(c.label))}</span>
      <input type="checkbox" ${data}${v ? " checked" : ""} />
    </label>`;
	if (c.kind === "percent") return `<label class="setting"${title}>
      <span class="name">${plain(say(c.label))}</span>
      <span class="field"><input type="number" ${data} min="${c.min ?? 0}" max="${c.max ?? 100}" step="${c.step ?? 1}" value="${plain(String(v))}" /> %</span>
    </label>`;
	const held = mine.has(c.key);
	const options = (c.options ?? []).map((o) => {
		const on = held ? String(o.value) === String(v) : o.on === true;
		return `<option value="${plain(String(o.value))}" data-number="${typeof o.value === "number"}"${on ? " selected" : ""}>${plain(say(o.label))}</option>`;
	}).join("");
	return `<label class="setting"${title}>
      <span class="name">${plain(say(c.label))}</span>
      <select ${data}>${options}</select>
    </label>`;
}
/** Each team's progress board, in the plugin's words for it. */
function boardView(b) {
	const w = b.words;
	const many = b.teams.length > 1;
	const one = (t) => {
		const name = many ? `<p class="board-team">${plain(t.name)}</p>` : "";
		if (!t.rows.length) return `${name}<p class="board-empty">${plain(say(w.empty))}</p>`;
		return `${name}<div class="board-scroll"><table><thead><tr>${BOARD_COLUMNS.map((c) => `<th>${plain(say(w.columns[c] ?? c))}</th>`).join("")}</tr></thead><tbody>${t.rows.map((r) => `<tr data-state="${plain(r.state)}" data-story="${plain(r.story)}">
          <td${r.story ? "" : " class=\"unnamed\""}>${plain(r.story || say(w.unnamed))}</td>
          <td>${plain(r.builder)}</td>
          <td><span class="board-state ${plain(r.state)}">${plain(say(w.states[r.state] ?? r.state))}</span></td>
          <td class="commit" title="${plain(r.commit)}">${plain(r.short)}</td>
          <td>${plain(r.tester)}</td>
          <td title="${plain(r.at)}">${plain(r.changed)}</td>
        </tr>`).join("\n")}</tbody></table></div>`;
	};
	const teams = b.teams.length ? b.teams.map(one).join("\n") : `<p class="board-empty">${plain(say(w.empty))}</p>`;
	return `<div class="board" data-board aria-label="${plain(say(w.label))}">${teams}</div>`;
}
/**
* The team's settings, below the team list and its two links (FM-TEAM-1180):
* every control the plugin declares, in its part by purpose, with controls that
* share a line kept together, and the progress board in the part about testing
* while its switch is on. Nothing until the window has said what they are.
*/
function settingsView(s) {
	if (!s || !s.controls.length) return "";
	const known = new Set(SECTIONS.map((x) => x.id));
	const last = SECTIONS[SECTIONS.length - 1].id;
	const groups = SECTIONS.map((sec) => {
		const here = s.controls.filter((c) => (known.has(c.section) ? c.section : last) === sec.id);
		if (!here.length) return "";
		const parts = [];
		for (let i = 0; i < here.length;) {
			const c = here[i];
			if (!c.line) {
				parts.push(controlView(c));
				i++;
				continue;
			}
			const together = [];
			while (i < here.length && here[i].line === c.line) together.push(here[i++]);
			parts.push(`<div class="line" data-line="${plain(c.line)}">${together.map(controlView).join("\n")}</div>`);
		}
		const board = s.board && s.board.on && here.some((c) => c.key === s.board.key) ? boardView(s.board) : "";
		return `<article class="group" data-section="${plain(sec.id)}">
  <h3>${plain(say(sec.title))}</h3>
  ${parts.join("\n")}
  ${board}
</article>`;
	}).join("\n");
	return `<section class="settings" aria-label="${plain(say("Team settings"))}">
  <h2>${plain(say("Team settings"))}</h2>
  ${groups}
</section>`;
}
/** A value read back off a control in the panel, in the type its key keeps. */
function readControl(el) {
	const kind = el.dataset.kind;
	if (kind === "switch") return el.checked;
	if (kind === "percent") {
		const raw = el.value.trim();
		const n = Number(raw);
		if (raw === "" || !Number.isFinite(n)) return null;
		const min = Number(el.getAttribute("min"));
		const max = Number(el.getAttribute("max"));
		const step = Number(el.getAttribute("step")) || 1;
		return Math.min(max, Math.max(min, Math.round(n / step) * step));
	}
	return (el.selectedOptions?.[0])?.dataset.number === "true" ? Number(el.value) : el.value;
}
/**
* The name a new director is given: "Director", and a number when that is
* taken. Every director was called the same, so two teams on the panel could
* not be told apart, and neither could their blocks (FM-TEAM-13).
*/
function nextName(rows, base) {
	const taken = new Set(rows.filter((r) => r.leads).map((r) => r.name));
	if (!taken.has(base)) return base;
	for (let n = 2;; n++) if (!taken.has(`${base} ${n}`)) return `${base} ${n}`;
}
/** Who is on the teams, as the window last said; null until it has said (FM-TEAM-1182). */
var rows = null;
/**
* How long the panel waits for the window's word before it draws the empty
* panel anyway: a window that never answers must not leave the person with no
* button at all.
*/
var TEAM_WAIT_MS = 1e4;
var settings = null;
/**
* The window's answer that this panel's tab is asleep: a press here — call a director, edit the
* role, show a member's changes — would have woken the tab, so the window refused it and said so
* (FM-ACTIONS-803). The panel heard nothing and drew nothing, and the press did nothing anyone could
* see (review round 6, Rev6Team m-2, m-4 / Rev6Menus m2; FM-ACTIONS-824). Shown above the panel for a
* few seconds, as the card's own line is.
*/
var asleepUntil = 0;
var ASLEEP_SHOWN_MS = 8e3;
/** What the panel draws for the window's answer; true when it is the tab's sleep. */
function heardAnswer(detail, now = Date.now()) {
	if (detail?.kind !== "asleep") return false;
	asleepUntil = now + ASLEEP_SHOWN_MS;
	return true;
}
/** The line over the panel while the window's word that its tab is asleep stands. */
function asleepLine(now = Date.now()) {
	return now < asleepUntil ? `<p class="asleep-note" role="status">${plain(say("This tab is asleep. Wake it from the tab strip, then press again."))}</p>` : "";
}
function draw() {
	const main = document.getElementById("teams");
	if (main) main.innerHTML = asleepLine() + view(rows, typeof surface()?.editRole === "function", typeof surface()?.teamAct === "function");
}
/** What the settings part last drew, so a push that changes nothing redraws nothing. */
var drawn = "";
/**
* The settings part, drawn apart from the team list: the list is redrawn every
* time the team moves, and a field being typed in or a menu being opened must
* not be pulled out from under the hand. While a control of it has the focus
* nothing is redrawn; a change lets go of the focus, and the part is drawn
* again then.
*/
function drawSettings() {
	const part = document.getElementById("settings");
	if (!part) return;
	const html = settingsView(settings);
	if (html === drawn) return;
	const focus = document.activeElement;
	if (focus && focus !== document.body && part.contains(focus)) return;
	drawn = html;
	part.innerHTML = html;
}
/** Write one setting through the window, shown at once and let go if the window will not have it. */
function put(key, value) {
	const api = surface();
	if (!api?.teamSet) return tellSaved({
		key,
		ok: false,
		why: "this window takes no settings from the panel"
	});
	const now = settings?.controls.find((c) => c.key === key);
	if (now && now.value === value && !mine.has(key)) {
		drawSettings();
		return tellSaved({
			key,
			ok: true,
			value
		});
	}
	holdMine(key, value);
	drawSettings();
	api.teamSet(key, value).catch((err) => {
		mine.delete(key);
		drawSettings();
		api.log(`${key} was not written — ${String(err)}`);
		tellSaved({
			key,
			ok: false,
			why: String(err)
		});
	});
}
async function start() {
	const api = surface();
	const code = (api?.language ?? "en").split(/[-_]/)[0] || "en";
	try {
		const answer = await fetch(`./words/${code}.json`);
		if (answer.ok) useWords(await answer.json());
	} catch {}
	try {
		const paintFrom = (tokens) => paint(document.documentElement, tokens);
		paintFrom(await api?.tokens() ?? {});
		api?.onTokens?.(paintFrom);
	} catch {}
	draw();
	startNews(api, director_default, say).catch((err) => api?.log(`the role's news was not shown — ${String(err)}`));
	api?.onTeamSettings?.((detail) => {
		if (!detail || typeof detail !== "object" || !Array.isArray(detail.controls)) return;
		settings = detail;
		const went = settle(settings);
		drawSettings();
		went.forEach(tellSaved);
	});
	if (typeof api?.teamSettings !== "function") {
		if (rows === null) rows = [];
		draw();
		return;
	}
	api.teamSettings().catch(() => {});
	setTimeout(() => {
		if (rows !== null) return;
		rows = [];
		draw();
	}, TEAM_WAIT_MS);
}
if (typeof window !== "undefined" && typeof document !== "undefined") {
	window.addEventListener("vobuda-plugin-team", (e) => {
		const detail = e.detail;
		rows = Array.isArray(detail) ? detail : [];
		draw();
	});
	window.addEventListener("vobuda-plugin-answer", (e) => {
		if (!heardAnswer(e.detail)) return;
		draw();
		setTimeout(draw, 8050);
	});
	document.addEventListener("change", (e) => {
		const el = e.target?.closest("#settings [data-key]");
		if (!el || el.tagName === "BUTTON") return;
		const value = readControl(el);
		const key = el.dataset.key;
		el.blur();
		if (value === null) {
			drawSettings();
			return tellSaved({
				key,
				ok: false,
				why: "the field takes a number"
			});
		}
		put(key, value);
	});
	document.addEventListener("keydown", (e) => {
		const el = e.target;
		if (e.key === "Enter" && el?.matches("#settings input[type='number']")) el.blur();
	});
	document.addEventListener("focusout", () => setTimeout(drawSettings, 0));
	document.addEventListener("click", (e) => {
		const toggle = e.target?.closest("#settings button[data-key]");
		if (toggle) {
			const c = settings?.controls.find((c) => c.key === toggle.dataset.key);
			if (c) put(c.key, !valueNow(c));
			toggle.blur();
			return;
		}
		if (e.target?.closest("[data-edit='role']")) {
			const api = surface();
			api?.editRole?.(director_default).catch((err) => api.log(`the role did not open — ${String(err)}`));
			return;
		}
		const acted = e.target?.closest("[data-act]");
		if (acted) {
			const api = surface();
			const act = acted.dataset.act;
			const block = Number(acted.dataset.block);
			if (api?.teamAct && (act === "merge" || act === "diff") && Number.isFinite(block)) api.teamAct(block, act).catch((err) => api.log(`${act} did not go — ${String(err)}`));
			return;
		}
		if (!e.target?.closest("[data-call='director']")) return;
		const api = surface();
		if (!api) return;
		if (rows === null) return;
		api.startAgent(nextName(rows, say("Director")), director_default).catch((err) => api.log(`the director did not start — ${String(err)}`));
	});
	start();
}
//#endregion
