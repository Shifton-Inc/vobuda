//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
/** A part with nothing said about it yet. */
function blankPart(id, note) {
	return {
		id,
		g: 0,
		t: id,
		s: "",
		d: "",
		f: [],
		note,
		broken: false,
		why: "",
		by: null,
		waits: false,
		waitsFor: "",
		changed: false,
		changedOn: "",
		changedLine: "",
		born: "",
		ver: "",
		kids: null,
		mem: []
	};
}
/** The links counted, and whether the map is a big one. */
function statsOf(level) {
	const by = {};
	for (const n of level.nodes) by[n.id] = n;
	const deg = {};
	for (const [a, b] of level.edges) {
		deg[a] = (deg[a] ?? 0) + 1;
		deg[b] = (deg[b] ?? 0) + 1;
	}
	const big = level.nodes.length > 60;
	return {
		by,
		deg,
		big,
		sc: big ? 2.6 : 1
	};
}
/** The parts a part is linked with, in the order the links were written. */
function neighbours(level, id) {
	const out = [];
	for (const [a, b] of level.edges) if (a === id && !out.includes(b)) out.push(b);
	else if (b === id && !out.includes(a)) out.push(a);
	return out;
}
/** The part a level opens on: the one most depends on. */
function firstPart(level, stats) {
	let best = null;
	for (const n of level.nodes) if (!best || (stats.deg[n.id] ?? 0) > (stats.deg[best.id] ?? 0)) best = n;
	return best ? best.id : null;
}
//#endregion
//#region plugins/map/notes.ts
var FENCE = /^---\s*$/;
/** A scalar as YAML writes it: quotes taken off, their escapes undone. */
function scalar(raw) {
	const v = raw.trim();
	if (v.length >= 2 && v.startsWith("\"") && v.endsWith("\"")) return v.slice(1, -1).replace(/\\(["\\n])/g, (_all, c) => c === "n" ? "\n" : c);
	if (v.length >= 2 && v.startsWith("'") && v.endsWith("'")) return v.slice(1, -1).replace(/''/g, "'");
	return v;
}
/** `[a, "b, c", d]` as its items; a comma inside quotes is not a separator. */
function inlineList(raw) {
	const inside = raw.trim().slice(1, -1);
	const items = [];
	let item = "";
	let quote = "";
	for (const c of inside) if (quote) {
		item += c;
		if (c === quote) quote = "";
	} else if (c === "\"" || c === "'") {
		quote = c;
		item += c;
	} else if (c === ",") {
		items.push(item);
		item = "";
	} else item += c;
	items.push(item);
	return items.map(scalar).filter((x) => x !== "");
}
/**
* Take a note apart: the front matter between two `---` lines, and the body after it.
*
* The subset of YAML a note needs and no more: `key: value`, a quoted value, a list written inline
* or one `- item` to a line, and a long value folded over indented lines (`>` or `|`). A file with
* no front matter is all body, and still a part — named by its file.
*/
function splitNote(text) {
	const lines = text.replace(/\r\n?/g, "\n").split("\n");
	if (!FENCE.test(lines[0] ?? "")) return {
		front: {},
		body: text.trim()
	};
	const end = lines.findIndex((l, i) => i > 0 && FENCE.test(l));
	if (end < 0) return {
		front: {},
		body: text.trim()
	};
	const front = {};
	let key = "";
	let folded = null;
	const close = () => {
		if (key && folded) front[key] = folded.join(" ").trim();
		folded = null;
	};
	for (const line of lines.slice(1, end)) {
		const item = /^\s*-\s+(.*)$/.exec(line);
		const pair = /^([A-Za-z_][\w-]*)\s*:\s*(.*)$/.exec(line);
		if (pair) {
			close();
			key = pair[1];
			const value = pair[2].trim();
			if (value === ">" || value === "|" || value === ">-" || value === "|-") folded = [];
			else if (value.startsWith("[") && value.endsWith("]")) front[key] = inlineList(value);
			else front[key] = scalar(value);
		} else if (item && key && !folded) {
			const had = front[key];
			front[key] = [...Array.isArray(had) ? had : [], scalar(item[1])];
		} else if (folded && /^\s+\S/.test(line)) folded.push(line.trim());
	}
	close();
	return {
		front,
		body: lines.slice(end + 1).join("\n").trim()
	};
}
var one$1 = (v) => (Array.isArray(v) ? v.join(", ") : v ?? "").trim();
var many = (v) => (Array.isArray(v) ? v : (v ?? "").split(",")).map((x) => x.trim()).filter((x) => x !== "");
/** A date as the notes write it: `2026-10-09`, optionally with ` 21:35`; anything after it is words. */
var DATED = /^(\d{4}-\d{2}-\d{2})(?:[ T](\d{2}:\d{2}))?\s*[—–:,-]?\s*(.*)$/s;
/** Whole days between two `YYYY-MM-DD` dates; NaN when either is not one. */
function daysBetween(from, to) {
	const at = (d) => Date.UTC(+d.slice(0, 4), +d.slice(5, 7) - 1, +d.slice(8, 10));
	if (!/^\d{4}-\d{2}-\d{2}/.test(from) || !/^\d{4}-\d{2}-\d{2}/.test(to)) return NaN;
	return Math.round((at(to) - at(from)) / 864e5);
}
/** Changed this week: within the seven days before `today`, and not in a future the clock denies. */
function thisWeek(on, today) {
	const days = daysBetween(on, today);
	return days >= 0 && days <= 7;
}
/** The slugs a body links to with `[[slug]]`, each once, in the order written. */
function linksIn(body) {
	const out = [];
	for (const m of body.matchAll(/\[\[([^\]|]+)(?:\|[^\]]*)?\]\]/g)) {
		const slug = m[1].trim();
		if (slug && !out.includes(slug)) out.push(slug);
	}
	return out;
}
/** A body as a person reads it: every `[[slug]]` said by the title of the part it names. */
function bodyText(body, titleOf) {
	return body.replace(/\[\[([^\]|]+)(?:\|([^\]]*))?\]\]/g, (_all, slug, label) => {
		return (label ?? "").trim() || titleOf(slug.trim()) || slug.trim();
	});
}
/**
* One note as a part.
*
* Broken is a fact or nothing (Gary's decision): `state: broken` counts only with `broken_by` saying
* who found it — a failing check, or the owner's own mark. A note that calls a part broken and
* names nobody is the agent's opinion, and an opinion is not a state.
*/
function readNote(path, text, today) {
	const { front, body } = splitNote(text);
	const slug = (path.split("/").pop() ?? path).replace(/\.md$/i, "");
	const part = blankPart(slug, path);
	part.t = one$1(front.title) || slug.replace(/[-_]+/g, " ");
	part.s = one$1(front.summary);
	part.d = body;
	part.f = many(front.files);
	part.mem = many(front.memory);
	const by = one$1(front.broken_by).toLowerCase();
	if (one$1(front.state).toLowerCase() === "broken" && (by === "check" || by === "person")) {
		part.broken = true;
		part.by = by;
		part.why = one$1(front.broken_why);
	}
	part.waitsFor = one$1(front.waits);
	part.waits = part.waitsFor !== "";
	const changed = DATED.exec(one$1(front.changed));
	if (changed) {
		part.changedOn = changed[1];
		part.changedLine = changed[3].trim();
		part.changed = thisWeek(changed[1], today);
	}
	const born = DATED.exec(one$1(front.born));
	if (born) part.born = born[2] ? `${born[1]} ${born[2]}` : born[1];
	return {
		part,
		group: one$1(front.group),
		links: linksIn(body)
	};
}
/** A value as one line of front matter: quoted whenever YAML would read it as something else. */
function written$1(value) {
	const flat = value.replace(/\s+/g, " ").trim();
	return /^[\w\u0400-\u04FF][^:#"'\[\]{}|>]*$/.test(flat) && !/\s$/.test(flat) ? flat : `"${flat.replace(/\\/g, "\\\\").replace(/"/g, "\\\"")}"`;
}
function linesOf(text) {
	const cut = text.split(/(\r\n|\n)/);
	const out = [];
	for (let i = 0; i < cut.length; i += 2) out.push({
		s: cut[i],
		e: cut[i + 1] ?? ""
	});
	return out;
}
var textOf = (lines) => lines.map((l) => l.s + l.e).join("");
/** Where the front matter closes; -1 when the note has none. */
var frontEnd = (lines) => FENCE.test(lines[0]?.s ?? "") ? lines.findIndex((l, i) => i > 0 && FENCE.test(l.s)) : -1;
/** The lines a key takes: its own, and the indented ones or the items of its list under it. */
function span(lines, end, key) {
	const at = lines.findIndex((l, i) => i > 0 && i < end && new RegExp(`^${key}\\s*:`).test(l.s));
	if (at < 0) return null;
	let last = at;
	while (last + 1 < end && /^(\s+\S|\s*-\s)/.test(lines[last + 1].s)) last += 1;
	return [at, last];
}
/** `setFront` on lines, in place. Answers where the front matter closes now. */
function setKeys(lines, changes) {
	const eol = lines.find((l) => l.e !== "")?.e ?? "\n";
	let end = frontEnd(lines);
	if (end < 0) {
		lines.unshift({
			s: "---",
			e: eol
		}, {
			s: "---",
			e: eol
		});
		end = 1;
	}
	for (const [key, value] of Object.entries(changes)) {
		const had = span(lines, end, key);
		if (!had) {
			if (value === null) continue;
			lines.splice(end, 0, {
				s: `${key}: ${written$1(value)}`,
				e: eol
			});
			end += 1;
			continue;
		}
		const put = value === null ? [] : [{
			s: `${key}: ${written$1(value)}`,
			e: lines[had[0]].e || eol
		}];
		lines.splice(had[0], had[1] - had[0] + 1, ...put);
		end += put.length - (had[1] - had[0] + 1);
	}
	return end;
}
/** The three keys the owner's mark is written in. */
var MARK_KEYS = [
	"state",
	"broken_by",
	"broken_why"
];
/**
* What the note said in those keys before the mark, kept beside the mark as a comment: "It works
* again" gives the note back byte for byte, and the note itself is the only place that is still
* there on another machine (FM-MAP-30).
*/
var BEFORE = "# before the owner's mark: ";
function dropBefore(lines) {
	const end = frontEnd(lines);
	const at = lines.findIndex((l, i) => i > 0 && i < end && l.s.startsWith(BEFORE));
	if (at < 0) return null;
	const [line] = lines.splice(at, 1);
	try {
		const value = JSON.parse(line.s.slice(27));
		return value && typeof value === "object" && !Array.isArray(value) ? value : {};
	} catch {
		return null;
	}
}
/** The owner's own mark, set: broken, by a person, and why in their words. */
function markBroken(text, why) {
	const lines = linesOf(text);
	const old = dropBefore(lines);
	const was = frontEnd(lines);
	const value = (key) => {
		const had = was < 0 ? null : span(lines, was, key);
		return had ? scalar(lines[had[0]].s.slice(lines[had[0]].s.indexOf(":") + 1)).toLowerCase() : "";
	};
	let before = {};
	if (old && value("state") === "broken" && value("broken_by") === "person") before = old;
	else {
		if (was < 0) before.bare = true;
		for (const key of MARK_KEYS) {
			const had = was < 0 ? null : span(lines, was, key);
			if (had) before[key] = lines.slice(had[0], had[1] + 1).map((l) => l.s + l.e);
		}
	}
	const state = span(lines, setKeys(lines, {
		state: "broken",
		broken_by: "person",
		broken_why: why.trim() || null
	}), "state");
	lines.splice(state[1] + 1, 0, {
		s: BEFORE + JSON.stringify(before),
		e: lines[state[0]].e || "\n"
	});
	return textOf(lines);
}
/**
* The owner's own mark, cleared: the note is what it was before the mark, byte for byte — also
* when it had no `state:` line, or no front matter (FM-MAP-30). A check's verdict is the agent's
* to clear, not the panel's.
*/
function clearBroken(text) {
	const lines = linesOf(text);
	const before = dropBefore(lines);
	if (!before) {
		setKeys(lines, {
			state: "ok",
			broken_by: null,
			broken_why: null
		});
		return textOf(lines);
	}
	let end = frontEnd(lines);
	for (const key of MARK_KEYS) {
		const now = span(lines, end, key);
		if (!now) continue;
		const put = (before[key] ?? []).flatMap((raw) => linesOf(String(raw)).filter((l) => l.s !== "" || l.e !== ""));
		lines.splice(now[0], now[1] - now[0] + 1, ...put);
		end += put.length - (now[1] - now[0] + 1);
	}
	if (before.bare && end === 1) lines.splice(0, 2);
	return textOf(lines);
}
//#endregion
//#region plugins/map/levels.ts
/** Where a project's map is kept, relative to the project. */
var MAP_FOLDER = "project-notes/map";
/** The note that names the project and the order of its groups. */
var MAP_NOTE = "_map.md";
/** The top level's key. */
var ROOT = "root";
/** The folder a level's notes are in. */
function folderOf(key) {
	return key === "root" ? MAP_FOLDER : `${MAP_FOLDER}/${key}`;
}
/** The level a part's inside is: its folder below the map's. */
function insideKey(level, slug) {
	return level === "root" ? slug : `${level}/${slug}`;
}
/** The level a level was entered from; none for the top. */
function parentKey(key) {
	if (key === "root") return null;
	const at = key.lastIndexOf("/");
	return at < 0 ? ROOT : key.slice(0, at);
}
/** The way back: every level from the top down to this one. */
function trail(key) {
	const out = [];
	for (let k = key; k; k = parentKey(k)) out.unshift(k);
	return out;
}
/** Whether a name in a map folder is a part's note: Markdown, and not one of the map's own files. */
function isPartNote(name) {
	return /\.md$/i.test(name) && !name.startsWith("_") && !name.startsWith(".");
}
/** Whether a name could be the folder of a part's inside. */
function mayBeInside(name) {
	return !name.includes(".") && !name.startsWith("_");
}
/**
* One level, from one folder as it was read.
*
* Groups come in the order `_map.md` gives them, then any group a note names that the list does
* not, in the order the notes come; a note that names none stands in the last group, called by
* `ungrouped`. Parts are in file-name order within a group, so a map drawn twice is the same map.
* A link is `[[slug]]` in a note's body, kept only where that slug is a part of this level: the
* notes are an agent's, and a link to something that is not there draws nothing rather than a
* line into the corner.
*/
function buildLevel(key, read, opts) {
	const map = read.map ? splitNote(read.map).front : {};
	const groups = (Array.isArray(map.groups) ? map.groups : []).map((g) => g.trim()).filter((g) => g !== "");
	const folder = folderOf(key);
	const reads = read.notes.filter((n) => isPartNote(n.name)).sort((a, b) => a.name.localeCompare(b.name)).map((n) => readNote(`${folder}/${n.name}`, n.text, opts.today));
	let loose = false;
	for (const r of reads) if (r.group === "") loose = true;
	else if (!groups.includes(r.group)) groups.push(r.group);
	if (loose && !groups.includes(opts.ungrouped)) groups.push(opts.ungrouped);
	const inside = new Set(read.insides);
	const nodes = reads.map((r) => {
		r.part.g = Math.max(0, groups.indexOf(r.group === "" ? opts.ungrouped : r.group));
		r.part.kids = inside.has(r.part.id) ? insideKey(key, r.part.id) : null;
		return r.part;
	});
	nodes.sort((a, b) => a.g - b.g || a.id.localeCompare(b.id));
	const ids = new Set(nodes.map((n) => n.id));
	const edges = [];
	const seen = /* @__PURE__ */ new Set();
	for (const r of reads) for (const to of r.links) {
		const from = r.part.id;
		if (to === from || !ids.has(to)) continue;
		const pair = from < to ? `${from}\n${to}` : `${to}\n${from}`;
		if (seen.has(pair)) continue;
		seen.add(pair);
		edges.push([from, to]);
	}
	return {
		key,
		title: (typeof map.title === "string" ? map.title.trim() : "") || opts.title,
		kind: "project",
		parent: parentKey(key),
		folder,
		frames: groups.map((t) => ({ t })),
		nodes,
		edges
	};
}
var en_default = {
	"File: {0}.": "File: {0}.",
	"Note: {0}.": "Note: {0}.",
	"Files: {0}.": "Files: {0}.",
	"Tell me more about the part «{0}»: how it works and what is wrong with it.": "Tell me more about the part «{0}»: how it works and what is wrong with it.",
	"I want to change the part «{0}»: {1}": "I want to change the part «{0}»: {1}",
	"Fix the part «{0}».": "Fix the part «{0}».",
	"What is broken: {0}": "What is broken: {0}",
	"When it works again, update its note.": "When it works again, update its note.",
	"The parts {0}: {1}": "The parts {0}: {1}",
	"What do you remember from the memory note «{0}», and where did you apply it?": "What do you remember from the memory note «{0}», and where did you apply it?",
	"Check the memory note «{0}» and tell me whether it is still true.": "Check the memory note «{0}» and tell me whether it is still true.",
	"Correct the memory note «{0}»: {1}": "Correct the memory note «{0}»: {1}",
	"Forget the memory note «{0}».": "Forget the memory note «{0}».",
	"Broken link": "Broken link",
	"Not checked for a long time": "Not checked for a long time",
	"In force": "In force",
	Broken: "Broken",
	"Waiting for your word": "Waiting for your word",
	Works: "Works",
	"What to change": "What to change",
	"For example: make it run once an hour": "For example: make it run once an hour",
	"Give the task to the agent": "Give the task to the agent",
	"What is broken": "What is broken",
	"In your own words: what does not work": "In your own words: what does not work",
	"Mark as broken": "Mark as broken",
	"What to correct": "What to correct",
	"For example: this has not been true since October": "For example: this has not been true since October",
	"Forget this note?": "Forget this note?",
	Forget: "Forget",
	"The agent will delete this memory note.": "The agent will delete this memory note.",
	Cancel: "Cancel",
	"Parts chosen: {0}": "Parts chosen: {0}",
	"One task for all of them": "One task for all of them",
	"What to do with them": "What to do with them",
	"For example: check that they agree with each other": "For example: check that they agree with each other",
	"Clear the choice": "Clear the choice",
	"About this project": "About this project",
	"What the agent remembers": "What the agent remembers",
	"about the project as a whole: {0}": "about the project as a whole: {0}",
	"Go inside": "Go inside",
	"Ask to fix it": "Ask to fix it",
	"Ask the agent": "Ask the agent",
	"Change this part": "Change this part",
	"It works again": "It works again",
	"Check whether it is still true": "Check whether it is still true",
	"Correct the note": "Correct the note",
	"A check of the project fails.": "A check of the project fails.",
	"You marked it yourself.": "You marked it yourself.",
	"Linked with": "Linked with",
	Appeared: "Appeared",
	Checked: "Checked",
	File: "File",
	Note: "Note",
	Graph: "Graph",
	Blueprint: "Blueprint",
	Space: "Space",
	Bubbles: "Bubbles",
	History: "History",
	Globe: "Globe",
	City: "City",
	"All the memory": "All the memory",
	"Broken links": "Broken links",
	"New this week": "New this week",
	"Not checked for long": "Not checked for long",
	"Changed this week": "Changed this week",
	Project: "Project",
	Memory: "Memory",
	"Only about {0}": "Only about {0}",
	"Waiting for your answer: {0}": "Waiting for your answer: {0}",
	"Working here now: {0}": "Working here now: {0}",
	"{0}, {1} min · {2}": "{0}, {1} min · {2}",
	"Asked the agent. Its answer is in its block.": "Asked the agent. Its answer is in its block.",
	"The question did not go: {0}": "The question did not go: {0}",
	Other: "Other",
	"The mark was not written: {0}": "The mark was not written: {0}",
	"Lay out again": "Lay out again",
	"Choose several": "Choose several",
	"Who is working where": "Who is working where",
	"The agent asks you something in its block. Answer it there, and your request goes on.": "The agent asks you something in its block. Answer it there, and your request goes on.",
	"The agent closed before it was asked. Press again.": "The agent closed before it was asked. Press again.",
	"This tab is asleep. Wake it from the tab strip, then press again.": "This tab is asleep. Wake it from the tab strip, then press again.",
	"{0} and {1} more": "{0} and {1} more",
	"Step {0}": "Step {0}",
	"{0} of {1}": "{0} of {1}",
	"several parts appeared: {0}": "appeared: {0}",
	"one part appeared: {0}": "appeared: {0}",
	Pause: "Pause",
	Play: "Play",
	"Files: {0}, and {1} more.": "Files: {0}, and {1} more.",
	"Where they are: {0}.": "Where they are: {0}.",
	"the task is written in {0}, read it first.": "the task is written in {0}, read it first.",
	"The task is too long to send, and it could not be written into the project: {0}": "The task is too long to send, and it could not be written into the project: {0}",
	"Too many parts for one task. Choose fewer.": "Too many parts for one task. Choose fewer.",
	"A worktree: its history is kept outside this folder, where the map cannot read.": "A worktree: its history is kept outside this folder, where the map cannot read.",
	"About the person": "About the person",
	"An empty folder, or one not looked into": "An empty folder, or one not looked into",
	"Choose a folder": "Choose a folder",
	"Close the text": "Close the text",
	Code: "Code",
	Data: "Data",
	Documents: "Documents",
	"Files here": "Files here",
	"Folder: {0}.": "Folder: {0}.",
	Folders: "Folders",
	"Folders inside: {0}, and {1} more.": "Folders inside: {0}, and {1} more.",
	"Folders inside: {0}.": "Folders inside: {0}.",
	"How to work": "How to work",
	"It is larger than the map reads at once: not all of it was looked into.": "It is larger than the map reads at once: not all of it was looked into.",
	"It keeps a history of its own.": "It keeps a history of its own.",
	"Its files differ from what the map read the time before.": "Its files differ from what the map read the time before.",
	"Last commit: {0} — {1}": "Last commit: {0} — {1}",
	"No dates of birth can be read in this folder. Shown: the commits that could be read, and what the map itself has seen since {0}.": "No dates of birth can be read in this folder. Shown: the commits that could be read, and what the map itself has seen since {0}.",
	"No history can be read in this folder.": "No history can be read in this folder.",
	"No memory notes are in this folder": "No memory notes are in this folder",
	"Nothing to draw in this folder": "Nothing to draw in this folder",
	"Open the map in the folder that holds the memory, or choose it, and the notes are drawn by themselves.": "Open the map in the folder that holds the memory, or choose it, and the notes are drawn by themselves.",
	"Other notes": "Other notes",
	"Pictures and media": "Pictures and media",
	Projects: "Projects",
	"Projects and work in hand": "Projects and work in hand",
	"Read it here": "Read it here",
	"Read: {0} lines of text in {1} files.": "Read: {0} lines of text in {1} files.",
	"Reading the files… {0} of {1}": "Reading the files… {0} of {1}",
	"Reading the folders… {0} of {1}": "Reading the folders… {0} of {1}",
	"Reading the folder…": "Reading the folder…",
	"Reading the memory notes… {0} of {1}": "Reading the memory notes… {0} of {1}",
	"Site pages": "Site pages",
	"That folder could not be opened: {0}": "That folder could not be opened: {0}",
	"The first of them: {0}, and {1} more.": "The first of them: {0}, and {1} more.",
	"The last recorded run of its checks failed: {0} of them. The record: {1}.": "The last recorded run of its checks failed: {0} of them. The record: {1}.",
	"The map found no folders and no files of yours here. What is hidden, fetched or built — names with a dot in front, packages, build outputs — is passed by.": "The map found no folders and no files of yours here. What is hidden, fetched or built — names with a dot in front, packages, build outputs — is passed by.",
	"The map needs a folder": "The map needs a folder",
	"The map reads memory notes straight from the folder it is opened in. What an agent remembers elsewhere on this machine cannot be seen from here: a panel reads only its own folder.": "The map reads memory notes straight from the folder it is opened in. What an agent remembers elsewhere on this machine cannot be seen from here: a panel reads only its own folder.",
	"The text could not be read.": "The text could not be read.",
	"This folder is larger than the map reads at once: its top is drawn whole, its depths as far as the reading got.": "This folder is larger than the map reads at once: its top is drawn whole, its depths as far as the reading got.",
	"Where it is": "Where it is",
	"Where things are": "Where things are",
	"about {0} min left": "about {0} min left",
	code: "code",
	"commits: {0} — {1}": "commits: {0} — {1}",
	data: "data",
	documents: "documents",
	"first seen by the map: {0}": "first seen by the map: {0}",
	"media and archives": "media and archives",
	"other files": "other files",
	pictures: "pictures",
	"site pages": "site pages",
	"the map first read this folder: {0} parts": "the map first read this folder: {0} parts",
	"Files of one kind, directly in this folder: {0}": "Files of one kind, directly in this folder: {0}",
	"Files: {0}, mostly {1}": "Files: {0}, mostly {1}",
	"Files: {0} — {1}": "Files: {0} — {1}",
	"{0}: {1} of them": "{0}: {1} of them",
	"{0} — lines: {1}": "{0} — lines: {1}",
	"The folder you are in": "The folder you are in",
	"less than a minute left": "less than a minute left",
	"about a minute left": "about a minute left",
	"About the part «{0}»: {1}": "About the part «{0}»: {1}",
	All: "All",
	"Another folder": "Another folder",
	"Another folder…": "Another folder…",
	"Answer the agent": "Answer the agent",
	"Back to the list": "Back to the list",
	Changed: "Changed",
	"Choose another folder": "Choose another folder",
	Done: "Done",
	"Find a part": "Find a part",
	"For example: yes, but only until noon": "For example: yes, but only until noon",
	"I'll show what it is made of, what is broken and what waits for you. I change nothing and ask nobody.": "I'll show what it is made of, what is broken and what waits for you. I change nothing and ask nobody.",
	Menu: "Menu",
	More: "More",
	"Nothing here, which is good.": "Nothing here, which is good.",
	"Press parts on the map.": "Press parts on the map.",
	"The map is drawn already; the links come when the reading ends.": "The map is drawn already; the links come when the reading ends.",
	"This answers: {0}": "This answers: {0}",
	"Try again": "Try again",
	"The folder is empty or vobuda has no access to it": "The folder is empty or vobuda has no access to it",
	"Update its note when it no longer waits.": "Update its note when it no longer waits.",
	"What is wrong": "What is wrong",
	When: "When",
	"Your answer": "Your answer",
	"Your decision is needed": "Your decision is needed",
	"changed {0}": "changed {0}",
	"checked {0}": "checked {0}",
	"for example the one that holds all your projects": "for example the one that holds all your projects",
	"forget where you moved the parts in this view": "forget where you moved the parts in this view",
	"macOS asks once. If the answer was no, allow vobuda in System Settings → Privacy & Security → Files and Folders, then try again.": "macOS asks once. If the answer was no, allow vobuda in System Settings → Privacy & Security → Files and Folders, then try again.",
	"one task to the agent for all of them": "one task to the agent for all of them",
	"or open the map in a tab whose terminal stands in the folder": "or open the map in a tab whose terminal stands in the folder",
	"say it in words; the agent does it": "say it in words; the agent does it",
	"say what is true now": "say what is true now",
	"take your mark away": "take your mark away",
	"the agent deletes the note": "the agent deletes the note",
	"until you say it works": "until you say it works",
	"Open the map in a tab whose terminal stands in the folder.": "Open the map in a tab whose terminal stands in the folder."
};
//#endregion
//#region plugins/map/words.ts
/** The table in force. English is the keys. */
var words = en_default;
/** The language in use, for dates and for a fault report. */
var using = "en";
/** Take a dictionary, dropping anything that is not a sentence. */
function useWords(code, table) {
	using = code;
	words = {};
	if (!table || typeof table !== "object") return;
	for (const [key, value] of Object.entries(table)) if (typeof value === "string" && value !== "") words[key] = value;
}
/** One sentence, translated if there is a translation and English if not. */
function say(key) {
	return words[key] ?? key;
}
/**
* A sentence with something of the person's own in it. The blanks are numbered, so a translator
* moves them where their language wants them.
*/
function saying(key, ...parts) {
	return say(key).replace(/\{(\d)\}/g, (whole, at) => {
		const part = parts[Number(at)];
		return part === void 0 ? whole : String(part);
	});
}
/** Fetch the dictionary for a language; one we do not carry leaves English in force. */
async function loadWords(code, get = fetch) {
	const wanted = code.split(/[-_]/)[0] || "en";
	if (wanted !== "en") try {
		const answer = await get(`./words/${wanted}.json`);
		if (!answer.ok) throw new Error(String(answer.status));
		useWords(wanted, await answer.json());
		return;
	} catch {}
	useWords("en", en_default);
}
/** Text as HTML text, whatever a note called its part. */
var plain = (text) => text.replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
/** `2026-10-07` or `2026-10-07 20:58` as its numbers; null for anything else. */
function parts$1(stamp) {
	const m = /^(\d{4})-(\d{2})-(\d{2})(?:[ T](\d{2}:\d{2}))?/.exec(stamp);
	return m ? {
		y: +m[1],
		m: +m[2],
		d: +m[3],
		time: m[4] ?? ""
	} : null;
}
/** A date drawn in the language in force; the note's own text when it is not a date. */
function dated(stamp, form) {
	const p = parts$1(stamp);
	if (!p) return stamp;
	let day;
	try {
		day = new Intl.DateTimeFormat(using, {
			...form,
			timeZone: "UTC"
		}).format(Date.UTC(p.y, p.m - 1, p.d));
	} catch {
		day = stamp.slice(0, 10);
	}
	return p.time ? `${day}, ${p.time}` : day;
}
/** "7 October, 20:58": the day a part appeared, on the history's caption. */
var dayAndMonth = (stamp) => dated(stamp, {
	day: "numeric",
	month: "long"
});
/** "7 Oct 2026, 20:58": a date in the card. */
var fullDay = (stamp) => dated(stamp, {
	day: "numeric",
	month: "short",
	year: "numeric"
});
/** Today as the notes write a date, by the person's own clock. */
function today(now = /* @__PURE__ */ new Date()) {
	const two = (n) => String(n).padStart(2, "0");
	return `${now.getFullYear()}-${two(now.getMonth() + 1)}-${two(now.getDate())}`;
}
/** Where a long task is written for the agent to read. */
var TASK_FILE = `${MAP_FOLDER}/_task.md`;
/** A text on one line, cut to `most` letters with an ellipsis. */
function cut(text, most) {
	const flat = text.replace(/\s+/g, " ").trim();
	return flat.length <= most ? flat : `${flat.slice(0, Math.max(1, most - 1)).trimEnd()}…`;
}
/** The person's words as a sentence: with a full stop when they left none. */
var ended = (words) => {
	const flat = words.replace(/\s+/g, " ").trim();
	return flat === "" || /[.!?…]$/.test(flat) ? flat : `${flat}.`;
};
/** A part's name as a request says it. */
var named$1 = (n, most = 60) => cut(n.t, most);
/** As many of the files as fit in `most` letters, and how many were left out. */
function someFiles(files, most) {
	const taken = [];
	for (const f of files) {
		if ([...taken, f].join(", ").length > most) break;
		taken.push(f);
	}
	if (!taken.length) return "";
	const left = files.length - taken.length;
	return left ? saying("Files: {0}, and {1} more.", taken.join(", "), left) : saying("Files: {0}.", taken.join(", "));
}
/** The note that names a part in plain words, where the project has one. */
var noteOf = (n, memory = false) => n.about ?? (!memory && !n.is ? n.note : "");
/** Where a part is described and what it is made of, said after the request. */
function about(n, memory) {
	const tail = [];
	const note = noteOf(n, memory);
	if (note) tail.push(saying("Note: {0}.", note));
	else if (n.note) tail.push(n.is === "folder" ? saying("Folder: {0}.", n.note) : saying("File: {0}.", n.note));
	if (!memory && n.is !== "file") tail.push(someFiles(n.f, 120));
	return tail.filter(Boolean).join(" ");
}
var joined = (...parts) => parts.filter((p) => p.trim() !== "").join(" ");
/** Whether a request is short enough to go. */
var fits = (text) => text.length <= 600 && !/[\r\n]/.test(text);
/** A request on one line and never longer than a request may be. */
var short = (text) => cut(text, 600);
/** Tell me about this part. */
function askAbout(n) {
	return short(joined(saying("Tell me more about the part «{0}»: how it works and what is wrong with it.", named$1(n)), about(n, false)));
}
/** Change this part, in the person's own words. Not cut: the panel sends it only when it `fits`. */
function askChange(n, words) {
	return joined(saying("I want to change the part «{0}»: {1}", named$1(n), ended(words)), about(n, false));
}
/** Fix a broken part: what is known to be broken goes with the request. */
function askFix(n) {
	return short(joined(saying("Fix the part «{0}».", named$1(n)), n.why ? saying("What is broken: {0}", ended(cut(n.why, 200))) : "", about(n, false), noteOf(n) ? say("When it works again, update its note.") : ""));
}
/**
* The owner's answer to what a part waits for: the question goes with it, so the agent knows what
* is answered. Not cut: the panel sends it only when it `fits` (FM-MAP-83).
*/
function askAnswer(n, words) {
	const said = (question) => joined(saying("About the part «{0}»: {1}", named$1(n), ended(words)), question, about(n, false), noteOf(n) ? say("Update its note when it no longer waits.") : "");
	const asked = (most) => n.waitsFor ? saying("This answers: {0}", ended(cut(n.waitsFor.replace(/\s+/g, " ").trim(), most))) : "";
	const whole = said(asked(200));
	return fits(whole) ? whole : said(asked(80));
}
/** One task for several chosen parts. Not cut: the panel sends it only when it `fits`. */
function askSeveral(parts, task) {
	return joined(saying("The parts {0}: {1}", parts.map((n) => `«${named$1(n, 40)}»`).join(", "), ended(task)), saying("Where they are: {0}.", parts.map((n) => noteOf(n) || n.note).join(", ")));
}
/** What stands in a request for words too long to go in it: where they were written. */
function wordsInFile() {
	return saying("the task is written in {0}, read it first.", TASK_FILE);
}
/**
* A request with the person's own words in it, made to fit. Words too long for a request are
* written into the project and the request names the file; a request still too long does not go,
* and `why` says so in the person's language.
*/
async function within(door, words, make) {
	let text = make(words);
	if (!fits(text)) {
		try {
			await door.writeSource(TASK_FILE, `${words.trim()}\n`);
		} catch (err) {
			return { why: saying("The task is too long to send, and it could not be written into the project: {0}", String(err)) };
		}
		text = make(wordsInFile());
	}
	return fits(text) ? { text } : { why: say("Too many parts for one task. Choose fewer.") };
}
/** A memory note: what do you remember, and where did you use it. */
function askMemory(n) {
	return short(joined(saying("What do you remember from the memory note «{0}», and where did you apply it?", named$1(n)), about(n, true)));
}
/** A memory note nobody has checked for a long time: is it still true. */
function askMemoryCheck(n) {
	return short(joined(saying("Check the memory note «{0}» and tell me whether it is still true.", named$1(n)), about(n, true)));
}
/** Correct a memory note, in the person's own words. Not cut: the panel sends it only when it `fits`. */
function askMemoryCorrect(n, words) {
	return joined(saying("Correct the memory note «{0}»: {1}", named$1(n), ended(words)), about(n, true));
}
/** Forget a memory note. */
function askMemoryForget(n) {
	return short(joined(saying("Forget the memory note «{0}».", named$1(n)), about(n, true)));
}
//#endregion
//#region plugins/map/icons.ts
var PATHS = {
	search: "<circle cx=\"7\" cy=\"7\" r=\"4.5\"/><path d=\"M10.5 10.5 14 14\"/>",
	more: "<circle cx=\"3.5\" cy=\"8\" r=\"1.1\"/><circle cx=\"8\" cy=\"8\" r=\"1.1\"/><circle cx=\"12.5\" cy=\"8\" r=\"1.1\"/>",
	x: "<path d=\"M4 4l8 8M12 4l-8 8\"/>",
	chev: "<path d=\"M6 3.5 10.5 8 6 12.5\"/>",
	bad: "<circle cx=\"8\" cy=\"8\" r=\"6.2\"/><path d=\"M5.6 5.6l4.8 4.8M10.4 5.6l-4.8 4.8\"/>",
	info: "<circle cx=\"8\" cy=\"8\" r=\"6.2\"/><path d=\"M8 7.2v4M8 4.8v.2\"/>",
	agent: "<rect x=\"2.5\" y=\"4\" width=\"11\" height=\"8.5\" rx=\"2.2\"/><path d=\"M8 4V2M5.8 8.2v.3M10.2 8.2v.3M6 10.6h4\"/>",
	enter: "<path d=\"M6 3H12.2c.5 0 .8.3.8.8v8.4c0 .5-.3.8-.8.8H6M2.5 8h7M7 5.5 9.5 8 7 10.5\"/>",
	pick: "<rect x=\"2\" y=\"2\" width=\"5\" height=\"5\" rx=\"1.2\"/><rect x=\"9\" y=\"2\" width=\"5\" height=\"5\" rx=\"1.2\"/><rect x=\"2\" y=\"9\" width=\"5\" height=\"5\" rx=\"1.2\"/><path d=\"M9.5 11.5l1.5 1.5 3-3.2\"/>",
	relay: "<path d=\"M2.5 8a5.5 5.5 0 0 1 9.6-3.6M13.5 8a5.5 5.5 0 0 1-9.6 3.6M12.6 2v2.8H9.8M3.4 14v-2.8h2.8\"/>",
	mem: "<path d=\"M8 2.5c-2.6 0-4.5 1.8-4.5 4 0 1.4.7 2.4 1.6 3.1V12c0 .8.6 1.5 1.5 1.5h2.8c.9 0 1.5-.7 1.5-1.5V9.6c.9-.7 1.6-1.7 1.6-3.1 0-2.2-1.9-4-4.5-4z\"/><path d=\"M6.5 13.5v.8M9.5 13.5v.8\"/>",
	folder: "<path d=\"M2 4.5c0-.6.4-1 1-1h3.2l1.5 1.6H13c.6 0 1 .4 1 1V12c0 .6-.4 1-1 1H3c-.6 0-1-.4-1-1z\"/>",
	flag: "<path d=\"M3.5 14V2.5M3.5 3h8l-1.8 3 1.8 3h-8\"/>",
	edit: "<path d=\"M10.5 2.8l2.7 2.7-7.4 7.4H3.1v-2.7z\"/>",
	book: "<path d=\"M2.5 3.2C4.5 2.6 6.5 2.8 8 4c1.5-1.2 3.5-1.4 5.5-.8v9.6c-2-.6-4-.4-5.5.8-1.5-1.2-3.5-1.4-5.5-.8z\"/><path d=\"M8 4v9.6\"/>",
	check: "<path d=\"M3 8.5 6.4 12 13 4.5\"/>",
	graph: "<circle cx=\"4\" cy=\"4.5\" r=\"1.8\"/><circle cx=\"12\" cy=\"4\" r=\"1.8\"/><circle cx=\"8\" cy=\"12\" r=\"1.8\"/><path d=\"M5.6 5.4 7 10.5M10.6 5.2 8.9 10.4M5.8 4.4h4.4\"/>",
	blueprint: "<rect x=\"2\" y=\"2.5\" width=\"5\" height=\"4\" rx=\".8\"/><rect x=\"9\" y=\"2.5\" width=\"5\" height=\"4\" rx=\".8\"/><rect x=\"5.5\" y=\"9.5\" width=\"5\" height=\"4\" rx=\".8\"/><path d=\"M4.5 6.5V8h7V6.5M8 8v1.5\"/>",
	space: "<circle cx=\"8\" cy=\"8\" r=\"2.2\"/><ellipse cx=\"8\" cy=\"8\" rx=\"6.3\" ry=\"2.6\" transform=\"rotate(-24 8 8)\"/><circle cx=\"13.2\" cy=\"5.6\" r=\".9\"/>",
	bubbles: "<circle cx=\"6\" cy=\"9\" r=\"4\"/><circle cx=\"11.6\" cy=\"5.4\" r=\"2.6\"/><circle cx=\"12\" cy=\"11.6\" r=\"1.6\"/>",
	history: "<path d=\"M2 12.5h12\"/><circle cx=\"4\" cy=\"9\" r=\"1.3\"/><circle cx=\"8\" cy=\"6\" r=\"1.3\"/><circle cx=\"12\" cy=\"8\" r=\"1.3\"/><path d=\"M4 12.5v-2.2M8 12.5V7.3M12 12.5V9.3\"/>",
	globe: "<circle cx=\"8\" cy=\"8\" r=\"6.2\"/><path d=\"M1.8 8h12.4M8 1.8a9 9 0 0 1 0 12.4M8 1.8a9 9 0 0 0 0 12.4M3 4.4h10M3 11.6h10\"/>",
	city: "<path d=\"M2 14V7.5l3-2 3 2V14M8 14V4l3-2 3 2v10M1.5 14h13M4 9.5h2M10 6.5h2M10 9.5h2\"/>"
};
/** An icon as markup: hidden from a screen reader, which reads the word beside it. */
var icon = (name) => `<svg class="i" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${PATHS[name]}</svg>`;
//#endregion
//#region plugins/map/bar.ts
var byId$1 = (id) => document.getElementById(id);
/** A menu opened by its button, or closed if it was open; every other menu closes. */
function toggleMenu(menu, button) {
	if (!menu) return;
	const open = menu.hidden;
	closeMenus();
	menu.hidden = !open;
	button?.setAttribute("aria-expanded", String(open));
}
/** Every open menu closed. Answers whether one was open. */
function closeMenus() {
	let was = false;
	for (const menu of document.querySelectorAll(".menu")) {
		if (!menu.hidden) was = true;
		menu.hidden = true;
	}
	for (const b of document.querySelectorAll("[aria-expanded=\"true\"]")) b.setAttribute("aria-expanded", "false");
	return was;
}
/** The words on the bar, its menu and the "choose several" chip, in the window's language. */
function barWords(canChoose) {
	const line = (id, ic, word, hint) => byId$1(id).innerHTML = `${icon(ic)}<span>${plain(word)}</span> <small>${plain(hint)}</small>`;
	line("choose", "folder", say("Another folder…"), say("for example the one that holds all your projects"));
	byId$1("choose").hidden = !canChoose;
	line("relay", "relay", say("Lay out again"), say("forget where you moved the parts in this view"));
	line("several", "pick", say("Choose several"), say("one task to the agent for all of them"));
	byId$1("multi").innerHTML = `${icon("pick")}<span>${plain(say("Choose several"))}</span>`;
	byId$1("q").placeholder = say("Find a part");
	byId$1("q").setAttribute("aria-label", say("Find a part"));
	byId$1("menubtn").setAttribute("aria-label", say("Menu"));
	byId$1("menubtn").title = say("Menu");
	byId$1("crew").setAttribute("aria-label", say("Who is working where"));
}
var told = "";
var until = 0;
var past$1 = "";
/** A line over the map for a few seconds: what was just asked, or why it did not go. */
function tell(line, ms = 9e3) {
	told = line;
	until = Date.now() + ms;
	status();
	setTimeout(status, ms + 50);
}
/** The line told, while it lasts; and, when given, what could be read of the folder's history, in the menu. */
function status(history) {
	if (history !== void 0) past$1 = history;
	const tag = byId$1("status");
	tag.textContent = Date.now() < until ? told : "";
	tag.hidden = tag.textContent === "";
	byId$1("past").textContent = past$1;
	byId$1("past").hidden = past$1 === "";
}
/** The bar's presses, its menus closed by a press elsewhere, its keys, and the window's answers. */
function wireBar(page, hands) {
	byId$1("menubtn").addEventListener("click", () => toggleMenu(byId$1("menu"), byId$1("menubtn")));
	for (const [id, go] of [
		["choose", hands.choose],
		["relay", hands.relay],
		["several", hands.several]
	]) byId$1(id).addEventListener("click", () => {
		closeMenus();
		go();
	});
	page.on(document, "pointerdown", (e) => {
		if (!e.target?.closest?.(".menu, #menubtn, [data-act=\"more\"]")) closeMenus();
	});
	page.on(window, "keydown", (e) => {
		const typing = /^(TEXTAREA|INPUT)$/.test(document.activeElement?.tagName ?? "");
		if (e.key === "Escape") return void (closeMenus() || typing || hands.up());
		if ((e.key === "/" || e.code === "Slash") && !typing && !e.metaKey && !e.ctrlKey && !e.altKey) {
			e.preventDefault();
			byId$1("q").focus();
		}
	});
	page.on(window, "vobuda-plugin-answer", (e) => {
		const kind = e.detail?.kind;
		if (kind === "asks") tell(say("The agent asks you something in its block. Answer it there, and your request goes on."), 2e4);
		else if (kind === "left") tell(say("The agent closed before it was asked. Press again."), 15e3);
		else if (kind === "asleep") tell(say("This tab is asleep. Wake it from the tab strip, then press again."), 15e3);
	});
}
//#endregion
//#region plugins/map/door.ts
var surface = () => window.vobuda;
/**
* What a call to the window gave, or `or` when it has not answered in `ms`.
*
* The panel's first words wait for the window's language and colours. A window that never answers
* one of them must not leave a panel with no word and no button on it: the map is drawn in the
* words and colours it has, and the answer is used if it comes (FM-MAP-62).
*/
function soon(work, or, ms = 1500) {
	return Promise.race([(work ?? Promise.resolve(or)).catch(() => or), new Promise((done) => setTimeout(() => done(or), ms))]);
}
/**
* The folder is granted by the window a moment after the panel opens: asked for until it is there,
* or until the panel is `stopped`. `late` is called once after a few tries — a panel that opened a
* moment before its grant is not without a folder, and is not told that it is.
*/
async function whenGranted(api, stopped, late) {
	for (let tries = 1;; tries++) {
		const project = await api.project().catch(() => null);
		if (project || stopped()) return project ?? "";
		if (tries === 5) late();
		await new Promise((done) => setTimeout(done, 700));
	}
}
//#endregion
//#region plugins/map/agent.ts
/** A task the owner hands their agent from a card: put into its input as the person would, and said to be done. */
function ask(text) {
	const api = surface();
	if (!api) return;
	tell(say("Asked the agent. Its answer is in its block."));
	api.askAgent(text).catch((err) => {
		api.log(`the question did not go — ${String(err)}`);
		tell(saying("The question did not go: {0}", String(err)));
	});
}
/** A task with the person's own words in it, handed to their agent; said why when it cannot go. Answers whether it went. */
async function askWith(words, make) {
	const api = surface();
	const got = api ? await within(api, words, make) : null;
	if (got && "why" in got) tell(got.why);
	if (!got || "why" in got) return false;
	ask(got.text);
	return true;
}
//#endregion
//#region plugins/map/crew.ts
/** The team as the window last said. Nothing says, on surface 4: always nobody. */
function workersNow() {
	return [];
}
/** The members standing in one part of a level. */
function workersAt(workers, level, id) {
	return level.kind === "memory" ? [] : workers.filter((w) => w.at[level.key] === id);
}
/** A member's block in the card of the part it is in. */
function hereHtml(w) {
	const head = w.state === "asks" ? saying("Waiting for your answer: {0}", w.name) : saying("Working here now: {0}", w.name);
	return `<div class="here ${w.state}"><b>${plain(head)}</b><span>${plain(saying("{0}, {1} min · {2}", w.role, w.minutes, w.does))}</span></div>`;
}
//#endregion
//#region plugins/map/filters.ts
/** Whether a part belongs to a tab. */
function inMode(n, mode) {
	return mode === "all" || mode === "bad" && n.broken || mode === "changed" && n.changed || mode === "wait" && n.waits;
}
/** Whether a part is lit: in the tab, in the filter, and named by the search. */
function isLit(n, lit) {
	const q = lit.q.trim().toLowerCase();
	return (!lit.only || lit.only.has(n.id)) && inMode(n, lit.mode) && (!q || `${n.t} ${n.s}`.toLowerCase().includes(q));
}
/** A link is lit when both its ends are. */
function linkLit(a, b, lit) {
	return !!a && !!b && isLit(a, lit) && isLit(b, lit);
}
/** The number each tab carries. */
function counts(nodes) {
	return {
		bad: nodes.filter((n) => n.broken).length,
		changed: nodes.filter((n) => n.changed).length,
		wait: nodes.filter((n) => n.waits).length
	};
}
/**
* The marks a part carries in every view, as classes. Which parts carry their names is not a mark
* of the part: it depends on what has room, and the views work it out (`views/names.ts`, FM-MAP-63).
*/
function marksOf(n, _stats) {
	return [
		n.changed ? "changed" : "",
		n.waits ? "wait" : "",
		n.broken ? "bad" : "",
		n.kids ? "kids" : ""
	].filter(Boolean).join(" ");
}
//#endregion
//#region plugins/map/memory.ts
/** Where the export is, relative to the project. */
var MEMORY_FILE = "project-notes/private/memory.json";
/** The memory world's key. */
var MEMORY = "memory";
var text = (v) => typeof v === "string" ? v : typeof v === "number" ? String(v) : "";
var list = (v) => Array.isArray(v) ? v.map(text).filter((x) => x !== "") : [];
/**
* The export as a level, or null when it is not one.
*
* Shape: `{nodes:[{id,g,t,s,d,f,ver,born,ch?,w?,bad?}], edges:[[a,b]], groups:[titles],
* project:[ids]}`. `bad` is a sentence — the link that broke; `w` marks a note nobody has checked
* for a long time; `ch` marks one new this week, and a note born this week is new whether or not
* the export says so.
*/
function readMemory(json, opts) {
	let raw;
	try {
		raw = JSON.parse(json);
	} catch {
		return null;
	}
	if (!raw || typeof raw !== "object" || !Array.isArray(raw.nodes)) return null;
	const data = raw;
	const nodes = [];
	const ids = /* @__PURE__ */ new Set();
	let groups = 0;
	for (const one of data.nodes) {
		if (!one || typeof one !== "object") continue;
		const n = one;
		const id = text(n.id);
		if (!id || ids.has(id)) continue;
		ids.add(id);
		const files = list(n.f);
		const part = blankPart(id, files[0] ?? "");
		part.g = typeof n.g === "number" && n.g >= 0 ? Math.floor(n.g) : 0;
		groups = Math.max(groups, part.g + 1);
		part.t = text(n.t) || id;
		part.s = text(n.s);
		part.d = text(n.d);
		part.f = files;
		part.ver = text(n.ver);
		part.born = text(n.born) || part.ver;
		part.broken = text(n.bad) !== "";
		part.why = text(n.bad);
		part.waits = !!n.w;
		part.changed = !!n.ch || thisWeek(part.born, opts.today);
		nodes.push(part);
	}
	const edges = [];
	if (Array.isArray(data.edges)) for (const e of data.edges) {
		if (!Array.isArray(e)) continue;
		const [a, b] = [text(e[0]), text(e[1])];
		if (a !== b && ids.has(a) && ids.has(b)) edges.push([a, b]);
	}
	const titles = list(data.groups);
	const frames = Array.from({ length: Math.max(groups, titles.length) }, (_x, i) => ({ t: titles[i] ?? opts.ungrouped }));
	return {
		level: {
			key: MEMORY,
			title: opts.title,
			kind: "memory",
			parent: null,
			folder: "",
			frames,
			nodes,
			edges
		},
		project: list(data.project).filter((id) => ids.has(id))
	};
}
/** The memory notes a part names, those the export really has, in the part's order. */
function memoryOf(part, world) {
	if (!world) return [];
	return part.mem.map((id) => world.level.nodes.find((n) => n.id === id)).filter((n) => !!n);
}
/** The parts, among those given, whose notes name this memory note. */
function partsAbout(memoryId, parts) {
	return parts.filter((p) => p.mem.includes(memoryId));
}
//#endregion
//#region plugins/map/selection.ts
/** Fewer than two picked is not "several": the one left is simply the chosen part. */
function settled(cur, picked) {
	if (picked.length >= 2) return {
		cur,
		picked
	};
	return {
		cur: picked[0] ?? cur,
		picked: []
	};
}
/**
* A press on a part.
*
* Plainly: that part is chosen, and nothing is picked. With `several`: the part joins the picked
* ones, or leaves them — and the first such press takes the part already chosen along, because a
* person who Shift-presses a second part means "this one too".
*/
function choose(now, id, several) {
	if (!several) return {
		cur: id,
		picked: []
	};
	const picked = [...now.picked];
	if (!picked.length && now.cur !== null && now.cur !== id) picked.push(now.cur);
	const at = picked.indexOf(id);
	if (at >= 0) picked.splice(at, 1);
	else picked.push(id);
	return settled(now.cur, picked);
}
/** One part taken out of the picked ones, by its cross in the card. */
function drop(now, id) {
	return settled(now.cur, now.picked.filter((x) => x !== id));
}
/** The pick let go; the chosen part stays. */
function unpick(now) {
	return {
		cur: now.cur,
		picked: []
	};
}
/** Whether the card is one task for several. */
function isSeveral(now) {
	return now.picked.length >= 2;
}
/**
* What stays chosen when the map under it changes: a part that is gone is let go, and a map that
* lost its chosen part falls back to `fallback`.
*/
function kept(now, has, fallback) {
	const next = settled(now.cur !== null && has(now.cur) ? now.cur : null, now.picked.filter(has));
	return next.cur === null ? {
		cur: fallback,
		picked: []
	} : next;
}
//#endregion
//#region plugins/map/card.ts
/** The chip over the title: what state the part is in, in each world's own words. */
function stateOf(n, memory) {
	if (memory) return n.broken ? {
		cls: "b",
		word: say("Broken link")
	} : n.waits ? {
		cls: "w",
		word: say("Not checked for a long time")
	} : {
		cls: "",
		word: say("In force")
	};
	return n.broken ? {
		cls: "b",
		word: say("Broken")
	} : n.waits ? {
		cls: "w",
		word: say("Waiting for your word")
	} : {
		cls: "",
		word: say("Works")
	};
}
var chips = (items) => `<div class="links">${items.join("")}</div>`;
var button = (act, label, cls = "", ic) => `<button type="button"${cls ? ` class="${cls}"` : ""} data-act="${plain(act)}">${ic ? icon(ic) : ""}${ic ? `<span>${plain(label)}</span>` : plain(label)}</button>`;
/** A line of the card's "⋯" menu: what it does and what that means, in one line each. */
var line = (act, label, hint, ic) => `<button type="button" class="opt" role="menuitem" data-act="${plain(act)}">${icon(ic)}<span>${plain(label)}</span> <small>${plain(hint)}</small></button>`;
/** The two buttons under the name, then "⋯" and the menu it opens, drawn closed. */
var acts = (main, lines) => `<div class="acts">${main}${lines.length ? `<button type="button" class="icon" data-act="more" aria-label="${plain(say("More"))}" title="${plain(say("More"))}" aria-haspopup="menu" aria-expanded="false">${icon("more")}</button>` : ""}</div>${lines.length ? `<div class="menu card-menu" role="menu" hidden>${lines.join("")}</div>` : ""}`;
/** What the person is writing: a field for their words, send and cancel. */
function composeHtml(c) {
	const w = {
		change: {
			head: say("What to change"),
			hint: say("For example: make it run once an hour"),
			send: say("Give the task to the agent")
		},
		broken: {
			head: say("What is broken"),
			hint: say("In your own words: what does not work"),
			send: say("Mark as broken")
		},
		correct: {
			head: say("What to correct"),
			hint: say("For example: this has not been true since October"),
			send: say("Give the task to the agent")
		},
		forget: {
			head: say("Forget this note?"),
			hint: "",
			send: say("Forget")
		},
		answer: {
			head: say("Your answer"),
			hint: say("For example: yes, but only until noon"),
			send: say("Answer the agent")
		}
	}[c.kind];
	const field = c.kind === "forget" ? `<p>${plain(say("The agent will delete this memory note."))}</p>` : `<textarea id="task" placeholder="${plain(w.hint)}"></textarea>`;
	return `<div class="picked"><h3>${plain(w.head)}</h3>${field}</div>
    <div class="acts">${button("send", w.send, "main")}${button("cancel", say("Cancel"))}</div>`;
}
/** The parts the one task is for: the picked ones, or the one chosen before a second is pressed. */
function taskParts(input) {
	const { stats, chosen } = input;
	return (isSeveral(chosen) ? chosen.picked : chosen.cur ? [chosen.cur] : []).map((id) => stats.by[id]).filter(Boolean);
}
/** One task for several chosen parts. */
function severalHtml(input) {
	const parts = taskParts(input);
	return `<div class="head"><span class="state plain">${plain(saying("Parts chosen: {0}", parts.length))}</span><span class="grow"></span>${input.severalOn ? button("done", say("Done"), "ghost") : ""}</div>
    <h2>${plain(say("One task for all of them"))}</h2>
    ${parts.length ? chips(parts.map((n) => `<button type="button" class="on" data-act="drop:${plain(n.id)}">${plain(n.t)} <span aria-hidden="true">×</span></button>`)) : `<p class="hint">${plain(say("Press parts on the map."))}</p>`}
    <div class="picked"><textarea id="task" aria-label="${plain(say("What to do with them"))}" placeholder="${plain(say("For example: check that they agree with each other"))}"></textarea></div>
    <div class="acts">${parts.length ? button("give", say("Give the task to the agent"), "main", "agent") : `<button type="button" class="main" data-act="give" disabled>${icon("agent")}<span>${plain(say("Give the task to the agent"))}</span></button>`}${button("unpick", say("Clear the choice"), "ghost")}</div>`;
}
/** Why a part is in a filter's list, in one line: what is broken, what it waits for, what changed. */
function reasonOf(n, mode, memory) {
	if (mode === "bad" && n.why) return n.why;
	if (mode === "wait") return n.waitsFor || (memory && n.ver ? saying("checked {0}", fullDay(n.ver)) : n.s);
	if (mode === "changed") return n.changedLine || (n.changedOn ? saying("changed {0}", fullDay(n.changedOn)) : n.s);
	return n.s;
}
/**
* A filter's list: exactly the parts it lights, each with why it is there; a press on a row opens
* that part's card (FM-MAP-81). Search and "only about this project" narrow it as they dim the map.
*/
function listHtml(input) {
	const { level, listing } = input;
	if (!listing) return "";
	const memory = level.kind === "memory";
	const rows = level.nodes.filter((n) => isLit(n, listing));
	const dot = (n) => n.broken ? "b" : n.waits ? "w" : "";
	return `<div class="list"><div class="hdr"><strong>${plain(input.listName ?? "")}</strong> <span>${rows.length}</span></div>${rows.length ? rows.map((n) => `<button type="button" class="row" data-act="go:${plain(n.id)}"><i class="${dot(n)}"></i><strong>${plain(n.t)}</strong> <span>${plain(reasonOf(n, listing.mode, memory))}</span></button>`).join("") : `<p class="none">${plain(say("Nothing here, which is good."))}</p>`}</div>`;
}
/** What the agent remembers about a part, or which parts a memory note is about. */
function memoryHtml(n, input) {
	const { level, world } = input;
	if (level.kind === "memory") {
		if (!world?.project.includes(n.id)) return "";
		const about = partsAbout(n.id, input.rootParts);
		return `<h3>${plain(say("About this project"))}</h3>${chips([button("part:", input.projectTitle), ...about.map((p) => button(`part:${p.id}`, p.t))])}`;
	}
	if (!world) return "";
	const own = memoryOf(n, world);
	return `<h3>${plain(say("What the agent remembers"))}</h3>${chips([...own.map((m) => button(`mem:${m.id}`, m.t)), button("memall", saying("about the project as a whole: {0}", world.project.length), "more")])}`;
}
/** The two buttons under a project part's name, and the rest behind "⋯". */
function partActs(n, input) {
	const inside = n.kids && !input.here;
	const enter = inside ? button("enter", say("Go inside"), n.broken ? "" : "main", n.broken ? void 0 : "enter") : "";
	const second = n.broken ? button("fix", say("Ask to fix it"), "main", "agent") : button("ask", say("Ask the agent"), inside ? "" : "main", inside ? void 0 : "agent");
	const rare = [line("change", say("Change this part"), say("say it in words; the agent does it"), "edit"), n.broken ? n.by === "person" ? line("clear", say("It works again"), say("take your mark away"), "check") : "" : line("mark", say("Mark as broken"), say("until you say it works"), "flag")].filter(Boolean);
	return acts(n.broken ? `${second}${enter}` : `${enter}${second}`, rare);
}
/** The two buttons under a memory note's name, and the rest behind "⋯". */
function memoryActs(n) {
	const rare = [n.waits ? line("correct", say("Correct the note"), say("say what is true now"), "edit") : "", line("forget", say("Forget"), say("the agent deletes the note"), "x")].filter(Boolean);
	return acts(`${button("ask", say("Ask the agent"), "main", "agent")}${n.waits ? button("check", say("Check whether it is still true")) : button("correct", say("Correct the note"), "", "edit")}`, rare);
}
/** The card, as markup. Empty when the map has no part to show. */
function cardHtml(input) {
	const { level, stats, chosen } = input;
	if (input.listing) return listHtml(input);
	if (isSeveral(chosen) || input.severalOn) return severalHtml(input);
	const n = chosen.cur ? stats.by[chosen.cur] : void 0;
	if (!n) return "";
	const memory = level.kind === "memory";
	const st = stateOf(n, memory);
	const who = n.by === "check" ? say("A check of the project fails.") : n.by === "person" ? say("You marked it yourself.") : "";
	const why = n.broken ? `<div class="callout b"><strong>${plain(memory ? say("What is wrong") : say("What is broken"))}</strong><p class="why">${plain(n.why)}${who ? `<small>${plain(who)}</small>` : ""}</p></div>` : "";
	const waits = !memory && n.waits ? `<div class="callout w"><strong>${plain(say("Your decision is needed"))}</strong><p class="waits">${plain(n.waitsFor)}</p>${input.compose?.id === n.id ? "" : button("answer", say("Answer the agent"), "sm")}</div>` : "";
	const body = bodyText(n.d, (slug) => stats.by[slug]?.t).split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean).map((p) => `<p>${plain(p)}</p>`).join("");
	const linked = neighbours(level, n.id).filter((id) => stats.by[id]);
	const composing = input.compose && input.compose.id === n.id ? input.compose : null;
	const answering = composing?.kind === "answer";
	const facts = [
		n.born ? `<span>${plain(say("Appeared"))}</span><span class="hist">${plain(fullDay(n.born))}</span>` : "",
		n.changedOn || n.changedLine ? `<span>${plain(say("Changed"))}</span><span class="hist">${n.changedOn ? `<span>${plain(fullDay(n.changedOn))}</span>` : ""}${plain(n.changedLine)}</span>` : "",
		memory && n.ver ? `<span>${plain(say("Checked"))}</span><span class="hist">${plain(fullDay(n.ver))}</span>` : ""
	].join("");
	const where = n.note || n.text || "";
	const reading = n.text ? button("open", typeof input.opened === "string" ? say("Close the text") : say("Read it here"), "sm", "book") : "";
	return `${input.here ? `<small class="youare">${plain(say("The folder you are in"))}</small>` : ""}<div class="head">${input.back ? `<button type="button" class="back" data-act="list">${icon("chev")}<span>${plain(say("Back to the list"))}</span></button><span class="grow"></span>` : ""}<span class="state ${st.cls}">${plain(st.word)}</span></div>
    <h2>${plain(n.t)}</h2>
    ${n.s ? `<p class="sum">${plain(n.s)}</p>` : ""}
    ${answering ? waits : ""}${composing ? composeHtml(composing) : memory ? memoryActs(n) : partActs(n, input)}
    ${why}${answering ? "" : waits}
    ${workersAt(input.workers, level, n.id).map(hereHtml).join("")}
    ${body}
    ${linked.length ? `<h3>${plain(say("Linked with"))}</h3>${chips(linked.map((id) => button(`go:${id}`, stats.by[id].t)))}` : ""}
    ${memoryHtml(n, input)}
    ${facts ? `<h3>${plain(say("When"))}</h3><div class="facts">${facts}</div>` : ""}
    ${where ? `<h3>${plain(memory ? say("File") : say("Where it is"))}</h3><div class="path"><code class="note" title="${plain(where)}">${plain(where)}</code>${reading}</div>` : ""}
    ${n.about && n.about !== where ? `<h3>${plain(say("Note"))}</h3><div class="note">${plain(n.about)}</div>` : ""}
    ${typeof input.opened === "string" ? `<pre class="notetext">${plain(input.opened)}</pre>` : ""}`;
}
//#endregion
//#region plugins/map/git.ts
var two = (n) => String(n).padStart(2, "0");
/** The day a moment was, on the clock of whoever committed: `seconds` since 1970 and `+0300`. */
function dayOf(seconds, zone) {
	const shift = (zone.startsWith("-") ? -1 : 1) * (Number(zone.slice(1, 3)) * 60 + Number(zone.slice(3, 5))) * 60;
	const at = /* @__PURE__ */ new Date((seconds + (Number.isFinite(shift) ? shift : 0)) * 1e3);
	return `${at.getUTCFullYear()}-${two(at.getUTCMonth() + 1)}-${two(at.getUTCDate())}`;
}
/** The commits in a `logs/HEAD`, by day, oldest first. */
function daysIn(log) {
	const days = /* @__PURE__ */ new Map();
	for (const line of log.split("\n")) {
		const m = /^[0-9a-f]+ [0-9a-f]+ .*? (\d{9,11}) ([+-]\d{4})\tcommit(?: \([^)]*\))?: (.*)$/.exec(line);
		if (!m) continue;
		const on = dayOf(Number(m[1]), m[2]);
		const day = days.get(on) ?? {
			on,
			count: 0,
			said: []
		};
		day.count += 1;
		if (day.said.length < 3) day.said.push(m[3].trim().slice(0, 120));
		days.set(on, day);
	}
	return [...days.values()].sort((a, b) => a.on.localeCompare(b.on)).slice(-60);
}
/** The history of one folder, as far as it can be read. */
async function readPast(door, folder) {
	const at = folder ? `${folder}/.git` : ".git";
	const log = await door.readSource(`${at}/logs/HEAD`).catch(() => null);
	if (log) return {
		how: "read",
		days: daysIn(log)
	};
	const pointer = await door.readSource(at).catch(() => null);
	return {
		how: pointer && /^gitdir:/m.test(pointer) ? "outside" : "none",
		days: []
	};
}
//#endregion
//#region plugins/map/scan.ts
/** Folders that are not the person's work: fetched, built, cached — and the map's own notes. */
var NOT_THE_PROJECT = /* @__PURE__ */ new Set([
	"node_modules",
	"bower_components",
	"target",
	"dist",
	"build",
	"out",
	"vendor",
	"venv",
	"env",
	"__pycache__",
	"Pods",
	"DerivedData",
	"coverage",
	"tmp",
	"temp",
	"cache",
	"logs",
	"project-notes",
	"site-packages",
	"Library",
	"Applications",
	"System",
	"Volumes"
]);
/** A name the walk passes by: hidden, or one of the folders that are not the project. */
var skipped = (name) => name.startsWith(".") || name.endsWith("~") || NOT_THE_PROJECT.has(name);
var ENDINGS = {
	doc: "md mdx markdown txt rst adoc org tex pdf doc docx odt rtf pages epub fb2 ppt pptx key numbers",
	code: "ts tsx js jsx mjs cjs py rs go java kt kts swift c h cc cpp hpp cs rb php pl lua sh bash zsh fish ps1 sql r scala dart ex exs erl hs clj elm zig nim vim el gradle cmake mk",
	page: "html htm css scss sass less astro vue svelte hbs ejs njk liquid twig",
	data: "json jsonl ndjson yaml yml toml xml csv tsv ini cfg conf env lock plist db sqlite sqlite3 xls xlsx ods parquet log bak map snap",
	picture: "png jpg jpeg gif webp avif svg ico icns bmp tif tiff heic psd ai sketch fig xcf",
	media: "mp3 wav flac ogg m4a aac mp4 mov mkv avi webm m4v zip gz tgz bz2 xz 7z rar tar dmg pkg iso exe dll so dylib a o class jar war wasm bin dat ttf otf woff woff2 eot"
};
var KIND_OF = /* @__PURE__ */ new Map();
for (const [kind, list] of Object.entries(ENDINGS)) for (const e of list.split(" ")) KIND_OF.set(e, kind);
/** Files known by their whole name, which has no ending. */
var NAMED_FILES = /* @__PURE__ */ new Set([
	"LICENSE",
	"LICENCE",
	"Makefile",
	"Dockerfile",
	"README",
	"CHANGELOG",
	"NOTICE",
	"AUTHORS",
	"Gemfile",
	"Procfile",
	"Rakefile",
	"Brewfile",
	"Justfile",
	"CODEOWNERS",
	"COPYING",
	"Pipfile",
	"Vagrantfile"
]);
/** A name's ending, in small letters; empty when it has none. */
var ending = (name) => {
	const at = name.lastIndexOf(".");
	return at <= 0 ? "" : name.slice(at + 1).toLowerCase();
};
/** What a file is by its ending; null for a name that is not known to be a file. */
function kindOf(name) {
	return KIND_OF.get(ending(name)) ?? (NAMED_FILES.has(name) ? "other" : null);
}
/** Endings whose text the map reads: writing, code and pages. Never data, never anything binary. */
var READ = new Set("md mdx markdown txt rst adoc org ts tsx js jsx mjs cjs py rs go java kt swift c h cc cpp hpp cs rb php sh html htm css scss astro vue svelte".split(" "));
/** Whether a file's text is read. A minified or bundled script is somebody's build, not their writing. */
var isRead = (name) => READ.has(ending(name)) && !/\.(min|bundle|chunk)\./i.test(name) && !/\.d\.ts$/i.test(name);
/** A walk of an ordinary level: thousands of folders, and never longer than this. */
var BOUNDS = {
	lists: 4e3,
	names: 6e4,
	deep: 9,
	time: 45e3,
	wide: 8
};
var join = (folder, name) => folder ? `${folder}/${name}` : name;
/** The path the surface is asked for: the granted folder itself is ".". */
var asked = (path) => path || ".";
/** Run `work` over `items`, `wide` at a time, in the order given. */
async function pool(items, wide, work) {
	const out = new Array(items.length);
	let next = 0;
	const run = async () => {
		for (let i = next++; i < items.length; i = next++) out[i] = await work(items[i]);
	};
	await Promise.all(Array.from({ length: Math.min(wide, items.length) }, run));
	return out;
}
/**
* Walk a folder, breadth first, one depth at a time.
*
* Breadth first so that what is cut by a bound is the depths, never a whole part of the level:
* every part of the top is looked into before any is looked into deeply. The same folder walked
* twice gives the same answer — names are sorted, and a depth is taken whole or not at all.
* `seen` is told how many folders are listed and how many are known to be waiting.
*/
async function walk(door, folder, bounds = BOUNDS, seen = () => {}, now = Date.now) {
	const root = {
		name: folder.split("/").pop() ?? "",
		path: folder,
		dir: true,
		kind: "other",
		kids: [],
		shut: false
	};
	const paths = /* @__PURE__ */ new Set();
	const began = now();
	let lists = 0;
	let names = 0;
	let cut = false;
	let wave = [root];
	for (let deep = 0; wave.length; deep++) {
		if (!(deep <= bounds.deep && lists + wave.length <= bounds.lists && names <= bounds.names && now() - began <= bounds.time) && deep > 0) {
			for (const e of wave) e.shut = true;
			cut = true;
			break;
		}
		const listed = await pool(wave, bounds.wide, (e) => door.listSource(asked(e.path)).catch(() => []));
		lists += wave.length;
		const next = [];
		wave.forEach((at, i) => {
			if (listed[i].includes(".git")) at.git = true;
			const here = listed[i].filter((n) => !skipped(n)).sort();
			const store = here.filter((n) => kindOf(n) === null).length > 200;
			for (const name of here) {
				names += 1;
				const path = join(at.path, name);
				const kind = kindOf(name) ?? (store ? "other" : null);
				const entry = {
					name,
					path,
					dir: kind === null,
					kind: kind ?? "other",
					kids: [],
					shut: false
				};
				at.kids.push(entry);
				paths.add(path);
				if (entry.dir) next.push(entry);
			}
		});
		seen(lists, lists + next.length);
		wave = next;
	}
	settle$1(root);
	return {
		root,
		paths,
		lists,
		names,
		cut
	};
}
/** A name listed and found empty is no folder to draw: a file with no ending, or nothing at all. */
function settle$1(at) {
	for (const kid of at.kids) {
		if (!kid.dir) continue;
		if (kid.shut || kid.kids.length) settle$1(kid);
		else kid.dir = false;
	}
}
/** Every file under an entry, shallow ones first. */
function filesUnder(at) {
	const out = [];
	for (let wave = [at]; wave.length;) {
		const next = [];
		for (const e of wave) for (const kid of e.kids) if (kid.dir) next.push(kid);
		else out.push(kid);
		wave = next;
	}
	return out;
}
/** Whether anything under an entry was left unlooked at. */
var anyShut = (at) => at.shut || at.kids.some((k) => k.dir && anyShut(k));
/** A short print of a text: enough to tell that it changed. */
function printOf(text) {
	let h = 2166136261;
	for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619) >>> 0;
	return `${h.toString(36)}.${text.length.toString(36)}`;
}
var one = (v) => (Array.isArray(v) ? v.join(", ") : v ?? "").trim();
var dirOf$1 = (path) => path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "";
var bare = (path) => path.slice(path.lastIndexOf("/") + 1).replace(/\.md$/i, "");
/** Whether a document's front matter is a memory note's. */
function isMemoryNote(text) {
	const { front } = splitNote(text);
	return one(front.name) !== "" && one(front.description) !== "";
}
/** The folders that hold a memory, among the documents a reading found and the paths it walked. */
function memoryFolders(docs, paths) {
	const count = /* @__PURE__ */ new Map();
	for (const d of docs) if (isMemoryNote(d.text)) count.set(dirOf$1(d.path), (count.get(dirOf$1(d.path)) ?? 0) + 1);
	const folders = new Set([...count.entries()].filter(([, n]) => n >= 3).map(([dir]) => dir));
	for (const path of paths) if (/(^|\/)MEMORY\.md$/.test(path) && count.has(dirOf$1(path))) folders.add(dirOf$1(path));
	return [...folders].sort();
}
/** The kind a note says it is, as a group. */
function kindWords(type) {
	switch (type.toLowerCase()) {
		case "user": return say("About the person");
		case "feedback": return say("How to work");
		case "project": return say("Projects and work in hand");
		case "reference": return say("Where things are");
		default: return say("Other notes");
	}
}
/** The titles an index gives its notes: `- [Title](file.md) — hook`. */
function indexTitles(index) {
	const titles = /* @__PURE__ */ new Map();
	for (const m of index.matchAll(/\[([^\]]+)\]\(([^)\s]+\.md)\)/g)) titles.set(bare(m[2]).toLowerCase(), m[1].trim());
	return titles;
}
/**
* Memory notes as the export the memory world is drawn from (`memory.ts`).
*
* A link is one note naming another, by `[[name]]` or `(file.md)`. A link to a note that is not
* there is a broken link, said on the note that carries it. `verified` is when the note was last
* checked to be true: older than `STALE_DAYS`, the note has not been checked for long.
*/
function memoryExport(notes, index, today) {
	const titles = indexTitles(index);
	const ids = /* @__PURE__ */ new Map();
	for (const n of notes) {
		ids.set(bare(n.path).toLowerCase(), bare(n.path));
		const named = one(splitNote(n.text).front.name).toLowerCase();
		if (named && !ids.has(named)) ids.set(named, bare(n.path));
	}
	const groups = [];
	const edges = [];
	const nodes = notes.map((n) => {
		const { front, body } = splitNote(n.text);
		const id = bare(n.path);
		const type = one(front.type) || (/^\s*type:\s*(\w+)/m.exec(n.text)?.[1] ?? "");
		const group = kindWords(type);
		if (!groups.includes(group)) groups.push(group);
		const missing = [];
		const named = [...linksIn(body), ...[...body.matchAll(/\]\(\s*([^)\s]+\.md)\s*\)/g)].filter((m) => !/^[a-z]+:/i.test(m[1])).map((m) => bare(m[1]))];
		for (const name of named) {
			const to = ids.get(name.toLowerCase());
			if (!to) missing.push(name);
			else if (to !== id) edges.push([id, to]);
		}
		const ver = /^\d{4}-\d{2}-\d{2}/.exec(one(front.verified))?.[0] ?? "";
		const stale = ver !== "" && daysBetween(ver, today) > 90;
		const words = [one(front.description), body.slice(0, 900).trim()].filter(Boolean).join("\n\n");
		return {
			id,
			g: groups.indexOf(group),
			t: titles.get(id.toLowerCase()) ?? one(front.name),
			s: type,
			d: words,
			f: [n.path],
			ver,
			born: "",
			...stale ? { w: 1 } : {},
			...missing.length ? { bad: missing.map((m) => `[[${m}]]`).join(", ") } : {}
		};
	});
	return JSON.stringify({
		nodes,
		edges,
		groups,
		project: []
	});
}
/** Every memory note of the folders given, read; and the indexes beside them. */
async function readMemoryNotes(door, folders, told = () => {}) {
	const files = [];
	let index = "";
	for (const folder of folders) {
		const names = (await door.listSource(folder || ".").catch(() => [])).filter((n) => /\.md$/i.test(n) && !n.startsWith(".")).sort();
		for (const name of names) {
			const path = folder ? `${folder}/${name}` : name;
			if (name === "MEMORY.md") index += `${await door.readSource(path).catch(() => null) ?? ""}\n`;
			else if (files.length < 1500) files.push(path);
		}
	}
	let done = 0;
	return {
		notes: (await pool(files, 8, async (path) => {
			const text = await door.readSource(path).catch(() => null);
			done += 1;
			if (done % 25 === 0 || done === files.length) told(done, files.length);
			return text !== null && isMemoryNote(text) ? {
				path,
				text
			} : null;
		})).filter((n) => !!n),
		index
	};
}
//#endregion
//#region plugins/map/refs.ts
var outside = (to) => /^([a-z][a-z0-9+.-]*:|\/\/|#|\{|\$|<)/i.test(to) || to.includes("*");
function add(out, how, raw) {
	let to = (raw ?? "").trim().split(/[?#]/)[0];
	try {
		to = decodeURI(to);
	} catch {}
	if (!to || to.length > 200 || outside(to)) return;
	if (!out.some((r) => r.how === how && r.to === to)) out.push({
		how,
		to
	});
}
var WRITING$1 = /* @__PURE__ */ new Set([
	"md",
	"mdx",
	"markdown",
	"txt",
	"rst",
	"adoc",
	"org"
]);
var SCRIPT = /* @__PURE__ */ new Set([
	"ts",
	"tsx",
	"js",
	"jsx",
	"mjs",
	"cjs",
	"astro",
	"vue",
	"svelte"
]);
var PAGE = /* @__PURE__ */ new Set([
	"html",
	"htm",
	"astro",
	"vue",
	"svelte",
	"php"
]);
/** Every target a file's text names. */
function refsOf(path, text) {
	const out = [];
	const e = ending(path);
	if (WRITING$1.has(e)) {
		for (const m of text.matchAll(/\[\[([^\]|#]+)/g)) add(out, "wiki", m[1]);
		for (const m of text.matchAll(/\]\(\s*<?([^)\s>]+)/g)) add(out, "rel", m[1]);
	}
	if (SCRIPT.has(e)) {
		for (const m of text.matchAll(/\bfrom\s*["']([^"']+)["']/g)) if (m[1].startsWith(".")) add(out, "rel", m[1]);
		for (const m of text.matchAll(/\b(?:import|require)\s*\(?\s*["']([^"']+)["']/g)) if (m[1].startsWith(".")) add(out, "rel", m[1]);
	}
	if (PAGE.has(e)) for (const m of text.matchAll(/\b(?:src|href)\s*=\s*["']([^"']+)["']/g)) add(out, m[1].startsWith("/") ? "path" : "rel", m[1].replace(/^\/+/, ""));
	if (e === "css" || e === "scss") {
		for (const m of text.matchAll(/@(?:import|use)\s+(?:url\()?["']([^"']+)["']/g)) add(out, "rel", m[1]);
		for (const m of text.matchAll(/url\(\s*["']?([^"')]+)/g)) add(out, "rel", m[1]);
	}
	if (e === "py") {
		for (const m of text.matchAll(/^\s*from\s+(\.+)([\w.]*)\s+import\b/gm)) add(out, "rel", `${m[1].length > 1 ? "../".repeat(m[1].length - 1) : "./"}${m[2].replace(/\./g, "/")}`);
		for (const m of text.matchAll(/^\s*(?:from|import)\s+([A-Za-z_][\w.]*)/gm)) add(out, "mod", m[1].replace(/\./g, "/"));
	}
	if (e === "rs") for (const m of text.matchAll(/^\s*(?:pub\s+)?mod\s+(\w+)\s*;/gm)) add(out, "rel", `./${m[1]}`);
	if ([
		"c",
		"h",
		"cc",
		"cpp",
		"hpp"
	].includes(e)) for (const m of text.matchAll(/^\s*#\s*include\s+"([^"]+)"/gm)) add(out, "rel", m[1]);
	for (const m of text.matchAll(/["'`]((?:[\w.@-]+\/)+[\w.@-]+\.[A-Za-z]\w{0,7})["'`]/g)) add(out, "path", m[1].replace(/^\.\//, ""));
	return out;
}
/** `a/b/../c` and `./a` as plain paths; null when it climbs out of the granted folder. */
function plainPath(path) {
	const out = [];
	for (const piece of path.split("/")) {
		if (piece === "" || piece === ".") continue;
		if (piece === "..") {
			if (!out.length) return null;
			out.pop();
		} else out.push(piece);
	}
	return out.join("/");
}
var dirOf = (path) => path.includes("/") ? path.slice(0, path.lastIndexOf("/")) : "";
/** What a name without its ending may be a file of, tried in this order. */
var TRIED = [
	"",
	".ts",
	".tsx",
	".js",
	".jsx",
	".mjs",
	".md",
	".mdx",
	".py",
	".rs",
	".astro",
	".vue",
	".svelte",
	".css",
	".scss",
	".h",
	".html",
	"/index.ts",
	"/index.tsx",
	"/index.js",
	"/mod.rs",
	"/__init__.py",
	"/index.md",
	"/README.md"
];
/** The names documents go by, for `[[name]]`. */
function namesOf(paths) {
	const byName = /* @__PURE__ */ new Map();
	for (const path of paths) {
		const name = path.slice(path.lastIndexOf("/") + 1);
		if (!WRITING$1.has(ending(name))) continue;
		const bare = name.slice(0, name.lastIndexOf(".")).toLowerCase();
		if (!byName.has(bare)) byName.set(bare, path);
	}
	return byName;
}
function tried(found, base) {
	if (base === null) return null;
	for (const tail of TRIED) if (base + tail !== "" && found.paths.has(base + tail)) return base + tail;
	const bare = base.replace(/\.(js|jsx|mjs)$/, "");
	if (bare !== base) {
		for (const tail of [".ts", ".tsx"]) if (found.paths.has(bare + tail)) return bare + tail;
	}
	return null;
}
/** The path a target means, among those the walk found; null for a target that is not there. */
function resolve(ref, from, found) {
	if (ref.how === "wiki") return found.byName.get(ref.to.trim().toLowerCase()) ?? tried(found, plainPath(`${dirOf(from)}/${ref.to}`));
	if (ref.how === "rel") return tried(found, plainPath(`${dirOf(from)}/${ref.to}`));
	for (let dir = dirOf(from);; dir = dirOf(dir)) {
		const hit = tried(found, plainPath(dir ? `${dir}/${ref.to}` : ref.to));
		if (hit) return hit;
		if (!dir) return null;
	}
}
//#endregion
//#region plugins/map/reader.ts
/** The folder a level is, relative to the granted one: the top is the granted folder itself, any other key a path below it. */
var folderOfKey = (key) => key === "root" ? "" : key;
/** A document's text kept for the memory world and the cards is no longer than this. */
var KEPT_MOST = 24e3;
var WRITING = /* @__PURE__ */ new Set([
	"md",
	"mdx",
	"markdown",
	"txt",
	"rst",
	"adoc",
	"org"
]);
var MARKERS = /* @__PURE__ */ new Set([
	"package.json",
	"Cargo.toml",
	"pyproject.toml",
	"setup.py",
	"go.mod",
	"pom.xml",
	"build.gradle",
	"Gemfile",
	"composer.json",
	"Package.swift",
	"astro.config.mjs",
	"astro.config.ts"
]);
/** A project of its own: it keeps a history, or carries the file its tools start from. */
var isProject = (e) => !!e.git || e.kids.some((k) => !k.dir && MARKERS.has(k.name));
/** The group a kind of thing stands in, in the order the groups are drawn. */
var ORDER = [
	"project",
	"code",
	"page",
	"doc",
	"data",
	"picture",
	"folder",
	"file"
];
function groupWord(group) {
	switch (group) {
		case "project": return say("Projects");
		case "code": return say("Code");
		case "page": return say("Site pages");
		case "doc": return say("Documents");
		case "data": return say("Data");
		case "picture": return say("Pictures and media");
		case "folder": return say("Folders");
		case "file": return say("Files here");
	}
}
/** A kind of file, as many of them are called. */
function kindWord(kind) {
	switch (kind) {
		case "doc": return say("documents");
		case "code": return say("code");
		case "page": return say("site pages");
		case "data": return say("data");
		case "picture": return say("pictures");
		case "media": return say("media and archives");
		case "other": return say("other files");
	}
}
var groupOfKind = (kind) => kind === "media" ? "picture" : kind === "other" ? "folder" : kind;
/** How many files of each kind, most first. */
function byKind(files) {
	const count = /* @__PURE__ */ new Map();
	for (const f of files) count.set(f.kind, (count.get(f.kind) ?? 0) + 1);
	return [...count.entries()].sort((a, b) => b[1] - a[1]);
}
/** A name as a part's id: letters, digits, dots and dashes, and no two alike on a level. */
function idFor(name, taken) {
	const base = name.replace(/[^\p{L}\p{N}._-]+/gu, "-").replace(/^-+|-+$/g, "") || "part";
	let id = base;
	for (let n = 2; taken.has(id); n++) id = `${base}-${n}`;
	taken.add(id);
	return id;
}
/** A document's first heading, or the name its front matter gives it. */
function titleIn(text) {
	const { front, body } = splitNote(text);
	return (typeof front.title === "string" ? front.title.trim() : "") || (/^#\s+(.+?)\s*#*\s*$/m.exec(body)?.[1] ?? "").trim();
}
/** The first paragraph of a document, as plain words. */
function leadOf(text, most = 420) {
	const { body } = splitNote(text);
	for (const block of body.split(/\n\s*\n/)) {
		const flat = block.split("\n").filter((l) => !/^\s*(#|!\[|\[!\[|<|```|---|===|\|)/.test(l)).join(" ").replace(/!?\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/[*_`>]+/g, "").replace(/\s+/g, " ").trim();
		if (flat.length > 20) return flat.length > most ? `${flat.slice(0, most - 1).trimEnd()}…` : flat;
	}
	return "";
}
/** The files of a piece whose text is read, shallow first, writing and code turn about. */
function readable$1(piece) {
	const all = piece.files.filter((f) => isRead(f.name));
	const [docs, rest] = [all.filter((f) => WRITING.has(ending(f.name))), all.filter((f) => !WRITING.has(ending(f.name)))];
	const out = [];
	for (let i = 0; i < Math.max(docs.length, rest.length); i++) {
		if (docs[i]) out.push(docs[i]);
		if (rest[i]) out.push(rest[i]);
	}
	return out;
}
/** Which files are read, a piece at a time in turn, so no large part takes every reading. */
function chosen(pieces) {
	const lines = pieces.map(readable$1);
	const out = [];
	for (let i = 0; out.length < 1500 && lines.some((l) => i < l.length); i++) for (const l of lines) if (l[i] && out.length < 1500) out.push(l[i]);
	return out;
}
/** A record of a failed run, read where a project keeps one; nothing is ever run. */
async function failedRun(door, e) {
	const read = (path) => door.readSource(path).catch(() => null);
	if (e.kids.some((k) => k.name === "test-results")) {
		const at = `${e.path}/test-results/.last-run.json`;
		try {
			const run = JSON.parse(await read(at) ?? "null");
			if (run?.status === "failed") return saying("The last recorded run of its checks failed: {0} of them. The record: {1}.", run.failedTests?.length ?? 0, at);
		} catch {}
	}
	if (e.kids.some((k) => k.name === "tests" || ending(k.name) === "py")) {
		const at = `${e.path}/.pytest_cache/v/cache/lastfailed`;
		try {
			const failed = Object.keys(JSON.parse(await read(at) ?? "{}") ?? {}).length;
			if (failed) return saying("The last recorded run of its checks failed: {0} of them. The record: {1}.", failed, at);
		} catch {}
	}
	return "";
}
/** What a folder holds, said in plain words. */
function folderWords(piece, texts, lead) {
	const kinds = byKind(piece.files);
	const n = piece.files.length;
	const s = !n ? say("An empty folder, or one not looked into") : kinds.length > 1 ? saying("Files: {0}, mostly {1}", n, kindWord(kinds[0][0])) : saying("Files: {0} — {1}", n, kindWord(kinds[0][0]));
	const d = [];
	if (lead) d.push(lead);
	const folders = piece.at.kids.filter((k) => k.dir).map((k) => k.name);
	if (folders.length) d.push(folders.length > 8 ? saying("Folders inside: {0}, and {1} more.", folders.slice(0, 8).join(", "), folders.length - 8) : saying("Folders inside: {0}.", folders.join(", ")));
	if (kinds.length > 1) d.push(saying("Files: {0}.", kinds.map(([kind, count]) => `${count} — ${kindWord(kind)}`).join("; ")));
	if (texts.length) d.push(saying("Read: {0} lines of text in {1} files.", texts.reduce((sum, t) => sum + t.lines, 0), texts.length));
	if (piece.at.git) d.push(say("It keeps a history of its own."));
	if (anyShut(piece.at)) d.push(say("It is larger than the map reads at once: not all of it was looked into."));
	return {
		s,
		d: d.join("\n\n")
	};
}
/**
* Read one folder into a level.
*
* Walk it within bounds; read the text of what is writing, code or a page; draw a link wherever a
* file of one part names a file of another; and bring the panel's record of each part up to date.
*/
async function readLevel(door, key, opts) {
	const folder = folderOfKey(key);
	const told = opts.told ?? (() => {});
	const walked = await walk(door, folder, opts.bounds ?? BOUNDS, (done, of) => told({
		stage: "folders",
		done,
		of
	}));
	const top = walked.root.kids;
	const taken = /* @__PURE__ */ new Set();
	const pieces = [];
	for (const e of top.filter((k) => k.dir)) {
		const files = filesUnder(e);
		const kinds = byKind(files);
		const leading = kinds.length && kinds[0][1] * 2 >= files.length ? kinds[0][0] : "other";
		pieces.push({
			id: idFor(e.name, taken),
			is: "folder",
			at: e,
			files,
			kind: leading,
			group: isProject(e) ? "project" : groupOfKind(leading)
		});
	}
	const loose = top.filter((k) => !k.dir);
	if (loose.length <= 300) for (const e of loose) pieces.push({
		id: idFor(e.name, taken),
		is: "file",
		at: e,
		files: [e],
		kind: e.kind,
		group: "file"
	});
	else for (const [kind] of byKind(loose)) pieces.push({
		id: idFor(`files-${kind}`, taken),
		is: "files",
		at: walked.root,
		files: loose.filter((f) => f.kind === kind),
		kind,
		group: "file"
	});
	/**
	* The level as the texts read so far give it. `whole` is the reading's end: only then is a
	* failed run looked for and the panel's own record of each part brought up to date.
	*/
	const made = async (texts, whole) => {
		const pieceOf = /* @__PURE__ */ new Map();
		for (const p of pieces) if (p.is === "folder") pieceOf.set(p.at.name, p);
		else for (const f of p.files) pieceOf.set(f.name, p);
		const below = (path) => {
			const rest = folder ? path.startsWith(`${folder}/`) ? path.slice(folder.length + 1) : null : path;
			return rest === null ? void 0 : pieceOf.get(rest.split("/")[0]);
		};
		const found = {
			paths: walked.paths,
			byName: namesOf(walked.paths)
		};
		const weight = /* @__PURE__ */ new Map();
		for (const t of texts.values()) {
			const from = below(t.path);
			if (!from) continue;
			for (const ref of t.refs) {
				const hit = resolve(ref, t.path, found);
				const to = hit ? below(hit) : void 0;
				if (!to || to === from) continue;
				const pair = from.id < to.id ? `${from.id}\n${to.id}` : `${to.id}\n${from.id}`;
				weight.set(pair, (weight.get(pair) ?? 0) + 1);
			}
		}
		const ranked = [...weight.entries()].sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]));
		const edges = (ranked.length > pieces.length ? ranked.filter(([, n]) => n >= 2) : ranked).slice(0, Math.max(12, pieces.length * 2)).map(([pair]) => pair.split("\n"));
		const groups = ORDER.filter((g) => pieces.some((p) => p.group === g));
		const nodes = [];
		for (const p of pieces) {
			const part = blankPart(p.id, p.is === "files" ? folder : p.at.path);
			const mine = p.files.map((f) => texts.get(f.path)).filter((t) => !!t);
			part.is = p.is;
			part.g = groups.indexOf(p.group);
			part.f = p.files.slice(0, 12).map((f) => f.path);
			if (p.is === "folder") {
				const readme = p.at.kids.find((k) => !k.dir && /^readme(\.|$)/i.test(k.name));
				const words = folderWords(p, mine, readme ? leadOf(texts.get(readme.path)?.kept ?? "") : "");
				part.t = p.at.name;
				part.s = words.s;
				part.d = words.d;
				part.kids = p.at.kids.length ? p.at.path : null;
				part.text = readme && isRead(readme.name) ? readme.path : void 0;
				if (p.group === "project") {
					const why = whole ? await failedRun(door, p.at) : "";
					if (why) Object.assign(part, {
						broken: true,
						by: "check",
						why
					});
				}
			} else if (p.is === "file") {
				const text = texts.get(p.at.path);
				part.t = text?.kept && titleIn(text.kept) || p.at.name;
				part.s = text ? saying("{0} — lines: {1}", p.at.name, text.lines) : p.at.name;
				part.d = text?.kept ? leadOf(text.kept) : "";
				part.text = isRead(p.at.name) ? p.at.path : void 0;
			} else {
				part.t = saying("{0}: {1} of them", kindWord(p.kind), p.files.length);
				part.s = saying("Files of one kind, directly in this folder: {0}", p.files.length);
				part.d = p.files.length > 12 ? saying("The first of them: {0}, and {1} more.", p.files.slice(0, 12).map((f) => f.name).join(", "), p.files.length - 12) : p.files.map((f) => f.name).join(", ");
			}
			if (whole && !(p.is === "folder" && anyShut(p.at))) {
				const print = printOf(p.files.map((f) => `${f.path}:${texts.get(f.path)?.print ?? ""}`).join("\n"));
				const row = opts.seen[part.note || p.id];
				const next = !row ? {
					p: print,
					first: opts.today
				} : row.p === print ? row : {
					p: print,
					first: row.first,
					on: opts.today
				};
				opts.seen[part.note || p.id] = next;
				part.seen = next.first;
				if (next.on) {
					part.changedOn = next.on;
					part.changedLine = say("Its files differ from what the map read the time before.");
					part.changed = thisWeek(next.on, opts.today);
				}
			}
			nodes.push(part);
		}
		nodes.sort((a, b) => a.g - b.g || a.id.localeCompare(b.id));
		const parent = key === "root" ? null : key.includes("/") ? key.slice(0, key.lastIndexOf("/")) : ROOT;
		return {
			key,
			title: opts.title,
			kind: "project",
			parent,
			folder,
			frames: groups.map((g) => ({ t: groupWord(g) })),
			nodes,
			edges,
			cut: walked.cut,
			...whole ? {} : { early: true }
		};
	};
	opts.early?.(await made(/* @__PURE__ */ new Map(), false));
	const wanted = chosen(pieces);
	let done = 0;
	let letters = 0;
	told({
		stage: "files",
		done: 0,
		of: wanted.length
	});
	const read = await pool(wanted, (opts.bounds ?? BOUNDS).wide, async (e) => {
		const text = letters > 24e6 ? null : await door.readSource(e.path).catch(() => null);
		done += 1;
		told({
			stage: "files",
			done,
			of: wanted.length
		});
		if (text === null) return null;
		letters += text.length;
		return {
			path: e.path,
			print: printOf(text),
			lines: text.split("\n").length,
			refs: refsOf(e.path, text),
			kept: WRITING.has(ending(e.name)) ? text.slice(0, KEPT_MOST) : ""
		};
	});
	const texts = /* @__PURE__ */ new Map();
	for (const t of read) if (t) texts.set(t.path, t);
	return {
		level: await made(texts, true),
		docs: [...texts.values()].filter((t) => t.kept.startsWith("---")).map((t) => ({
			path: t.path,
			text: t.kept
		})),
		files: filesUnder(walked.root).length,
		read: texts.size,
		paths: walked.paths
	};
}
/**
* A level named in plain words where the project has notes about it.
*
* `project-notes/map/<part>.md`, written by an agent or by hand, is optional and never asked for:
* where one is there for a part, its title, its sentence, its words, its group, what waits for the
* owner and the broken fact it records are taken; what the panel read itself stays — the files,
* the inside, the links, the record of change.
*/
function dressed(level, notes) {
	if (!notes?.nodes.length) return level;
	const by = new Map(notes.nodes.map((n) => [n.id.toLowerCase(), n]));
	const frames = [...notes.frames.filter((f) => notes.nodes.some((n) => notes.frames[n.g] === f && level.nodes.some((p) => p.id.toLowerCase() === n.id.toLowerCase())))];
	const groupAt = (title) => {
		const at = frames.findIndex((f) => f.t === title);
		return at >= 0 ? at : frames.push({ t: title }) - 1;
	};
	const nodes = level.nodes.map((p) => {
		const note = by.get(p.id.toLowerCase());
		const g = groupAt(note ? notes.frames[note.g]?.t ?? level.frames[p.g].t : level.frames[p.g].t);
		if (!note) return {
			...p,
			g
		};
		const fact = note.broken ? {
			broken: true,
			by: note.by,
			why: note.why
		} : {};
		return {
			...p,
			g,
			t: note.t,
			s: note.s || p.s,
			d: note.d || p.d,
			waits: note.waits,
			waitsFor: note.waitsFor,
			mem: note.mem,
			born: note.born,
			about: note.note,
			text: note.note,
			...fact
		};
	});
	nodes.sort((a, b) => a.g - b.g || a.id.localeCompare(b.id));
	return {
		...level,
		title: notes.title || level.title,
		frames,
		nodes
	};
}
//#endregion
//#region plugins/map/source.ts
/**
* One folder of the map, read whole: its `_map.md`, every part's note, and which parts have an
* inside — a folder named by a part's slug with at least one note in it.
*/
async function readFolder(door, folder) {
	const names = (await door.listSource(folder).catch(() => [])).slice().sort();
	const notes = [];
	for (const name of names.filter(isPartNote)) {
		const text = await door.readSource(`${folder}/${name}`).catch(() => null);
		if (text !== null) notes.push({
			name,
			text
		});
	}
	const map = names.includes("_map.md") ? await door.readSource(`${folder}/${MAP_NOTE}`).catch(() => null) : null;
	const slugs = new Set(notes.map((n) => n.name.replace(/\.md$/i, "")));
	const insides = [];
	for (const name of names) if (mayBeInside(name) && slugs.has(name)) {
		if ((await door.listSource(`${folder}/${name}`).catch(() => [])).some(isPartNote)) insides.push(name);
	}
	return {
		map,
		notes,
		insides
	};
}
/** What a read looked like, so the next one can be told from it without keeping two copies. */
function fingerprint(read) {
	if (read === null || typeof read === "string") return read ?? "";
	return JSON.stringify([
		read.map,
		read.notes.map((n) => [n.name, n.text]),
		read.insides
	]);
}
var wall = {
	set: (fn, ms) => setTimeout(fn, ms),
	clear: (h) => clearTimeout(h)
};
/** How often the panel looks at the notes while it is on the screen. */
var LOOK_EVERY_MS = 3e3;
/** A look reads every note of the folder: a folder of hundreds is looked at less often, never rarer than this. */
var LOOK_RAREST_MS = 2e4;
/** How long to wait before the next look at a folder of so many notes. */
function lookEvery(notes) {
	return Math.min(LOOK_RAREST_MS, Math.max(LOOK_EVERY_MS, notes * 30));
}
/** While the panel rests — nobody has touched it for a while — it looks this rarely at the least. */
var LOOK_RESTING_MS = 15e3;
/** And never more rarely than this, however many notes there are. */
var LOOK_RESTING_RAREST_MS = 6e4;
/** How long a resting panel waits before the next look at a folder of so many notes (FM-MAP-34). */
function lookEveryResting(notes) {
	return Math.min(LOOK_RESTING_RAREST_MS, Math.max(LOOK_RESTING_MS, lookEvery(notes) * 4));
}
/**
* Look again and again, and say when what was read is not what was read before.
*
* `look` reads whatever is on the screen now and answers its fingerprint with the read itself;
* `changed` is called with a read whose fingerprint differs from the last one seen — the first
* read included. One look at a time: a look still reading when the clock comes round is waited
* for, not doubled. Nothing is read while `visible` says no; a panel in a tab behind others costs
* nothing, and its first look on coming back is at once (`now`).
*/
function watch(opts) {
	const clock = opts.clock ?? wall;
	const every = () => typeof opts.every === "function" ? opts.every() : opts.every ?? 3e3;
	let last = null;
	let looking = false;
	let again = false;
	let stopped = false;
	let timer = null;
	const next = () => {
		if (stopped) return;
		clock.clear(timer);
		timer = clock.set(tick, every());
	};
	const tick = () => {
		if (stopped) return;
		clock.clear(timer);
		if (!opts.visible()) return next();
		if (looking) {
			again = true;
			return;
		}
		looking = true;
		opts.look().then(({ print, read }) => {
			if (stopped || print === last) return;
			last = print;
			opts.changed(read);
		}).catch(() => {}).finally(() => {
			looking = false;
			if (again) {
				again = false;
				tick();
			} else next();
		});
	};
	tick();
	return {
		now: tick,
		stop: () => {
			stopped = true;
			clock.clear(timer);
		}
	};
}
/** How long a reading's marks are kept: longer than the window its pace is taken over. */
var MARKS_KEPT_MS = 12e3;
/**
* The memory as it is kept between openings: every note's title, its one line, its links, its
* dates and its marks — what the map is drawn from — and not the words of the notes themselves.
*
* The first version kept the export whole, so a copy of everything the person's agent remembers
* lay in the settings folder, and would have left the machine with a backup of the settings (the
* live run of 10 October 2026, FM-MAP-68). The words are in the folder; they are read from there
* again a moment after the panel opens, and a card shows them from then on.
*/
function withoutWords(json) {
	try {
		const data = JSON.parse(json);
		if (!Array.isArray(data.nodes)) return json;
		return JSON.stringify({
			...data,
			nodes: data.nodes.map((n) => n && typeof n === "object" ? {
				...n,
				d: ""
			} : n)
		});
	} catch {
		return json;
	}
}
function openBook(host) {
	const { door, keep } = host;
	/** Levels as read, before the project's own notes name them. */
	const raw = new Map(Object.entries(keep.get("levels") ?? {}));
	const seen = keep.get("seen") ?? {};
	const marks = keep.get("marks") ?? {};
	const took = keep.get("took") ?? {};
	const notes = /* @__PURE__ */ new Map();
	const names = /* @__PURE__ */ new Map();
	const readAt = /* @__PURE__ */ new Map();
	let worldJson = keep.get("world");
	let world = null;
	/** Whether the folder was looked through for memory notes, this opening or one before. */
	let memoryLooked = keep.get("memoryLooked") ?? false;
	const failedAt = /* @__PURE__ */ new Map();
	/**
	* The readings in hand, the newest last. Two at most: a folder gone into while the folder above
	* it is still being read for the first time is read at once, beside it — a press that seemed
	* dead for eighteen seconds and then acted by itself is what waiting its turn looked like (the
	* tester's run of 10 October 2026, FM-MAP-77).
	*/
	const going = [];
	const BESIDE_MOST = 2;
	let stripAt = 0;
	let waiting = null;
	let stopped = false;
	const opts = () => ({
		today: host.today(),
		title: say("Memory"),
		ungrouped: say("Other")
	});
	const remake = () => void (world = worldJson ? readMemory(worldJson, opts()) : null);
	remake();
	/** The owner's own mark on a part no note names: kept by the panel, with the folder's reading. */
	const marked = (p) => p.about || p.broken || !(p.note in marks) ? p : {
		...p,
		broken: true,
		by: "person",
		why: marks[p.note]
	};
	/** The names in a folder, as one line: what a cheap look compares. */
	const namesIn = async (folder) => (await door.listSource(asked(folder)).catch(() => [])).filter((n) => !skipped(n)).sort().join("\n");
	/** The project's own notes about a level, where it has any. */
	async function readNotes(key) {
		const read = await readFolder(door, folderOf(key));
		const print = fingerprint(read);
		if (notes.get(key)?.print === print) return false;
		const any = read.notes.length > 0 || read.map !== null;
		notes.set(key, {
			print,
			level: any ? buildLevel(key, read, {
				today: host.today(),
				title: "",
				ungrouped: say("Other")
			}) : null
		});
		return true;
	}
	async function readMemoryWorld(got, mine) {
		const folders = memoryFolders(got.docs, got.paths);
		let json = null;
		if (folders.length) {
			Object.assign(mine, {
				began: Date.now(),
				since: void 0,
				marks: void 0,
				stage: "files",
				done: 0,
				of: 0,
				memory: true
			});
			const { notes: found, index } = await readMemoryNotes(door, folders, (done, of) => {
				Object.assign(mine, {
					done,
					of
				});
				host.redraw("strip");
			});
			if (found.length) json = memoryExport(found, index, host.today());
		}
		json ??= await door.readSource(MEMORY_FILE).catch(() => null);
		memoryLooked = true;
		keep.set("memoryLooked", true);
		if (json === worldJson) return;
		worldJson = json;
		if (json === null) keep.forget(["world"]);
		else keep.set("world", withoutWords(json));
		remake();
	}
	async function run(key) {
		const began = Date.now();
		const mine = {
			key,
			began,
			last: took[key] ?? 0,
			stage: "folders",
			done: 0,
			of: 0
		};
		going.push(mine);
		host.redraw("strip");
		const tick = setInterval(() => host.redraw("strip"), 1e3);
		try {
			const title = key === "root" ? host.name : key.split("/").pop() ?? key;
			const got = await readLevel(door, key, {
				today: host.today(),
				title,
				seen,
				bounds: host.bounds,
				early: (level) => {
					if (stopped || raw.has(key)) return;
					raw.set(key, level);
					host.redraw("map");
				},
				told: (t) => {
					const now = Date.now();
					const turned = mine.stage !== t.stage;
					if (turned) Object.assign(mine, {
						since: now,
						marks: []
					});
					Object.assign(mine, t);
					const marks = mine.marks ??= [];
					marks.push([now, t.done]);
					while (marks.length > 2 && marks[1][0] <= now - MARKS_KEPT_MS) marks.shift();
					if (now - stripAt < 100 && t.done < t.of && !turned) return;
					stripAt = now;
					host.redraw("strip");
				}
			});
			if (stopped) return;
			const past = await readPast(door, folderOfKey(key));
			raw.set(key, {
				...got.level,
				past
			});
			names.set(key, await namesIn(folderOfKey(key)));
			await readNotes(key);
			took[key] = Date.now() - began;
			readAt.set(key, Date.now());
			keep.set("levels", Object.fromEntries([...raw.entries()].slice(-40)));
			keep.set("seen", seen);
			keep.set("took", took);
			host.redraw("map");
			if (key === "root") await readMemoryWorld(got, mine);
		} catch {
			failedAt.set(key, Date.now());
		}
		clearInterval(tick);
		going.splice(going.indexOf(mine), 1);
		if (stopped) return;
		host.redraw("map");
		const next = waiting;
		waiting = null;
		if (next !== null) run(next);
	}
	/** Have a folder read: now, or as soon as the reading in hand is over. */
	function ask(key) {
		if (stopped || going.some((r) => r.key === key) || Date.now() - (failedAt.get(key) ?? -3e4) < 3e4) return;
		if (going.length >= BESIDE_MOST || going.length && raw.has(key)) waiting = key;
		else run(key);
	}
	return {
		ask,
		/** The reading the strip speaks of: the newest of those in hand. */
		reading: () => going[going.length - 1] ?? null,
		has: (key) => raw.has(key),
		world: () => world,
		/** No memory is drawn: still being looked for, or not in this folder. */
		memoryLooked: () => memoryLooked,
		took: (key) => took[key] ?? 0,
		/** A level as it is drawn: what was read, named by the project's notes where there are any, with the owner's marks. */
		level(key) {
			const read = raw.get(key);
			if (!read) return null;
			const level = dressed(read, notes.get(key)?.level ?? null);
			return {
				...level,
				title: level.title || read.title,
				nodes: level.nodes.map(marked)
			};
		},
		/**
		* A look at the folder on the screen. Cheap: its names and the project's notes about it. A name
		* that came or went has the folder read again at once; and it is read again anyway when it was
		* last read long enough ago. Answers whether what is drawn changed without a reading.
		*/
		async look(key, resting) {
			if (stopped) return false;
			if (!raw.has(key) || readAt.get(key) === void 0) {
				ask(key);
				return await readNotes(key) && raw.has(key);
			}
			const dressedAnew = await readNotes(key);
			if (await namesIn(folderOfKey(key)) !== names.get(key) || Date.now() - (readAt.get(key) ?? 0) >= (resting ? 6e5 : 12e4)) ask(key);
			return dressedAnew;
		},
		/** The person asks for the folder again, now: after allowing access, for instance. */
		retry() {
			if (!raw.get("root")?.nodes.length) raw.delete(ROOT);
			readAt.delete(ROOT);
			failedAt.delete(ROOT);
			ask(ROOT);
		},
		/** The owner's own mark on a part that no note names: set with their words, or cleared. */
		mark(part, why) {
			if (why === null) delete marks[part.note];
			else marks[part.note] = why;
			keep.set("marks", marks);
			host.redraw("map");
		},
		stop() {
			stopped = true;
		}
	};
}
//#endregion
//#region plugins/map/chrome.ts
/** The seven views, in the order of the row under the map. */
var SKINS = [
	"graph",
	"blueprint",
	"space",
	"bubbles",
	"history",
	"globe",
	"city"
];
/** A view's name on its button. */
function skinWord(skin) {
	switch (skin) {
		case "graph": return say("Graph");
		case "blueprint": return say("Blueprint");
		case "space": return say("Space");
		case "bubbles": return say("Bubbles");
		case "history": return say("History");
		case "globe": return say("Globe");
		case "city": return say("City");
	}
}
/** The view to open on: the one remembered, if it is still one of ours. */
function skinOr(kept) {
	return SKINS.includes(kept) ? kept : "graph";
}
/**
* The dock of views over the bottom of the map: an icon and a name each, the one in force on the
* sky gradient. Where the map is narrow only that one keeps its name; the rest say theirs on hover
* (the design of 15 October 2026, FM-MAP-81).
*/
function skinsHtml(on) {
	return SKINS.map((s) => `<button type="button" data-skin="${s}" class="${s === on ? "on" : ""}" aria-pressed="${s === on}" title="${plain(skinWord(s))}">${icon(s)}<span>${plain(skinWord(s))}</span></button>`).join("");
}
/** A tab's word, in the world's own vocabulary. */
function modeWord(mode, memory) {
	if (memory) switch (mode) {
		case "all": return say("All the memory");
		case "bad": return say("Broken links");
		case "changed": return say("New this week");
		case "wait": return say("Not checked for long");
	}
	switch (mode) {
		case "all": return say("All");
		case "bad": return say("Broken");
		case "changed": return say("Changed this week");
		case "wait": return say("Waiting for your word");
	}
}
/**
* The four filters as chips, each but "all" with its number — nought too: "Broken 0" is news worth
* a glance. Broken is red and waiting amber only once pressed; at rest only their numbers are
* (the design of 15 October 2026, FM-MAP-81).
*/
function tabsHtml(level, on) {
	const c = counts(level.nodes);
	const memory = level.kind === "memory";
	const tab = (mode, cls, n) => `<button type="button" data-mode="${mode}" class="${[
		"chip",
		cls,
		mode === on ? "on" : ""
	].join(" ").trim()}" aria-pressed="${mode === on}">${plain(modeWord(mode, memory))}${n === null ? "" : ` <em>${n}</em>`}</button>`;
	return tab("all", "", null) + tab("bad", "b", c.bad) + tab("changed", "", c.changed) + tab("wait", "w", c.wait);
}
/** The two worlds: the project, and what the agent remembers. */
function worldsHtml(memory) {
	return `<button type="button" data-world="project" class="${memory ? "" : "on"}" aria-pressed="${!memory}">${plain(say("Project"))}</button><button type="button" data-world="memory" class="${memory ? "on" : ""}" aria-pressed="${memory}">${plain(say("Memory"))}</button>`;
}
/** The way back: every level from the top down to this one, the last of them not a link. */
function crumbsHtml(key, titleOf, memory) {
	if (memory) return "";
	const path = trail(key);
	return path.map((k, i) => i < path.length - 1 ? `<button type="button" data-level="${plain(k)}">${plain(titleOf(k))}</button><i>›</i>` : i > 0 ? `<button type="button" data-level="${plain(k)}" class="here" aria-current="location">${plain(titleOf(k))}</button>` : `<span>${plain(titleOf(k))}</span>`).join("");
}
/** The sketch over the first screen: a few parts and their links, drifting as a map does. */
var SKETCH = `<div class="sketch" aria-hidden="true"><svg viewBox="0 0 100 100" preserveAspectRatio="none"><line x1="18" y1="30" x2="42" y2="62"/><line x1="42" y1="62" x2="70" y2="28"/><line x1="42" y1="62" x2="56" y2="78"/><line x1="70" y1="28" x2="86" y2="58"/><line x1="30" y1="80" x2="42" y2="62"/></svg>${[
	[18, 30],
	[42, 62],
	[70, 28],
	[56, 78],
	[86, 58],
	[30, 80]
].map(([x, y], i) => `<i style="left:calc(${x}% - 5px);top:calc(${y}% - 5px);--dx:${(i % 2 ? -1 : 1) * 5}px;--dy:${(i % 3 - 1) * 4}px;animation-delay:${-i}s"></i>`).join("")}</div>`;
/**
* What is said when there is nothing to draw: a card on the dotted ground, a title, a sentence, and
* the one thing to do. Nothing here asks anybody for a map: the panel reads the folder itself
* (FM-MAP-44). `canChoose`: the window lets the person point at another folder.
*
* "emptyRoot" is the top of the folder answering no names. The window lists an empty folder and
* one the system refuses alike, with no names, and a plugin asks nothing of the program to tell
* them apart (Gary's rule 14: a plugin fix never goes into the core). So the screen says both,
* honestly, and offers the two things that help either way (FM-MAP-82).
*/
function emptyHtml(what, canChoose) {
	if (what === "reading") return `<section class="empty"><p role="status">${plain(say("Reading the folder…"))}</p></section>`;
	const go = (label, act = "choose") => `<button type="button" class="go" data-act="${act}">${icon("folder")}<span>${plain(label)}</span></button>`;
	const box = (inner) => `<section class="empty"><div class="box">${inner}</div></section>`;
	if (what === "folder") return box(`${SKETCH}<h1>${plain(say("The map needs a folder"))}</h1><p>${plain(say("I'll show what it is made of, what is broken and what waits for you. I change nothing and ask nobody."))}</p><div class="row">${canChoose ? `${go(say("Choose a folder"))}<small>${plain(say("or open the map in a tab whose terminal stands in the folder"))}</small>` : `<small>${plain(say("Open the map in a tab whose terminal stands in the folder."))}</small>`}</div>`);
	if (what === "emptyRoot") return box(`<span class="sign">${icon("folder")}</span><h1>${plain(say("The folder is empty or vobuda has no access to it"))}</h1><p class="hint">${plain(say("macOS asks once. If the answer was no, allow vobuda in System Settings → Privacy & Security → Files and Folders, then try again."))}</p><div class="row"><button type="button" class="go" data-act="retry"><span>${plain(say("Try again"))}</span></button>${canChoose ? `<button type="button" class="btn" data-act="choose">${plain(say("Another folder"))}</button>` : ""}</div>`);
	if (what === "empty") return box(`<h1>${plain(say("Nothing to draw in this folder"))}</h1><p>${plain(say("The map found no folders and no files of yours here. What is hidden, fetched or built — names with a dot in front, packages, build outputs — is passed by."))}</p>${canChoose ? `<div class="row">${go(say("Choose another folder"))}</div>` : ""}`);
	return box(`<h1>${plain(say("No memory notes are in this folder"))}</h1>
      <p>${plain(say("The map reads memory notes straight from the folder it is opened in. What an agent remembers elsewhere on this machine cannot be seen from here: a panel reads only its own folder."))}</p>
      <p class="hint">${plain(say("Open the map in the folder that holds the memory, or choose it, and the notes are drawn by themselves."))}</p>${canChoose ? `<div class="row">${go(say("Choose another folder"))}</div>` : ""}`);
}
/** The label of "only about this project", with its cross. */
function onlyWord(projectTitle) {
	return saying("Only about {0}", projectTitle);
}
//#endregion
//#region plugins/map/keep.ts
/** The three things a view remembers: where parts were put, where the sheet was moved, how the camera stood. */
var PLACE_KINDS = [
	"pos",
	"view",
	"cam"
];
/** The key one view's places of one level are kept under. */
function placeKey(level, skin, kind) {
	return `${level}:${skin}:${kind}`;
}
/** What "Lay out again" forgets: the view on the screen, on the level on the screen. */
function layoutKeys(level, skin) {
	return PLACE_KINDS.map((kind) => placeKey(level, skin, kind));
}
/** A file name for a project's places: its folder's name, and a short hash of the whole path. */
function fileFor(project) {
	let h = 2166136261;
	for (let i = 0; i < project.length; i++) h = Math.imul(h ^ project.charCodeAt(i), 16777619) >>> 0;
	return `${(project.split(/[\\/]/).filter(Boolean).pop() ?? "project").replace(/[^A-Za-z0-9_-]+/g, "-").slice(0, 40).replace(/^-+|-+$/g, "") || "project"}-${h.toString(16)}.json`;
}
/** A table kept in memory, written through `write` a moment after the last change. */
function tableKeep(start, write, wait = 400) {
	const table = { ...start };
	let timer = null;
	let going = Promise.resolve();
	const save = () => {
		timer = null;
		going = going.then(() => write(JSON.stringify(table))).catch(() => {});
	};
	const later = () => {
		if (timer) clearTimeout(timer);
		timer = setTimeout(save, wait);
	};
	return {
		get: (key) => key in table ? table[key] : null,
		set: (key, value) => {
			table[key] = value;
			later();
		},
		forget: (keys) => {
			for (const key of keys) delete table[key];
			later();
		},
		flushed: () => {
			if (timer) {
				clearTimeout(timer);
				save();
			}
			return going;
		}
	};
}
var parsed = (text) => {
	try {
		const value = text ? JSON.parse(text) : {};
		return value && typeof value === "object" && !Array.isArray(value) ? value : {};
	} catch {
		return {};
	}
};
/**
* The keep for one file: the plugin's work folder; else the page's own storage; else this page's
* life. A window that cannot keep anything still draws the map — it only forgets.
*/
async function openKeep(api, file, where = "places") {
	if (typeof api?.workFolder === "function") try {
		const folder = await api.workFolder(where);
		return tableKeep(parsed(await folder.read(file)), (text) => folder.write(file, text));
	} catch (err) {
		api.log?.(`the map's places have no work folder — ${String(err)}`);
	}
	try {
		const storage = globalThis.localStorage;
		const key = `map.${where}.${file}`;
		return tableKeep(parsed(storage.getItem(key)), async (text) => storage.setItem(key, text));
	} catch {
		return tableKeep({}, async () => {});
	}
}
/**
* Where every card stands to begin with: a column to a group, cards down it in order.
*
* A big map's group would be a column a hundred cards tall, so there a group takes as many
* columns as it needs, twenty-two cards each, and the next group starts after them.
*/
function homes(level, big) {
	const out = {};
	let column = 0;
	for (let g = 0; g < Math.max(1, level.frames.length); g++) {
		const members = level.nodes.filter((n) => n.g === g);
		const rows = big ? 22 : Math.max(1, members.length);
		members.forEach((n, i) => {
			out[n.id] = [20 + 215 * (column + Math.floor(i / rows)), 70 + 104 * (i % rows)];
		});
		column += Math.max(1, Math.ceil(members.length / rows));
	}
	for (const n of level.nodes) out[n.id] ??= [20 + 215 * column, 70];
	return out;
}
/**
* The line from card A to card B, as a path.
*
* Side to side when the cards are in different columns. In one column, top to bottom — unless
* another card stands between them, and then the line goes round by the right, bowing further the
* further apart they are, so it never runs under a card it has nothing to do with.
*/
function route(a, b, others, big) {
	const [ax, ay] = [a[0] + 90, a[1] + 27];
	const [bx, by] = [b[0] + 90, b[1] + 27];
	const dx = bx - ax;
	const dy = by - ay;
	if (Math.abs(dx) > 108) {
		const x1 = dx > 0 ? a[0] + 180 : a[0];
		const x2 = dx > 0 ? b[0] : b[0] + 180;
		const m = (x1 + x2) / 2;
		return `M${x1},${ay} C${m},${ay} ${m},${by} ${x2},${by}`;
	}
	const top = dy > 0 ? a : b;
	const bot = dy > 0 ? b : a;
	if (!big && others.some((c) => c !== a && c !== b && Math.abs(c[0] - top[0]) < 180 * .7 && c[1] > top[1] + 10 && c[1] < bot[1] - 10)) {
		const x = Math.max(top[0], bot[0]) + 180;
		const y1 = top[1] + 27;
		const y2 = bot[1] + 27;
		const k = 16 + (y2 - y1) / 104 * 5;
		return `M${top[0] + 180},${y1} C${x + k},${y1} ${x + k},${y2} ${bot[0] + 180},${y2}`;
	}
	const m = (top[1] + 54 + bot[1]) / 2;
	const tx = top[0] + 90;
	const bx2 = bot[0] + 90;
	return `M${tx},${top[1] + 54} C${tx},${m} ${bx2},${m} ${bx2},${bot[1]}`;
}
/**
* The numbers of a line `route` drew — its one curve, `M x,y C x,y x,y x,y` — for the dot that runs
* along it. Read once when the line is drawn, not at every frame.
*/
function curveOf(d) {
	return d.match(/-?\d+(?:\.\d+)?/g)?.map(Number) ?? [];
}
/**
* A point `t` of the way along such a curve, written into `out`.
*
* Worked out from the numbers, not asked of the screen: a path can say where its points are only
* once it is drawn, and the dot is placed before that.
*/
function alongCurve(n, t, out) {
	if (n.length < 8) {
		out[0] = n[0] ?? 0;
		out[1] = n[1] ?? 0;
		return out;
	}
	const u = 1 - t;
	const a = u * u * u;
	const b = 3 * u * u * t;
	const c = 3 * u * t * t;
	const e = t * t * t;
	out[0] = a * n[0] + b * n[2] + c * n[4] + e * n[6];
	out[1] = a * n[1] + b * n[3] + c * n[5] + e * n[7];
	return out;
}
/** The box a group draws round its cards, with room for its title above them. */
function frameBox(members) {
	const x = Math.min(...members.map((m) => m[0])) - 12;
	const y = Math.min(...members.map((m) => m[1])) - 42;
	return {
		x,
		y,
		width: Math.max(...members.map((m) => m[0])) + 180 + 12 - x,
		height: Math.max(...members.map((m) => m[1])) + 54 + 24 - y
	};
}
/**
* A line of a card cut to what the card holds, with an ellipsis.
*
* The sketch's summaries were a few words; a real note's is a sentence, and a sentence ran out of
* its card across the next one (FM-MAP-24). Counted in letters, because an SVG text cannot be
* asked its width before it is on a screen; the card also clips, for the letters that are wide.
*/
function fitted(text, letters) {
	const flat = text.replace(/\s+/g, " ").trim();
	return flat.length <= letters ? flat : `${flat.slice(0, Math.max(1, letters - 1)).trimEnd()}…`;
}
/**
* A place for a card where no card stands: the place wanted, or the nearest free slot to it.
*
* A part the agent adds after the owner has moved cards about used to be drawn at its starting
* place whatever stood there, and a card left on that place hid it whole (FM-MAP-33).
*/
function freePlace(want, taken) {
	const hit = (p) => taken.some((t) => Math.abs(t[0] - p[0]) < 188 && Math.abs(t[1] - p[1]) < 62);
	if (!hit(want)) return want;
	const tries = [];
	for (let i = -8; i <= 8; i++) for (let j = -12; j <= 12; j++) {
		const at = [want[0] + i * 215, want[1] + j * 104];
		if (at[0] >= 0 && at[1] >= 40) tries.push({
			at,
			far: Math.abs(i) * 215 * 1.5 + Math.abs(j) * 104 + (j < 0 ? 1 : 0)
		});
	}
	return tries.sort((a, b) => a.far - b.far).find((t) => !hit(t.at))?.at ?? want;
}
/** A title in the two rows a card holds when it is seen from afar, in letters large enough to tell cards apart. */
function farRows(title, letters = 11) {
	const rows = [];
	let row = "";
	for (const word of title.replace(/\s+/g, " ").trim().split(" ")) {
		const joined = `${row} ${word}`.trim();
		if (joined.length > letters && row) {
			rows.push(row);
			row = word;
		} else row = joined;
	}
	rows.push(row);
	const two = rows.slice(0, 2);
	if (rows.length > 2) two[1] = `${two[1]} ${rows[2]}`;
	return two.map((r) => fitted(r, letters + 1));
}
//#endregion
//#region plugins/map/look.ts
/** A plain hex or `rgb()` / `rgba()` as numbers; null for anything else. */
function parseColour(colour) {
	const c = (colour ?? "").trim();
	const hex = /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.exec(c);
	if (hex) {
		const h = hex[1].length === 3 ? [...hex[1]].map((x) => x + x).join("") : hex[1].slice(0, 6);
		return [
			0,
			2,
			4
		].map((i) => parseInt(h.slice(i, i + 2), 16));
	}
	const fn = /^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(c);
	if (!fn) return null;
	const rgb = [
		fn[1],
		fn[2],
		fn[3]
	].map(Number);
	return rgb.some((v) => !Number.isFinite(v)) ? null : rgb.map((v) => Math.min(255, Math.max(0, v)));
}
/** Numbers as a hex colour. */
function hex(rgb) {
	return `#${rgb.map((v) => Math.round(Math.min(255, Math.max(0, v))).toString(16).padStart(2, "0")).join("")}`;
}
/** `t` of the way from one colour to another. */
function mix(from, to, t) {
	return from.map((v, i) => v + (to[i] - v) * t);
}
/** A colour's relative luminance. */
function luminance(rgb) {
	const [r, g, b] = rgb.map((v) => {
		const x = v / 255;
		return x <= .03928 ? x / 12.92 : ((x + .055) / 1.055) ** 2.4;
	});
	return .2126 * r + .7152 * g + .0722 * b;
}
/** White or near-black, whichever stands further from a fill (FM-THEME-21). */
function onFill(fill) {
	const y = luminance(fill);
	return 1.05 / (y + .05) >= (y + .05) / .0552 ? "#ffffff" : "#101010";
}
/** A wall or a roof of the city: a colour darkened by `k`, after `w` of the way to white. */
function tint(colour, k, w = 0) {
	return `rgb(${(parseColour(colour) ?? [
		128,
		128,
		128
	]).map((v) => Math.round((v + (255 - v) * w) * k)).join(",")})`;
}
/** The sketch's own two palettes: what a window that names no colours gets. */
var OWN = {
	light: {
		bg: "#ffffff",
		fg: "#1c2733",
		accent: "#2a6c94",
		bad: "#c8402f",
		wait: "#b7791f"
	},
	dark: {
		bg: "#18212b",
		fg: "#e7eef5",
		accent: "#62b4e6",
		bad: "#ef6a57",
		wait: "#e7b24a"
	}
};
/**
* The palette for the window's colours now in force.
*
* Dark or light is read off the ground, not asked: a look is dark when what it draws on is. Every
* derived shade is a mix of two colours the look names, so a look with a green accent gets green
* groups and a look with a warm ground gets a warm canvas — nobody tuned them one by one.
*/
function paletteFor(tokens) {
	const named = (key) => parseColour(tokens[key]);
	const ground = named("--app-bg") ?? named("--panel-bg");
	const text = named("--app-fg") ?? named("--panel-fg");
	const dark = ground ? luminance(ground) < .2 : text ? luminance(text) > .4 : false;
	const own = dark ? OWN.dark : OWN.light;
	const bg = ground ?? parseColour(own.bg);
	const fg = text ?? parseColour(own.fg);
	const accent = named("--app-accent") ?? parseColour(own.accent);
	const bad = named("--app-danger") ?? parseColour(own.bad);
	const wait = named("--app-warning") ?? parseColour(own.wait);
	const white = [
		255,
		255,
		255
	];
	const black = [
		0,
		0,
		0
	];
	const paper = dark ? mix(bg, black, .18) : mix(bg, fg, .015);
	const vars = {
		"--bg": hex(bg),
		"--fg": hex(fg),
		"--muted": hex(named("--app-fg-muted") ?? mix(fg, bg, .42)),
		"--accent": hex(accent),
		"--accent-2": hex(mix(accent, bg, .3)),
		"--accent-soft": hex(mix(bg, accent, .14)),
		"--on-accent": onFill(accent),
		"--line": hex(named("--line") ?? mix(bg, fg, .16)),
		"--chip": hex(mix(bg, fg, .07)),
		"--paper": hex(paper),
		"--card": hex(dark ? mix(bg, fg, .05) : mix(bg, white, .7)),
		"--label": hex(mix(fg, bg, .12)),
		"--edge": hex(mix(paper, fg, .24)),
		"--grid": hex(mix(paper, fg, .1)),
		"--frame": hex(mix(paper, accent, .05)),
		"--frame-line": hex(mix(paper, fg, .2)),
		"--bad": hex(bad),
		"--bad-soft": hex(mix(bg, bad, .14)),
		"--wait": hex(wait),
		"--wait-soft": hex(mix(bg, wait, .16)),
		"--shade": dark ? "rgba(0,0,0,.4)" : "rgba(15,35,55,.16)"
	};
	const radius = tokens["--block-radius"];
	if (typeof radius === "string" && radius.trim()) vars["--radius"] = radius.trim();
	return {
		dark,
		vars,
		groups: [
			hex(mix(accent, bg, .42)),
			hex(accent),
			hex(mix(accent, fg, .3)),
			hex(mix(accent, bg, .2)),
			hex(mix(accent, fg, .56)),
			hex(mix(accent, bg, .62)),
			hex(mix(accent, fg, .15)),
			hex(mix(accent, bg, .31))
		],
		bad: hex(bad),
		wait: hex(wait),
		paper: hex(paper),
		globe: dark ? [
			hex(mix(bg, accent, .3)),
			hex(mix(bg, accent, .12)),
			hex(mix(bg, black, .35))
		] : [
			hex(mix(bg, white, .9)),
			hex(mix(bg, accent, .12)),
			hex(mix(bg, accent, .32))
		]
	};
}
/** The colour a part is drawn in: red when broken, amber when it waits, else its group's shade. */
function colourOf(n, p) {
	return n.broken ? p.bad : n.waits ? p.wait : p.groups[n.g % p.groups.length];
}
/** The palette on the page's root, and the scheme the engine draws its own controls in (FM-PLUGIN-1424). */
function wear(root, p) {
	for (const [name, value] of Object.entries(p.vars)) root.style.setProperty(name, value);
	root.dataset.scheme = p.dark ? "dark" : "light";
}
//#endregion
//#region plugins/map/pace.ts
/** Between two frames while somebody is at the map: thirty a second. */
var AWAKE_MS = 1e3 / 30;
/** Whether a panel rests: untouched for long enough, and not the page the keys go to. */
function resting(sinceTouch, focused) {
	return sinceTouch >= 2e4 && !focused;
}
var started = false;
var touchedAt = 0;
var asleep = false;
var parts = 0;
var wakers = /* @__PURE__ */ new Set();
/** The system's "reduce motion", asked once and followed live; null where there is no such question. */
var calm;
var focused = () => typeof document !== "undefined" && typeof document.hasFocus === "function" && document.hasFocus();
var pace = {
	/** The panel is up: from here on the pace is kept. A view drawn alone, in a check, draws every frame. */
	start() {
		started = true;
		touchedAt = Date.now();
		asleep = false;
	},
	stop() {
		started = false;
		wakers.clear();
	},
	/** How many parts are on the screen: what a frame costs. */
	size(count) {
		parts = count;
	},
	/** A pointer or a key came: the panel is awake, and whoever waits for that is told at once. */
	touch() {
		touchedAt = Date.now();
		if (!asleep) return;
		asleep = false;
		for (const wake of [...wakers]) wake();
	},
	/** Whether the panel rests now. */
	resting() {
		if (!started) return false;
		asleep = resting(Date.now() - touchedAt, focused());
		return asleep;
	},
	/** The least time between two frames now; nought before the panel is up. */
	gap() {
		if (!started) return 0;
		if (!pace.resting()) return AWAKE_MS;
		return parts >= 150 ? 220 : 50;
	},
	/**
	* The system asks for less motion: no view moves by itself — nothing drifts, turns, floats, runs
	* along a link or plays — and what a hand holds still follows the hand. The one change to the
	* views Gary allowed with the panel's new design (15 October 2026, FM-MAP-80). Asked of the
	* system at every frame, so a setting changed while the panel is open is followed at once.
	*/
	still() {
		if (calm === void 0) calm = typeof matchMedia === "function" ? matchMedia("(prefers-reduced-motion: reduce)") : null;
		return !!calm?.matches;
	},
	/** Be told when a resting panel is touched. Answers how to stop being told. */
	onWake(fn) {
		wakers.add(fn);
		return () => void wakers.delete(fn);
	}
};
/**
* What is left, said as coarsely as it is known. Under a minute no figure is given: the pace of
* the files still to come is not known, and "about 6 s" was said with twenty-five seconds left
* (the tester's run of 10 October 2026, FM-MAP-74). "Less than a minute" is said only where half
* as much again would still be less than one.
*/
function leftWords(ms) {
	const s = ms / 1e3;
	if (s < 40) return say("less than a minute left");
	if (s < 100) return say("about a minute left");
	return saying("about {0} min left", Math.round(s / 60));
}
/**
* How long a reading has still to go, by how fast this very reading reads its files — and nought
* until enough of it has been watched to say.
*
* The first rule divided the time since the reading began by the files read: the walk through the
* folders, which comes first, was counted as time spent on files, so two seconds in — a handful
* of files read — it said "about 3 min left" of a reading that took thirteen seconds (the live
* run of 10 October 2026, FM-MAP-70). And it trusted how long the folder took the last time, which
* says nothing of this time. Now: only the stage that reads files, only its own clock, only once
* three seconds and a tenth of the files are behind it; and what is left is what that pace gives
* for the files not yet read, nothing else. The count on the strip is the fact; this is a guess,
* and is not made before it can be a fair one.
*/
function leftOf(r, now) {
	if (r.stage !== "files" || !(r.of > 0)) return 0;
	const since = r.since ?? r.began;
	if (now - since < 3e3 || r.done < Math.max(40, r.of * .1)) return 0;
	const marks = r.marks ?? [];
	const newest = marks.length ? marks[marks.length - 1] : [now, r.done];
	let from = [since, 0];
	for (const mark of marks) if (mark[0] <= newest[0] - 4e3 && mark[1] < newest[1] && mark[0] >= from[0]) from = mark;
	const read = newest[1] - from[1];
	if (!(read > 0) || !(newest[0] > from[0])) return 0;
	const each = (newest[0] - from[0]) / read;
	return (now - newest[0] > 2 * each ? (now - from[0]) / read : each) * Math.max(0, r.of - r.done);
}
/**
* The strip over the map: a reading in hand, as a count, a bar of how much of it is done, and — once
* the map is drawn from the walk — that the links are still to come (FM-MAP-52, FM-MAP-75). The bar
* is the count's own share, never a guess.
*/
function stripHtml(r, level, now) {
	if (r) {
		const what = r.memory ? saying("Reading the memory notes… {0} of {1}", r.done, r.of) : r.stage === "folders" ? saying("Reading the folders… {0} of {1}", r.done, r.of) : saying("Reading the files… {0} of {1}", r.done, r.of);
		const left = leftOf(r, now);
		const share = r.of > 0 ? Math.max(0, Math.min(100, Math.round(r.done / r.of * 100))) : 0;
		const early = !r.memory && r.stage === "files" && level?.early ? `<span>${plain(say("The map is drawn already; the links come when the reading ends."))}</span>` : "";
		return `<div class="work" role="status"><div class="r"><b>${plain(what)}</b>${left >= 5e3 ? `<span>${plain(leftWords(left))}</span>` : ""}</div><div class="prog"><i style="--p:${share}%"></i></div>${early}</div>`;
	}
	return "";
}
/**
* Said of a folder larger than the map reads at once — on a row of its own under the folder's
* path, there from the moment the map is first drawn. Not on the strip: the strip lies over the
* map and goes when a reading ends, and this stays for as long as the folder is on the screen
* (FM-MAP-79).
*/
function cutWords(level) {
	return level?.cut ? say("This folder is larger than the map reads at once: its top is drawn whole, its depths as far as the reading got.") : "";
}
/** What could be read of the folder's history, in one line. */
function pastWords(level) {
	const past = level?.kind === "project" ? level.past : void 0;
	if (!past) return "";
	if (past.how === "outside") return say("A worktree: its history is kept outside this folder, where the map cannot read.");
	const last = past.days[past.days.length - 1];
	if (!last) return say("No history can be read in this folder.");
	return saying("Last commit: {0} — {1}", fullDay(last.on), last.said[last.said.length - 1] ?? "");
}
//#endregion
//#region plugins/map/layout/camera.ts
/** A camera at a view's own start, or where the person left it. */
function camera(start, lim, saved) {
	const kept = (v, or) => typeof v === "number" && Number.isFinite(v) ? v : or;
	return {
		ry: kept(saved?.ry, start.ry),
		rx: Math.max(lim[0], Math.min(lim[1], kept(saved?.rx, start.rx))),
		zoom: kept(saved?.zoom, start.zoom),
		rot: null,
		aim: null,
		zAim: null,
		over: false,
		lim,
		t: 0
	};
}
/** One frame is this long at sixty a second; the speeds below are per such frame. */
var FRAME_MS = 16.7;
/** No frame counts for more than three: a tab that slept does not come back spun round. */
var MOST_FRAMES = 3;
/**
* One frame at time `now`: glide to the aim if there is one, else turn at `speed` — unless a hand
* is on the map or the pointer is over a part.
*/
function camStep(k, now, speed) {
	const dt = Math.min(MOST_FRAMES, ((now || 0) - (k.t || now || 0)) / FRAME_MS) || 1;
	k.t = now || 0;
	if (k.aim !== null) {
		let d = k.aim - k.ry;
		d = Math.atan2(Math.sin(d), Math.cos(d));
		k.ry += d * (1 - Math.pow(.92, dt));
		if (Math.abs(d) < .01) k.aim = null;
	} else if (!k.rot && !k.over && !pace.still()) k.ry += speed * dt;
	if (k.zAim !== null) {
		k.zoom += (k.zAim - k.zoom) * (1 - Math.pow(.93, dt));
		if (Math.abs(k.zAim - k.zoom) < .004) k.zAim = null;
	}
}
/** A drag begins. */
function grab(k, x, y) {
	k.rot = {
		x,
		y,
		ry: k.ry,
		rx: k.rx
	};
}
/** A drag moves: the map turns with the hand, and tilts within its limits. */
function dragTo(k, x, y) {
	if (!k.rot) return;
	k.aim = null;
	k.ry = k.rot.ry + (x - k.rot.x) * .006;
	k.rx = Math.max(k.lim[0], Math.min(k.lim[1], k.rot.rx - (y - k.rot.y) * .005));
}
/** The wheel: nearer or further, within reason. */
function wheel(k, deltaY) {
	k.zAim = null;
	k.zoom = Math.min(2.4, Math.max(.5, k.zoom * (deltaY < 0 ? 1.08 : .93)));
}
/** Turn to bring a point of the ground plan to the front. */
function aimAt(k, x, z) {
	k.aim = Math.atan2(-x, z);
}
/** What is remembered of a camera. */
function camPlace(k) {
	return {
		ry: k.ry,
		rx: k.rx,
		zoom: k.zoom
	};
}
/** A point of space on the sheet: `[x, y, scale, depth]`. Nearer is larger, and further back in `depth`. */
function project(k, p, eye) {
	const [cy, sy, cx, sx] = [
		Math.cos(k.ry),
		Math.sin(k.ry),
		Math.cos(k.rx),
		Math.sin(k.rx)
	];
	const x1 = p.X * cy + p.Z * sy;
	const z1 = -p.X * sy + p.Z * cy;
	const y1 = p.Y * cx - z1 * sx;
	const z2 = p.Y * sx + z1 * cx;
	const scale = eye.focal / (eye.focal - z2) * k.zoom;
	return [
		eye.cx + x1 * scale,
		eye.cy + y1 * scale,
		scale,
		z2
	];
}
//#endregion
//#region plugins/map/views/kit.ts
var NS = "http://www.w3.org/2000/svg";
/** An SVG element with its attributes, and its text if it has one. */
function el(tag, attrs = {}, text) {
	const e = document.createElementNS(NS, tag);
	for (const [name, value] of Object.entries(attrs)) e.setAttribute(name, String(value));
	if (text !== void 0) e.textContent = text;
	return e;
}
/**
* A part drawn as a circle: a halo for the chosen one, a dashed ring for a changed one (solid and
* red for a broken one), a thin ring for one you can go inside, and its name under it.
*/
function dot(n, r, ctx, extra = "") {
	const g = el("g", {
		class: `n gn ${extra} ${marksOf(n, ctx.stats)}`.replace(/\s+/g, " ").trim(),
		tabindex: 0
	});
	g.dataset.id = n.id;
	g.append(el("circle", {
		class: "hit",
		r
	}), el("circle", {
		class: "halo",
		r: r + 12
	}), el("circle", {
		class: "ring",
		r: r + 6
	}), el("circle", {
		class: "deep",
		r: r + 3.2
	}), el("circle", {
		class: "c",
		r,
		fill: colourOf(n, ctx.palette)
	}), el("text", {
		y: r + 6,
		"dominant-baseline": "hanging"
	}, n.t));
	return g;
}
/**
* A size a turning view draws a part at, in steps of a thirty-second.
*
* A part nearer the eye is drawn larger, its name with it — and a name drawn at a size never used
* before is letters the engine shapes and keeps. Hundreds of names, each at a new size at every
* frame, were hundreds of megabytes the page never gave back (measured in a headless engine,
* FM-MAP-66). In steps, there are a few dozen sizes in all, and no eye sees the step.
*/
var stepped = (scale) => Math.round(scale * 32) / 32;
/** The size such a name is shown at instead, on the screen. */
var NAME_PX$2 = 11.5;
/**
* How large a turning view writes the name of a part drawn at `scale`: as the stylesheet has it
* while that is read on the screen, and otherwise just large enough to be (FM-MAP-69). `css` is
* what to set on the name — empty for the stylesheet's own — and `font` its height in the sheet's
* units, for the room it needs.
*/
function readable(canvas, scale) {
	const unit = screenScale(canvas);
	const own = 12 * nameScale(canvas) * scale;
	const least = 9.72;
	if (own * unit >= least) return {
		css: "",
		font: own
	};
	return {
		css: `${(least / (unit * Math.max(.05, scale))).toFixed(2)}px`,
		font: least / unit
	};
}
/**
* A part's hit area made at least `HIT_PX` across on the screen: `unit` is how many points of the
* screen one unit is drawn as where the part stands.
*
* On a big map in a panel beside a terminal a dot is a point and a half across: a hand cannot be
* asked to land on it, and a press that slid off it by its own allowed travel was lost (the live
* run of 10 October 2026, FM-MAP-71).
*/
function reach(g, r, unit) {
	g.querySelector(".hit")?.setAttribute("r", String(Math.max(r, 5 / Math.max(.01, unit))));
}
/** A link's element, carrying its ends. */
function link(tag, cls, a, b) {
	const e = el(tag, { class: cls });
	e.dataset.a = a;
	e.dataset.b = b;
	return e;
}
/** The chosen part's links run, and its neighbours are marked. */
function hot(view, level, id) {
	for (const e of view.edgeEls) e.classList.toggle("hot", e.dataset.a === id || e.dataset.b === id);
	const near = new Set(neighbours(level, id));
	for (const n of level.nodes) view.nodeEls[n.id]?.classList.toggle("near", near.has(n.id));
}
/** Under the pointer: everything but the part and its neighbours steps back. Null puts it all forward again. */
function fadeBut(view, level, id) {
	const keep = id ? /* @__PURE__ */ new Set([id, ...neighbours(level, id)]) : null;
	for (const n of level.nodes) view.nodeEls[n.id]?.classList.toggle("fade", !!keep && !keep.has(n.id));
	for (const e of view.edgeEls) e.classList.toggle("fade", !!keep && !(e.dataset.a === id || e.dataset.b === id));
}
/** Whether a link is dimmed, by a tab, the search or the pointer: its running dot hides with it. */
var dimmed = (e) => e.classList.contains("off") || e.classList.contains("fade");
/** A pointer's place on the sheet, in the sheet's own units. */
function sheetPoint(svg, e) {
	const matrix = svg.getScreenCTM?.();
	if (!matrix) return {
		x: e.clientX,
		y: e.clientY
	};
	const p = svg.createSVGPoint();
	p.x = e.clientX;
	p.y = e.clientY;
	const at = p.matrixTransform(matrix.inverse());
	return {
		x: at.x,
		y: at.y
	};
}
/**
* A part taken in the hand keeps the pointer even when the hand leaves it. A press that is not a
* real pointer's — a check's, or the window pressing by name — has no pointer to keep, and the
* engine throws at being asked; the press still counts.
*/
function hold(target, e) {
	try {
		target.setPointerCapture?.(e.pointerId);
	} catch {}
}
/** Whether a button is down under a moving pointer: a part follows the hand only while it is. */
var pressed = (e) => (e.buttons ?? 0) !== 0;
/** Whether the pointer has gone far enough from where it was pressed to be dragging. */
var dragging = (down, e) => Math.hypot(e.clientX - down.x, e.clientY - down.y) > 5;
/** The main button, or a press that names none: the secondary button is the card's, not a press (FM-MAP-65). */
var mainButton = (e) => (e.button ?? 0) === 0;
/**
* A part that is only pressed, in the views where the hand turns the whole map: pressed and let go
* within a few points it is `press`; moved further, the press is the map's — it turns, and the
* part is not chosen.
*/
function pressable(l, target, press) {
	let down = null;
	l.on(target, "pointerdown", (e) => down = mainButton(e) ? {
		x: e.clientX,
		y: e.clientY
	} : null);
	l.on(window, "pointerup", (e) => {
		const was = down;
		down = null;
		if (was && !dragging(was, e)) press();
	});
	l.on(target, "pointercancel", () => down = null);
	l.on(window, "blur", () => down = null);
}
/**
* A quiet life for a thing that otherwise stands still: where it is drawn at `now`, a little off
* its place, on a slow wave of its own.
*
* The owner's rule is that every view moves. The graph moved by the dots running along its links,
* so a level with no links stood dead still, and the blueprint and the history never moved at all
* (the live run of 10 October 2026, FM-MAP-67). No glow, no haze, no dust: the part itself drifts
* a couple of units and comes back, each on its own phase, so nothing moves in step.
*/
function drifter(id) {
	let h = 2166136261;
	for (let i = 0; i < id.length; i++) h = Math.imul(h ^ id.charCodeAt(i), 16777619) >>> 0;
	const phase = h % 6283 / 1e3;
	const slow = 1500 + h % 900;
	const out = [0, 0];
	return (now, reach) => {
		out[0] = Math.cos(now / slow + phase) * reach;
		out[1] = Math.sin(now / (slow * 1.31) + phase * 1.7) * reach;
		return out;
	};
}
/** A frame slower than this is waited for on a timer, so a resting panel is not woken sixty times a second. */
var TIMED_FROM_MS = 100;
/** A frame that comes this much early is still drawn: screens do not tick exactly. */
var EARLY_MS = 3;
/**
* A frame clock: `frame(now)` until stopped, at the panel's pace — never more than thirty frames a
* second, twenty while an ordinary map rests, a few while a big one does, and at once when the
* panel is touched (FM-MAP-34).
*/
function frames(frame) {
	let alive = true;
	let handle = 0;
	let timer = null;
	let last = -Infinity;
	let shown = 0;
	const tick = (now) => {
		if (!alive) return;
		const gap = pace.gap();
		if (now - last >= gap - EARLY_MS) {
			last = now;
			frame(pace.still() ? shown : shown = now);
		}
		if (gap < TIMED_FROM_MS) handle = requestAnimationFrame(tick);
		else timer = setTimeout(() => {
			timer = null;
			handle = requestAnimationFrame(tick);
		}, gap - 16);
	};
	const unwake = pace.onWake(() => {
		if (!timer) return;
		clearTimeout(timer);
		timer = null;
		handle = requestAnimationFrame(tick);
	});
	tick(0);
	return () => {
		alive = false;
		unwake();
		if (timer) clearTimeout(timer);
		cancelAnimationFrame(handle);
	};
}
/** How many sixtieths of a second a frame stands for, for what moves by the frame: one to three. */
function stepsIn(now, before) {
	return Math.max(1, Math.min(3, Math.round((now - before) / (1e3 / 60)) || 1));
}
/** The drift in a view's own units, where one unit is drawn as `unit` points of the screen. */
var driftReach = (unit) => 5 / Math.SQRT2 / Math.max(.05, unit);
/** Listeners added together and taken away together. */
function listeners() {
	const all = [];
	return {
		on: (target, type, fn, opts) => {
			target.addEventListener(type, fn, opts);
			all.push(() => target.removeEventListener(type, fn, opts));
		},
		off: () => all.splice(0).forEach((undo) => undo())
	};
}
/**
* Every way a press on `target` ends without its `pointerup` reaching it: the engine cancels the
* pointer, or takes its capture away. `end` must stand being called twice.
*
* A part once followed the pointer with no button held, on to another part, and was remembered
* there (the tester's run of 10 October 2026). Its `pointerup` had not come; so a drag is ended by
* every door a press can leave through, and a move with no button down ends it too (FM-MAP-32).
*/
function onLost(l, target, end) {
	l.on(target, "pointercancel", end);
	l.on(target, "lostpointercapture", end);
}
/** The same for the whole view, once: a release anywhere, a double press, the window losing the pointer. */
function onLostAnywhere(l, svg, end) {
	l.on(window, "pointerup", end);
	l.on(window, "pointercancel", end);
	l.on(window, "blur", end);
	l.on(svg, "dblclick", end);
}
/** The sheet as it is drawn when nobody can say how big the panel is. */
var SHEET_BOX = {
	x: 0,
	y: 0,
	w: 885,
	h: 900
};
/** What the row of views covers at the foot of the map, in the page's own points. */
var FOOT_PX = 62;
/**
* The part of the sheet a person really sees, in the sheet's own units, or null on a page that
* has not been laid out.
*
* The sheet is drawn 885 by 900 and fitted into the panel whole, so a panel that is wide and low
* shows a great deal of empty sheet either side of it — and a map laid out for the sheet is then a
* small clump in the middle (FM-MAP-37). What is drawn beyond the sheet's edges is still seen.
*/
function seen(canvas) {
	const [cw, ch] = [canvas.clientWidth, canvas.clientHeight];
	if (!(cw > 0) || !(ch > 0)) return null;
	const s = Math.min(cw / SHEET_BOX.w, ch / SHEET_BOX.h);
	const [w, h] = [cw / s, ch / s];
	const foot = Math.min(h * .3, FOOT_PX / s);
	return {
		x: (SHEET_BOX.w - w) / 2,
		y: (SHEET_BOX.h - h) / 2,
		w,
		h: h - foot
	};
}
/**
* How much larger than the sheet's own units the names over the map are drawn, so that a panel
* half as large does not make them half as large: the sheet is fitted into the panel whole, and
* its letters would shrink with it (FM-MAP-37).
*/
var nameScale = (canvas) => Math.min(2.4, Math.max(1, 1 / screenScale(canvas)));
/** How many of the page's points one unit of the sheet is drawn as; one on a page not laid out. */
function screenScale(canvas) {
	const [cw, ch] = [canvas.clientWidth, canvas.clientHeight];
	return cw > 0 && ch > 0 ? Math.min(cw / SHEET_BOX.w, ch / SHEET_BOX.h) : 1;
}
/**
* The zoom at which a turning scene `wide` by `tall` fills the panel, or `or` on a page that
* cannot say how big it is: a town drawn for the whole sheet is a few houses in the middle of a
* panel that is wide and low (FM-MAP-37).
*/
function zoomToFill(canvas, wide, tall, or) {
	const room = seen(canvas);
	return room ? Math.min(2.4, Math.max(.5, Math.min(room.w / wide, room.h / tall) * .9)) : or;
}
/** How to move and scale a sheet so that `content` fills `room`, never larger than `most`. */
function fitTo(content, room, most) {
	const pad = Math.min(room.w, room.h) * .04;
	const k = Math.min(most, (room.w - 2 * pad) / Math.max(1, content.w), (room.h - 2 * pad) / Math.max(1, content.h));
	return {
		x: room.x + (room.w - content.w * k) / 2 - content.x * k,
		y: room.y + (room.h - content.h * k) / 2 - content.y * k,
		k
	};
}
/**
* How a sheet lay when a part was last placed on it — per panel, level and view, for this opening
* of the panel and no longer.
*
* A view is drawn again whenever its level changes under it: a first reading ends, a file
* appears. A sheet nobody moved is then fitted to what is on it — and a part just dragged has
* changed what is on it, so the whole map shifted under the hand that had placed the part: its
* place on the sheet was kept, and it stood forty points off on the screen (the tester's run of
* 10 October 2026, FM-MAP-77). So a sheet a part was placed on stays as it lay; a panel that
* changes its size fits it again, and "Lay out again" forgets the places and this with them.
*/
var stayed = /* @__PURE__ */ new WeakMap();
/**
* A flat sheet a person can move with the hand and scale with the wheel: the graph's and the
* blueprint's. It opens fitted to the panel, and is fitted again when the panel changes its size —
* until a person has put it somewhere themselves.
*/
function flatSheet(ctx, opts) {
	const kept = ctx.places.get("view");
	let own = !!kept && [
		kept.x,
		kept.y,
		kept.k
	].every((v) => Number.isFinite(v));
	const stays = opts.stays ? `${ctx.level.key}\n${opts.stays}` : null;
	const lay = stays && ctx.places.get("pos") ? stayed.get(ctx.canvas)?.get(stays) : void 0;
	const fit = () => {
		const room = seen(ctx.canvas);
		return room && opts.content ? fitTo(opts.content(), room, opts.most ?? 1) : { ...opts.start };
	};
	const at = own ? { ...kept } : lay ? { ...lay } : fit();
	let [wide, tall] = [ctx.canvas.clientWidth, ctx.canvas.clientHeight];
	const layer = el("g");
	ctx.svg.append(layer);
	const apply = () => {
		layer.setAttribute("transform", `translate(${at.x},${at.y}) scale(${at.k})`);
		opts.scaled?.(at.k);
	};
	apply();
	let pan = null;
	const l = listeners();
	const end = () => {
		if (pan?.moved && !opts.held()) ctx.places.set("view", { ...at });
		pan = null;
	};
	l.on(ctx.svg, "pointerdown", (e) => {
		const p = sheetPoint(ctx.svg, e);
		pan = {
			x: p.x,
			y: p.y,
			ox: at.x,
			oy: at.y,
			down: {
				x: e.clientX,
				y: e.clientY
			},
			moved: false
		};
	});
	l.on(ctx.svg, "pointermove", (e) => {
		if (!pan || opts.held()) return;
		if (!pressed(e)) return end();
		if (!pan.moved && !dragging(pan.down, e)) return;
		pan.moved = true;
		const p = sheetPoint(ctx.svg, e);
		at.x = pan.ox + p.x - pan.x;
		at.y = pan.oy + p.y - pan.y;
		own = true;
		apply();
	});
	onLostAnywhere(l, ctx.svg, end);
	l.on(ctx.svg, "wheel", (e) => {
		e.preventDefault();
		const p = sheetPoint(ctx.svg, e);
		const k = Math.min(2.4, Math.max(.5 / Math.max(1, ctx.stats.sc * 2), at.k * (e.deltaY < 0 ? 1.1 : .91)));
		at.x = p.x - (p.x - at.x) * k / at.k;
		at.y = p.y - (p.y - at.y) * k / at.k;
		at.k = k;
		own = true;
		apply();
		ctx.places.set("view", { ...at });
	}, { passive: false });
	const watcher = typeof ResizeObserver === "function" ? new ResizeObserver(() => {
		if (own || ctx.canvas.clientWidth === wide && ctx.canvas.clientHeight === tall) return;
		[wide, tall] = [ctx.canvas.clientWidth, ctx.canvas.clientHeight];
		if (stays) stayed.get(ctx.canvas)?.delete(stays);
		Object.assign(at, fit());
		apply();
	}) : null;
	watcher?.observe(ctx.canvas);
	return {
		layer,
		at,
		apply,
		stay: () => {
			if (!stays) return;
			if (!stayed.has(ctx.canvas)) stayed.set(ctx.canvas, /* @__PURE__ */ new Map());
			stayed.get(ctx.canvas).set(stays, { ...at });
		},
		stop: () => {
			watcher?.disconnect();
			l.off();
		}
	};
}
/**
* A turning view in the hand: a drag turns it, the wheel brings it nearer, and where it was left
* is remembered. `fill` is the zoom at which the scene fills the panel now: kept to as the panel
* changes its size, until a person has set the zoom themselves.
*/
function turning(ctx, k, fill) {
	const l = listeners();
	let own = ctx.places.get("cam") !== null;
	const watcher = fill && typeof ResizeObserver === "function" ? new ResizeObserver(() => {
		if (!own) k.zoom = fill();
	}) : null;
	watcher?.observe(ctx.canvas);
	let down = null;
	let turned = false;
	l.on(ctx.svg, "pointerdown", (e) => {
		down = {
			x: e.clientX,
			y: e.clientY
		};
		turned = false;
		grab(k, e.clientX, e.clientY);
	});
	const end = () => {
		if (k.rot && turned) ctx.places.set("cam", camPlace(k));
		k.rot = null;
		down = null;
	};
	l.on(window, "pointermove", (e) => {
		if (!k.rot) return;
		if (!pressed(e)) return end();
		if (!turned && down && !dragging(down, e)) return;
		turned = true;
		dragTo(k, e.clientX, e.clientY);
	});
	onLostAnywhere(l, ctx.svg, end);
	l.on(ctx.svg, "wheel", (e) => {
		e.preventDefault();
		wheel(k, e.deltaY);
		own = true;
		ctx.places.set("cam", camPlace(k));
	}, { passive: false });
	return () => {
		watcher?.disconnect();
		l.off();
	};
}
/** A polygon's points as SVG writes them. */
var points = (corners) => corners.map((q) => `${q[0].toFixed(1)},${q[1].toFixed(1)}`).join(" ");
//#endregion
//#region plugins/map/views/names.ts
/** How wide a letter is against how high: an SVG text cannot be asked before it is on a screen. */
var LETTER = .56;
/** Between a dot and the name under it. */
var GAP = 6;
/** The box a part's name is written in, under its dot. */
function nameBox(s, letters) {
	const w = Math.max(1, letters) * s.font * LETTER + s.font * .6;
	return {
		x: s.x - w / 2,
		y: s.y + s.r + GAP,
		w,
		h: s.font * 1.25
	};
}
/**
* How much a part matters on its level: the links that touch it, then how much is in it — a folder
* before a file, more files before fewer. A fact about the part, the same at every look.
*/
function weight(n, stats) {
	return (stats.deg[n.id] ?? 0) * 1e3 + (n.kids ? 500 : 0) + Math.min(499, n.f.length * 10 + (n.is === "files" ? 100 : 0));
}
/** The parts that carry their names now. */
function named(spots, stats, look) {
	const out = /* @__PURE__ */ new Set();
	const boxes = [...look.taken ?? []];
	const order = (s) => {
		const n = stats.by[s.id];
		return (look.first.has(s.id) ? 4e9 : 0) + (look.near.has(s.id) ? 2e9 : 0) + (look.before?.has(s.id) ? 1e9 : 0) + (n ? weight(n, stats) : 0);
	};
	const sorted = spots.filter((s) => !s.gone && stats.by[s.id]).sort((a, b) => order(b) - order(a) || (a.id < b.id ? -1 : 1));
	for (const s of sorted) {
		const box = nameBox(s, stats.by[s.id].t.length);
		if (!boxes.every((b) => box.x >= b.x + b.w || b.x >= box.x + box.w || box.y >= b.y + b.h || b.y >= box.y + box.h) && !look.first.has(s.id)) continue;
		boxes.push(box);
		out.add(s.id);
	}
	return out;
}
/** What is chosen on a view just now, read off the marks every view carries. */
function lookOf(nodeEls, before) {
	const first = /* @__PURE__ */ new Set();
	const near = /* @__PURE__ */ new Set();
	for (const [id, g] of Object.entries(nodeEls)) {
		const cl = g.classList;
		if (cl.contains("sel") || cl.contains("pick") || cl.contains("keep") || cl.contains("over")) first.add(id);
		else if (cl.contains("near")) near.add(id);
	}
	return {
		first,
		near,
		before
	};
}
/** The names put on a view: a part without room for its name is `quiet`, and named under the pointer. */
function put(nodeEls, on) {
	for (const [id, g] of Object.entries(nodeEls)) g.classList.toggle("quiet", !on.has(id));
}
//#endregion
//#region plugins/map/views/blueprint.ts
/** How long a dot takes to run a line, in milliseconds. */
var RUN_MS = 3400;
/** Below this scale a card's two lines cannot be read: its name alone is drawn, large (FM-MAP-36). */
var FAR_BELOW = .55;
/** Two cards kept nearer than this lie on one place. */
var ON_ONE = 8;
/** How high a card's letters are, in the sheet's units: its two lines, and its name alone from afar. */
var LETTERS = 12.5;
var LETTERS_FAR = 25;
function blueprint(ctx) {
	const { level, stats } = ctx;
	let holding = false;
	/** The scale changed, a card was moved or the pointer is on another: the names are looked at again. */
	let stale = true;
	let over = null;
	const saved = ctx.places.get("pos") ?? {};
	const at = {};
	const placed = [];
	const kept = (id) => {
		const k = saved[id];
		return Array.isArray(k) && Number.isFinite(k[0]) && Number.isFinite(k[1]) ? [k[0], k[1]] : null;
	};
	for (const n of [...level.nodes.filter((n) => kept(n.id)), ...level.nodes.filter((n) => !kept(n.id))]) {
		const mine = kept(n.id);
		const hidden = mine && placed.some((p) => Math.abs(p[0] - mine[0]) < ON_ONE && Math.abs(p[1] - mine[1]) < ON_ONE);
		at[n.id] = mine && !hidden ? mine : freePlace(mine ?? [...ctx.home[n.id] ?? [20, 70]], placed);
		placed.push(at[n.id]);
	}
	/** Every card, with its group's title above it. */
	const content = () => {
		const all = level.nodes.map((n) => at[n.id]);
		if (!all.length) return {
			x: 0,
			y: 0,
			w: 885,
			h: 900
		};
		const box = frameBox(all);
		return {
			x: box.x,
			y: box.y,
			w: box.width,
			h: box.height
		};
	};
	const sheet = flatSheet(ctx, {
		start: stats.big ? {
			x: 10,
			y: 10,
			k: .27
		} : {
			x: 0,
			y: 0,
			k: 1
		},
		content,
		most: 1.25,
		stays: "blueprint",
		held: () => holding,
		scaled: (k) => {
			ctx.svg.classList.toggle("far", k < FAR_BELOW);
			stale = true;
		}
	});
	const keep = () => {
		const out = {};
		for (const n of level.nodes) out[n.id] = [Math.round(at[n.id][0]), Math.round(at[n.id][1])];
		ctx.places.set("pos", out);
		sheet.stay();
	};
	const view = {
		nodeEls: {},
		edgeEls: [],
		chosen: (id) => {
			hot(view, level, id);
			stale = true;
		},
		stop: () => {}
	};
	const clip = el("clipPath", { id: "card-clip" });
	clip.append(el("rect", {
		x: 8,
		y: 0,
		width: 164,
		height: 54
	}));
	const defs = el("defs");
	defs.append(clip);
	sheet.layer.append(defs);
	const groups = level.frames.map((f, gi) => ({
		gi,
		title: f.t
	})).filter((g) => level.nodes.some((n) => n.g === g.gi)).map((g) => {
		const rect = el("rect", {
			class: "frame",
			rx: 12
		});
		const title = el("text", { class: "ftitle" }, g.title);
		sheet.layer.append(rect, title);
		return {
			...g,
			rect,
			title
		};
	});
	view.edgeEls = level.edges.map(([a, b]) => {
		const path = link("path", "e edge", a, b);
		sheet.layer.append(path);
		return path;
	});
	const all = () => level.nodes.map((n) => at[n.id]);
	/** Each line's curve as numbers, for the dot that runs along it. */
	const curves = [];
	const update = () => {
		for (const n of level.nodes) view.nodeEls[n.id].setAttribute("transform", `translate(${at[n.id][0]},${at[n.id][1]})`);
		stale = true;
		const others = all();
		view.edgeEls.forEach((path, i) => {
			const d = route(at[path.dataset.a], at[path.dataset.b], others, stats.big);
			path.setAttribute("d", d);
			curves[i] = curveOf(d);
		});
		for (const g of groups) {
			const box = frameBox(level.nodes.filter((n) => n.g === g.gi).map((n) => at[n.id]));
			for (const [name, value] of Object.entries(box)) g.rect.setAttribute(name, String(value));
			g.title.setAttribute("x", String(box.x + 14));
			g.title.setAttribute("y", String(box.y + 24));
		}
	};
	const l = listeners();
	const ends = [];
	onLostAnywhere(l, ctx.svg, () => ends.forEach((end) => end()));
	/** A thing that can be taken in the hand: it moves the cards `ids` names, and a press without a move is `press`. */
	const takeable = (target, ids, press) => {
		let start = null;
		let dragged = false;
		l.on(target, "pointerdown", (e) => {
			e.stopPropagation();
			if (!mainButton(e)) return;
			const p = sheetPoint(ctx.svg, e);
			start = {
				x: p.x,
				y: p.y,
				down: {
					x: e.clientX,
					y: e.clientY
				},
				was: ids().map((id) => [...at[id]])
			};
			dragged = false;
			holding = true;
			hold(target, e);
		});
		const lost = () => {
			if (start && dragged) keep();
			start = null;
			holding = false;
		};
		ends.push(lost);
		onLost(l, target, lost);
		l.on(target, "pointermove", (e) => {
			if (!start) return;
			if (!pressed(e)) return lost();
			const p = sheetPoint(ctx.svg, e);
			const dx = (p.x - start.x) / sheet.at.k;
			const dy = (p.y - start.y) / sheet.at.k;
			if (dragging(start.down, e)) dragged = true;
			if (!dragged) return;
			ids().forEach((id, i) => {
				at[id][0] = start.was[i][0] + dx;
				at[id][1] = start.was[i][1] + dy;
			});
			update();
		});
		l.on(target, "pointerup", () => {
			if (start && dragged) keep();
			else if (start && press) press();
			start = null;
			holding = false;
		});
	};
	for (const n of level.nodes) {
		const g = el("g", {
			class: `n node ${marksOf(n, stats)}`.trim(),
			tabindex: 0
		});
		g.dataset.id = n.id;
		const hint = el("title", {}, n.s ? `${n.t} — ${n.s}` : n.t);
		g.append(hint, el("rect", {
			class: "hit",
			width: 180,
			height: 54
		}), el("rect", {
			class: "deep",
			x: -4,
			y: -4,
			width: 188,
			height: 62,
			rx: 12
		}), el("rect", {
			class: "card",
			width: 180,
			height: 54,
			rx: 9
		}), el("text", {
			class: "t",
			x: 14,
			y: 23,
			"clip-path": "url(#card-clip)"
		}, fitted(n.t, 22)), el("text", {
			class: "s",
			x: 14,
			y: 40,
			"clip-path": "url(#card-clip)"
		}, fitted(n.s, 29)), ...farRows(n.t).map((row, i, rows) => el("text", {
			class: "tf",
			x: 12,
			y: rows.length > 1 ? 24 + i * 23 : 35,
			"clip-path": "url(#card-clip)"
		}, row)), el("circle", {
			class: "dot",
			cx: 166,
			cy: 14,
			r: 4
		}));
		sheet.layer.append(g);
		view.nodeEls[n.id] = g;
		takeable(g, () => [n.id], () => ctx.choose(n.id));
		l.on(g, "pointerenter", () => {
			over = n.id;
			stale = true;
		});
		l.on(g, "pointerleave", () => {
			if (over === n.id) over = null;
			stale = true;
		});
	}
	for (const g of groups) {
		const members = () => level.nodes.filter((n) => n.g === g.gi).map((n) => n.id);
		takeable(g.rect, members);
		takeable(g.title, members);
	}
	update();
	const tags = el("g");
	sheet.layer.append(tags);
	const tagOf = {};
	for (const n of level.nodes) tags.append(tagOf[n.id] = el("text", { class: "cn" }, n.t));
	const rename = () => {
		stale = false;
		const unit = sheet.at.k * screenScale(ctx.canvas);
		const tiny = (ctx.svg.classList.contains("far") ? LETTERS_FAR : LETTERS) * unit < 9;
		ctx.svg.classList.toggle("tiny", tiny);
		const side = 10 / unit;
		for (const n of level.nodes) {
			const hit = view.nodeEls[n.id].querySelector(".hit");
			const [w, h] = [Math.max(180, side), Math.max(54, side)];
			for (const [name, value] of Object.entries({
				x: (180 - w) / 2,
				y: (54 - h) / 2,
				width: w,
				height: h
			})) hit.setAttribute(name, String(value));
		}
		if (!tiny) return;
		const font = NAME_PX$2 / unit;
		const first = new Set(level.nodes.filter((n) => n.id === over || view.nodeEls[n.id].classList.contains("sel") || view.nodeEls[n.id].classList.contains("pick")).map((n) => n.id));
		const on = named(level.nodes.map((n) => ({
			id: n.id,
			x: at[n.id][0] + 90,
			y: at[n.id][1] + 27 - font * .62 - 6,
			r: 0,
			font
		})), stats, {
			first,
			near: /* @__PURE__ */ new Set()
		});
		for (const n of level.nodes) {
			const tag = tagOf[n.id];
			tag.style.display = on.has(n.id) ? "" : "none";
			if (!on.has(n.id)) continue;
			tag.setAttribute("x", String(at[n.id][0] + 90));
			tag.setAttribute("y", String(at[n.id][1] + 27));
			tag.style.fontSize = `${font}px`;
			tag.style.strokeWidth = `${3.5 / unit}px`;
		}
	};
	const runners = view.edgeEls.map(() => {
		const c = el("circle", {
			class: "pt",
			r: stats.big ? 3 : 2.4
		});
		sheet.layer.insertBefore(c, level.nodes.length ? view.nodeEls[level.nodes[0].id] : null);
		return c;
	});
	const phase = view.edgeEls.map((_e, i) => i * .61803 % 1);
	const loose = level.nodes.filter((n) => !(stats.deg[n.id] > 0)).map((n) => ({
		id: n.id,
		drift: drifter(n.id)
	}));
	const q = [0, 0];
	const stopFrames = frames((now) => {
		for (let i = 0; i < runners.length; i++) {
			alongCurve(curves[i] ?? [], (now / RUN_MS + phase[i]) % 1, q);
			runners[i].setAttribute("cx", String(q[0]));
			runners[i].setAttribute("cy", String(q[1]));
			runners[i].style.opacity = dimmed(view.edgeEls[i]) ? "0" : ".8";
		}
		if (stale) rename();
		if (holding) return;
		const sway = driftReach(sheet.at.k * screenScale(ctx.canvas)) * .6;
		for (const one of loose) {
			const off = one.drift(now, sway);
			view.nodeEls[one.id].setAttribute("transform", `translate(${at[one.id][0]},${at[one.id][1]}) translate(${off[0].toFixed(2)},${off[1].toFixed(2)})`);
		}
	});
	view.stop = () => {
		stopFrames();
		l.off();
		sheet.stop();
		ctx.svg.classList.remove("far", "tiny");
	};
	return view;
}
//#endregion
//#region plugins/map/layout/steady.ts
/** A stream of numbers in [0, 1) that belongs to one part. */
function partRand(id) {
	let s = 2166136261;
	for (let i = 0; i < id.length; i++) s = Math.imul(s ^ id.charCodeAt(i), 16777619) >>> 0;
	return () => {
		s = Math.imul(s, 1664525) + 1013904223 >>> 0;
		return s / 4294967296;
	};
}
/**
* Places with no two on one spot.
*
* Two parts kept on one place are one part to the eye: the one underneath is gone from the map,
* and stays gone at every opening (FM-MAP-32). So places are moved apart when they are put back
* and when they are stored: a part standing within `room` of one before it — in the order of their
* names, so the answer is the same every time — steps aside, a little further at each try.
*/
function apart(places, room) {
	const out = {};
	const taken = [];
	const free = (x, y) => taken.every((t) => Math.abs(t[0] - x) >= room || Math.abs(t[1] - y) >= room);
	for (const id of Object.keys(places).sort()) {
		const at = places[id];
		if (!Array.isArray(at) || !Number.isFinite(at[0]) || !Number.isFinite(at[1])) continue;
		let [x, y] = at;
		for (let k = 1; !free(x, y) && k < 400; k++) {
			x = Math.round(at[0] + Math.cos(k * 2.39996) * room * (1 + k * .35));
			y = Math.round(at[1] + Math.sin(k * 2.39996) * room * (1 + k * .35));
		}
		taken.push([x, y]);
		out[id] = x === at[0] && y === at[1] ? at : [x, y];
	}
	return out;
}
//#endregion
//#region plugins/map/layout/bubbles.ts
/** Where the four clouds gather, as the sketch drew them. */
var CLOUDS = [
	[200, 230],
	[640, 255],
	[235, 600],
	[650, 620]
];
/** The sheet's edges for a bubble. */
var SHEET$1 = {
	w: 885,
	h: 820
};
/**
* Where the clouds of so many groups gather: the sketch's four places for up to four, and for more
* a cloud's own cell of the sheet each, so no two groups share a cloud and no two titles a place
* (FM-MAP-35).
*/
function cloudsFor(groups) {
	if (groups <= CLOUDS.length) return CLOUDS;
	const columns = Math.ceil(Math.sqrt(groups * SHEET$1.w / SHEET$1.h));
	const rows = Math.ceil(groups / columns);
	return Array.from({ length: groups }, (_, g) => {
		const row = Math.floor(g / columns);
		const inRow = row === rows - 1 ? groups - columns * (rows - 1) : columns;
		return [SHEET$1.w * (g % columns + .5) / inRow, 50 + (SHEET$1.h - 50) * (row + .5) / rows];
	});
}
/** Every bubble of a level, scattered round its cloud or put back where it was dropped. */
function bubbles$1(level, stats, saved, given) {
	const clouds = cloudsFor(Math.max(1, level.frames.length));
	const tight = Math.sqrt(CLOUDS.length / clouds.length);
	const roomy = Math.max(8, Math.min(30, .5 * Math.sqrt(SHEET$1.w * SHEET$1.h / (Math.max(1, level.nodes.length) * Math.PI))));
	const alone = stats.big && new Set(level.nodes.map((n) => n.g)).size === 1;
	return level.nodes.map((n) => {
		const rand = given ?? partRand(n.id);
		const deg = stats.deg[n.id] ?? 0;
		const kept = saved?.[n.id];
		const own = Array.isArray(kept) && Number.isFinite(kept[0]) && Number.isFinite(kept[1]);
		const [ax, ay] = own ? kept : alone ? [SHEET$1.w / 2, SHEET$1.h / 2 + 20] : clouds[n.g % clouds.length];
		const spread = own ? 4 : 160 * tight;
		return {
			id: n.id,
			g: n.g,
			r: (stats.big ? roomy + Math.min(30, deg * 1.9) : 40 + (deg || 1) * 5) * (stats.big ? Math.max(.8, tight) : tight),
			ax,
			ay,
			bx: ax + (rand() - .5) * spread,
			by: ay + (rand() - .5) * spread,
			vx: 0,
			vy: 0,
			ph: rand() * 6.28,
			own
		};
	});
}
/** One frame at `seconds`: drift, the pull home, bubbles pushing apart, the sheet's edges. The held one only pushes. */
function float(all, seconds, held) {
	for (const n of all) {
		if (n === held) continue;
		const k = n.own ? .006 : .0016;
		n.vx += (n.ax - n.bx) * k + Math.cos(seconds * .7 + n.ph) * .035;
		n.vy += (n.ay - n.by) * k + Math.sin(seconds * .6 + n.ph * 1.7) * .035;
	}
	for (let i = 0; i < all.length; i++) for (let j = i + 1; j < all.length; j++) {
		const a = all[i];
		const b = all[j];
		const dx = b.bx - a.bx;
		const dy = b.by - a.by;
		const d = Math.sqrt(dx * dx + dy * dy) || 1;
		const over = a.r + b.r + 7 - d;
		if (over <= 0) continue;
		const ux = dx / d;
		const uy = dy / d;
		const ka = a === held ? 0 : b === held ? 1 : .5;
		const kb = 1 - ka;
		a.bx -= ux * over * ka;
		a.by -= uy * over * ka;
		b.bx += ux * over * kb;
		b.by += uy * over * kb;
		if (a !== held) {
			a.vx -= ux * .25;
			a.vy -= uy * .25;
		}
		if (b !== held) {
			b.vx += ux * .25;
			b.vy += uy * .25;
		}
	}
	for (const n of all) {
		if (n !== held) {
			n.vx *= .9;
			n.vy *= .9;
			n.bx += n.vx;
			n.by += n.vy;
		}
		n.bx = Math.min(SHEET$1.w - n.r, Math.max(n.r, n.bx));
		n.by = Math.min(SHEET$1.h - n.r, Math.max(n.r + 8, n.by));
	}
}
/** The clouds allowed to find their shape before the first frame is drawn. */
function gather(all, frames = 260) {
	for (let i = 0; i < frames; i++) float(all, i * 16 / 1e3, null);
}
/** A bubble dropped: where it is now is its home. */
function dropped(n) {
	n.ax = n.bx;
	n.ay = n.by;
	n.own = true;
}
/** The homes of the bubbles a person dropped, to be remembered. */
function homesOf(all) {
	const out = {};
	for (const n of all) if (n.own) out[n.id] = [Math.round(n.ax), Math.round(n.ay)];
	return out;
}
/** Where a group's title stands: over the bubbles of it nobody moved. Null when there are none. */
function titleAt(all, g) {
	const members = all.filter((n) => n.g === g && !n.own);
	if (!members.length) return null;
	return [members.reduce((sum, n) => sum + n.bx, 0) / members.length, Math.max(34, Math.min(...members.map((n) => n.by - n.r)) - 18)];
}
/**
* A title inside a bubble: its words in rows that fit, and the size they are drawn at.
*
* A bubble under twenty-two across holds no name at all — on a big map it is named beside the
* card, not inside the dot.
*/
function written(title, r) {
	if (r < 22) return {
		rows: [],
		size: 0
	};
	const words = title.replace("-", "- ").split(" ");
	const most = Math.max(7, Math.floor(r / 3.4));
	const rows = [];
	let row = "";
	for (const word of words) {
		const joined = row.endsWith("-") ? row + word : `${row} ${word}`.trim();
		if (joined.length > most && row) {
			rows.push(row);
			row = word;
		} else row = joined;
	}
	rows.push(row);
	const longest = Math.max(1, ...rows.map((x) => x.length));
	return {
		rows,
		size: Math.min(15, Math.max(10, r / 3.6), 2 * r * .84 / (longest * .6))
	};
}
//#endregion
//#region plugins/map/views/bubbles.ts
/** How wide a letter of a group's title is against how high: capitals, spaced, bold. */
var TITLE_LETTER = .74;
/** How long pushed bubbles are let settle once a hand lets go, while less motion is asked for. */
var SETTLE_MS = 1500;
function bubbles(ctx) {
	const { level, stats } = ctx;
	const all = bubbles$1(level, stats, ctx.places.get("pos"));
	const by = Object.fromEntries(all.map((b) => [b.id, b]));
	let held = null;
	/** Until when the bubbles a hand pushed are let find their places, while less motion is asked for. */
	let settling = 0;
	const titles = level.frames.map((f) => el("text", { class: "bgt" }, f.t.split(" · ")[0]));
	const lineLayer = el("g");
	/** The scale changed: which names can be read inside their bubbles is looked at again. */
	let stale = true;
	const sheet = flatSheet(ctx, {
		start: {
			x: 0,
			y: 0,
			k: 1
		},
		held: () => held !== null,
		scaled: () => stale = true
	});
	/** A pointer's place among the bubbles, whatever the sheet's scale. */
	const among = (e) => {
		const p = sheetPoint(ctx.svg, e);
		return {
			x: (p.x - sheet.at.x) / sheet.at.k,
			y: (p.y - sheet.at.y) / sheet.at.k
		};
	};
	sheet.layer.append(...titles, lineLayer);
	let lines = [];
	const view = {
		nodeEls: {},
		edgeEls: [],
		chosen: (id) => {
			lineLayer.replaceChildren();
			const near = new Set(neighbours(level, id));
			lines = [...near].map((other) => {
				const line = link("line", "bl", id, other);
				lineLayer.append(line);
				return line;
			});
			for (const n of level.nodes) view.nodeEls[n.id].classList.toggle("near", near.has(n.id));
		},
		stop: () => {}
	};
	const l = listeners();
	const ends = [];
	/** How large each bubble's name is written inside it; nought for a bubble that holds none. */
	const inside = {};
	const tags = el("g");
	const tagOf = {};
	/** The bubble under the pointer, and the bubbles whose names are written underneath now. */
	let over = null;
	let tagged = [];
	/** The titles that have stepped aside for the name of the chosen or the pointed-at part. */
	let aside = [];
	onLostAnywhere(l, ctx.svg, () => ends.forEach((end) => end()));
	for (const n of level.nodes) {
		const b = by[n.id];
		const fill = colourOf(n, ctx.palette);
		const g = el("g", {
			class: `n bub ${marksOf(n, stats)}`.trim(),
			tabindex: 0
		});
		g.dataset.id = n.id;
		g.append(el("circle", {
			class: "hit",
			r: b.r
		}), el("circle", {
			class: "halo",
			r: b.r + 9
		}), el("circle", {
			class: "ring",
			r: b.r + 6
		}), el("circle", {
			class: "deep",
			r: b.r + 3.2
		}), el("circle", {
			class: "c",
			r: b.r,
			fill
		}));
		const name = written(n.t, b.r);
		const ink = luminance(parseColour(fill) ?? [
			128,
			128,
			128
		]) < .3 ? "#ffffff" : "#12303f";
		name.rows.forEach((row, i) => g.append(el("text", {
			class: "bt",
			y: (i - (name.rows.length - 1) / 2) * name.size * 1.15 + name.size * .35,
			"font-size": name.size,
			fill: ink
		}, row)));
		const tag = el("text", {
			class: "bn",
			"dominant-baseline": "hanging"
		}, n.t);
		tag.dataset.for = n.id;
		tag.style.display = "none";
		tags.append(tag);
		tagOf[n.id] = tag;
		inside[n.id] = name.rows.length ? name.size : 0;
		l.on(g, "pointerenter", () => {
			over = n.id;
			stale = true;
		});
		l.on(g, "pointerleave", () => {
			if (over === n.id) over = null;
			stale = true;
		});
		let start = null;
		let dragged = false;
		l.on(g, "pointerdown", (e) => {
			if (!mainButton(e)) return;
			const p = among(e);
			start = {
				dx: b.bx - p.x,
				dy: b.by - p.y,
				down: {
					x: e.clientX,
					y: e.clientY
				}
			};
			dragged = false;
			held = b;
			hold(g, e);
		});
		const lost = () => {
			if (start && dragged) {
				dropped(b);
				ctx.places.set("pos", homesOf(all));
			}
			start = null;
			if (held === b) held = null;
		};
		ends.push(lost);
		onLost(l, g, lost);
		l.on(g, "pointermove", (e) => {
			if (!start) return;
			if (!pressed(e)) return lost();
			if (!dragged && !dragging(start.down, e)) return;
			dragged = true;
			const p = among(e);
			b.bx = p.x + start.dx;
			b.by = p.y + start.dy;
			b.vx = b.vy = 0;
		});
		l.on(g, "pointerup", () => {
			if (start && !dragged) ctx.choose(n.id);
			else if (start) {
				dropped(b);
				ctx.places.set("pos", homesOf(all));
			}
			start = null;
			held = null;
		});
		sheet.layer.append(g);
		view.nodeEls[n.id] = g;
	}
	sheet.layer.append(...titles, tags);
	gather(all);
	let before = 0;
	let frame = 0;
	let on = /* @__PURE__ */ new Set();
	const stopFrames = frames((now) => {
		if (stale || frame++ % 12 === 0) {
			const unit = sheet.at.k * screenScale(ctx.canvas);
			const font = NAME_PX$2 / unit;
			const tiny = all.filter((b) => inside[b.id] * unit < 9);
			if (stale) {
				for (const b of all) {
					view.nodeEls[b.id].classList.toggle("tiny", inside[b.id] * unit < 9);
					tagOf[b.id].style.fontSize = `${font}px`;
					tagOf[b.id].style.strokeWidth = `${3.5 / unit}px`;
					reach(view.nodeEls[b.id], b.r, unit);
				}
				for (const title of titles) {
					title.style.fontSize = `${15 * Math.min(nameScale(ctx.canvas), 1.6) / sheet.at.k}px`;
					title.style.strokeWidth = `${5 / sheet.at.k}px`;
				}
			}
			stale = false;
			const look = lookOf(view.nodeEls, on);
			if (over) look.first.add(over);
			const high = 15 * Math.min(nameScale(ctx.canvas), 1.6) / sheet.at.k;
			const rooms = titles.map((title, g) => {
				const at = titleAt(all, g);
				const w = (title.textContent ?? "").length * high * TITLE_LETTER;
				return at ? {
					x: at[0] - w / 2,
					y: at[1] - high,
					w,
					h: high * 1.3
				} : null;
			});
			look.taken = rooms.filter((room) => room !== null);
			const spots = tiny.map((b) => ({
				id: b.id,
				x: b.bx,
				y: b.by,
				r: b.r,
				font
			}));
			on = named(spots, stats, look);
			const firsts = spots.filter((s) => look.first.has(s.id)).map((s) => nameBox(s, stats.by[s.id].t.length));
			aside = rooms.map((room) => !!room && firsts.some((box) => box.x < room.x + room.w && room.x < box.x + box.w && box.y < room.y + room.h && room.y < box.y + box.h));
			tagged = [];
			for (const b of all) {
				const shown = inside[b.id] * unit < 9 && on.has(b.id);
				view.nodeEls[b.id].classList.toggle("quiet", inside[b.id] * unit < 9 && !shown);
				tagOf[b.id].style.display = shown ? "" : "none";
				if (shown) tagged.push(b);
			}
		}
		if (held) settling = now + SETTLE_MS;
		if (!pace.still() || held || now < settling) for (let i = stepsIn(now, before); i > 0; i--) float(all, now / 1e3, held);
		before = now;
		for (const b of all) view.nodeEls[b.id].setAttribute("transform", `translate(${b.bx},${b.by})`);
		for (const b of tagged) tagOf[b.id].setAttribute("transform", `translate(${b.bx.toFixed(1)},${(b.by + b.r + 6).toFixed(1)})`);
		titles.forEach((title, g) => {
			const at = titleAt(all, g);
			title.style.display = at && !aside[g] ? "" : "none";
			if (!at) return;
			title.setAttribute("x", String(at[0]));
			title.setAttribute("y", String(at[1]));
		});
		for (const line of lines) {
			const [a, b] = [by[line.dataset.a], by[line.dataset.b]];
			line.setAttribute("x1", String(a.bx));
			line.setAttribute("y1", String(a.by));
			line.setAttribute("x2", String(b.bx));
			line.setAttribute("y2", String(b.by));
		}
	});
	view.stop = () => {
		stopFrames();
		l.off();
		sheet.stop();
	};
	return view;
}
//#endregion
//#region plugins/map/layout/city.ts
/**
* The plan: each group a grid of houses on a plate, the plates in two rows, the town centred on
* the middle so it turns about itself.
*
* Up to four groups stand two to a row, as the sketch drew them; more take as many rows as keep
* the town about as deep as it is wide, and no plate ever stands on another (FM-MAP-35).
*/
function town(level, stats) {
	const big = stats.big;
	const cell = big ? 44 : 112;
	const hw = big ? 13 : 30;
	const gap = big ? 34 : 46;
	const blocks = level.frames.map((f, gi) => {
		const members = level.nodes.filter((n) => n.g === gi);
		if (!members.length) return null;
		const columns = big ? Math.ceil(Math.sqrt(members.length)) : [
			2,
			3,
			2,
			3
		][gi % 4];
		return {
			title: f.t,
			members,
			columns,
			w: columns * cell + 24,
			d: Math.ceil(members.length / columns) * cell + 24,
			x: 0,
			z: 0
		};
	}).filter((b) => b !== null);
	const perRow = blocks.length <= 4 ? 2 : blocks.length <= 6 ? 3 : Math.ceil(Math.sqrt(blocks.length));
	let z = 0;
	for (let from = 0; from < blocks.length; from += perRow) {
		const row = blocks.slice(from, from + perRow);
		let x = 0;
		for (const b of row) {
			b.x = x;
			b.z = z;
			x += b.w + gap;
		}
		z += Math.max(0, ...row.map((b) => b.d)) + gap;
	}
	const mx = Math.max(0, ...blocks.map((b) => b.x + b.w)) / 2;
	const mz = Math.max(0, ...blocks.map((b) => b.z + b.d)) / 2;
	const houses = [];
	const plates = [];
	for (const b of blocks) {
		b.x -= mx;
		b.z -= mz;
		b.members.forEach((n, i) => {
			const deg = stats.deg[n.id] ?? 0;
			houses.push({
				id: n.id,
				gx: b.x + 12 + i % b.columns * cell + cell / 2,
				gz: b.z + 12 + Math.floor(i / b.columns) * cell + cell / 2,
				bh: big ? 8 + deg * 5 : 24 + (deg || 1) * 14
			});
		});
		plates.push({
			title: b.title.split(" · ")[0],
			corners: [
				[b.x, b.z],
				[b.x + b.w, b.z],
				[b.x + b.w, b.z + b.d],
				[b.x, b.z + b.d]
			]
		});
	}
	return {
		houses,
		plates,
		hw
	};
}
/** The outline round a set of points: a house's footprint and its shadow's, as one shape. */
function hull(points) {
	const p = points.slice().sort((a, b) => a[0] - b[0] || a[1] - b[1]);
	const cross = (o, a, b) => (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
	const lower = [];
	const upper = [];
	for (const q of p) {
		while (lower.length > 1 && cross(lower[lower.length - 2], lower[lower.length - 1], q) <= 0) lower.pop();
		lower.push(q);
	}
	for (const q of p.slice().reverse()) {
		while (upper.length > 1 && cross(upper[upper.length - 2], upper[upper.length - 1], q) <= 0) upper.pop();
		upper.push(q);
	}
	return lower.slice(0, -1).concat(upper.slice(0, -1));
}
/** The four corners of a house, and the way each wall faces. */
var CORNERS = [
	[-1, -1],
	[1, -1],
	[1, 1],
	[-1, 1]
];
var NORMALS = [
	[0, -1],
	[1, 0],
	[0, 1],
	[-1, 0]
];
/** Where the light comes from: how far a shadow falls for each unit of height. */
var LIGHT = [.5, .34];
/** How bright a wall is, for the way it faces once the town has turned by `ry`. */
function wallLight(side, ry) {
	const [cy, sy] = [Math.cos(ry), Math.sin(ry)];
	const nx = NORMALS[side][0] * cy + NORMALS[side][1] * sy;
	const nz = -NORMALS[side][0] * sy + NORMALS[side][1] * cy;
	return .6 + .34 * Math.max(0, -nx * .55 + nz * .83);
}
//#endregion
//#region plugins/map/views/city.ts
/** The eye the town is seen from. */
var EYE$1 = {
	focal: 1500,
	cx: 442,
	cy: 455
};
/** How fast the town turns by itself, per sixtieth of a second. */
var SPEED$2 = .0028;
/** How many of the nearest houses keep their names; fewer in a small panel, where a name is large beside a house. */
var NAMED_NEAR = 7;
var NAMED_NEAR_SMALL = 3;
/**
* On a big town, more of them: the town is seen from further off, and its names are small beside it.
*
* A big town once named only the houses with fourteen links or more, so a town of sixty-four
* houses with no roads had no name on it (FM-MAP-63). Naming every house that has room — the rule
* of the flat views — was tried here and measured: hundreds of names moving with the town raised
* the page's memory by three hundred megabytes in some runs of a headless engine (FM-MAP-66). So
* a big town keeps the town's own rule: the nearest houses are named, each in its turn as the
* town turns, and the chosen, the picked and the pointed-at ones always.
*/
var NAMED_NEAR_BIG = 12;
function city(ctx) {
	const { level, stats } = ctx;
	const plan = town(level, stats);
	const reach = Math.max(1, ...plan.plates.flatMap((p) => p.corners.map((c) => Math.hypot(c[0], c[1]))));
	const high = Math.max(0, ...plan.houses.map((h) => h.bh));
	const fill = () => zoomToFill(ctx.canvas, reach * 2.1, reach * .9 + high + 40, stats.big ? .56 : .78);
	const k = camera({
		ry: .65,
		rx: -.62,
		zoom: fill()
	}, [-1.2, -.28], ctx.places.get("cam"));
	const hw = plan.hw;
	const ground = el("g");
	const roads = el("g");
	const shades = el("g");
	const layer = el("g");
	const routes = el("g");
	const names = el("g");
	ctx.svg.append(ground, roads, shades, layer, routes, names);
	const plates = plan.plates.map((p) => {
		const polygon = el("polygon", { class: "plate" });
		const title = el("text", { class: "ptitle" }, p.title);
		ground.append(polygon);
		names.append(title);
		return {
			polygon,
			title,
			corners: p.corners
		};
	});
	const view = {
		nodeEls: {},
		edgeEls: [],
		chosen: () => {},
		stop: () => {}
	};
	const l = listeners();
	let hovered = null;
	const houses = plan.houses.map((h) => {
		const n = stats.by[h.id];
		const shade = el("polygon", { class: "shade" });
		shades.append(shade);
		const g = el("g", {
			class: `n house ${marksOf(n, stats)}`.trim(),
			tabindex: 0
		});
		g.dataset.id = n.id;
		const walls = [
			0,
			1,
			2,
			3
		].map(() => el("polygon", { class: "wall" }));
		const roof = el("polygon", { class: "roof" });
		const lamp = el("circle", {
			class: "lamp",
			r: 5
		});
		const name = el("g");
		name.append(el("text", { class: "hlbl" }, n.t));
		g.append(...walls, roof, lamp, name);
		pressable(l, g, () => ctx.choose(n.id));
		l.on(g, "pointerenter", () => {
			k.over = true;
			hovered = n.id;
		});
		l.on(g, "pointerleave", () => {
			k.over = false;
			hovered = null;
		});
		layer.append(g);
		view.nodeEls[n.id] = g;
		return {
			...h,
			colour: colourOf(n, ctx.palette),
			g,
			shade,
			walls,
			roof,
			lamp,
			name,
			qx: 0,
			qy: 0,
			fx: 0,
			fy: 0,
			qz: 0
		};
	});
	const by = Object.fromEntries(houses.map((h) => [h.id, h]));
	const roadEls = level.edges.filter(([a, b]) => by[a] && by[b]).map(([a, b]) => {
		const line = link("line", "road", a, b);
		roads.append(line);
		return line;
	});
	let lines = [];
	let runners = [];
	view.chosen = (id, quiet) => {
		const h = by[id];
		if (!h) return;
		if (!quiet) aimAt(k, h.gx, h.gz);
		routes.replaceChildren();
		const near = neighbours(level, id).filter((other) => by[other]);
		lines = near.map((other) => {
			const line = link("line", "bl", id, other);
			routes.append(line);
			return line;
		});
		runners = near.map(() => {
			const c = el("circle", {
				class: "pt",
				r: 3
			});
			routes.append(c);
			return c;
		});
		for (const n of level.nodes) view.nodeEls[n.id]?.classList.toggle("near", near.includes(n.id));
	};
	const stopTurning = turning(ctx, k, fill);
	let order = "";
	const stopFrames = frames((now) => {
		camStep(k, now, SPEED$2);
		const at = (x, y, z) => {
			const q = project(k, {
				X: x,
				Y: y,
				Z: z
			}, EYE$1);
			return [
				q[0],
				q[1],
				q[3]
			];
		};
		for (const p of plates) {
			const q = p.corners.map((c) => at(c[0], 0, c[1]));
			p.polygon.setAttribute("points", points(q));
			let best = null;
			for (let i = 0; i < 4; i++) {
				const [a, b] = [q[i], q[(i + 1) % 4]];
				const mid = [
					(a[0] + b[0]) / 2,
					(a[1] + b[1]) / 2,
					(a[2] + b[2]) / 2
				];
				if (!best || mid[2] > best[2]) best = mid;
			}
			p.title.setAttribute("x", String(best[0]));
			p.title.setAttribute("y", String(best[1] + 20));
		}
		for (const h of houses) {
			const foot = CORNERS.map((c) => at(h.gx + c[0] * hw, 0, h.gz + c[1] * hw));
			const top = CORNERS.map((c) => at(h.gx + c[0] * hw, -h.bh, h.gz + c[1] * hw));
			const cast = CORNERS.map((c) => at(h.gx + c[0] * hw + LIGHT[0] * h.bh, 0, h.gz + c[1] * hw + LIGHT[1] * h.bh));
			h.shade.setAttribute("points", points(hull(foot.concat(cast).map((q) => [q[0], q[1]]))));
			[
				0,
				1,
				2,
				3
			].sort((i, j) => foot[i][2] + foot[(i + 1) % 4][2] - (foot[j][2] + foot[(j + 1) % 4][2])).forEach((i, n) => {
				h.walls[n].setAttribute("points", points([
					foot[i],
					foot[(i + 1) % 4],
					top[(i + 1) % 4],
					top[i]
				]));
				h.walls[n].setAttribute("fill", tint(h.colour, wallLight(i, k.ry)));
			});
			h.roof.setAttribute("points", points(top));
			h.roof.setAttribute("fill", tint(h.colour, 1, .28));
			const c = at(h.gx, -h.bh, h.gz);
			const g0 = at(h.gx, 0, h.gz);
			[h.qx, h.qy, h.qz, h.fx, h.fy] = [
				c[0],
				c[1],
				g0[2],
				g0[0],
				g0[1]
			];
			h.lamp.setAttribute("cx", String(c[0]));
			h.lamp.setAttribute("cy", String(c[1]));
			if (!h.g.classList.contains("mute")) h.name.setAttribute("transform", `translate(${c[0].toFixed(1)},${(c[1] - 14).toFixed(1)})`);
		}
		for (const road of roadEls) {
			const [a, b] = [by[road.dataset.a], by[road.dataset.b]];
			road.setAttribute("x1", String(a.fx));
			road.setAttribute("y1", String(a.fy));
			road.setAttribute("x2", String(b.fx));
			road.setAttribute("y2", String(b.fy));
		}
		const sorted = houses.slice().sort((a, b) => a.qz - b.qz);
		const key = sorted.map((h) => h.id).join();
		if (key !== order && !k.over) {
			order = key;
			for (const h of sorted) layer.append(h.g);
		}
		const small = screenScale(ctx.canvas) < .6;
		const near = new Set(sorted.slice(-(small ? NAMED_NEAR_SMALL : stats.big ? NAMED_NEAR_BIG : NAMED_NEAR)).map((h) => h.id));
		for (const h of houses) {
			const cl = h.g.classList;
			const shown = near.has(h.id) || h.id === hovered || cl.contains("sel") || cl.contains("pick") || !stats.big && !small && cl.contains("near");
			cl.toggle("mute", !shown);
		}
		lines.forEach((line, i) => {
			const [a, b] = [by[line.dataset.a], by[line.dataset.b]];
			line.setAttribute("x1", String(a.qx));
			line.setAttribute("y1", String(a.qy));
			line.setAttribute("x2", String(b.qx));
			line.setAttribute("y2", String(b.qy));
			const t = (now / 1800 + i * .17) % 1;
			runners[i].setAttribute("cx", String(a.qx + (b.qx - a.qx) * t));
			runners[i].setAttribute("cy", String(a.qy + (b.qy - a.qy) * t));
		});
	});
	view.stop = () => {
		stopFrames();
		stopTurning();
		l.off();
	};
	return view;
}
//#endregion
//#region plugins/map/layout/globe.ts
/** The globe on the sheet: its radius at rest and its middle. */
var GLOBE = {
	r: 292,
	cx: 442,
	cy: 405
};
/**
* Towns spread evenly over the sphere, group by group, so a group is a region.
*
* A golden-angle spiral from pole to pole: every town has the same room, however many there are.
*/
function towns(level, stats) {
	const order = level.nodes.slice().sort((a, b) => a.g - b.g);
	return order.map((n, i) => {
		const y = 1 - 2 * (i + .5) / order.length;
		const ring = Math.sqrt(1 - y * y);
		const th = i * 2.399963;
		const deg = stats.deg[n.id] ?? 0;
		return {
			id: n.id,
			u: [
				Math.cos(th) * ring,
				y,
				Math.sin(th) * ring
			],
			r: stats.big ? 3 + Math.min(9, deg * .55) : 6 + (deg || 1) * 1.5
		};
	});
}
/** The graticule: twelve meridians and five parallels, each a line of points. */
function graticule() {
	const lines = [];
	for (let m = 0; m < 12; m++) {
		const a = m * Math.PI / 6;
		const line = [];
		for (let k = 0; k <= 36; k++) {
			const t = -Math.PI / 2 + k * Math.PI / 36;
			line.push([
				Math.cos(t) * Math.cos(a),
				Math.sin(t),
				Math.cos(t) * Math.sin(a)
			]);
		}
		lines.push(line);
	}
	for (const lat of [
		-60,
		-30,
		0,
		30,
		60
	]) {
		const t = lat * Math.PI / 180;
		const line = [];
		for (let k = 0; k <= 48; k++) {
			const a = k * Math.PI / 24;
			line.push([
				Math.cos(t) * Math.cos(a),
				Math.sin(t),
				Math.cos(t) * Math.sin(a)
			]);
		}
		lines.push(line);
	}
	return lines;
}
/** A flight from one town to another: the great circle between them, lifted a little off the ground mid-way. */
function arc(a, b) {
	const w = Math.acos(Math.max(-1, Math.min(1, a[0] * b[0] + a[1] * b[1] + a[2] * b[2]))) || .001;
	const points = [];
	for (let k = 0; k <= 24; k++) {
		const t = k / 24;
		const ka = Math.sin((1 - t) * w) / Math.sin(w);
		const kb = Math.sin(t * w) / Math.sin(w);
		const lift = 1 + .045 * Math.sin(Math.PI * t) * Math.min(1, w);
		points.push([
			0,
			1,
			2
		].map((i) => (a[i] * ka + b[i] * kb) * lift));
	}
	return points;
}
/** A point `t` of the way along a flight. */
function along(points, t) {
	const k = Math.min(23, Math.floor(t * 24));
	const f = t * 24 - k;
	return [
		0,
		1,
		2
	].map((j) => points[k][j] + (points[k + 1][j] - points[k][j]) * f);
}
/** A point of the sphere on the sheet: `[x, y, depth]`; depth above zero faces the person. */
function turned(k, u) {
	const [cy, sy, cx, sx] = [
		Math.cos(k.ry),
		Math.sin(k.ry),
		Math.cos(k.rx),
		Math.sin(k.rx)
	];
	const size = GLOBE.r * k.zoom;
	const x1 = u[0] * cy + u[2] * sy;
	const z1 = -u[0] * sy + u[2] * cy;
	return [
		GLOBE.cx + x1 * size,
		GLOBE.cy - (u[1] * cx + z1 * sx) * size,
		-u[1] * sx + z1 * cx
	];
}
/** A line of the sphere as a path, drawn only where it faces the person: the pen lifts at the horizon. */
function facing(k, line, horizon) {
	let d = "";
	let pen = false;
	for (const u of line) {
		const q = turned(k, u);
		if (q[2] > horizon) {
			d += `${pen ? "L" : "M"}${q[0].toFixed(1)},${q[1].toFixed(1)}`;
			pen = true;
		} else pen = false;
	}
	return d;
}
//#endregion
//#region plugins/map/views/globe.ts
/** How fast the planet turns by itself, per sixtieth of a second. */
var SPEED$1 = .0034;
/** A flight and a town are drawn only this far round the edge, so nothing pops on the horizon. */
var HORIZON = .04;
function globe(ctx) {
	const { level, stats, palette } = ctx;
	const k = camera({
		ry: 0,
		rx: -.34,
		zoom: 1
	}, [-1.1, 1.1], ctx.places.get("cam"));
	const all = towns(level, stats);
	const by = Object.fromEntries(all.map((t) => [t.id, t]));
	const links = level.edges.filter(([a, b]) => by[a] && by[b]);
	const defs = el("defs");
	const light = el("radialGradient", {
		id: "globe-light",
		cx: ".36",
		cy: ".3",
		r: ".8"
	});
	light.append(el("stop", {
		offset: "0",
		"stop-color": palette.globe[0]
	}), el("stop", {
		offset: ".55",
		"stop-color": palette.globe[1]
	}), el("stop", {
		offset: "1",
		"stop-color": palette.globe[2]
	}));
	defs.append(light);
	const ball = el("circle", {
		class: "globe",
		cx: GLOBE.cx,
		cy: GLOBE.cy,
		fill: "url(#globe-light)"
	});
	const grid = el("path", { class: "grat" });
	const flights = el("g");
	const dots = el("g");
	ctx.svg.append(defs, ball, grid, flights, dots);
	const lines = graticule();
	const arcs = links.map(([a, b]) => arc(by[a].u, by[b].u));
	const view = {
		nodeEls: {},
		edgeEls: [],
		chosen: (id, quiet) => {
			hot(view, level, id);
			if (!quiet && by[id]) aimAt(k, by[id].u[0], by[id].u[2]);
		},
		stop: () => {}
	};
	view.edgeEls = links.map(([a, b]) => {
		const path = link("path", "e ga", a, b);
		flights.append(path);
		return path;
	});
	const runners = links.map(() => {
		const c = el("circle", {
			class: "pt",
			r: stats.big ? 1.6 : 2.8
		});
		flights.append(c);
		return c;
	});
	const phase = links.map(() => Math.random());
	const l = listeners();
	for (const n of level.nodes) {
		const g = dot(n, by[n.id].r, ctx, "kn");
		const c = g.querySelector(".c");
		c.setAttribute("stroke", palette.paper);
		c.setAttribute("stroke-width", "1.5");
		pressable(l, g, () => ctx.choose(n.id));
		l.on(g, "pointerenter", () => k.over = true);
		l.on(g, "pointerleave", () => k.over = false);
		dots.append(g);
		view.nodeEls[n.id] = g;
	}
	const stopTurning = turning(ctx, k);
	let frame = 0;
	let on = /* @__PURE__ */ new Set();
	const names = Object.fromEntries(level.nodes.map((n) => [n.id, view.nodeEls[n.id].querySelector("text")]));
	const sized = {};
	const stopFrames = frames((now) => {
		camStep(k, now, SPEED$1);
		ball.setAttribute("r", String(GLOBE.r * k.zoom));
		grid.setAttribute("d", lines.map((line) => facing(k, line, 0)).join(""));
		const spots = frame++ % 12 === 0 ? [] : null;
		for (const t of all) {
			const q = turned(k, t.u);
			const g = view.nodeEls[t.id];
			const size = stepped(.75 + .35 * Math.max(0, q[2]));
			g.setAttribute("transform", `translate(${q[0]},${q[1]}) scale(${size})`);
			g.style.display = q[2] > -.04 ? "" : "none";
			if (!spots) continue;
			const fits = readable(ctx.canvas, size);
			if (sized[t.id] !== fits.css) names[t.id].style.fontSize = sized[t.id] = fits.css;
			spots.push({
				id: t.id,
				x: q[0],
				y: q[1],
				r: t.r * size,
				font: fits.font,
				gone: q[2] <= -.04
			});
			reach(g, t.r, screenScale(ctx.canvas) * size);
		}
		if (spots) {
			on = named(spots, stats, lookOf(view.nodeEls, on));
			put(view.nodeEls, on);
		}
		view.edgeEls.forEach((path, i) => {
			path.setAttribute("d", facing(k, arcs[i], HORIZON));
			const q = turned(k, along(arcs[i], (now / 3e3 + phase[i]) % 1));
			runners[i].setAttribute("cx", String(q[0]));
			runners[i].setAttribute("cy", String(q[1]));
			runners[i].style.opacity = q[2] < HORIZON || path.classList.contains("off") ? "0" : ".9";
		});
	});
	view.stop = () => {
		stopFrames();
		stopTurning();
		l.off();
	};
	return view;
}
//#endregion
//#region plugins/map/layout/spring.ts
/** The sheet the flat views draw on. */
var SHEET = {
	w: 885,
	h: 840
};
/**
* Every part put down before the springs act: near its place on the blueprint, or — on a big
* map, where the blueprint is several screens wide — anywhere on the sheet.
*/
function seed(level, stats, home, given) {
	const bodies = level.nodes.map((n) => {
		const rand = given ?? partRand(n.id);
		const deg = stats.deg[n.id] ?? 0;
		if (stats.big) return {
			id: n.id,
			px: (.1 + .8 * rand()) * SHEET.w * stats.sc,
			py: (.1 + .8 * rand()) * SHEET.h * stats.sc,
			vx: 0,
			vy: 0,
			r: 3.5 + Math.min(13, deg * .75)
		};
		const [x, y] = home[n.id] ?? [20, 70];
		return {
			id: n.id,
			px: x + 90 + (rand() - .5) * 30,
			py: y + 27 + (rand() - .5) * 30,
			vx: 0,
			vy: 0,
			r: 6 + (deg || 1) * 1.7
		};
	});
	const by = {};
	for (const b of bodies) by[b.id] = b;
	return {
		bodies,
		by,
		links: level.edges.filter(([a, b]) => by[a] && by[b]).map(([a, b]) => [by[a], by[b]]),
		big: stats.big,
		sc: stats.sc,
		alpha: 1
	};
}
/** One step of the springs, at heat `a0`. A part held in the hand is pushed but does not move. */
function step(f, a0, held = null) {
	const push = f.big ? 5200 : 19e3;
	const rest = f.big ? 62 : 165;
	for (const a of f.bodies) {
		for (const b of f.bodies) {
			if (a === b) continue;
			const dx = a.px - b.px;
			const dy = a.py - b.py;
			const d2 = dx * dx + dy * dy + .01;
			const d = Math.sqrt(d2);
			const force = push / d2;
			a.vx += dx / d * force;
			a.vy += dy / d * force;
		}
		a.vx += (442 * f.sc - a.px) * .0035;
		a.vy += (420 * f.sc - a.py) * .0035;
	}
	for (const [a, b] of f.links) {
		const dx = b.px - a.px;
		const dy = b.py - a.py;
		const d = Math.sqrt(dx * dx + dy * dy) || 1;
		const force = (d - rest) * .03;
		a.vx += dx / d * force;
		a.vy += dy / d * force;
		b.vx -= dx / d * force;
		b.vy -= dy / d * force;
	}
	for (const n of f.bodies) {
		if (n === held) continue;
		n.vx += past(n.px, 40, 845 * f.sc) * WALL;
		n.vy += past(n.py, 30, 800 * f.sc) * WALL;
		n.vx *= .78;
		n.vy *= .78;
		n.px += n.vx * a0;
		n.py += n.vy * a0;
	}
}
/** How hard an edge of the sheet pushes a part back, for each unit it is past it. */
var WALL = .3;
/** How far a place is outside `[low, high]`, signed towards the inside; nought within. */
var past = (at, low, high) => at < low ? low - at : at > high ? high - at : 0;
/**
* No part on another: any two nearer than their two radii and a little are moved apart, along the
* line between them — or, when they stand on one point, each its own way by its place in the list,
* so the answer is the same every time. The springs leave it so already; this is what makes it
* certain, for places kept by an older version as much as for a layout just made (FM-MAP-64).
*/
function unstack(f, held = null) {
	for (let pass = 0; pass < 12; pass++) {
		let moved = false;
		for (let i = 0; i < f.bodies.length; i++) for (let j = i + 1; j < f.bodies.length; j++) {
			const a = f.bodies[i];
			const b = f.bodies[j];
			const need = a.r + b.r + 6;
			let dx = b.px - a.px;
			let dy = b.py - a.py;
			if (Math.abs(dx) >= need || Math.abs(dy) >= need) continue;
			let d = Math.sqrt(dx * dx + dy * dy);
			if (d >= need) continue;
			if (d < .01) {
				dx = Math.cos(j * 2.39996);
				dy = Math.sin(j * 2.39996);
				d = 1;
			}
			const step = (need - d) / d;
			const ka = a === held ? 0 : b === held ? 1 : .5;
			a.px -= dx * step * ka;
			a.py -= dy * step * ka;
			b.px += dx * step * (1 - ka);
			b.py += dy * step * (1 - ka);
			moved = true;
		}
		if (!moved) return;
	}
}
/** The springs run to rest before the first frame, so a map opens laid out and not exploding. */
function settle(f) {
	f.alpha = 1;
	for (let i = 0; i < (f.big ? 240 : 420); i++) {
		step(f, f.alpha);
		f.alpha *= .992;
	}
	unstack(f);
}
/** A frame of the living graph: the springs cool a little more each time, and stop when cold. */
function live(f, held) {
	if (f.alpha <= .02) return;
	step(f, f.alpha, held);
	unstack(f, held);
	f.alpha *= .985;
}
/** Where every part stands, rounded, to be remembered. */
function placesOf(f) {
	const out = {};
	for (const b of f.bodies) out[b.id] = [Math.round(b.px), Math.round(b.py)];
	return out;
}
/** Remembered places put back; a part that has none keeps where the springs left it. */
function restore(f, saved) {
	if (!saved) return false;
	for (const b of f.bodies) {
		const at = saved[b.id];
		if (Array.isArray(at) && Number.isFinite(at[0]) && Number.isFinite(at[1])) [b.px, b.py] = at;
	}
	unstack(f);
	return true;
}
//#endregion
//#region plugins/map/views/graph.ts
/** Two parts nearer than this are one to the eye: kept places are moved this far apart. */
var ROOM = 16;
/** Names are drawn this large on the screen, whatever the scale and however small the panel. */
var NAME_PX$1 = 12;
function graph(ctx) {
	const { level, stats } = ctx;
	let held = null;
	let dropped = null;
	let moved = false;
	let from = {
		x: 0,
		y: 0
	};
	/** The names are looked at again: the scale changed, a part was moved, another was chosen. */
	let stale = true;
	const field = seed(level, stats, ctx.home);
	settle(field);
	const saved = ctx.places.get("pos");
	field.alpha = restore(field, saved ? apart(saved, ROOM) : null) ? 0 : .25;
	/** The places as they stand, no two on one spot, remembered — and the parts moved to them. */
	const keep = () => {
		const places = apart(placesOf(field), ROOM);
		restore(field, places);
		ctx.places.set("pos", places);
		sheet.stay();
	};
	const names = [];
	/** Everything drawn, with room for the names under the dots. */
	const content = () => {
		const xs = field.bodies.map((b) => b.px);
		const ys = field.bodies.map((b) => b.py);
		const pad = stats.big ? 40 : 56;
		const [x, y] = [Math.min(...xs) - pad, Math.min(...ys) - pad];
		return {
			x,
			y,
			w: Math.max(...xs) + pad - x,
			h: Math.max(...ys) + pad + 14 - y
		};
	};
	const sheet = flatSheet(ctx, {
		start: {
			x: 0,
			y: 0,
			k: 1 / stats.sc
		},
		content,
		most: stats.big ? 1 : 1.5,
		stays: "graph",
		held: () => held !== null,
		scaled: (k) => {
			const one = 1 / (k * screenScale(ctx.canvas));
			for (const text of names) {
				text.style.fontSize = `${NAME_PX$1 * one}px`;
				text.style.strokeWidth = `${3.5 * one}px`;
			}
			stale = true;
		}
	});
	const name = () => {
		stale = false;
		const unit = sheet.at.k * screenScale(ctx.canvas);
		const font = NAME_PX$1 / unit;
		put(view.nodeEls, named(field.bodies.map((b) => ({
			id: b.id,
			x: b.px,
			y: b.py,
			r: b.r,
			font
		})), stats, lookOf(view.nodeEls)));
		for (const b of field.bodies) reach(view.nodeEls[b.id], b.r, unit);
	};
	const view = {
		nodeEls: {},
		edgeEls: [],
		chosen: (id) => {
			hot(view, level, id);
			stale = true;
		},
		stop: () => {}
	};
	view.edgeEls = field.links.map(([a, b]) => {
		const line = link("line", "e ge", a.id, b.id);
		sheet.layer.append(line);
		return line;
	});
	const runners = field.links.map(() => {
		const c = el("circle", {
			class: "pt",
			r: stats.big ? 1.6 : 2.4
		});
		sheet.layer.append(c);
		return c;
	});
	const phase = field.links.map(() => Math.random());
	const l = listeners();
	/** The press is over. Dropped after a move, the part stays; let go in place by its own release, it is chosen. */
	const release = (own) => {
		const body = held;
		if (!body) return;
		held = null;
		if (moved) {
			dropped = body;
			keep();
		} else if (own) ctx.choose(body.id);
	};
	const lost = () => release(false);
	for (const n of level.nodes) {
		const body = field.by[n.id];
		const g = dot(n, body.r, ctx);
		names.push(g.querySelector("text"));
		l.on(g, "pointerdown", (e) => {
			e.stopPropagation();
			lost();
			if (!mainButton(e)) return;
			held = body;
			dropped = null;
			moved = false;
			from = {
				x: e.clientX,
				y: e.clientY
			};
			hold(g, e);
		});
		l.on(g, "pointerup", () => {
			if (held === body) release(true);
		});
		onLost(l, g, lost);
		l.on(g, "pointerenter", () => {
			if (!held) fadeBut(view, level, n.id);
		});
		l.on(g, "pointerleave", () => {
			if (!held) fadeBut(view, level, null);
		});
		sheet.layer.append(g);
		view.nodeEls[n.id] = g;
	}
	l.on(ctx.svg, "pointermove", (e) => {
		if (!held) return;
		if (!pressed(e)) return lost();
		if (!moved && !dragging(from, e)) return;
		moved = true;
		const p = sheetPoint(ctx.svg, e);
		held.px = (p.x - sheet.at.x) / sheet.at.k;
		held.py = (p.y - sheet.at.y) / sheet.at.k;
		held.vx = held.vy = 0;
		stale = true;
		field.alpha = Math.max(field.alpha, .35);
	});
	onLostAnywhere(l, ctx.svg, lost);
	sheet.apply();
	const drift = Object.fromEntries(field.bodies.map((b) => [b.id, drifter(b.id)]));
	const at = Object.fromEntries(field.bodies.map((b) => [b.id, [b.px, b.py]]));
	let frame = 0;
	const stopFrames = frames((now) => {
		const warm = field.alpha > .02;
		live(field, held ?? dropped);
		if (dropped && field.alpha <= .02) {
			keep();
			dropped = null;
			stale = true;
		}
		const far = driftReach(sheet.at.k * screenScale(ctx.canvas));
		for (const b of field.bodies) {
			const off = b === held || b === dropped ? null : drift[b.id](now, far);
			const place = at[b.id];
			place[0] = b.px + (off ? off[0] : 0);
			place[1] = b.py + (off ? off[1] : 0);
			view.nodeEls[b.id].setAttribute("transform", off ? `translate(${b.px},${b.py}) translate(${off[0].toFixed(2)},${off[1].toFixed(2)})` : `translate(${b.px},${b.py})`);
		}
		field.links.forEach((pair, i) => {
			const a = at[pair[0].id];
			const b = at[pair[1].id];
			const line = view.edgeEls[i];
			line.setAttribute("x1", String(a[0]));
			line.setAttribute("y1", String(a[1]));
			line.setAttribute("x2", String(b[0]));
			line.setAttribute("y2", String(b[1]));
			const t = (now / 2600 + phase[i]) % 1;
			runners[i].setAttribute("cx", String(a[0] + (b[0] - a[0]) * t));
			runners[i].setAttribute("cy", String(a[1] + (b[1] - a[1]) * t));
			runners[i].style.opacity = dimmed(line) ? "0" : ".8";
		});
		if (stale || warm && ++frame % 12 === 0) name();
	});
	view.stop = () => {
		if (dropped) keep();
		stopFrames();
		l.off();
		sheet.stop();
	};
	return view;
}
//#endregion
//#region plugins/map/layout/history.ts
/** The steps a level grows in. */
function growth(nodes, past) {
	const bornAt = {};
	if (nodes.length > 0 && nodes.every((n) => n.born !== "")) {
		const steps = [...new Set(nodes.map((n) => n.born))].sort().map((stamp) => ({
			stamp,
			ids: nodes.filter((n) => n.born === stamp).map((n) => n.id)
		}));
		steps.forEach((s, i) => s.ids.forEach((id) => bornAt[id] = i + 1));
		return {
			dated: true,
			by: "born",
			steps,
			bornAt,
			freshAt: { ...bornAt }
		};
	}
	if (!nodes.some((n) => n.seen)) {
		const steps = nodes.map((n) => ({
			stamp: "",
			ids: [n.id]
		}));
		steps.forEach((s, i) => s.ids.forEach((id) => bornAt[id] = i + 1));
		return {
			dated: false,
			by: "order",
			steps,
			bornAt,
			freshAt: { ...bornAt }
		};
	}
	const days = [...new Set(nodes.map((n) => n.seen ?? "").filter(Boolean))].sort();
	const first = days[0];
	const record = days.map((stamp) => ({
		stamp,
		seen: true,
		ids: nodes.filter((n) => (n.seen || first) === stamp).map((n) => n.id)
	}));
	const steps = [...(past?.days ?? []).map((d) => ({
		stamp: d.on,
		ids: [],
		commits: {
			count: d.count,
			said: d.said
		}
	})), ...record].sort((a, b) => a.stamp.localeCompare(b.stamp) || Number(!!a.seen) - Number(!!b.seen));
	const freshAt = {};
	steps.forEach((s, i) => s.ids.forEach((id) => {
		bornAt[id] = s.stamp === first ? 1 : i + 1;
		if (s.stamp !== first) freshAt[id] = i + 1;
	}));
	return {
		dated: true,
		by: "record",
		steps,
		bornAt,
		freshAt
	};
}
/** How many parts exist once step `k` has happened. */
function grownBy(g, k) {
	return Object.values(g.bornAt).filter((at) => at <= k).length;
}
/** The names said at a step: the first three, and how many more there are. */
function namesAt(step, titleOf) {
	return {
		names: step.ids.slice(0, 3).map(titleOf).join(", "),
		more: Math.max(0, step.ids.length - 3)
	};
}
//#endregion
//#region plugins/map/views/history.ts
/** How long each step of the growth stays before the next. */
var STEP_MS = 1300;
/** Names are drawn this large on the screen, whatever the scale and however small the panel. */
var NAME_PX = 12;
function history(ctx) {
	const { level, stats } = ctx;
	const field = seed(level, stats, ctx.home);
	settle(field);
	const grown = growth(level.nodes, level.past);
	const names = [];
	let stale = true;
	const content = () => {
		const xs = field.bodies.map((b) => b.px);
		const ys = field.bodies.map((b) => b.py);
		const pad = stats.big ? 40 : 56;
		const [x, y] = [Math.min(...xs) - pad, Math.min(...ys) - pad];
		return {
			x,
			y,
			w: Math.max(...xs) + pad - x,
			h: Math.max(...ys) + pad + 14 - y
		};
	};
	const sheet = flatSheet(ctx, {
		start: {
			x: 0,
			y: 0,
			k: 1 / stats.sc
		},
		content,
		most: stats.big ? 1 : 1.5,
		held: () => false,
		scaled: (k) => {
			const one = 1 / (k * screenScale(ctx.canvas));
			for (const text of names) {
				text.style.fontSize = `${NAME_PX * one}px`;
				text.style.strokeWidth = `${3.5 * one}px`;
			}
			stale = true;
		}
	});
	const root = sheet.layer;
	const view = {
		nodeEls: {},
		edgeEls: [],
		chosen: (id) => {
			hot(view, level, id);
			stale = true;
		},
		stop: () => {}
	};
	view.edgeEls = field.links.map(([a, b]) => {
		const line = link("line", "e ge he", a.id, b.id);
		root.append(line);
		return line;
	});
	const l = listeners();
	for (const n of level.nodes) {
		const body = field.by[n.id];
		const g = dot(n, body.r, ctx, "hn");
		names.push(g.querySelector("text"));
		const inner = el("g", { class: "in" });
		const name = g.querySelector("text");
		while (g.firstChild) inner.append(g.firstChild);
		inner.insertBefore(el("circle", {
			class: "wave",
			r: body.r + 4
		}), inner.children[1]);
		g.append(inner, name);
		pressable(l, g, () => ctx.choose(n.id));
		root.append(g);
		view.nodeEls[n.id] = g;
	}
	sheet.apply();
	const drift = Object.fromEntries(field.bodies.map((b) => [b.id, drifter(b.id)]));
	const at = Object.fromEntries(field.bodies.map((b) => [b.id, [b.px, b.py]]));
	const stopFrames = frames((now) => {
		const far = driftReach(sheet.at.k * screenScale(ctx.canvas));
		for (const b of field.bodies) {
			const off = drift[b.id](now, far);
			const place = at[b.id];
			place[0] = b.px + off[0];
			place[1] = b.py + off[1];
			view.nodeEls[b.id].setAttribute("transform", `translate(${b.px},${b.py}) translate(${off[0].toFixed(2)},${off[1].toFixed(2)})`);
		}
		field.links.forEach((pair, i) => {
			const a = at[pair[0].id];
			const b = at[pair[1].id];
			const line = view.edgeEls[i];
			line.setAttribute("x1", String(a[0]));
			line.setAttribute("y1", String(a[1]));
			line.setAttribute("x2", String(b[0]));
			line.setAttribute("y2", String(b[1]));
		});
		if (!stale) return;
		stale = false;
		const unit = sheet.at.k * screenScale(ctx.canvas);
		const font = NAME_PX / unit;
		put(view.nodeEls, named(field.bodies.map((b) => ({
			id: b.id,
			x: b.px,
			y: b.py,
			r: b.r,
			font
		})), stats, lookOf(view.nodeEls)));
		for (const b of field.bodies) reach(view.nodeEls[b.id], b.r, unit);
	});
	const bar = document.createElement("div");
	bar.id = "timebar";
	const play = document.createElement("button");
	play.id = "tplay";
	play.type = "button";
	const slider = document.createElement("input");
	slider.id = "tr";
	slider.type = "range";
	slider.min = "1";
	slider.max = String(Math.max(1, grown.steps.length));
	slider.value = "1";
	const caption = document.createElement("div");
	caption.id = "tcap";
	bar.append(play, slider, caption);
	if (grown.by === "record") {
		const plainly = document.createElement("div");
		plainly.id = "tnote";
		plainly.textContent = ctx.say("No dates of birth can be read in this folder. Shown: the commits that could be read, and what the map itself has seen since {0}.", ctx.day(grown.steps.find((s) => s.seen)?.stamp ?? ""));
		bar.append(plainly);
	}
	ctx.canvas.append(bar);
	let step = 0;
	let timer = null;
	/** ▶ was pressed: the person asked for the growth, so it plays even with less motion asked for. */
	let byHand = false;
	const last = () => step >= grown.steps.length;
	const show = (k) => {
		step = k;
		slider.value = String(k);
		const at = grown.steps[k - 1];
		if (at) {
			const { names, more } = namesAt(at, (id) => stats.by[id]?.t ?? id);
			const said = more ? ctx.say("{0} and {1} more", names, more) : names;
			const when = document.createElement("b");
			when.textContent = grown.dated ? ctx.day(at.stamp) : ctx.say("Step {0}", k);
			const count = document.createElement("small");
			count.textContent = ctx.say("{0} of {1}", grownBy(grown, k), level.nodes.length);
			const told = at.commits ? ctx.say("commits: {0} — {1}", at.commits.count, at.commits.said.join("; ")) : at.seen && grown.bornAt[at.ids[0]] === 1 ? ctx.say("the map first read this folder: {0} parts", at.ids.length) : at.seen ? ctx.say("first seen by the map: {0}", said) : at.ids.length > 1 ? ctx.say("several parts appeared: {0}", said) : ctx.say("one part appeared: {0}", said);
			caption.replaceChildren(when, told, count);
		}
		for (const n of level.nodes) {
			view.nodeEls[n.id].classList.toggle("born", grown.bornAt[n.id] <= k);
			view.nodeEls[n.id].classList.toggle("fresh", grown.freshAt[n.id] === k);
		}
		for (const line of view.edgeEls) line.classList.toggle("born", grown.bornAt[line.dataset.a] <= k && grown.bornAt[line.dataset.b] <= k);
	};
	const face = () => {
		play.textContent = timer ? "❚❚" : last() ? "↻" : "▶";
		play.setAttribute("aria-label", timer ? ctx.say("Pause") : ctx.say("Play"));
	};
	const pause = () => {
		if (timer) clearInterval(timer);
		timer = null;
		face();
	};
	const start = () => {
		if (last()) show(1);
		timer = setInterval(() => last() || pace.still() && !byHand ? pause() : show(step + 1), STEP_MS);
		face();
	};
	l.on(play, "click", () => (byHand = true, timer ? pause() : start()));
	l.on(slider, "input", () => {
		pause();
		show(Number(slider.value));
		face();
	});
	if (grown.steps.length > 1 && !pace.still()) {
		show(1);
		start();
	} else {
		show(pace.still() ? Math.max(1, grown.steps.length) : 1);
		face();
	}
	view.stop = () => {
		if (timer) clearInterval(timer);
		stopFrames();
		l.off();
		sheet.stop();
		bar.remove();
	};
	return view;
}
//#endregion
//#region plugins/map/layout/cloud.ts
/** The cloud for a level, at rest. */
function cloud(level, stats, home, given) {
	const v = {};
	const stars = level.nodes.map((n) => {
		const rand = given ?? partRand(n.id);
		const deg = stats.deg[n.id] ?? 0;
		v[n.id] = [
			0,
			0,
			0
		];
		const at = {
			qx: 0,
			qy: 0,
			qz: 0
		};
		if (stats.big) return {
			id: n.id,
			X: (rand() - .5) * 1100,
			Y: (rand() - .5) * 800,
			Z: (rand() - .5) * 1100,
			r: 3.5 + Math.min(13, deg * .75),
			...at
		};
		const [x, y] = home[n.id] ?? [20, 70];
		return {
			id: n.id,
			X: (x - 350) * .8 + (rand() - .5) * 60,
			Y: (y - 420) * .55 + (rand() - .5) * 60,
			Z: (rand() - .5) * 380,
			r: 7 + (deg || 1) * 1.8,
			...at
		};
	});
	const by = {};
	for (const s of stars) by[s.id] = s;
	const links = level.edges.filter(([a, b]) => by[a] && by[b]);
	const push = stats.big ? 7e3 : 3e4;
	const rest = stats.big ? 75 : 170;
	const pairs = links.map(([i, j]) => [by[i], by[j]]);
	for (let k = 0; k < (stats.big ? 200 : 420); k++) {
		const a0 = Math.pow(.992, k);
		for (const a of stars) {
			const va = v[a.id];
			for (const b of stars) {
				if (a === b) continue;
				const dx = a.X - b.X;
				const dy = a.Y - b.Y;
				const dz = a.Z - b.Z;
				const d2 = dx * dx + dy * dy + dz * dz + .01;
				const d = Math.sqrt(d2);
				const f = push / d2;
				va[0] += dx / d * f;
				va[1] += dy / d * f;
				va[2] += dz / d * f;
			}
			va[0] -= a.X * .004;
			va[1] -= a.Y * .004;
			va[2] -= a.Z * .004;
		}
		for (const pair of pairs) {
			const a = pair[0];
			const b = pair[1];
			const dx = b.X - a.X;
			const dy = b.Y - a.Y;
			const dz = b.Z - a.Z;
			const d = Math.sqrt(dx * dx + dy * dy + dz * dz) || 1;
			const f = (d - rest) * .03;
			const va = v[a.id];
			const vb = v[b.id];
			va[0] += dx / d * f;
			va[1] += dy / d * f;
			va[2] += dz / d * f;
			vb[0] -= dx / d * f;
			vb[1] -= dy / d * f;
			vb[2] -= dz / d * f;
		}
		for (const s of stars) {
			const vs = v[s.id];
			vs[0] *= .78;
			vs[1] *= .78;
			vs[2] *= .78;
			s.X += vs[0] * a0;
			s.Y += vs[1] * a0;
			s.Z += vs[2] * a0;
		}
	}
	return stars;
}
//#endregion
//#region plugins/map/views/space.ts
/** The eye the cloud is seen from. */
var EYE = {
	focal: 1100,
	cx: 442,
	cy: 410
};
/** How fast the cloud turns by itself, per sixtieth of a second. */
var SPEED = .0032;
function space(ctx) {
	const { level, stats } = ctx;
	const stars = cloud(level, stats, ctx.home);
	const reach$1 = Math.max(1, ...stars.map((s) => Math.hypot(s.X, s.Y, s.Z))) + 40;
	const fill = () => zoomToFill(ctx.canvas, reach$1 * 2.1, reach$1 * 2.1, stats.big ? .5 : .8);
	const k = camera({
		ry: 0,
		rx: -.28,
		zoom: fill()
	}, [-1.2, 1.2], ctx.places.get("cam"));
	const by = Object.fromEntries(stars.map((s) => [s.id, s]));
	const links = level.edges.filter(([a, b]) => by[a] && by[b]);
	const lines = el("g");
	const dots = el("g");
	ctx.svg.append(lines, dots);
	const view = {
		nodeEls: {},
		edgeEls: [],
		chosen: (id, quiet) => {
			hot(view, level, id);
			if (!quiet && by[id]) aimAt(k, by[id].X, by[id].Z);
		},
		stop: () => {}
	};
	view.edgeEls = links.map(([a, b]) => {
		const line = link("line", "e ge", a, b);
		lines.append(line);
		return line;
	});
	const runners = links.map(() => {
		const c = el("circle", {
			class: "pt",
			r: stats.big ? 1.6 : 2.6
		});
		lines.append(c);
		return c;
	});
	const phase = links.map(() => Math.random());
	const l = listeners();
	for (const n of level.nodes) {
		const g = dot(n, by[n.id].r, ctx, "kn");
		pressable(l, g, () => ctx.choose(n.id));
		l.on(g, "pointerenter", () => {
			k.over = true;
			fadeBut(view, level, n.id);
		});
		l.on(g, "pointerleave", () => {
			k.over = false;
			fadeBut(view, level, null);
		});
		dots.append(g);
		view.nodeEls[n.id] = g;
	}
	const stopTurning = turning(ctx, k, fill);
	let frame = 0;
	let on = /* @__PURE__ */ new Set();
	const scale = {};
	const names = Object.fromEntries(level.nodes.map((n) => [n.id, view.nodeEls[n.id].querySelector("text")]));
	const sized = {};
	const stopFrames = frames((now) => {
		camStep(k, now, SPEED);
		for (const s of stars) {
			const q = project(k, s, EYE);
			s.qx = q[0];
			s.qy = q[1];
			s.qz = q[3];
			scale[s.id] = stepped(q[2]);
			const g = view.nodeEls[s.id];
			g.setAttribute("transform", `translate(${q[0]},${q[1]}) scale(${scale[s.id]})`);
			g.style.opacity = dimmed(g) ? "" : String(Math.max(.5, Math.min(1, .7 + q[3] / 600)));
		}
		links.forEach(([i, j], n) => {
			const [a, b] = [by[i], by[j]];
			const line = view.edgeEls[n];
			line.setAttribute("x1", String(a.qx));
			line.setAttribute("y1", String(a.qy));
			line.setAttribute("x2", String(b.qx));
			line.setAttribute("y2", String(b.qy));
			const t = (now / 2600 + phase[n]) % 1;
			runners[n].setAttribute("cx", String(a.qx + (b.qx - a.qx) * t));
			runners[n].setAttribute("cy", String(a.qy + (b.qy - a.qy) * t));
			runners[n].style.opacity = dimmed(line) ? "0" : ".8";
		});
		if (++frame % 20 === 0 && !k.over) stars.slice().sort((a, b) => a.qz - b.qz).forEach((s) => dots.append(view.nodeEls[s.id]));
		if (frame % 12 === 1) {
			on = named(stars.map((s) => {
				const size = readable(ctx.canvas, scale[s.id]);
				if (sized[s.id] !== size.css) names[s.id].style.fontSize = sized[s.id] = size.css;
				return {
					id: s.id,
					x: s.qx,
					y: s.qy,
					r: s.r * scale[s.id],
					font: size.font
				};
			}), stats, lookOf(view.nodeEls, on));
			put(view.nodeEls, on);
			const unit = screenScale(ctx.canvas);
			for (const s of stars) reach(view.nodeEls[s.id], s.r, unit * scale[s.id]);
		}
	});
	view.stop = () => {
		stopFrames();
		stopTurning();
		l.off();
	};
	return view;
}
//#endregion
//#region plugins/map/map.ts
var VIEWS = {
	graph,
	blueprint,
	space,
	bubbles,
	history,
	globe,
	city
};
var byId = (id) => document.getElementById(id);
var sheet = () => document.getElementById("svg");
/** Everything the panel knows and shows. */
var state = {
	project: null,
	/** Asked for long enough: the window has no folder to grant. */
	noFolder: false,
	palette: paletteFor({}),
	/** The memory, and whether the top of the folder has been read. */
	world: null,
	read: false,
	/** The level on the screen, and the project level to come back to from the memory. */
	key: ROOT,
	projectKey: ROOT,
	level: null,
	stats: null,
	/** What the level on the screen looked like when it was last drawn. */
	drawn: "",
	chosen: {
		cur: null,
		picked: []
	},
	lit: {
		mode: "all",
		q: "",
		only: null
	},
	skin: "graph",
	/** "Choose several" is on, or Shift was down at the last press; Control was: the Mac's secondary press. */
	several: false,
	shift: false,
	ctrl: false,
	/** The person has chosen or moved something on the level on the screen. */
	acted: false,
	compose: null,
	view: null,
	places: null,
	choice: null,
	/** The card is the one of the folder the screen is in, until a part of it is chosen (FM-MAP-61). */
	own: false,
	/** Going into a folder, or coming out: a second press in that moment goes nowhere. */
	entering: false,
	/** The text of a part, read and shown in its card. */
	opened: null,
	/** A filter is on and nothing has been chosen from it yet: the card is its list (FM-MAP-81). */
	listing: false
};
var watcher = null;
/** Every listener the panel puts on the window and the document, so it can take them all away. */
var page = listeners();
var stopped = false;
/** Watches the panel's size, for the size of the names over the map. */
var sized = null;
/** The panel's own reading of the folder, kept between openings (FM-MAP-44, FM-MAP-52). */
var book = null;
/** What could be read of the folder's history: a line of the "⋯" menu, never a tag over the map (FM-MAP-54, FM-MAP-81). */
var drawStatus = () => status(pastWords(state.level));
/** The strip of the panel's own reading, and which folder is being mapped (FM-MAP-56). */
function drawWork() {
	byId("work").innerHTML = stripHtml(book?.reading() ?? null, state.level, Date.now());
	const at = [state.project ?? "", state.key === "root" || state.key === "memory" ? "" : state.key].filter(Boolean).join("/");
	byId("where").textContent = at;
	byId("cut").textContent = cutWords(state.level);
	byId("where").title = at;
}
/** One look at the folder on the screen: cheap, and it asks for a reading when one is due. */
async function look() {
	if (await book.look(state.projectKey, pace.resting())) looks += 1;
	return {
		print: String(looks),
		read: null
	};
}
/** Counted up whenever a look, or a reading, changed what is drawn. */
var looks = 0;
/** The title a level goes by: the folder's own for the top, the part's for its inside. */
function titleOf(key) {
	if (key === "root") return book?.level("root")?.title || projectName();
	return book?.level(parentKey(key) ?? "root")?.nodes.find((n) => n.kids === key)?.t ?? key.split("/").pop();
}
var projectName = () => (state.project ?? "").split(/[\\/]/).filter(Boolean).pop() ?? say("Project");
/** What the reading holds now; then the screen follows. */
function take() {
	if (!book) return;
	state.read = book.has(ROOT);
	state.world = book.world();
	if (state.projectKey !== "root" && book.has(state.projectKey) && !book.level(state.projectKey)?.nodes.length) {
		if (state.key === state.projectKey) state.key = ROOT;
		state.projectKey = ROOT;
	}
	show();
}
/** The level the screen should be on. */
var levelNow = () => state.key === "memory" ? state.world?.level ?? null : book?.level(state.key) ?? null;
/** Draw whatever the state says: an empty panel with its one button, or the map. */
function show() {
	const main = byId("map");
	const level = levelNow();
	if (state.project && state.read && state.key !== "memory" && state.key !== "root" && !level) return;
	const memoryMissing = book?.memoryLooked() ? "memory" : "reading";
	const inMemory = level ? null : memoryMissing;
	const nothing = state.key === "root" ? "emptyRoot" : "empty";
	const read = !state.read ? "reading" : state.key === "memory" ? inMemory : level?.nodes.length ? null : nothing;
	const missing = !state.project ? state.noFolder ? "folder" : "reading" : read;
	main.classList.toggle("nothing", missing !== null);
	main.classList.toggle("bare", missing === "folder" || missing === "emptyRoot");
	byId("worlds").innerHTML = worldsHtml(state.key === MEMORY);
	byId("worlds").hidden = missing === "reading" && state.key !== "memory";
	if (missing) {
		state.view?.stop();
		state.view = null;
		state.level = null;
		state.drawn = "";
		sheet().replaceChildren();
		byId("empty").innerHTML = emptyHtml(missing, typeof surface()?.chooseProject === "function");
		byId("crumbs").innerHTML = "";
		byId("side").innerHTML = "";
		drawStatus();
		drawWork();
		return;
	}
	byId("empty").innerHTML = "";
	const print = JSON.stringify(level);
	if (print === state.drawn) return;
	const fresh = state.level?.key !== level.key;
	const anew = !fresh && !!state.level?.early && !level.early && !state.acted && !state.own && !state.compose;
	state.drawn = print;
	state.level = level;
	state.stats = statsOf(level);
	pace.size(level.nodes.length);
	if (fresh) {
		state.lit = {
			mode: "all",
			q: state.lit.q,
			only: null
		};
		state.listing = false;
		state.own = level.kind === "project" && level.key !== "root";
		state.chosen = {
			cur: state.own ? null : firstPart(level, state.stats),
			picked: []
		};
		state.compose = null;
		state.acted = false;
	} else if (anew) state.chosen = {
		cur: firstPart(level, state.stats),
		picked: []
	};
	else if (!state.own || isSeveral(state.chosen)) state.chosen = kept(state.chosen, (id) => !!state.stats.by[id], firstPart(level, state.stats));
	drawChrome();
	setSkin(state.skin);
}
/** The words and numbers round the map. */
function drawChrome() {
	const level = state.level;
	byId("crumbs").innerHTML = crumbsHtml(state.key, titleOf, level.kind === "memory");
	byId("crumbs").title = byId("crumbs").textContent ?? "";
	byId("seg").innerHTML = tabsHtml(level, state.lit.mode);
	const only = byId("only");
	only.hidden = !state.lit.only;
	only.textContent = state.lit.only ? `${onlyWord(titleOf(ROOT))} ×` : "";
	drawStatus();
	drawWork();
}
/** What a view is given: the level, the colours, and this view's own remembered places. */
function setSkin(skin) {
	const level = state.level;
	const stats = state.stats;
	if (!level || !stats) return;
	state.view?.stop();
	state.skin = skin;
	const svg = sheet();
	svg.replaceChildren();
	svg.dataset.skin = skin;
	svg.classList.toggle("many", stats.big);
	sizeNames();
	state.view = VIEWS[skin]({
		svg,
		canvas: byId("canvas"),
		level,
		stats,
		home: homes(level, stats.big),
		palette: state.palette,
		places: {
			get: (kind) => state.places?.get(placeKey(level.key, skin, kind)) ?? null,
			set: (kind, value) => void (state.acted = true, state.places?.set(placeKey(level.key, skin, kind), value))
		},
		choose: press,
		say: saying,
		day: dayAndMonth
	});
	byId("skins").innerHTML = skinsHtml(skin);
	state.choice?.set("skin", skin);
	paint();
	again();
}
/**
* The choice as it stands, shown on a view just drawn. Nothing is chosen anew: a view is drawn
* again whenever a note changes, the view is switched or the theme changes, and several parts
* picked for one task — with the task half written — must come through all three (FM-MAP-31).
*/
function again() {
	marks();
	if (state.chosen.cur) state.view?.chosen(state.chosen.cur, true);
	drawCard();
}
/** The names over the map keep the size a person reads, however small the panel (FM-MAP-37). */
function sizeNames() {
	sheet().style.setProperty("--s", String(nameScale(byId("canvas"))));
}
/** Dim what the tab, the search and the filter leave out. */
function paint() {
	const { level, stats, view } = state;
	if (!level || !stats || !view) return;
	for (const n of level.nodes) {
		const g = view.nodeEls[n.id];
		if (!g) continue;
		const on = isLit(n, state.lit);
		g.classList.toggle("off", !on);
		g.classList.toggle("keep", !!state.lit.only && on);
	}
	for (const e of view.edgeEls) e.classList.toggle("off", !linkLit(stats.by[e.dataset.a], stats.by[e.dataset.b], state.lit));
}
/** The chosen part and the picked ones, marked on the map. */
function marks() {
	const { view, chosen } = state;
	if (!view) return;
	for (const [id, g] of Object.entries(view.nodeEls)) {
		g.classList.toggle("sel", id === chosen.cur && !isSeveral(chosen));
		g.classList.toggle("pick", chosen.picked.includes(id));
	}
}
/** A part the panel brings forward — a tab's first, a filter's first, the one a link names: chosen plainly, and glided to. */
function bring(id) {
	state.listing = false;
	state.chosen = {
		cur: id,
		picked: []
	};
	state.compose = null;
	marks();
	state.view?.chosen(id, false);
	drawCard();
}
/**
* A press on a part, as in a list of files (the owner, 10 October 2026: "pressed, and the folder
* opened for you"): a folder is entered, a file is chosen and shown. While several are being picked
* a press picks, and a press in the moment of going in goes nowhere (FM-MAP-61).
*/
function press(id) {
	const n = state.stats?.by[id];
	if (state.entering) return;
	if (n?.kids && state.level?.kind === "project" && !state.several && !state.shift && !state.ctrl) return enter(n.kids, false);
	select(id, false);
}
/** The folder the screen is in, as the part it is one level up: what its own card is drawn from. */
function ownPart() {
	const level = state.own && state.key !== "root" && state.key !== "memory" ? book?.level(parentKey(state.key) ?? "root") : null;
	const part = level?.nodes.find((n) => n.kids === state.key);
	return level && part ? {
		level,
		stats: statsOf(level),
		part
	} : null;
}
/** The card of the folder the screen is in, brought back: by a press on its name in the path over the map. */
function showOwn() {
	state.own = true;
	state.chosen = {
		cur: null,
		picked: []
	};
	state.compose = null;
	marks();
	drawCard();
}
/** A part is chosen: by the person's press, or quietly by the panel itself. */
function select(id, quiet) {
	state.own = false;
	if (!quiet) state.listing = false;
	if (!quiet) state.acted = true;
	const was = state.chosen.cur;
	state.chosen = choose(state.chosen, id, !quiet && (state.several || state.shift));
	if (state.chosen.cur !== was) state.compose = null;
	marks();
	if (state.chosen.cur) state.view?.chosen(state.chosen.cur, quiet);
	drawCard();
	const n = state.chosen.cur && !quiet ? state.stats?.by[state.chosen.cur] : void 0;
	if (n?.is === "file" && n.text && state.opened?.id !== n.id) openText(n);
}
function drawCard() {
	const own = !state.chosen.cur && !isSeveral(state.chosen) && !state.listing && !state.several ? ownPart() : null;
	const { level, stats } = own ?? state;
	if (!level || !stats) return;
	const old = document.getElementById("task");
	const writing = old?.value ?? "";
	const caret = old && document.activeElement === old ? [old.selectionStart, old.selectionEnd] : null;
	byId("side").innerHTML = cardHtml({
		level,
		stats,
		chosen: own ? {
			cur: own.part.id,
			picked: []
		} : state.chosen,
		here: !!own,
		world: state.world,
		rootParts: book?.level("root")?.nodes ?? [],
		projectTitle: titleOf(ROOT),
		compose: state.compose,
		workers: workersNow(),
		opened: state.opened?.id === (own?.part.id ?? state.chosen.cur) ? state.opened.text : null,
		severalOn: state.several,
		listing: state.listing && !own ? state.lit : null,
		back: state.lit.mode !== "all" && !state.listing && !own,
		listName: modeWord(state.lit.mode, level.kind === "memory")
	});
	const field = document.getElementById("task");
	if (field && writing) field.value = writing;
	if (state.compose || caret) field?.focus();
	if (field && caret) field.setSelectionRange(caret[0], caret[1]);
}
/** What was being written has been sent: the field is empty again, so a second press sends nothing twice. */
function doneWriting() {
	const field = document.getElementById("task");
	if (field) field.value = "";
	state.compose = null;
	drawCard();
}
/** Going inside a part and coming back: the map dives in, or rises out. */
function enter(key, up, after) {
	const canvas = byId("canvas");
	canvas.classList.add(up ? "rise" : "dive");
	state.key = key;
	state.entering = true;
	if (key !== "memory") state.projectKey = key;
	const pulled = look().then(take).catch(() => show());
	Promise.all([pulled, new Promise((done) => setTimeout(done, 230))]).then(() => {
		state.entering = false;
		after?.();
		canvas.classList.remove("dive", "rise");
		canvas.classList.add(up ? "dive" : "rise");
		requestAnimationFrame(() => requestAnimationFrame(() => canvas.classList.remove("dive", "rise")));
		watcher?.now();
	});
}
/** "Only about this project": the memory narrowed to the notes that name it. */
function setOnly(only) {
	state.lit = {
		...state.lit,
		only
	};
	drawChrome();
	paint();
	const first = only && state.level?.nodes.find((n) => only.has(n.id));
	if (first) bring(first.id);
}
/** The owner's own mark on a part's note: set with their words, or cleared. */
async function markNote(n, why) {
	const api = surface();
	if (!api) return;
	if (!n.about) return book?.mark(n, why);
	try {
		const text = await api.readSource(n.about);
		if (text === null) throw new Error(`${n.about} is not there`);
		await api.writeSource(n.about, why === null ? clearBroken(text) : markBroken(text, why));
		watcher?.now();
	} catch (err) {
		api.log(`the mark was not written — ${String(err)}`);
		tell(saying("The mark was not written: {0}", String(err)));
	}
}
/** What the person wrote in the card's field, sent where it was meant for. */
function send(c, n, words) {
	if (c.kind !== "forget" && !words.trim()) return byId("task")?.focus();
	const sent = (went) => went ? doneWriting() : void 0;
	if (c.kind === "change") return void askWith(words, (w) => askChange(n, w)).then(sent);
	if (c.kind === "correct") return void askWith(words, (w) => askMemoryCorrect(n, w)).then(sent);
	if (c.kind === "answer") return void askWith(words, (w) => askAnswer(n, w)).then(sent);
	if (c.kind === "forget") ask(askMemoryForget(n));
	else markNote(n, words);
	doneWriting();
}
/** A press in the card, by the name its button carries. */
function act(name) {
	const { level, stats, chosen } = state;
	if (!level || !stats) return;
	const colon = name.indexOf(":");
	const verb = colon < 0 ? name : name.slice(0, colon);
	const arg = colon < 0 ? "" : name.slice(colon + 1);
	const memory = level.kind === "memory";
	const own = chosen.cur || isSeveral(chosen) || state.listing || state.several ? null : ownPart();
	const n = chosen.cur ? stats.by[chosen.cur] : own?.part;
	if (verb === "go" && own) return enter(parentKey(state.key) ?? "root", true, () => bring(arg));
	if (verb === "go") return select(arg, false);
	if (verb === "drop") {
		state.chosen = !isSeveral(chosen) && chosen.cur === arg ? {
			cur: null,
			picked: []
		} : drop(chosen, arg);
		marks();
		return drawCard();
	}
	if (verb === "unpick") {
		state.chosen = state.several ? {
			cur: null,
			picked: []
		} : unpick(chosen);
		marks();
		return drawCard();
	}
	if (verb === "give") {
		const task = byId("task")?.value ?? "";
		if (!task.trim()) return byId("task")?.focus();
		const parts = (isSeveral(chosen) ? chosen.picked : chosen.cur ? [chosen.cur] : []).map((id) => stats.by[id]).filter(Boolean);
		if (!parts.length) return;
		askWith(task, (w) => askSeveral(parts, w)).then((went) => went ? doneWriting() : void 0);
		return;
	}
	if (verb === "more") return toggleMenu(byId("side").querySelector(".card-menu"), byId("side").querySelector("[data-act=\"more\"]"));
	if (verb === "list") {
		state.listing = true;
		return drawCard();
	}
	if (verb === "done") return setSeveral(false);
	if (verb === "mem") return enter(MEMORY, false, () => bring(arg));
	if (verb === "memall") return enter(MEMORY, false, () => setOnly(new Set(state.world?.project ?? [])));
	if (verb === "part") return enter(ROOT, true, () => arg && state.stats?.by[arg] ? bring(arg) : void 0);
	if (!n) return;
	if (verb === "cancel") state.compose = null;
	else if (verb === "send" && state.compose) return send(state.compose, n, byId("task")?.value ?? "");
	else if (verb === "enter" && n.kids) return enter(n.kids, false);
	else if (verb === "ask") return ask(memory ? askMemory(n) : askAbout(n));
	else if (verb === "fix") return ask(askFix(n));
	else if (verb === "check") return ask(askMemoryCheck(n));
	else if (verb === "open") return void openText(n);
	else if (verb === "clear") return void markNote(n, null);
	else if (verb === "change") state.compose = {
		kind: "change",
		id: n.id
	};
	else if (verb === "mark") state.compose = {
		kind: "broken",
		id: n.id
	};
	else if (verb === "correct") state.compose = {
		kind: "correct",
		id: n.id
	};
	else if (verb === "forget") state.compose = {
		kind: "forget",
		id: n.id
	};
	else if (verb === "answer") state.compose = {
		kind: "answer",
		id: n.id
	};
	drawCard();
}
/** The most of a file shown in a card. */
var SHOWN_MOST = 2e4;
/** A file's own text, read and shown in the card; pressed again, closed. Nobody is asked for it (FM-MAP-48). */
async function openText(n) {
	if (state.opened?.id === n.id) state.opened = null;
	else {
		const text = n.text ? await surface()?.readSource(n.text).catch(() => null) : null;
		state.opened = {
			id: n.id,
			text: text == null ? say("The text could not be read.") : text.length > SHOWN_MOST ? `${text.slice(0, SHOWN_MOST)}\n…` : text
		};
	}
	drawCard();
}
/** Another folder to map: the person points at it in the system's own chooser, and the panel starts over in it. */
async function chooseFolder() {
	const api = surface();
	try {
		const folder = await api?.chooseProject?.();
		if (folder) await openFolder(api, folder);
	} catch (err) {
		if (String(err).includes("cancelled")) return;
		tell(saying("That folder could not be opened: {0}", String(err)));
	}
}
/** "Choose several" on or off: on, the card is the one task at once; off, the pick is let go. */
function setSeveral(on) {
	state.several = on;
	byId("multi").classList.toggle("on", on);
	byId("multi").setAttribute("aria-pressed", String(on));
	byId("several").setAttribute("aria-checked", String(on));
	if (!on) state.chosen = unpick(state.chosen);
	if (!on && !state.chosen.cur && state.level && state.stats) state.chosen = {
		cur: firstPart(state.level, state.stats),
		picked: []
	};
	marks();
	drawCard();
}
/** The static words, and every press that is not inside the card. */
function wire() {
	barWords(typeof surface()?.chooseProject === "function");
	wireBar(page, {
		choose: () => void chooseFolder(),
		relay: () => {
			if (!state.level) return;
			state.places?.forget(layoutKeys(state.level.key, state.skin));
			setSkin(state.skin);
		},
		several: () => setSeveral(!state.several),
		up: () => {
			const parent = state.key === "memory" ? null : parentKey(state.key);
			if (parent) enter(parent, true);
		}
	});
	byId("multi").addEventListener("click", () => setSeveral(!state.several));
	byId("only").addEventListener("click", () => setOnly(null));
	byId("q").addEventListener("input", (e) => {
		state.lit = {
			...state.lit,
			q: e.target.value
		};
		paint();
	});
	byId("worlds").addEventListener("click", (e) => {
		const world = e.target.closest("[data-world]")?.dataset.world;
		if (!state.project || !book) return;
		if (world === "memory" && state.key !== "memory") enter(MEMORY, false);
		if (world === "project" && state.key === "memory") enter(state.projectKey, true);
	});
	byId("crumbs").addEventListener("click", (e) => {
		const key = e.target.closest("[data-level]")?.dataset.level;
		if (key === state.key) showOwn();
		else if (key) enter(key, true);
	});
	byId("skins").addEventListener("click", (e) => {
		const skin = e.target.closest("[data-skin]")?.dataset.skin;
		if (skin) setSkin(skinOr(skin));
	});
	byId("seg").addEventListener("click", (e) => {
		const pressed = e.target.closest("[data-mode]")?.dataset.mode;
		if (!pressed || !state.level) return;
		const mode = pressed === state.lit.mode ? "all" : pressed;
		state.lit = {
			...state.lit,
			mode
		};
		state.listing = mode !== "all";
		state.compose = null;
		byId("seg").innerHTML = tabsHtml(state.level, mode);
		paint();
		drawCard();
	});
	byId("side").addEventListener("click", (e) => {
		const name = e.target.closest("[data-act]")?.dataset.act;
		if (name) act(name);
	});
	byId("empty").addEventListener("click", (e) => {
		const name = e.target.closest("[data-act]")?.dataset.act;
		if (name === "choose") chooseFolder();
		if (name === "retry") {
			book?.retry();
			take();
		}
	});
	const svg = sheet();
	svg.addEventListener("contextmenu", (e) => {
		const id = e.target.closest("[data-id]")?.dataset.id;
		if (!id) return;
		e.preventDefault();
		select(id, false);
	});
	svg.addEventListener("keydown", (e) => {
		const id = e.target.closest("[data-id]")?.dataset.id;
		if (id && (e.key === "Enter" || e.key === " ")) press(id);
	});
	page.on(window, "pointerdown", (e) => void (state.shift = e.shiftKey, state.ctrl = e.ctrlKey), { capture: true });
	page.on(document, "visibilitychange", () => watcher?.now());
	pace.start();
	for (const type of [
		"pointermove",
		"pointerdown",
		"wheel",
		"keydown",
		"focus"
	]) page.on(window, type, () => pace.touch(), {
		capture: true,
		passive: true
	});
	pace.onWake(() => watcher?.now());
	if (typeof ResizeObserver === "function") {
		sized = new ResizeObserver(sizeNames);
		sized.observe(byId("canvas"));
	}
}
async function start() {
	const api = surface();
	await soon(loadWords(api?.language ?? "en"), void 0);
	document.documentElement.lang = (api?.language ?? "en").split(/[-_]/)[0];
	const paintFrom = (tokens) => {
		state.palette = paletteFor(tokens);
		wear(document.documentElement, state.palette);
		if (state.view) setSkin(state.skin);
	};
	try {
		paintFrom(await soon(api?.tokens(), {}));
		api?.onTokens?.(paintFrom);
	} catch {
		paintFrom({});
	}
	wire();
	show();
	if (!api) return;
	state.choice = await openKeep(api, "choice.json");
	state.skin = skinOr(state.choice.get("skin"));
	const project = await whenGranted(api, () => stopped, () => {
		state.noFolder = true;
		show();
	});
	if (!stopped) await openFolder(api, project);
}
/** Start mapping a folder: what was kept of it is drawn at once, and it is read again in the background. */
async function openFolder(api, project) {
	watcher?.stop();
	book?.stop();
	Object.assign(state, {
		project,
		noFolder: false,
		read: false,
		key: ROOT,
		projectKey: ROOT,
		level: null,
		drawn: "",
		opened: null,
		world: null
	});
	state.places = await openKeep(api, fileFor(project));
	const mine = book = openBook({
		door: api,
		keep: await openKeep(api, fileFor(project), "reading"),
		name: projectName(),
		today,
		redraw: (what) => {
			if (book !== mine) return;
			if (what === "strip") return drawWork();
			looks += 1;
			take();
			drawWork();
			if (state.own) drawCard();
		}
	});
	take();
	watcher = watch({
		look,
		changed: take,
		visible: () => document.visibilityState !== "hidden",
		every: () => pace.resting() ? lookEveryResting(state.level?.nodes.length ?? 0) : lookEvery(state.level?.nodes.length ?? 0)
	});
}
if (typeof window !== "undefined" && typeof document !== "undefined" && document.getElementById("map")) start();
//#endregion
