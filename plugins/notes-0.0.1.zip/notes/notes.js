//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region plugins/notes/model.ts
/** The file's opening words, for a person or an agent who opens it by hand. */
var HEAD = {
	notes: "# Notes\n\nOne list of notes for every project, kept by vobuda's Notes plugin. Add one from any shell with: vobuda notes add \"<text>\"\n",
	done: "# Done notes\n\nThe notes marked done in vobuda's Notes plugin.\n"
};
var ENTRY = /^## (?:(\d+)(?: · |\. |$))?(.*)$/;
var META = /^(.*?) · (\d{4}-\d{2}-\d{2} \d{2}:\d{2})(?: · sent to (.*) at (\d{4}-\d{2}-\d{2} \d{2}:\d{2}))?\s*$/;
/** A time as the file keeps it. */
function stamp(d) {
	const two = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())} ${two(d.getHours())}:${two(d.getMinutes())}`;
}
/** A name as a header can carry it: one line, and no ` · ` that would split it (FM-NOTES-2). */
var plainName = (name) => name.replace(/\s+/g, " ").replace(/·/g, "-").trim() || "agent";
/**
* A line of a note's text as the file keeps it: one that begins with `#` or a
* backslash gets a backslash in front, so a note that says "## step 2" is never
* read back as two notes and never counted twice on the strip (FM-NOTES-2).
*/
var keepLine = (line) => line.startsWith("#") || line.startsWith("\\") ? `\\${line}` : line;
var readLine = (line) => line.startsWith("\\") ? line.slice(1) : line;
/** The text cleaned the same way on every road (`notes.py` too): no trailing spaces, nothing blank at either end. */
var cleanText = (text) => text.replace(/\r\n?/g, "\n").split("\n").map((l) => l.replace(/\s+$/, "")).join("\n").trim();
/**
* The notes in a file, in order. Lenient on purpose: the file is a person's to
* open by hand, and a header written as `## an idea` or `## 3. an idea` is a
* note whose first line is what follows the number, never a lost one.
*/
function parse(text) {
	const notes = [];
	let current = null;
	const close = () => {
		if (!current) return;
		current.note.text = cleanText([...current.note.text ? [current.note.text] : [], ...current.lines].join("\n"));
		if (current.note.text) notes.push(current.note);
		current = null;
	};
	for (const raw of text.replace(/\r\n?/g, "\n").split("\n")) {
		const entry = raw.startsWith("## ") ? ENTRY.exec(raw) : null;
		if (entry) {
			close();
			const rest = entry[2] ?? "";
			const meta = META.exec(rest);
			current = meta ? {
				note: {
					by: meta[1].trim(),
					at: meta[2],
					text: "",
					...meta[3] ? { sent: {
						to: meta[3].trim(),
						at: meta[4]
					} } : {}
				},
				lines: []
			} : {
				note: {
					by: "",
					at: "",
					text: rest.trim()
				},
				lines: []
			};
			continue;
		}
		if (current) current.lines.push(readLine(raw));
	}
	close();
	return notes;
}
/** The file for these notes, numbered by place. */
function write(notes, head = HEAD.notes) {
	const out = [head.replace(/\n*$/, "\n")];
	notes.forEach((n, i) => {
		const sent = n.sent ? ` · sent to ${plainName(n.sent.to)} at ${n.sent.at}` : "";
		const meta = n.at ? ` · ${plainName(n.by)} · ${n.at}${sent}` : "";
		out.push(`## ${i + 1}${meta}\n${cleanText(n.text).split("\n").map(keepLine).join("\n")}\n`);
	});
	return out.join("\n");
}
/** What a row shows folded: the note's first line. */
var titleOf = (note) => cleanText(note.text).split("\n")[0] ?? "";
/** Which note this is, across a re-read in which others came or went (FM-NOTES-4). */
var keyOf = (note) => `${note.by}\u0000${note.at}\u0000${cleanText(note.text)}`;
/** Whether a note has every word of the search in it, case and «ё» aside. */
function matches(note, query) {
	const fold = (s) => s.toLocaleLowerCase().replace(/ё/g, "е");
	const hay = fold(`${note.text}\n${note.by}`);
	return fold(query).split(/\s+/).filter(Boolean).every((w) => hay.includes(w));
}
/** The list with a new note at its end, or as it was for an empty text. */
function added(notes, text, by, now) {
	const clean = cleanText(text);
	return clean ? [...notes, {
		by: plainName(by),
		at: stamp(now),
		text: clean
	}] : notes;
}
/** The list with the note of this key changed by `fn`; as it was if the note is gone. */
function changed(notes, key, fn) {
	const out = [];
	for (const n of notes) if (keyOf(n) !== key) out.push(n);
	else {
		const next = fn(n);
		if (next) out.push(next);
	}
	return out;
}
/** The note's text sent to an agent: who and when, kept in its header. */
var sentTo = (to, now) => (n) => ({
	...n,
	sent: {
		to: plainName(to),
		at: stamp(now)
	}
});
/** A new text for a note; an emptied one is not a delete — the old text stays. */
var edited = (text) => (n) => cleanText(text) ? {
	...n,
	text: cleanText(text)
} : n;
/**
* A note moved from one list to the other — done, or back from done — at the
* other list's end. Both lists come back, so the caller writes both. A note the
* other list already holds is not added again: the panel writes the list it goes
* to first, and makes the change again when the second write is refused
* (FM-PLUGIN-4273).
*/
function moved(from, to, key) {
	const note = from.find((n) => keyOf(n) === key);
	if (!note) return {
		from,
		to
	};
	return {
		from: from.filter((n) => n !== note),
		to: to.some((n) => keyOf(n) === key) ? to : [...to, note]
	};
}
var en_default = {
	Notes: "Notes",
	"Done notes": "Done notes",
	Search: "Search",
	"New note": "New note",
	Close: "Close",
	"One list for every project": "One list for every project",
	"Done · {0}": "Done · {0}",
	"Notes · {0}": "Notes · {0}",
	"No notes": "No notes",
	"Press + and write an idea down. Or tell any agent: «add to the notes…» — the line appears here.": "Press + and write an idea down. Or tell any agent: «add to the notes…» — the line appears here.",
	"Nothing done yet": "Nothing done yet",
	"Nothing found": "Nothing found",
	"Enter — save, Shift+Enter — new line, Esc — cancel": "Enter — save, Shift+Enter — new line, Esc — cancel",
	"Press the text — it goes to {0}": "Press the text — it goes to {0}",
	"No agent to send it to: open a director or a chat": "No agent to send it to: open a director or a chat",
	edit: "edit",
	done: "done",
	"back to the list": "back to the list",
	"delete": "delete",
	"Delete this note?": "Delete this note?",
	yes: "yes",
	no: "no",
	"The note's text goes to": "The note's text goes to",
	"no agent here": "no agent here",
	mine: "mine",
	"added by {0}": "added by {0}",
	"✓ sent · {0} · {1}": "✓ sent · {0} · {1}",
	yesterday: "yesterday",
	"The list could not be read": "The list could not be read",
	"The note was not saved: {0}": "The note was not saved: {0}"
};
//#endregion
//#region plugins/notes/words.ts
var words = en_default;
var lang = "en";
/** Take a dictionary, dropping anything that is not a sentence. */
function useWords(table, code = lang) {
	words = {};
	lang = code.split(/[-_]/)[0] || "en";
	if (!table || typeof table !== "object") return;
	for (const [key, value] of Object.entries(table)) if (typeof value === "string" && value !== "") words[key] = value;
}
/** The language the words are in, for dates. */
var language = () => lang;
/** One sentence, translated if there is a translation and English if not, its `{0}` blanks filled. */
function say(key, ...parts) {
	return (words[key] ?? key).replace(/\{(\d)\}/g, (whole, at) => {
		const part = parts[Number(at)];
		return part === void 0 ? whole : String(part);
	});
}
/** Fetch the dictionary for a language; one not carried leaves English in force. */
async function loadWords(code, get = fetch) {
	const wanted = code.split(/[-_]/)[0] || "en";
	if (wanted !== "en") try {
		const answer = await get(`./words/${wanted}.json`);
		if (!answer.ok) throw new Error(String(answer.status));
		useWords(await answer.json(), wanted);
		return;
	} catch {}
	useWords(en_default, "en");
}
/** The work folder every project shares: one list for all of them (R13a). */
var COMMON = "common";
var NOTES = "notes.md";
var DONE = "done.md";
/** The core's refusal of a write whose file changed since it was read (`WORK_CHANGED` in plugins.rs). */
var CHANGED = "changed since it was read";
/** How often the file is read again for a note an agent added: cheap, and soon enough to see it appear. */
var REREAD_MS = 3e3;
/** A note's time as a row says it: the hour today, «вчера», else the day and month. */
function when(at, now = /* @__PURE__ */ new Date()) {
	const m = /^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/.exec(at);
	if (!m) return at;
	const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]));
	const day = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
	const apart = Math.round((day(now) - day(d)) / 864e5);
	if (apart === 0) return `${m[4]}:${m[5]}`;
	if (apart === 1) return say("yesterday");
	try {
		return new Intl.DateTimeFormat(language(), {
			day: "numeric",
			month: "short"
		}).format(d);
	} catch {
		return `${m[3]}.${m[2]}`;
	}
}
/** The row's second line: who added it and when, or that it was sent. */
function metaOf(note, now = /* @__PURE__ */ new Date()) {
	const by = note.by === "you" || !note.by ? say("mine") : say("added by {0}", note.by);
	return note.at ? `${by} · ${when(note.at, now)}` : by;
}
function el(tag, cls = "", text = "") {
	const e = document.createElement(tag);
	if (cls) e.className = cls;
	if (text) e.textContent = text;
	return e;
}
/** The panel, started on its surface and drawn into `root`. Answers what a check drives. */
async function startNotes(api, root, now = () => /* @__PURE__ */ new Date(), table) {
	if (table) useWords(table, api.language);
	else await loadWords(api.language);
	document.documentElement.lang = language();
	const folder = await api.workFolder(COMMON);
	const hearing = new AbortController();
	const { signal } = hearing;
	const state = {
		notes: [],
		done: [],
		texts: ["", ""],
		showDone: false,
		query: "",
		open: /* @__PURE__ */ new Set(),
		editing: null,
		deleting: null,
		targets: [],
		chosen: null,
		justSent: null,
		flash: ""
	};
	root.textContent = "";
	root.className = "notes";
	const tool = el("div", "ntool");
	const search = el("input", "search");
	search.type = "search";
	search.placeholder = say("Search");
	search.setAttribute("aria-label", say("Search"));
	const add = el("button", "ibtn add", "+");
	add.title = say("New note");
	add.setAttribute("aria-label", say("New note"));
	const close = el("button", "ibtn close", "×");
	close.title = say("Close");
	close.setAttribute("aria-label", say("Close"));
	tool.append(search, add, close);
	const head = el("div", "nhead");
	const title = el("h1");
	const count = el("span", "count");
	head.append(title, count);
	const sub = el("div", "nsub");
	const subText = el("span");
	const toggle = el("button", "link");
	sub.append(subText, toggle);
	const list = el("div", "list");
	list.setAttribute("role", "list");
	const flash = el("div", "flash");
	flash.setAttribute("role", "status");
	const foot = el("div", "nfoot");
	const footText = el("span", "", say("The note's text goes to"));
	const target = el("select", "target");
	target.setAttribute("aria-label", say("The note's text goes to"));
	foot.append(footText, target);
	root.append(tool, head, sub, list, flash, foot);
	const reread = async () => {
		const [a, b] = await Promise.all([folder.read(NOTES), folder.read(DONE)]);
		const texts = [a ?? "", b ?? ""];
		if (texts[0] === state.texts[0] && texts[1] === state.texts[1]) return false;
		state.texts = texts;
		state.notes = parse(texts[0]);
		state.done = parse(texts[1]);
		return true;
	};
	/**
	* One change, made to the list as it is on the disk now, never to what was read seconds ago (FM-NOTES-4). Each file
	* is written only if it still holds what the change was made from, under the lock `vobuda notes add` takes; when an
	* agent's note landed between the read and the write, the write is refused, and the change is made again to the
	* list as it is now — the agent's note is never written over (the whole review of 4.2.6, F5; FM-PLUGIN-4273). The
	* list a note moves into is written before the one it leaves, so a refusal between the two leaves it in both for a
	* moment — `moved` does not add it twice — and never in neither.
	*/
	const mutate = async (fn) => {
		try {
			for (let tried = 1;; tried++) {
				await reread();
				const next = fn(state.notes, state.done);
				const texts = [write(next.notes, HEAD.notes), write(next.done, HEAD.done)];
				const order = next.done.length > state.done.length ? [1, 0] : [0, 1];
				try {
					for (const i of order) if (texts[i] !== state.texts[i]) await folder.write(i ? DONE : NOTES, texts[i], state.texts[i]);
				} catch (e) {
					if (!String(e).includes(CHANGED) || tried >= 5) throw e;
					continue;
				}
				state.texts = texts;
				state.notes = next.notes;
				state.done = next.done;
				break;
			}
		} catch (e) {
			state.flash = say("The note was not saved: {0}", String(e));
		}
		draw();
	};
	/** Where a press on a text goes now: the one chosen while it is still there, else the window's current one. */
	const destination = () => state.targets.find((t) => t.block === state.chosen) ?? state.targets.find((t) => t.current) ?? null;
	const send = async (note) => {
		const to = destination();
		if (!to) {
			state.flash = say("No agent to send it to: open a director or a chat");
			draw();
			return;
		}
		const key = keyOf(note);
		await api.askAgent(note.text, to.block);
		state.justSent = key;
		state.flash = "";
		await mutate((notes, done) => ({
			notes: changed(notes, key, sentTo(to.name, now())),
			done
		}));
	};
	const editor = (value, save) => {
		const box = el("textarea", "editor");
		box.value = value;
		box.rows = Math.min(8, Math.max(2, value.split("\n").length + 1));
		box.addEventListener("keydown", (e) => {
			if (e.key === "Enter" && !e.shiftKey && !e.isComposing) {
				e.preventDefault();
				save(box.value);
			} else if (e.key === "Escape") {
				e.preventDefault();
				e.stopPropagation();
				state.editing = null;
				draw();
			}
		});
		queueMicrotask(() => box.focus());
		return box;
	};
	const row = (note, n, doneList) => {
		const key = keyOf(note);
		const open = state.open.has(key);
		const r = el("div", `row${open ? " open" : ""}${state.justSent === key ? " justsent" : ""}`);
		r.setAttribute("role", "listitem");
		r.dataset.key = key;
		const num = el("div", "num", String(n));
		const mid = el("div", "mid");
		mid.append(el("div", "title", titleOf(note)));
		const meta = el("div", "meta");
		if (note.sent && !doneList) meta.append(el("span", "sent", say("✓ sent · {0} · {1}", note.sent.to, when(note.sent.at, now()))));
		else meta.textContent = metaOf(note, now());
		mid.append(meta);
		const chev = el("div", "chev", "›");
		const fold = el("button", "fold");
		fold.setAttribute("aria-expanded", String(open));
		fold.setAttribute("aria-label", titleOf(note));
		fold.append(num, mid, chev);
		fold.addEventListener("click", () => {
			if (open) state.open.delete(key);
			else state.open.add(key);
			state.deleting = null;
			draw();
		});
		r.append(fold);
		if (!open) return r;
		const full = el("div", "full");
		if (state.editing === key) {
			full.append(editor(note.text, (text) => {
				state.editing = null;
				if (cleanText(text)) state.open.add(keyOf({
					...note,
					text: cleanText(text)
				}));
				mutate((notes, done) => doneList ? {
					notes,
					done: changed(done, key, edited(text))
				} : {
					notes: changed(notes, key, edited(text)),
					done
				});
			}), el("div", "sendhint", say("Enter — save, Shift+Enter — new line, Esc — cancel")));
			r.append(full);
			return r;
		}
		if (doneList) full.append(el("div", "text", note.text));
		else {
			const text = el("button", "sendtext", note.text);
			text.dataset.send = "";
			text.addEventListener("click", () => void send(note));
			full.append(text);
		}
		const hint = el("div", "sendhint");
		const to = destination();
		if (!doneList) hint.append(el("span", "", to ? say("Press the text — it goes to {0}", to.name) : say("no agent here")));
		else hint.append(el("span"));
		const acts = el("span", "acts");
		const act = (word, fn, cls = "") => {
			const b = el("button", `act${cls ? ` ${cls}` : ""}`, say(word));
			b.addEventListener("click", fn);
			acts.append(b);
		};
		if (state.deleting === key) {
			acts.append(el("span", "ask", say("Delete this note?")));
			act("yes", () => {
				state.deleting = null;
				state.open.delete(key);
				mutate((notes, done) => doneList ? {
					notes,
					done: changed(done, key, () => null)
				} : {
					notes: changed(notes, key, () => null),
					done
				});
			}, "confirm danger");
			act("no", () => {
				state.deleting = null;
				draw();
			}, "confirm");
		} else {
			act("edit", () => {
				state.editing = key;
				draw();
			});
			if (doneList) act("back to the list", () => {
				mutate((notes, done) => {
					const m = moved(done, notes, key);
					return {
						notes: m.to,
						done: m.from
					};
				});
			});
			else act("done", () => {
				state.open.delete(key);
				mutate((notes, done) => {
					const m = moved(notes, done, key);
					return {
						notes: m.from,
						done: m.to
					};
				});
			});
			act("delete", () => {
				state.deleting = key;
				draw();
			});
		}
		hint.append(acts);
		full.append(hint);
		r.append(full);
		return r;
	};
	const draw = () => {
		const shown = state.showDone ? state.done : state.notes;
		title.textContent = say(state.showDone ? "Done notes" : "Notes");
		count.textContent = String(shown.length);
		subText.textContent = say("One list for every project");
		toggle.textContent = state.showDone ? say("Notes · {0}", state.notes.length) : say("Done · {0}", state.done.length);
		list.textContent = "";
		if (state.editing === "new" && !state.showDone) {
			const fresh = el("div", "newrow");
			fresh.append(el("span", "num", String(state.notes.length + 1)), editor("", (text) => {
				state.editing = null;
				mutate((notes, done) => ({
					notes: added(notes, text, "you", now()),
					done
				}));
			}));
			list.append(fresh, el("div", "sendhint pad", say("Enter — save, Shift+Enter — new line, Esc — cancel")));
		}
		const hits = shown.map((n, i) => ({
			n,
			i
		})).filter(({ n }) => !state.query || matches(n, state.query));
		for (const { n, i } of hits) list.append(row(n, i + 1, state.showDone));
		if (!hits.length && state.editing !== "new") {
			const empty = el("div", "empty");
			if (state.query && shown.length) empty.append(el("b", "", say("Nothing found")));
			else if (state.showDone) empty.append(el("b", "", say("Nothing done yet")));
			else empty.append(el("b", "", say("No notes")), el("div", "hintbox", say("Press + and write an idea down. Or tell any agent: «add to the notes…» — the line appears here.")));
			list.append(empty);
		}
		flash.textContent = state.flash;
		flash.hidden = !state.flash;
		target.textContent = "";
		const to = destination();
		if (!state.targets.length) {
			const none = el("option", "", say("no agent here"));
			none.value = "";
			target.append(none);
			target.disabled = true;
		} else {
			target.disabled = false;
			for (const t of state.targets) {
				const o = el("option", "", t.tab && t.tab !== t.name ? `${t.name} · ${t.tab}` : t.name);
				o.value = String(t.block);
				o.selected = t.block === to?.block;
				target.append(o);
			}
		}
	};
	search.addEventListener("input", () => {
		state.query = search.value;
		draw();
	});
	add.addEventListener("click", () => {
		state.showDone = false;
		state.editing = "new";
		draw();
	});
	close.addEventListener("click", () => void api.closePanel?.());
	toggle.addEventListener("click", () => {
		state.showDone = !state.showDone;
		state.editing = null;
		state.deleting = null;
		draw();
	});
	target.addEventListener("change", () => {
		state.chosen = target.value ? Number(target.value) : null;
		draw();
	});
	document.addEventListener("keydown", (e) => {
		if (e.key !== "Escape" || e.defaultPrevented) return;
		if (state.deleting) {
			state.deleting = null;
			draw();
			return;
		}
		if (document.activeElement === search && search.value) {
			search.value = "";
			state.query = "";
			draw();
			return;
		}
		api.closePanel?.();
	}, { signal });
	api.onAgentTargets?.((targets) => {
		const before = JSON.stringify(state.targets);
		state.targets = targets.filter((t) => typeof t?.block === "number" && typeof t?.name === "string");
		if (state.chosen !== null && !state.targets.some((t) => t.block === state.chosen)) state.chosen = null;
		if (JSON.stringify(state.targets) !== before && state.editing === null) draw();
	});
	window.addEventListener("vobuda-plugin-answer", (e) => {
		if (e.detail?.kind !== "gone") return;
		state.flash = say("No agent to send it to: open a director or a chat");
		draw();
	}, { signal });
	try {
		await reread();
	} catch {
		state.flash = say("The list could not be read");
	}
	draw();
	const timer = window.setInterval(() => {
		if (state.editing !== null) return;
		reread().then((news) => news && draw()).catch(() => {});
	}, REREAD_MS);
	return {
		state,
		draw,
		reread,
		stop: () => {
			window.clearInterval(timer);
			hearing.abort();
		}
	};
}
/** The window's colours, as CSS variables of this page (FM-PLUGIN-50). */
function paint(tokens) {
	const style = document.documentElement.style;
	for (const [k, v] of Object.entries(tokens)) if (k.startsWith("--") && typeof v === "string") style.setProperty(k, v);
	const hex = /^#([0-9a-f]{6})/i.exec((tokens["--app-bg"] ?? "").trim());
	if (hex) {
		const [r, g, b] = [
			0,
			2,
			4
		].map((i) => parseInt(hex[1].slice(i, i + 2), 16) / 255);
		style.colorScheme = .2126 * r + .7152 * g + .0722 * b < .35 ? "dark" : "light";
	}
}
var surface = () => window.vobuda;
var api = surface();
var root = typeof document !== "undefined" ? document.getElementById("notes") : null;
if (api && root) {
	api.tokens?.().then(paint).catch(() => {});
	api.onTokens?.(paint);
	startNotes(api, root).catch((e) => api.log?.(`notes: did not start — ${String(e)}`));
}
//#endregion
