#!/usr/bin/env python3
"""The Notes plugin from a shell: `vobuda notes add|list|done|path`.

Gary, 11 November 2026 (R13): an agent told «оставь в заметках» or «добавь в
заметки» must know which notes are meant and add to them. Every agent is told
so in its brief (the plugin's `brief` line), and this is what it runs. The
command line hands it over (`vobuda <plugin> …`, the plugin's `command`), with
`VOBUDA_CONFIG` set; it writes the very file the panel reads,
`<config>/plugins/notes/work/common/notes.md`, in the shape `model.ts` reads
and writes (FM-NOTES-3).

    vobuda notes add "<text>"     a new note at the end of the list; who added it is the block's name
    vobuda notes list             the notes, numbered as the panel numbers them
    vobuda notes done <n>         note n moved to the done notes
    vobuda notes remind <n> <when>   note n calls for the person at <when> (YYYY-MM-DD HH:MM), or `off`
    vobuda notes snooze [n]       the notes that are calling, or note n, quiet for ten minutes
    vobuda notes alarm            how many notes are calling now, as {"due": n}: what the window asks every half minute
    vobuda notes path             where the list is kept
"""
import datetime
import fcntl
import glob
import json
import os
import re
import sys

HEAD_NOTES = (
    "# Notes\n\nOne list of notes for every project, kept by vobuda's Notes plugin. "
    'Add one from any shell with: vobuda notes add "<text>"\n'
)
HEAD_DONE = "# Done notes\n\nThe notes marked done in vobuda's Notes plugin.\n"
# The same two patterns as model.ts: `## 3 · who · when[ · sent to x at when]`.
ENTRY = re.compile(r"^## (?:(\d+)(?: · |\. |$))?(.*)$")
STAMP = r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}"
META = re.compile(
    rf"^(.*?) · ({STAMP})(?: · sent to (.*) at ({STAMP}))?(?: · due ({STAMP}))?(?: · snoozed until ({STAMP}))?\s*$"
)
SNOOZE_MINUTES = 10


def config_dir() -> str:
    return os.environ.get("VOBUDA_CONFIG") or os.path.join(os.path.expanduser("~"), ".config", "vobuda")


def folder() -> str:
    return os.path.join(config_dir(), "plugins", "notes", "work", "common")


def clean(text: str) -> str:
    lines = [l.rstrip() for l in text.replace("\r\n", "\n").replace("\r", "\n").split("\n")]
    return "\n".join(lines).strip()


def plain_name(name: str) -> str:
    return re.sub(r"\s+", " ", name).replace("·", "-").strip() or "agent"


def parse(text: str) -> list:
    notes, cur = [], None

    def close():
        if cur is None:
            return
        body = clean("\n".join(([cur["text"]] if cur["text"] else []) + cur["lines"]))
        if body:
            note = {k: v for k, v in cur.items() if k != "lines"}
            note["text"] = body
            notes.append(note)

    for raw in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        m = ENTRY.match(raw) if raw.startswith("## ") else None
        if m:
            close()
            rest = m.group(2) or ""
            meta = META.match(rest)
            if meta:
                cur = {"by": meta.group(1).strip(), "at": meta.group(2), "text": "", "lines": []}
                if meta.group(3):
                    cur["sent"] = {"to": meta.group(3).strip(), "at": meta.group(4)}
                if meta.group(5):
                    cur["due"] = meta.group(5)
                    if meta.group(6):
                        cur["snooze"] = meta.group(6)
            else:
                cur = {"by": "", "at": "", "text": rest.strip(), "lines": []}
            continue
        if cur is not None:
            cur["lines"].append(raw[1:] if raw.startswith("\\") else raw)
    close()
    return notes


def write(notes: list, head: str) -> str:
    out = [head.rstrip("\n") + "\n"]
    for i, n in enumerate(notes, 1):
        sent = f" · sent to {plain_name(n['sent']['to'])} at {n['sent']['at']}" if n.get("sent") else ""
        due = ""
        if n.get("at") and n.get("due"):
            due = f" · due {n['due']}" + (f" · snoozed until {n['snooze']}" if n.get("snooze") else "")
        meta = f" · {plain_name(n['by'])} · {n['at']}{sent}{due}" if n.get("at") else ""
        body = "\n".join(("\\" + l) if l.startswith(("#", "\\")) else l for l in clean(n["text"]).split("\n"))
        out.append(f"## {i}{meta}\n{body}\n")
    return "\n".join(out)


def read(path: str) -> list:
    try:
        with open(path, encoding="utf-8") as f:
            return parse(f.read())
    except FileNotFoundError:
        return []


def keep(path: str, text: str) -> None:
    # Written aside and moved into place, so the panel never reads half a list.
    tmp = os.path.join(os.path.dirname(path), "." + os.path.basename(path) + ".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(tmp, path)


def stamp(when: datetime.datetime) -> str:
    return when.strftime("%Y-%m-%d %H:%M")


def parse_when(text: str):
    """`YYYY-MM-DD HH:MM` (or with a T) as the file keeps it, or None for anything that is not a real time."""
    m = re.fullmatch(r"(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})", text.strip())
    if not m:
        return None
    try:
        when = datetime.datetime.strptime(f"{m.group(1)} {m.group(2)}", "%Y-%m-%d %H:%M")
    except ValueError:
        return None
    return stamp(when)


def ringing(note: dict, now: datetime.datetime) -> bool:
    """Whether a note is calling for the person: the very rule of `ringing` in model.ts (FM-NOTES-4398).

    Its time has come, it is not asleep after a press, and its text has not been
    sent to an agent at or after that time (taken to work). Done notes are not in
    this list. The file's times are fixed-width, so comparing strings compares times.
    """
    due = note.get("due")
    at = stamp(now)
    if not due or due > at:
        return False
    if note.get("snooze") and note["snooze"] > at:
        return False
    if note.get("sent") and note["sent"]["at"] >= due:
        return False
    return True


def who() -> str:
    """The block's name, as its header shows it, from the window's state; else the agent's word."""
    if os.environ.get("VOBUDA_NOTES_BY"):
        return plain_name(os.environ["VOBUDA_NOTES_BY"])
    key = os.environ.get("VOBUDA_BLOCK", "")
    block = key.rsplit(":", 1)[-1]
    if block.isdigit():
        states = [os.path.join(config_dir(), "state.json")] + sorted(glob.glob(os.path.join(config_dir(), "workspaces", "*-state.json")))
        for path in states:
            try:
                state = json.load(open(path, encoding="utf-8"))
            except Exception:
                continue
            for tab in state.get("tabs") or []:
                for b in tab.get("blocks") or []:
                    if str(b.get("id")) == block and b.get("name"):
                        return plain_name(str(b["name"]))
    return "agent"


def main(argv: list) -> int:
    verb = argv[0] if argv else "list"
    os.makedirs(folder(), exist_ok=True)
    notes_at = os.path.join(folder(), "notes.md")
    done_at = os.path.join(folder(), "done.md")
    if verb == "path":
        print(notes_at)
        return 0
    if verb == "alarm":
        # What the window asks every half minute with the panel closed: read only, no lock, and always an
        # answer it can read, however the file is.
        try:
            calling = sum(1 for n in read(notes_at) if ringing(n, datetime.datetime.now()))
        except Exception:
            calling = 0
        print(json.dumps({"due": calling}))
        return 0
    with open(os.path.join(folder(), ".lock"), "w") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        notes = read(notes_at)
        if verb == "add":
            args, due = argv[1:], None
            if "--due" in args:
                at = args.index("--due")
                due = parse_when(args[at + 1]) if at + 1 < len(args) else None
                if due is None:
                    print('vobuda notes: --due wants a time, "YYYY-MM-DD HH:MM"', file=sys.stderr)
                    return 1
                args = args[:at] + args[at + 2 :]
            text = clean(" ".join(args) if args else sys.stdin.read())
            if not text:
                print("vobuda notes: nothing to add — vobuda notes add \"<text>\"", file=sys.stderr)
                return 1
            notes.append({"by": who(), "at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), "text": text})
            if due:
                notes[-1]["due"] = due
            keep(notes_at, write(notes, HEAD_NOTES))
            print(f"Note {len(notes)} added to the Notes ({notes_at})")
            return 0
        if verb == "list":
            if not notes:
                print("No notes.")
            for i, n in enumerate(notes, 1):
                lines = n["text"].split("\n")
                by = f"  ({n['by']}, {n['at']})" if n.get("at") else ""
                print(f"{i}. {lines[0]}{by}")
                if n.get("due"):
                    print(f"   (reminder {n['due']})")
                for line in lines[1:]:
                    print(f"   {line}")
            return 0
        if verb == "remind":
            if len(argv) < 3 or not argv[1].isdigit() or not 1 <= int(argv[1]) <= len(notes):
                print(f'vobuda notes: remind <n> "<YYYY-MM-DD HH:MM>" or off — n is 1 to {len(notes)}', file=sys.stderr)
                return 1
            note = notes[int(argv[1]) - 1]
            when = " ".join(argv[2:])
            if when.strip() == "off":
                note.pop("due", None)
                note.pop("snooze", None)
                keep(notes_at, write(notes, HEAD_NOTES))
                print(f"Note {argv[1]} has no reminder")
                return 0
            due = parse_when(when)
            if due is None:
                print('vobuda notes: a time looks like "2026-11-16 09:00"', file=sys.stderr)
                return 1
            note["due"] = due
            note.pop("snooze", None)
            keep(notes_at, write(notes, HEAD_NOTES))
            print(f"Note {argv[1]} will call at {due}")
            return 0
        if verb == "snooze":
            now = datetime.datetime.now()
            until = stamp(now + datetime.timedelta(minutes=SNOOZE_MINUTES))
            if len(argv) > 1:
                if not argv[1].isdigit() or not 1 <= int(argv[1]) <= len(notes):
                    print(f"vobuda notes: which note? 1 to {len(notes)}", file=sys.stderr)
                    return 1
                chosen = [notes[int(argv[1]) - 1]]
            else:
                chosen = [n for n in notes if ringing(n, now)]
            for n in chosen:
                if n.get("due"):
                    n["snooze"] = until
            if chosen:
                keep(notes_at, write(notes, HEAD_NOTES))
            print(f"{len(chosen)} quiet until {until}")
            return 0
        if verb == "done":
            if len(argv) < 2 or not argv[1].isdigit() or not 1 <= int(argv[1]) <= len(notes):
                print(f"vobuda notes: which note? 1 to {len(notes)}", file=sys.stderr)
                return 1
            note = notes.pop(int(argv[1]) - 1)
            done = read(done_at) + [note]
            keep(done_at, write(done, HEAD_DONE))
            keep(notes_at, write(notes, HEAD_NOTES))
            print(f"Note {argv[1]} is done: {note['text'].splitlines()[0]}")
            return 0
    print(__doc__.split("\n\n", 2)[2].rstrip(), file=sys.stderr)
    return 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
