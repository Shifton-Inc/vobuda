//#region \0vite/modulepreload-polyfill.js
(function polyfill() {
	const relList = document.createElement("link").relList;
	if (relList && relList.supports && relList.supports("modulepreload")) return;
	for (const link of document.querySelectorAll("link[rel=\"modulepreload\"]")) processPreload(link);
	new MutationObserver((mutations) => {
		for (const mutation of mutations) {
			if (mutation.type !== "childList") continue;
			for (const node of mutation.addedNodes) if (node.tagName === "LINK" && node.rel === "modulepreload") processPreload(node);
		}
	}).observe(document, {
		childList: true,
		subtree: true
	});
	function getFetchOpts(link) {
		const fetchOpts = {};
		if (link.integrity) fetchOpts.integrity = link.integrity;
		if (link.referrerPolicy) fetchOpts.referrerPolicy = link.referrerPolicy;
		if (link.crossOrigin === "use-credentials") fetchOpts.credentials = "include";
		else if (link.crossOrigin === "anonymous") fetchOpts.credentials = "omit";
		else fetchOpts.credentials = "same-origin";
		return fetchOpts;
	}
	function processPreload(link) {
		if (link.ep) return;
		link.ep = true;
		const fetchOpts = getFetchOpts(link);
		fetch(link.href, fetchOpts);
	}
})();
//#endregion
//#region plugins/remote/reasons.ts
var CLASSES = [
	"unreachable",
	"identity",
	"key",
	"desk",
	"claude",
	"paused",
	"version",
	"full",
	"notrunning",
	"copying",
	"timeout",
	"refused",
	"fetch",
	"pairing",
	"off"
];
var SAID = {
	unreachable: {
		line: "{0} has not been reachable since {1} — work waits",
		of: ["host", "time"],
		fix: "check the cable or the network; «Повторить сейчас»",
		fixOf: []
	},
	identity: {
		line: "{0} answered with another identity — nothing was sent",
		of: ["host"],
		fix: "pair again",
		fixOf: []
	},
	key: {
		line: "{0} refused this Mac's key",
		of: ["host"],
		fix: "pair again",
		fixOf: []
	},
	desk: {
		line: "This Mac could not start the connection to {0}: {1}",
		of: ["host", "words"],
		fix: "update this Mac, then «Повторить сейчас»",
		fixOf: []
	},
	claude: {
		line: "Claude is not signed in on {0}",
		of: ["host"],
		fix: "sign in to Claude on {0}",
		fixOf: ["host"]
	},
	paused: {
		line: "Remote work is switched off on {0}",
		of: ["host"],
		fix: "switch it on there",
		fixOf: []
	},
	version: {
		line: "{0} runs another vobuda ({1}, here {2})",
		of: [
			"host",
			"there",
			"here"
		],
		fix: "update the older one",
		fixOf: []
	},
	full: {
		line: "{0} is short of memory — nobody was hired",
		of: ["host"],
		fix: "dismiss a member there, or free space",
		fixOf: []
	},
	notrunning: {
		line: "vobuda is not running on {0}",
		of: ["host"],
		fix: "open vobuda on {0}",
		fixOf: ["host"]
	},
	copying: {
		line: "{0} is getting a copy of the project — hire again in a minute",
		of: ["host"],
		fix: "wait",
		fixOf: []
	},
	timeout: {
		line: "{0} did not answer in time — nothing was changed",
		of: ["host"],
		fix: "try again",
		fixOf: []
	},
	refused: {
		line: "{0} refused: {1}",
		of: ["host", "words"],
		fix: null,
		fixOf: []
	},
	fetch: {
		line: "{0}'s work stays on {1} ({2} commits) — nothing was removed",
		of: [
			"name",
			"host",
			"n"
		],
		fix: "try again when {0} answers",
		fixOf: ["host"]
	},
	pairing: {
		line: "Pairing did not happen: {0}",
		of: ["words"],
		fix: null,
		fixOf: []
	},
	off: {
		line: "Remote work is off on this Mac — the block on {0} was not opened",
		of: ["host"],
		fix: "switch it on",
		fixOf: []
	}
};
/** The table says the class `full` of a short disk in a parenthesis: «мало места на диске» · "of disk". */
var FULL_DISK = "{0} is short of disk — nobody was hired";
/**
* What fills the `<reason>` of a `pairing` line, and the one fix it names: SPEC-remote, *Contract: pairing reasons*,
* word for word (contract.test.ts). The core sends the word as the second of a refusal's parts; the page never draws
* the core's English words, and a word it does not know is `failed` (FM-REMOTE-3500). `nologin` is drawn as a box of
* its own, where «Связать» would be (FM-REMOTE-3501). `notme` names the Mac that paired with the invite, the core's third
* part, and `samename` this Mac's own name (FM-REMOTE-3509, FM-REMOTE-3511, FM-REMOTE-3513).
*/
var PAIRING = {
	nologin: {
		line: "This Mac cannot be a workshop: Remote Login is off on it. The workshop is the second Mac, where the work runs.",
		fix: "Choose “My desk” here. If this Mac should be the workshop, switch on Remote Login: System Settings → General → Sharing."
	},
	noaddress: {
		line: "this Mac has no address on a network of your own",
		fix: "connect it by cable or to the same network as the desk Mac, then press “Pair with another computer” again"
	},
	badname: {
		line: "this Mac's name cannot go into an invite",
		fix: "give it a plain Latin name: System Settings → General → Sharing → Local hostname"
	},
	expired: {
		line: "the invite's time is over",
		fix: "on the workshop, press “Pair with another computer” again and paste the new text here"
	},
	used: {
		line: "this Mac has taken this invite already",
		fix: "on the workshop, press “Pair with another computer” again and paste the new text here"
	},
	notme: {
		line: "another Mac paired with this invite (“{0}”). It is not this Mac",
		fix: "on the workshop, press “Disconnect” for “{0}” and make a new invite"
	},
	samename: {
		line: "the workshop already has another Mac paired under this Mac's name (“{0}”) — a second one by the same name was not paired",
		fix: "if that Mac is this one with new vobuda settings, press “Disconnect” for the old “{0}” on the workshop and make a new invite; if not, press “Disconnect” for it too: it is not your Mac"
	},
	noworkshop: {
		line: "the workshop did not answer: vobuda is closed there, Remote work is off, it is not set to Workshop, or it cannot be reached",
		fix: "check these on the workshop and the cable or network between the Macs, then press “They match” again"
	},
	differ: {
		line: "the check words differ — nothing was written",
		fix: "on the workshop, press “Pair with another computer” again; if the words differ again, carry the text another way"
	},
	unreadable: {
		line: "the text pasted does not read — it was cut or changed",
		fix: "copy the whole text, from its first letter to its last, and paste it again"
	},
	oldversion: {
		line: "the invite was made by another version of vobuda",
		fix: "update vobuda on both Macs to the same version, then make a new invite"
	},
	owninvite: {
		line: "this Mac made that invite itself",
		fix: "paste it on the other Mac, the one you write at"
	},
	failed: {
		line: "this Mac could not finish its half",
		fix: "press “Pair with another computer” again; if it repeats, restart vobuda"
	}
};
var WHYS = Object.keys(PAIRING);
/** The reasons whose line names a Mac, the core's third part. */
var NAMED = ["notme", "samename"];
//#endregion
//#region plugins/remote/model.ts
/** The names of the nine verbs, as the contract's table lists them. */
var VERBS = [
	"remoteState",
	"onRemoteState",
	"remoteCheck",
	"remoteSet",
	"remotePairInvite",
	"remotePairAccept",
	"remotePairAnswer",
	"remotePairConfirm",
	"remoteUnpair"
];
/** Control characters, soft hyphen, and every character that hides itself or turns the text around it: marks, joiners, separators, embeddings, isolates. */
var HIDDEN = /[\u0000-\u001f\u007f-\u009f\u00ad\u061c\u200b-\u200f\u2028-\u202e\u2060-\u2069\ufeff]/g;
/** Text a host sent, made safe to draw: control and direction-changing characters out, a length. */
function clean(value, max = 200) {
	if (typeof value !== "string" && typeof value !== "number") return "";
	return String(value).replace(HIDDEN, "").trim().slice(0, max);
}
/** A longer text with its lines kept: the invite and the answer. One longer than a text of the pairing can be is refused, not cut: a cut invite would be copied as if whole. */
function cleanLines(value) {
	if (typeof value !== "string" || value.length > 4e3) return "";
	return value.replace(/\r\n?/g, "\n").split("\n").map((line) => line.replace(HIDDEN, "")).join("\n").trim();
}
var obj = (v) => v && typeof v === "object" && !Array.isArray(v) ? v : {};
/** A time as milliseconds: seconds or milliseconds since 1970, or a date text; none when it is not one. */
function when(value) {
	if (typeof value === "number" && Number.isFinite(value) && value > 0) return value < 1e11 ? Math.round(value * 1e3) : Math.round(value);
	if (typeof value === "string" && value.trim()) {
		const t = Date.parse(value);
		if (Number.isFinite(t)) return t;
	}
	return null;
}
var known = (c) => typeof c === "string" && CLASSES.includes(c);
/** A reason out of a class word, an object, or a thing that failed; a class not in the table is `refused` with its words. */
function reasonOf(raw, parts) {
	if (raw === null || raw === void 0 || raw === false) return null;
	if (typeof raw === "string") return known(raw) ? withParts({ class: raw }, parts) : {
		class: "refused",
		words: clean(raw)
	};
	const o = obj(raw instanceof Error ? {
		class: raw.class,
		words: raw.words ?? raw.message
	} : raw);
	const inner = obj(o.error);
	const src = Object.keys(inner).length ? inner : o;
	const cls = src.class ?? src.code;
	const what = src.what === "disk" || src.what === "memory" ? src.what : void 0;
	const r = known(cls) ? { class: cls } : {
		class: "refused",
		words: clean(src.words ?? src.message ?? cls)
	};
	if (known(cls) && typeof src.words === "string") r.words = clean(src.words);
	if (what) r.what = what;
	for (const k of [
		"there",
		"here",
		"name"
	]) if (typeof src[k] === "string") r[k] = clean(src[k], 60);
	if (typeof src.n === "number" && Number.isFinite(src.n)) r.n = src.n;
	r.since = when(src.since);
	return withParts(r, parts ?? src.parts);
}
/**
* What fills the blanks of a class's line besides the host and the time, from the contract's `parts`
* (SPEC-remote, *Fixed shapes*): `version` there and here, `full` memory or disk, `fetch` the member's
* name and the count, and the host's or ssh's words for `refused`, `pairing` and `desk`. A part the
* object already named in its own field is kept; a part that is not text, or that is too long, is none.
*/
function withParts(r, parts) {
	if (!Array.isArray(parts)) return r;
	const at = (i) => typeof parts[i] === "string" || typeof parts[i] === "number" ? clean(parts[i], 200) : "";
	const out = { ...r };
	switch (r.class) {
		case "version":
			out.there ??= at(0).slice(0, 60) || void 0;
			out.here ??= at(1).slice(0, 60) || void 0;
			break;
		case "full":
			if (!out.what && at(0) === "disk") out.what = "disk";
			else if (!out.what && at(0) === "memory") out.what = "memory";
			break;
		case "fetch": {
			out.name ??= at(0).slice(0, 60) || void 0;
			const n = Number(at(1));
			if (out.n === void 0 && at(1) !== "" && Number.isFinite(n)) out.n = n;
			break;
		}
		case "pairing": {
			const w = at(1);
			if (!out.why) out.why = WHYS.includes(w) ? w : "failed";
			if (out.why && NAMED.includes(out.why) && at(2)) out.name = at(2).slice(0, 60);
			break;
		}
		case "refused":
		case "desk": if (at(0)) out.words = at(0);
	}
	for (const k of Object.keys(out)) if (out[k] === void 0) delete out[k];
	return out;
}
/** The pair out of whatever the core wrote. A pair with no id is not one. */
function pairOf(raw) {
	const o = obj(raw);
	const id = clean(o.id, 16);
	if (!id) return null;
	return {
		id,
		name: clean(o.name, 60) || id,
		state: clean(o.state, 20),
		route: clean(o.route, 40),
		ms: typeof o.ms === "number" && Number.isFinite(o.ms) ? Math.round(o.ms) : null,
		reason: reasonOf(o.reason, o.parts),
		since: when(o.since),
		copying: clean(o.copying, 200)
	};
}
/** The state out of `remoteState()` or a `remote://state` event; null when it is not one. */
function stateOf(raw) {
	const o = obj(raw);
	if (typeof o.enabled !== "boolean") return null;
	const pairs = (Array.isArray(o.pairs) ? o.pairs : []).map(pairOf).filter((p) => p !== null);
	return {
		enabled: o.enabled,
		role: o.role === "host" ? "host" : "desk",
		place: clean(o.place, 16) || "here",
		hereUntil: clean(o.hereUntil, 16),
		pairs,
		login: o.login === true,
		canHost: o.canHost !== false
	};
}
/** Check's lines, in the contract's order of items; a failed item carries its class when the core gave it. */
function checksOf(raw) {
	return (Array.isArray(raw) ? raw : []).map((r) => {
		const o = obj(r);
		const item = clean(o.item, 20);
		const words = clean(o.words, 300);
		const ok = o.ok === true || item === "password";
		return {
			item,
			ok,
			words,
			reason: ok ? null : reasonOf(o.reason ?? o.error ?? (known(o.class) ? o.class : null), o.parts)
		};
	});
}
/** The six words of a check: a list, or one text with spaces; never more than six. */
function wordsOf(raw) {
	const words = (Array.isArray(raw) ? raw : typeof raw === "string" ? raw.trim().split(/[\s,]+/) : []).map((w) => clean(w, 200));
	return words.length === 6 && words.every((w) => w !== "" && w.length <= 24) ? words : [];
}
/** The label of a route: «по кабелю», «по сети», «через Tailscale», or the host's own word for it. */
function routeKey(route) {
	const r = route.toLowerCase();
	if (/cable|thunderbolt|bridge|кабел/.test(r)) return "cable";
	if (/tailscale|overlay|vpn/.test(r)) return "overlay";
	if (/network|lan|wifi|wi-fi|ethernet|сет/.test(r)) return "network";
	return "";
}
/** The clock time of a moment, as a person reads it. */
function clock(ms, locale) {
	if (!ms || Number.isNaN(new Date(ms).getTime())) return "";
	try {
		return new Intl.DateTimeFormat(locale || void 0, {
			hour: "2-digit",
			minute: "2-digit",
			hour12: false
		}).format(new Date(ms));
	} catch {
		const d = new Date(ms);
		return `${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
	}
}
/** Minutes and seconds left, "9:41"; never below 0:00. */
function left(expires, now) {
	const s = Math.max(0, Math.ceil((expires - now) / 1e3));
	return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
//#endregion
//#region plugins/remote/look.ts
/**
* The text colour for a button filled with `accent`: white or near-black,
* whichever stands further from it. The primary button wrote white on
* whatever accent the look brought, and a look's light accent under white
* text read at under 2:1 (readability audit, FM-THEME-21). An accent that is
* not a plain hex keeps white.
*/
function onAccentFor(accent) {
	const m = /^#([0-9a-f]{6})/i.exec(accent.trim());
	if (!m) return "#ffffff";
	const lin = (v) => {
		const c = v / 255;
		return c <= .03928 ? c / 12.92 : ((c + .055) / 1.055) ** 2.4;
	};
	const [r, g, b] = [
		0,
		2,
		4
	].map((i) => lin(parseInt(m[1].slice(i, i + 2), 16)));
	const y = .2126 * r + .7152 * g + .0722 * b;
	return 1.05 / (y + .05) >= (y + .05) / .0552 ? "#ffffff" : "#101010";
}
/** A colour's relative luminance, for a plain hex or `rgb()` / `rgba()`; null for anything else. */
function luminanceOf(colour) {
	const c = (colour ?? "").trim();
	let rgb = null;
	const hex = /^#([0-9a-f]{3}|[0-9a-f]{6}|[0-9a-f]{8})$/i.exec(c);
	if (hex) {
		const h = hex[1].length === 3 ? [...hex[1]].map((x) => x + x).join("") : hex[1].slice(0, 6);
		rgb = [
			0,
			2,
			4
		].map((i) => parseInt(h.slice(i, i + 2), 16));
	} else {
		const fn = /^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)/i.exec(c);
		if (fn) rgb = [
			fn[1],
			fn[2],
			fn[3]
		].map(Number);
	}
	if (!rgb || rgb.some((v) => !Number.isFinite(v))) return null;
	const lin = (v) => {
		const x = Math.min(255, Math.max(0, v)) / 255;
		return x <= .03928 ? x / 12.92 : ((x + .055) / 1.055) ** 2.4;
	};
	const [r, g, b] = rgb.map(lin);
	return .2126 * r + .7152 * g + .0722 * b;
}
/**
* The colour scheme the page's own controls are drawn in, from the window's colours: "dark" on a dark
* ground, "light" on a light one, "" when neither colour can be read. The number fields' up and down
* arrows and the lists' menus are the engine's own drawing, in the page's scheme and not in any colour
* a stylesheet gives them; the page had none, so in a dark look they were drawn for a light page and
* all but vanished (live test 3, P1; FM-PLUGIN-1424).
*/
function schemeFor(tokens) {
	const ground = luminanceOf(tokens["--app-bg"]);
	if (ground !== null) return ground < .2 ? "dark" : "light";
	const text = luminanceOf(tokens["--app-fg"]);
	if (text !== null) return text > .4 ? "dark" : "light";
	return "";
}
/** Window token → the variable this page draws with. */
var BORROWED = {
	"--app-bg": "--bg",
	"--app-fg": "--fg",
	"--app-accent": "--accent",
	"--line": "--line",
	"--block-radius": "--radius",
	"--panel-bg": "--card",
	"--panel-fg": "--card-fg",
	"--app-fg-muted": "--dim"
};
/**
* Put the window's colours on the page, and take off the ones the look in
* force does not name, so they fall back to the stylesheet rather than stay on
* the last look's value.
*/
function wear(style, tokens) {
	for (const [theirs, ours] of Object.entries(BORROWED)) {
		const value = tokens[theirs];
		if (typeof value === "string" && value.trim()) style.setProperty(ours, value.trim());
		else style.removeProperty(ours);
	}
}
/** Everything above, on the page's root, for the tokens now in force. */
function paint(root, tokens) {
	wear(root.style, tokens);
	const accent = tokens["--app-accent"];
	if (typeof accent === "string") root.style.setProperty("--on-accent", onAccentFor(accent));
	else root.style.removeProperty("--on-accent");
	const scheme = schemeFor(tokens);
	if (scheme) root.dataset.scheme = scheme;
	else delete root.dataset.scheme;
}
var en_default = {
	"Work on another computer": "Work on another computer",
	"Off: the window works as before, nothing is started or opened.": "Off: the window works as before, nothing is started or opened.",
	"On, but the second computer is not paired yet — everything still happens here, as before.": "On, but the second computer is not paired yet — everything still happens here, as before.",
	"On: new members start where you choose below.": "On: new members start where you choose below.",
	"On: paired computers may start work here. Off: every one of them is refused at once.": "On: paired computers may start work here. Off: every one of them is refused at once.",
	"This module must be installed on the second Mac too. Without it, remote work will not switch on there.": "This module must be installed on the second Mac too. Without it, remote work will not switch on there.",
	"What kind of Mac this is": "What kind of Mac this is",
	"My desk (I write here)": "My desk (I write here)",
	"Workshop (the work runs here)": "Workshop (the work runs here)",
	"Pair with another computer": "Pair with another computer",
	"Stays on the desk Mac: the director, your own blocks, deployment.": "Stays on the desk Mac: the director, your own blocks, deployment.",
	"Stays here: the director, your own blocks, deployment.": "Stays here: the director, your own blocks, deployment.",
	"Paste the text from the workshop": "Paste the text from the workshop",
	Continue: "Continue",
	Back: "Back",
	"Check words": "Check words",
	"Compare the six words with the workshop's screen.": "Compare the six words with the workshop's screen.",
	"If they differ, do not confirm: somebody changed a text on the way.": "If they differ, do not confirm: somebody changed a text on the way.",
	"They differ": "They differ",
	Paired: "Paired",
	"Text to copy": "Text to copy",
	"Make a new one": "Make a new one",
	"Waiting for the desk Mac…": "Waiting for the desk Mac…",
	"{0} left": "{0} left",
	"Open vobuda when I log in": "Open vobuda when I log in",
	"vobuda will open on its own when this Mac starts, so the workshop is ready.": "vobuda will open on its own when this Mac starts, so the workshop is ready.",
	Copy: "Copy",
	Copied: "Copied",
	"Selected: press ⌘C": "Selected: press ⌘C",
	"Checking…": "Checking…",
	"{0} answers": "{0} answers",
	"the same version of vobuda there": "the same version of vobuda there",
	"Remote work is switched on there": "Remote work is switched on there",
	"Claude is signed in there": "Claude is signed in there",
	"git, disk and memory are fine": "git, disk and memory are fine",
	"git is there": "git is there",
	"there is enough disk": "there is enough disk",
	"there is enough memory": "there is enough memory",
	"Paired with {0}": "Paired with {0}",
	"{0} ms": "{0} ms",
	"by cable": "by cable",
	"over the network": "over the network",
	"through Tailscale": "through Tailscale",
	"New members start": "New members start",
	"on {0}": "on {0}",
	here: "here",
	"Check again": "Check again",
	Disconnect: "Disconnect",
	"Disconnect {0}": "Disconnect {0}",
	"Disconnect {0}? Its key and pairing are removed on both Macs.": "Disconnect {0}? Its key and pairing are removed on both Macs.",
	"Yes, disconnect": "Yes, disconnect",
	Keep: "Keep",
	"Paired computers": "Paired computers",
	"this Mac": "this Mac",
	"Remote work needs a newer vobuda. Update it to use this page.": "Remote work needs a newer vobuda. Update it to use this page.",
	"{0} has not been reachable since {1} — work waits": "{0} has not been reachable since {1} — work waits",
	"{0} answered with another identity — nothing was sent": "{0} answered with another identity — nothing was sent",
	"This Mac could not start the connection to {0}: {1}": "This Mac could not start the connection to {0}: {1}",
	"{0} refused this Mac's key": "{0} refused this Mac's key",
	"Claude is not signed in on {0}": "Claude is not signed in on {0}",
	"Remote work is switched off on {0}": "Remote work is switched off on {0}",
	"{0} runs another vobuda ({1}, here {2})": "{0} runs another vobuda ({1}, here {2})",
	"{0} is short of memory — nobody was hired": "{0} is short of memory — nobody was hired",
	"{0} is short of disk — nobody was hired": "{0} is short of disk — nobody was hired",
	"vobuda is not running on {0}": "vobuda is not running on {0}",
	"{0} is getting a copy of the project — hire again in a minute": "{0} is getting a copy of the project — hire again in a minute",
	"{0} did not answer in time — nothing was changed": "{0} did not answer in time — nothing was changed",
	"{0} refused: {1}": "{0} refused: {1}",
	"{0}'s work stays on {1} ({2} commits) — nothing was removed": "{0}'s work stays on {1} ({2} commits) — nothing was removed",
	"Pairing did not happen: {0}": "Pairing did not happen: {0}",
	"Remote work is off on this Mac — the block on {0} was not opened": "Remote work is off on this Mac — the block on {0} was not opened",
	"check the cable or the network; «Повторить сейчас»": "check the cable or the network; press “Retry now”",
	"pair again": "pair again",
	"update this Mac, then «Повторить сейчас»": "update this Mac, then press “Retry now”",
	"sign in to Claude on {0}": "sign in to Claude on {0}",
	"switch it on there": "switch it on there",
	"update the older one": "update the older one",
	"dismiss a member there, or free space": "dismiss a member there, or free space",
	"open vobuda on {0}": "open vobuda on {0}",
	wait: "wait",
	"try again": "try again",
	"try again when {0} answers": "try again when {0} answers",
	"switch it on": "switch it on",
	"Here while {0} is unreachable; then on {0} again": "Here while {0} is unreachable; then on {0} again",
	"This Mac cannot be a workshop: Remote Login is off on it. The workshop is the second Mac, where the work runs.": "This Mac cannot be a workshop: Remote Login is off on it. The workshop is the second Mac, where the work runs.",
	"Choose “My desk” here. If this Mac should be the workshop, switch on Remote Login: System Settings → General → Sharing.": "Choose “My desk” here. If this Mac should be the workshop, switch on Remote Login: System Settings → General → Sharing.",
	"this Mac has no address on a network of your own": "this Mac has no address on a network of your own",
	"connect it by cable or to the same network as the desk Mac, then press “Pair with another computer” again": "connect it by cable or to the same network as the desk Mac, then press “Pair with another computer” again",
	"this Mac's name cannot go into an invite": "this Mac's name cannot go into an invite",
	"give it a plain Latin name: System Settings → General → Sharing → Local hostname": "give it a plain Latin name: System Settings → General → Sharing → Local hostname",
	"the check words differ — nothing was written": "the check words differ — nothing was written",
	"the text pasted does not read — it was cut or changed": "the text pasted does not read — it was cut or changed",
	"copy the whole text, from its first letter to its last, and paste it again": "copy the whole text, from its first letter to its last, and paste it again",
	"this Mac made that invite itself": "this Mac made that invite itself",
	"paste it on the other Mac, the one you write at": "paste it on the other Mac, the one you write at",
	"this Mac could not finish its half": "this Mac could not finish its half",
	"press “Pair with another computer” again; if it repeats, restart vobuda": "press “Pair with another computer” again; if it repeats, restart vobuda",
	"At {0}": "At {0}",
	"Again at {0}, attempt {1}": "Again at {0}, attempt {1}",
	"Checked at {0}": "Checked at {0}",
	"One moment…": "One moment…",
	"The workshop makes this text: on the second Mac choose “Workshop” and press “Pair with another computer”.": "The workshop makes this text: on the second Mac choose “Workshop” and press “Pair with another computer”.",
	"the workshop did not answer: vobuda is closed there, Remote work is off, it is not set to Workshop, or it cannot be reached": "the workshop did not answer: vobuda is closed there, Remote work is off, it is not set to Workshop, or it cannot be reached",
	"check these on the workshop and the cable or network between the Macs, then press “They match” again": "check these on the workshop and the cable or network between the Macs, then press “They match” again",
	"on the workshop, press “Pair with another computer” again; if the words differ again, carry the text another way": "on the workshop, press “Pair with another computer” again; if the words differ again, carry the text another way",
	"the invite was made by another version of vobuda": "the invite was made by another version of vobuda",
	"update vobuda on both Macs to the same version, then make a new invite": "update vobuda on both Macs to the same version, then make a new invite",
	"They match": "They match",
	"This Mac is the workshop. Copy the text below. On the Mac you write at, choose “My desk”, press “Pair with another computer” and paste it there. The text works for 10 minutes, once.": "This Mac is the workshop. Copy the text below. On the Mac you write at, choose “My desk”, press “Pair with another computer” and paste it there. The text works for 10 minutes, once.",
	"The desk Mac shows the same six words once the text is pasted there. Compare them; they are confirmed there, not here.": "The desk Mac shows the same six words once the text is pasted there. Compare them; they are confirmed there, not here.",
	"the invite's time is over": "the invite's time is over",
	"on the workshop, press “Pair with another computer” again and paste the new text here": "on the workshop, press “Pair with another computer” again and paste the new text here",
	"without a name": "without a name",
	"On the workshop, this Mac will be listed as «{0}».": "On the workshop, this Mac will be listed as «{0}».",
	"If you do not know this Mac, press “Disconnect” for it.": "If you do not know this Mac, press “Disconnect” for it.",
	"on the workshop, press “Disconnect” for “{0}” and make a new invite": "on the workshop, press “Disconnect” for “{0}” and make a new invite",
	"the workshop already has another Mac paired under this Mac's name (“{0}”) — a second one by the same name was not paired": "the workshop already has another Mac paired under this Mac's name (“{0}”) — a second one by the same name was not paired",
	"if that Mac is this one with new vobuda settings, press “Disconnect” for the old “{0}” on the workshop and make a new invite; if not, press “Disconnect” for it too: it is not your Mac": "if that Mac is this one with new vobuda settings, press “Disconnect” for the old “{0}” on the workshop and make a new invite; if not, press “Disconnect” for it too: it is not your Mac",
	"this Mac has taken this invite already": "this Mac has taken this invite already",
	"another Mac paired with this invite (“{0}”). It is not this Mac": "another Mac paired with this invite (“{0}”). It is not this Mac"
};
//#endregion
//#region plugins/remote/words.ts
var words = en_default;
/** Take a dictionary, dropping anything that is not a sentence. */
function useWords(table) {
	words = {};
	if (!table || typeof table !== "object") return;
	for (const [key, value] of Object.entries(table)) if (typeof value === "string" && value !== "") words[key] = value;
}
/** One sentence, translated if there is a translation and English if not. */
var say = (key) => words[key] ?? key;
/** A sentence with something of the person's own in it. */
function saying(key, ...parts) {
	return say(key).replace(/\{(\d)\}/g, (whole, at) => {
		const part = parts[Number(at)];
		return part === void 0 ? whole : String(part);
	});
}
/** Fetch the dictionary for a language; one we do not carry leaves English in force. */
async function loadWords(code, get = fetch) {
	const wanted = code.split(/[-_]/)[0] || "en";
	if (wanted !== "en") try {
		const answer = await get(`./words/${wanted}.json`);
		if (!answer.ok) throw new Error(String(answer.status));
		useWords(await answer.json());
		return;
	} catch {}
	useWords(en_default);
}
/** Text as HTML text, whatever a host or a file wrote in it. */
var plain = (text) => String(text).replace(/[&<>"']/g, (c) => ({
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;"
})[c]);
//#endregion
//#region plugins/remote/screens.ts
var b = (key, ...rest) => plain(saying(key, ...rest));
var t = (key) => plain(say(key));
var up = (s) => s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
/** The value of one blank of a reason, by the table's name for it. */
function valueOf(p, r, host, since, locale) {
	switch (p) {
		case "host": return host;
		case "time": return clock(r.since ?? since, locale) || "…";
		case "there": return r.there ?? "?";
		case "here": return r.here ?? "?";
		case "words": return r.words || "—";
		case "name": return r.name ?? "?";
		case "n": return String(r.n ?? "?");
	}
}
/** One failure, as the table says it: the line, and the fix it names. */
function reasonHtml(r, host, since = null, locale, stamp = "") {
	if (r.class === "pairing") {
		const p = PAIRING[r.why ?? "failed"] ?? PAIRING.failed;
		const name = r.name || say("without a name");
		return `<div class="said" role="status"><b>${plain(NAMED.includes(r.why ?? "failed") ? up(saying(p.line, name)) : saying(SAID.pairing.line, say(p.line)))}</b><span class="fix">${plain(up(saying(p.fix, name)))}</span>${stamp}</div>`;
	}
	const said = SAID[r.class];
	const line = r.class === "full" && r.what === "disk" ? FULL_DISK : said.line;
	const h = clean(host, 60) || "…";
	const fills = said.of.map((p) => valueOf(p, r, h, since, locale));
	const fix = said.fix ? plain(up(saying(said.fix, ...said.fixOf.map((p) => valueOf(p, r, h, since, locale))))) : "";
	return `<div class="said" role="status"><b>${plain(saying(line, ...fills))}</b>${fix ? `<span class="fix">${fix}</span>` : ""}${stamp}</div>`;
}
/** A clock time with its seconds, so a second attempt a moment later reads as a new one. */
function seconds(ms, locale) {
	try {
		return new Intl.DateTimeFormat(locale || void 0, {
			hour: "2-digit",
			minute: "2-digit",
			second: "2-digit",
			hour12: false
		}).format(new Date(ms));
	} catch {
		const d = new Date(ms);
		return [
			d.getHours(),
			d.getMinutes(),
			d.getSeconds()
		].map((n) => String(n).padStart(2, "0")).join(":");
	}
}
/** When a note was said: the time, and «ещё раз» with the attempt when the same failure came again (FM-REMOTE-3503). */
function stampHtml(at, tries, locale) {
	if (!at) return "";
	const time = seconds(at, locale);
	return `<span class="when">${(tries ?? 1) > 1 ? b("Again at {0}, attempt {1}", time, tries ?? 2) : b("At {0}", time)}</span>`;
}
/** Whether this page says that this Mac cannot be a workshop: the core's state, or the core's refusal of an invite. */
var cannotHost = (c) => c.state.role === "host" && (c.state.canHost === false || c.note?.class === "pairing" && c.note.why === "nologin");
/** The box of `nologin`, where «Связать» would be, the moment «Мастерская» is chosen (FM-REMOTE-3501). */
function noHostBox(c) {
	const p = PAIRING.nologin;
	const checked = c.checkedAt ? `<span class="when">${b("Checked at {0}", seconds(c.checkedAt, c.locale))}</span>` : "";
	const busy = c.busy && c.pressing === "recheck";
	return `<div class="said nohost" role="status"><b>${t(p.line)}</b><span class="fix">${t(p.fix)}</span>${checked}</div><div class="row-btns"><button class="btn2" data-do="recheck"${c.busy ? " disabled" : ""}>${t(busy ? "One moment…" : "Check again")}</button></div>`;
}
/** A button's own label, or «Минутку…» while its press is being answered. */
var label = (c, what, key) => t(c.busy && c.pressing === what ? "One moment…" : key);
var checkLabel = {
	version: "the same version of vobuda there",
	switched: "Remote work is switched on there",
	claude: "Claude is signed in there"
};
/** Which class a failed item of Check is, when the core did not say. */
var ITEM_CLASS = {
	reach: "unreachable",
	version: "version",
	switched: "paused",
	claude: "claude",
	disk: "full",
	memory: "full",
	git: "refused"
};
/** Check's lines: a ✓ for what is well, the table's line and fix for what is not, the password as a fact. */
function checksHtml(items, pair, locale) {
	if (items === "loading" || items === void 0) return `<p class="small">${t("Checking…")}</p>`;
	const by = new Map(items.map((i) => [i.item, i]));
	const rows = [];
	const bad = [];
	const failed = (i) => {
		const r = i.reason ?? {
			class: ITEM_CLASS[i.item] ?? "refused",
			words: i.words
		};
		if (r.class === "refused" && !r.words) r.words = i.words;
		if (i.item === "disk" || i.item === "memory") r.what = i.item;
		bad.push(reasonHtml(r, pair.name, pair.since, locale));
	};
	const reach = by.get("reach");
	if (reach) reach.ok ? rows.push(`<li>${b("{0} answers", pair.name)}</li>`) : failed(reach);
	for (const name of [
		"version",
		"switched",
		"claude"
	]) {
		const i = by.get(name);
		if (i) i.ok ? rows.push(`<li>${t(checkLabel[name])}</li>`) : failed(i);
	}
	const rest = [
		"git",
		"disk",
		"memory"
	].map((n) => by.get(n)).filter((i) => !!i);
	if (rest.length && rest.every((i) => i.ok)) rows.push(`<li>${t("git, disk and memory are fine")}</li>`);
	else for (const i of rest) if (!i.ok) failed(i);
	else rows.push(`<li>${t(i.item === "git" ? "git is there" : i.item === "disk" ? "there is enough disk" : "there is enough memory")}</li>`);
	const pw = by.get("password");
	const fact = pw?.words ? `<p class="fact">${plain(pw.words)}</p>` : "";
	return `${bad.join("")}${rows.length ? `<ul class="checks">${rows.join("")}</ul>` : ""}${fact}`;
}
var switchRow = (on, hint) => `<div class="set"><div class="t"><b>${t("Work on another computer")}</b><span>${plain(hint)}</span></div><button class="sw${on ? " on" : ""}" role="switch" aria-checked="${on}" aria-label="${t("Work on another computer")}" data-do="enable" data-value="${on ? "false" : "true"}"></button></div>`;
var seg = (role) => `<div class="seg" role="radiogroup" aria-label="${t("What kind of Mac this is")}">` + ["desk", "host"].map((r) => `<button role="radio" aria-checked="${r === role}" class="${r === role ? "on" : ""}" data-do="role" data-value="${r}">${t(r === "desk" ? "My desk (I write here)" : "Workshop (the work runs here)")}</button>`).join("") + `</div>`;
var lines = (text) => plain(text).split("\n").join("<br>");
var wordsHtml = (list) => `<div class="words">${list.map((w, i) => `<span><i>${i + 1}</i>${plain(w)}</span>`).join("")}</div>`;
var copyBtn = (c) => `<button class="btn2 ok" data-do="copy">${t(c.copied === "copied" ? "Copied" : c.copied === "selected" ? "Selected: press ⌘C" : "Copy")}</button>`;
var matchBtns = (c) => `<div class="row-btns"><button class="btn2 ok" data-do="match" data-value="true"${c.busy ? " disabled" : ""}>${label(c, "match", "They match")}</button><button class="btnq" data-do="match" data-value="false"${c.busy ? " disabled" : ""}>${t("They differ")}</button><button class="btnq" data-do="back"${c.busy ? " disabled" : ""}>${t("Back")}</button></div>`;
var stays = (key) => `<p class="stays">${t(key)}</p>`;
function routeWord(route) {
	const k = routeKey(route);
	return k === "cable" ? say("by cable") : k === "network" ? say("over the network") : k === "overlay" ? say("through Tailscale") : clean(route, 40);
}
/** The line over one pair, and under it git's own words while the project's first copy goes there (FM-REMOTE-3006). */
function pairLine(p, c) {
	const copying = p.copying ? `<p class="small copying">${plain(p.copying)}</p>` : "";
	return stateLine(p, c) + copying;
}
/** «Связан с garymini · по кабелю · 3 мс», or what keeps the pair from being ready. */
function stateLine(p, c) {
	if (p.state === "ready") {
		const bits = [routeWord(p.route), p.ms === null ? "" : saying("{0} ms", p.ms)].filter(Boolean).map((x) => `<span class="m">· ${plain(x)}</span>`).join(" ");
		return `<div class="state-line"><span class="dot ok"></span><b>${b("Paired with {0}", p.name)}</b>${bits}</div>`;
	}
	const r = p.reason ?? (p.state === "paused" ? { class: "paused" } : p.state === "unreachable" ? { class: "unreachable" } : null);
	if (!r) return `<div class="state-line"><span class="dot wait"></span><b>${b("Paired with {0}", p.name)}</b></div>`;
	return `<div class="state-line"><span class="dot bad"></span><b>${b("Paired with {0}", p.name)}</b></div>${reasonHtml(r, p.name, p.since, c.locale)}`;
}
function paired(c) {
	const s = c.state;
	const at = s.pairs.some((p) => p.id === s.place) ? s.place : "here";
	const held = s.hereUntil ? s.pairs.find((p) => p.id === s.hereUntil) : void 0;
	const until = at === "here" && held ? `<p class="small">${b("Here while {0} is unreachable; then on {0} again", held.name)}</p>` : "";
	const place = s.role === "desk" ? `<div class="lbl">${t("New members start")}</div><div class="radio" role="radiogroup" aria-label="${t("New members start")}">` + s.pairs.map((p) => `<button role="radio" aria-checked="${at === p.id}" class="${at === p.id ? "on" : ""}" data-do="place" data-value="${plain(p.id)}">${b("on {0}", p.name)}</button>`).join("") + `<button role="radio" aria-checked="${at === "here"}" class="${at === "here" ? "on" : ""}" data-do="place" data-value="here">${t("here")}</button></div>` + until : "";
	const ends = s.pairs.map((p) => c.asking === p.id ? `<span class="ask">${b("Disconnect {0}? Its key and pairing are removed on both Macs.", p.name)}</span><button class="btn2" data-do="unpair" data-value="${plain(p.id)}">${t("Yes, disconnect")}</button><button class="btnq" data-do="keep">${t("Keep")}</button>` : `<button class="btnq" data-do="ask-unpair" data-value="${plain(p.id)}">${s.pairs.length > 1 ? b("Disconnect {0}", p.name) : t("Disconnect")}</button>`);
	return switchRow(true, say(s.role === "host" ? "On: paired computers may start work here. Off: every one of them is refused at once." : "On: new members start where you choose below.")) + (cannotHost(c) ? noHostBox(c) : "") + (s.role === "host" ? `<div class="lbl">${t("Paired computers")}</div>` : "") + s.pairs.map((p) => pairLine(p, c) + (p.state === "ready" && s.role === "desk" ? checksHtml(c.checks[p.id], p, c.locale) : "")).join("") + place + stays(s.role === "desk" ? "Stays here: the director, your own blocks, deployment." : "Stays on the desk Mac: the director, your own blocks, deployment.") + `<div class="row-btns">${s.role === "desk" ? `<button class="btn2" data-do="check">${t("Check again")}</button>` : ""}${ends.join("")}</div>`;
}
function home(c) {
	const s = c.state;
	if (!s.enabled) return switchRow(false, say("Off: the window works as before, nothing is started or opened.")) + `<p class="small">${t("This module must be installed on the second Mac too. Without it, remote work will not switch on there.")}</p>`;
	if (!s.pairs.length) return switchRow(true, say("On, but the second computer is not paired yet — everything still happens here, as before.")) + `<div class="lbl">${t("What kind of Mac this is")}</div>${seg(s.role)}` + (cannotHost(c) ? noHostBox(c) : `<button class="btn1" data-do="pair"${c.busy ? " disabled" : ""}>${label(c, "pair", "Pair with another computer")}</button>`) + stays("Stays on the desk Mac: the director, your own blocks, deployment.");
	return paired(c);
}
function flow(c, f) {
	const head = `<h3>${t("Pair with another computer")}</h3>`;
	switch (f.at) {
		case "desk-paste": return head + `<div class="lbl first">${t("Paste the text from the workshop")}</div><textarea class="blob mono field" data-field="paste" rows="5" spellcheck="false" autocomplete="off" autocapitalize="off"></textarea><p class="small">${t("The workshop makes this text: on the second Mac choose “Workshop” and press “Pair with another computer”.")}</p><div class="row-btns"><button class="btn2 ok" data-do="accept"${c.busy ? " disabled" : ""}>${label(c, "accept", "Continue")}</button><button class="btnq" data-do="back">${t("Back")}</button></div>`;
		case "desk-words": return head + `<div class="lbl first">${t("Check words")}</div>${wordsHtml(f.words)}` + (f.me ? `<p class="small">${b("On the workshop, this Mac will be listed as «{0}».", f.me)}</p>` : "") + `<p class="small after">${t("Compare the six words with the workshop's screen.")} ${t("If they differ, do not confirm: somebody changed a text on the way.")}</p>` + matchBtns(c);
		case "paired": {
			const p = c.state.pairs.find((x) => x.id === f.pair);
			return head + `<div class="state-line big"><span class="dot ok"></span><b>${t("Paired")}</b></div>` + (p && c.state.role === "host" ? `<p class="small"><b>${b("Paired with {0}", p.name)}</b>. ${t("If you do not know this Mac, press “Disconnect” for it.")}</p>` : "") + (p && c.state.role === "desk" ? checksHtml(c.checks[p.id], p, c.locale) : "") + `<div class="row-btns"><button class="btn2 ok" data-do="back">${t("Continue")}</button></div>`;
		}
		case "host-invite": return head + `<p class="small">${t("This Mac is the workshop. Copy the text below. On the Mac you write at, choose “My desk”, press “Pair with another computer” and paste it there. The text works for 10 minutes, once.")}</p><div class="lbl">${t("Text to copy")}</div><div class="blob mono" data-blob>${lines(f.text)}</div><div class="row-btns">${copyBtn(c)}<button class="btnq" data-do="invite"${c.busy ? " disabled" : ""}>${label(c, "invite", "Make a new one")}</button></div><div class="lbl">${t("Check words")}</div>${wordsHtml(f.words)}<p class="small after">${t("The desk Mac shows the same six words once the text is pasted there. Compare them; they are confirmed there, not here.")}</p><div class="state-line"><span class="dot wait"></span><b>${t("Waiting for the desk Mac…")}</b><span class="m" data-timer>${b("{0} left", left(f.expires, c.now))}</span></div><div class="row-btns tight"><button class="btnq" data-do="back">${t("Back")}</button></div><div class="set apart"><div class="t"><b>${t("Open vobuda when I log in")}</b><span>${t("vobuda will open on its own when this Mac starts, so the workshop is ready.")}</span></div><button class="sw${c.state.login ? " on" : ""}" role="switch" aria-checked="${c.state.login}" aria-label="${t("Open vobuda when I log in")}" data-do="login" data-value="${c.state.login ? "false" : "true"}"></button></div>`;
	}
}
/** The whole page for what the window said and what the person has done. */
function view(c) {
	if (!c.surface) return `<p class="small">${t("Remote work needs a newer vobuda. Update it to use this page.")}</p>`;
	const boxed = c.note?.class === "pairing" && c.note.why === "nologin" && c.flow.at === "home" && cannotHost(c);
	return `<div class="pp">${c.note && !boxed ? reasonHtml(c.note, say("this Mac"), null, c.locale, stampHtml(c.noteAt, c.tries, c.locale)) : ""}${c.flow.at === "home" ? home(c) : flow(c, c.flow)}</div>`;
}
//#endregion
//#region plugins/remote/remote.ts
/** The surface, read without declaring it on `window` for every plugin at once. */
var surface = () => {
	const api = window.vobuda;
	return api && VERBS.every((v) => typeof api[v] === "function") ? api : void 0;
};
/** How long the page waits for one verb before it says the window did not answer: the page is never held for good. */
var CALL_BOUND_MS = 3e4;
/** A verb's answer that says no: a thrown thing, or an object with an error. */
var refusal = (answer) => {
	const o = answer && typeof answer === "object" ? answer : {};
	if (o.ok === false || o.error) return reasonOf(o.error ?? o) ?? {
		class: "refused",
		words: ""
	};
	return null;
};
var rec = (v) => v && typeof v === "object" ? v : {};
/** Draw the panel into `root` and keep it drawn. */
async function mount(root, api = surface(), opts = {}) {
	const now = opts.now ?? Date.now;
	let state = null;
	let flow = { at: "home" };
	let note = null;
	let busy = false;
	/** What was pressed, while `busy`. */
	let pressing = "";
	/** When the note was said, the failure it is, and how many times running it came (FM-REMOTE-3503). */
	let noteAt = null;
	let lastFail = "";
	let tries = 0;
	/** When «Проверить снова» last asked the state. */
	let checkedAt = null;
	let asking = null;
	let copied = "";
	const checks = {};
	const checkSeq = {};
	/** Counts the endings of a pairing: an answer that comes back after one is not drawn. */
	let gen = 0;
	const ready = /* @__PURE__ */ new Map();
	let timer = null;
	const stops = [];
	const ctx = () => ({
		state,
		flow,
		checks,
		now: now(),
		locale: opts.locale,
		note,
		busy,
		pressing,
		noteAt,
		tries,
		checkedAt,
		asking,
		copied,
		surface: !!api
	});
	/**
	* Say a failure: the note, when it was said, and the attempt when the same failure comes again, so a second press
	* that fails the same way reads as a new attempt and not as nothing happening (FM-REMOTE-3503).
	*/
	function tell(r) {
		const key = `${r.class}/${r.why ?? ""}/${r.words ?? ""}`;
		tries = key === lastFail ? tries + 1 : 1;
		lastFail = key;
		note = r;
		noteAt = now();
	}
	/** Nothing of a failure before is true any more: the note, its count and the box's last look go (FM-REMOTE-3502). */
	function forget() {
		note = null;
		noteAt = null;
		lastFail = "";
		tries = 0;
		checkedAt = null;
	}
	function draw() {
		if (api && !state) {
			root.innerHTML = note ? `<div class="pp">${reasonHtml(note, say("this Mac"), null, opts.locale, stampHtml(noteAt, tries, opts.locale))}</div>` : "";
			return;
		}
		const held = document.activeElement;
		const spot = held && root.contains(held) && held.dataset.do ? {
			d: held.dataset.do,
			v: held.dataset.value
		} : null;
		const field = root.querySelector("[data-field]");
		const kept = field && {
			value: field.value,
			focus: document.activeElement === field,
			from: field.selectionStart,
			to: field.selectionEnd
		};
		root.innerHTML = view(ctx());
		if (spot) root.querySelector(`[data-do="${spot.d}"]${spot.v === void 0 ? "" : `[data-value="${spot.v}"]`}`)?.focus();
		const again = root.querySelector("[data-field]");
		if (kept && again) {
			again.value = kept.value;
			if (kept.focus) again.focus();
			try {
				if (kept.from !== null && kept.to !== null) again.setSelectionRange(kept.from, kept.to);
			} catch {}
		}
	}
	/** Something went wrong: say it in the table's words, over the page. */
	function fail(err) {
		tell(reasonOf(err) ?? {
			class: "refused",
			words: String(err)
		});
		busy = false;
		pressing = "";
		api?.log?.(`remote: ${note.class}`);
		draw();
	}
	async function askCheck(pair) {
		const seq = checkSeq[pair] = (checkSeq[pair] ?? 0) + 1;
		checks[pair] = "loading";
		draw();
		let items;
		try {
			const answer = await api.remoteCheck(pair);
			const bad = refusal(answer);
			items = bad ? [{
				item: "reach",
				ok: false,
				words: bad.words ?? "",
				reason: bad
			}] : checksOf(answer);
		} catch (err) {
			items = [{
				item: "reach",
				ok: false,
				words: "",
				reason: reasonOf(err)
			}];
		}
		if (checkSeq[pair] !== seq || !state?.pairs.some((p) => p.id === pair)) return;
		checks[pair] = items;
		draw();
	}
	/** A new state: drawn, and Check asked for each pair that has just become ready. */
	function take(raw) {
		const next = stateOf(raw);
		if (!next) return fail({
			class: "refused",
			words: ""
		});
		const was = state;
		state = next;
		const changed = !!was && (was.role !== next.role || was.enabled !== next.enabled);
		if (!next.enabled || changed) {
			if (flow.at !== "home") {
				endPairing();
				flow = { at: "home" };
			}
			for (const id of Object.keys(checks)) delete checks[id];
			ready.clear();
		}
		if (changed) {
			forget();
			asking = null;
			copied = "";
		}
		if (flow.at === "host-invite") {
			const before = flow.before;
			const made = next.pairs.find((p) => !before.includes(p.id));
			if (made) {
				gen++;
				flow = {
					at: "paired",
					pair: made.id
				};
			}
		}
		const asks = [];
		for (const p of next.pairs) {
			const isReady = p.state === "ready";
			if (isReady && next.enabled && next.role === "desk" && (!ready.get(p.id) || checks[p.id] === void 0)) asks.push(p.id);
			ready.set(p.id, isReady);
		}
		for (const id of [...ready.keys()]) if (!next.pairs.some((p) => p.id === id)) ready.delete(id), delete checks[id];
		draw();
		for (const id of asks) askCheck(id);
	}
	async function refresh() {
		try {
			take(await api.remoteState());
		} catch (err) {
			fail(err);
		}
	}
	/** A verb of the window, awaited with the page held still; its refusal is said and nothing else happens. */
	async function call(run, then, what = "") {
		busy = true;
		pressing = what;
		note = null;
		draw();
		let bound;
		try {
			const answer = await Promise.race([run(), new Promise((_, no) => bound = setTimeout(() => no({ class: "timeout" }), CALL_BOUND_MS))]);
			clearTimeout(bound);
			const bad = refusal(answer);
			busy = false;
			pressing = "";
			if (bad) {
				tell(bad);
				draw();
				return;
			}
			lastFail = "";
			tries = 0;
			return then(rec(answer));
		} catch (err) {
			clearTimeout(bound);
			fail(err);
			return;
		}
	}
	/** The token of a pairing that is under way, on whichever screen holds it. */
	const tokenNow = () => flow.at === "desk-words" || flow.at === "host-invite" ? flow.token : null;
	/**
	* A pairing ended by anything but «Слова совпадают»: the window is told so, `match: false`, and nothing
	* is written on either side. The page never sends `true` on its own (FM-REMOTE-1301).
	*/
	function endPairing() {
		gen++;
		const token = tokenNow();
		if (!token || !api) return;
		try {
			Promise.resolve(api.remotePairConfirm(token, false)).catch(() => void 0);
		} catch {}
	}
	/** A pairing the page itself ended, said by the reason's word of the contract's table (FM-REMOTE-3500). */
	const pairingWhy = (why) => ({
		class: "pairing",
		why
	});
	/** A new invite; `what` is the button pressed for it, «Связать» or «Сделать новый», which reads «Минутку…» meanwhile. */
	async function invite(what) {
		endPairing();
		await call(() => api.remotePairInvite(), (a) => {
			const text = cleanLines(a.text);
			const words = wordsOf(a.words);
			const before = (state?.pairs ?? []).map((p) => p.id);
			if (typeof a.token === "string" && text && words.length === 6) flow = {
				at: "host-invite",
				token: a.token,
				text,
				expires: when(a.expires) ?? now() + 6e5,
				words,
				before
			};
			else tell(pairingWhy("failed"));
			draw();
		}, what);
	}
	const pasted = () => root.querySelector("[data-field]")?.value ?? "";
	async function act(what, value) {
		if (!api || busy) return;
		if (what !== "copy") copied = "";
		switch (what) {
			case "enable":
				await call(() => api.remoteSet("remote.enabled", value === "true"), () => void 0);
				flow = { at: "home" };
				return refresh();
			case "role":
				await call(() => api.remoteSet("remote.role", value === "host" ? "host" : "desk"), () => void 0);
				return refresh();
			case "place":
				await call(() => api.remoteSet("remote.place", clean(value, 16)), () => void 0);
				return refresh();
			case "login":
				await call(() => api.remoteSet("remote.login", value === "true"), () => void 0);
				return refresh();
			case "pair":
				note = null;
				if (state?.role === "host") return invite("pair");
				forget();
				flow = { at: "desk-paste" };
				return draw();
			case "invite": return invite("invite");
			case "back":
				endPairing();
				flow = { at: "home" };
				forget();
				return draw();
			case "recheck":
				busy = true;
				pressing = "recheck";
				forget();
				draw();
				await refresh();
				busy = false;
				pressing = "";
				checkedAt = now();
				return draw();
			case "accept": {
				const text = pasted();
				if (!text.trim()) return;
				const g = gen;
				await call(() => api.remotePairAccept(text), (a) => {
					if (g !== gen) return;
					const words = wordsOf(a.words);
					if (typeof a.token !== "string" || words.length !== 6) tell(pairingWhy("failed"));
					else flow = {
						at: "desk-words",
						token: a.token,
						words,
						me: clean(a.me, 60)
					};
					draw();
				}, "accept");
				return;
			}
			case "match": {
				if (flow.at !== "desk-words") return;
				const token = flow.token;
				const match = value === "true";
				await call(() => api.remotePairConfirm(token, match), (a) => {
					if (match && a.paired === true) {
						flow = {
							at: "paired",
							pair: clean(a.pair, 16)
						};
						draw();
						return refresh();
					}
					flow = { at: "home" };
					tell(match ? reasonOf(a.reason ?? a.error) ?? pairingWhy("failed") : pairingWhy("differ"));
					draw();
				}, "match");
				if (flow.at === "desk-words" && note?.class === "pairing" && note.why !== "noworkshop") {
					gen++;
					flow = { at: "home" };
					draw();
				}
				return;
			}
			case "check":
				for (const p of state?.pairs ?? []) askCheck(p.id);
				return;
			case "ask-unpair":
				asking = clean(value, 16);
				return draw();
			case "keep":
				asking = null;
				return draw();
			case "unpair":
				await call(() => api.remoteUnpair(value), () => {
					asking = null;
					flow = { at: "home" };
				});
				return refresh();
			case "copy": {
				const text = flow.at === "host-invite" ? flow.text : "";
				if (!text) return;
				try {
					await navigator.clipboard.writeText(text);
					copied = "copied";
				} catch {
					const blob = root.querySelector("[data-blob]");
					if (blob) {
						const range = document.createRange();
						range.selectNodeContents(blob);
						const sel = window.getSelection();
						sel?.removeAllRanges();
						sel?.addRange(range);
					}
					copied = "selected";
				}
				return draw();
			}
		}
	}
	const onClick = (e) => {
		const el = e.target?.closest("[data-do]");
		if (!el || el.disabled) return;
		act(el.dataset.do, el.dataset.value ?? "");
	};
	root.addEventListener("click", onClick);
	stops.push(() => root.removeEventListener("click", onClick));
	timer = setInterval(() => {
		if (flow.at === "host-invite" && now() >= flow.expires) {
			endPairing();
			flow = { at: "home" };
			tell(pairingWhy("expired"));
			draw();
			return;
		}
		const el = root.querySelector("[data-timer]");
		if (el && flow.at === "host-invite") el.textContent = saying("{0} left", left(flow.expires, now()));
	}, 1e3);
	stops.push(() => timer && clearInterval(timer));
	const onHide = () => endPairing();
	window.addEventListener("pagehide", onHide);
	stops.push(() => window.removeEventListener("pagehide", onHide));
	const onShown = () => {
		if (document.visibilityState !== "visible" || !api || !state) return;
		if (!busy) forget();
		refresh();
	};
	document.addEventListener("visibilitychange", onShown);
	stops.push(() => document.removeEventListener("visibilitychange", onShown));
	const code = (opts.locale ?? api?.language ?? (typeof navigator !== "undefined" ? navigator.language : "") ?? "en").split(/[-_]/)[0] || "en";
	await loadWords(code, opts.get).catch(() => void 0);
	document.documentElement.lang = code;
	if (!api) {
		draw();
		return { stop: () => stops.forEach((s) => s()) };
	}
	try {
		const paintFrom = (tokens) => paint(document.documentElement, tokens);
		paintFrom(await api.tokens?.() ?? {});
		api.onTokens?.(paintFrom);
	} catch {}
	api.onRemoteState((raw) => take(raw));
	await refresh();
	return { stop: () => stops.forEach((s) => s()) };
}
if (typeof document !== "undefined" && document.getElementById("remote")) mount(document.getElementById("remote"));
//#endregion
