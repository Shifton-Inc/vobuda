// The deeper pass: the pages the base pass opened, opened again in a headless browser at a
// phone's size. Only with a browser already on the machine — the one Playwright keeps in its
// cache — and nothing is ever downloaded or installed for it (FM-SWARM-86). No window: the
// headless shell has none. Driven from plain Node over a pipe of its own, with no library and no
// port open on the machine; a browser whose pipe closes ends itself, so none outlives the probe
// however the probe ends (FM-SWARM-124).
//
// The browser reads and never writes (FM-SWARM-84): every request that is not a GET is refused
// before it leaves, counters of visitors are not asked, and of buttons only those outside any
// form whose words promise nothing are pressed. It opens no socket and runs no worker of any kind,
// a press may not lead to a link the base pass would not open, and every connection it makes is
// made for it by the probe, through the same wall as the base pass (FM-SWARM-123).

import { spawn } from "node:child_process";
import { mkdtempSync, readdirSync, rmSync, statSync } from "node:fs";
import http from "node:http";
import { connect as dial } from "node:net";
import { homedir, tmpdir } from "node:os";
import { join } from "node:path";
import { PRIVATE } from "./net.mjs";
import { ACTION, DANGER, LIMITS, QUIET, TOKEN, bare, countsVisitors, fact, loopback, siteKey, tier } from "./rules.mjs";

const sleep = (ms) => new Promise((done) => setTimeout(done, ms));
const list = (dir) => {
  try {
    return readdirSync(dir);
  } catch {
    return [];
  }
};

/** The newest headless shell in Playwright's cache; null where there is none. */
export function findBrowser(env = process.env) {
  const roots = env.PLAYWRIGHT_BROWSERS_PATH ? [env.PLAYWRIGHT_BROWSERS_PATH] : [join(homedir(), "Library", "Caches", "ms-playwright"), join(homedir(), ".cache", "ms-playwright"), env.LOCALAPPDATA && join(env.LOCALAPPDATA, "ms-playwright")].filter(Boolean);
  for (const root of roots) {
    const builds = list(root)
      .filter((d) => /^chromium_headless_shell-\d+$/.test(d))
      .sort((a, b) => Number(b.split("-")[1]) - Number(a.split("-")[1]));
    for (const build of builds)
      for (const folder of list(join(root, build)))
        for (const name of ["chrome-headless-shell", "headless_shell", "chrome-headless-shell.exe"]) {
          const path = join(root, build, folder, name);
          try {
            if (statSync(path).isFile()) return path;
          } catch {
            // Not this one.
          }
        }
  }
  return null;
}

/**
 * The one door the browser has to the network: a proxy on this machine that the probe itself
 * keeps. The browser looks up no name and opens no connection of its own — it asks here, and the
 * connection is made through the run's wall, to the very address the wall judged. So a script, a
 * style sheet, a socket or a worker's request can reach nothing the base pass could not, and a
 * name cannot come to mean another address between the judging and the asking (FM-SWARM-123).
 * `refused` is told every host turned away. Plain requests that are not a GET are turned away
 * here a second time; of a secure connection only where it goes can be seen.
 */
function door(through, open, refused) {
  const side = through.side(open);
  const no = (host) => through.refuses(host, open) || (!open && loopback(host));
  const server = http.createServer((req, res) => {
    let u = null;
    try {
      u = new URL(req.url);
    } catch {
      // Not asked as a proxy is asked.
    }
    if (!u || u.protocol !== "http:" || (req.method !== "GET" && req.method !== "HEAD")) return void res.writeHead(403).end();
    if (no(u.hostname)) return void (refused(u.hostname), res.writeHead(403).end());
    const headers = { ...req.headers };
    for (const h of ["proxy-connection", "proxy-authorization", "connection", "keep-alive"]) delete headers[h];
    const out = http.request({ host: bare(u.hostname), port: u.port || 80, method: req.method, path: u.pathname + u.search, headers, lookup: side.lookup, agent: false }, (r) => {
      const back = { ...r.headers };
      for (const h of ["connection", "keep-alive", "transfer-encoding"]) delete back[h];
      res.writeHead(r.statusCode, back);
      r.pipe(res);
      r.on("error", () => res.destroy());
    });
    out.on("error", (e) => {
      if (e?.code === "EPRIVATE") refused(u.hostname);
      if (res.headersSent) res.destroy();
      else res.writeHead(e?.code === "EPRIVATE" ? 403 : 502).end();
    });
    res.on("close", () => out.destroy());
    out.end();
  });
  server.on("connect", (req, client, head) => {
    const m = /^\[?([^\]]*?)\]?:(\d+)$/.exec(req.url ?? "");
    client.on("error", () => {});
    if (!m) return void client.end("HTTP/1.1 400 Bad Request\r\n\r\n");
    if (no(m[1])) return void (refused(m[1]), client.end("HTTP/1.1 403 Forbidden\r\n\r\n"));
    const up = dial({ host: m[1], port: Number(m[2]), lookup: side.lookup });
    let joined = false;
    up.on("connect", () => {
      joined = true;
      client.write("HTTP/1.1 200 Connection Established\r\n\r\n");
      if (head.length) up.write(head);
      up.pipe(client);
      client.pipe(up);
    });
    up.on("error", (e) => {
      if (e?.code === "EPRIVATE") refused(m[1]);
      if (!joined && client.writable) client.end(`HTTP/1.1 ${e?.code === "EPRIVATE" ? "403 Forbidden" : "502 Bad Gateway"}\r\n\r\n`);
      else client.destroy();
    });
    client.on("close", () => up.destroy());
  });
  server.on("clientError", (_e, socket) => socket.destroy());
  return new Promise((ok, no) => {
    server.once("error", no);
    server.listen(0, "127.0.0.1", () => ok({ port: server.address().port, close: () => (server.closeAllConnections?.(), server.close()) }));
  });
}

/** The longest any one word to the browser is waited for: a page that never lets go of its own thread answers none. */
const WORD_MS = 30_000;

async function connect(shell, { through, open, refused, deadline }) {
  const way = await door(through, open, refused);
  const profile = mkdtempSync(join(tmpdir(), "swarm-probe-"));
  const child = spawn(
    shell,
    ["--remote-debugging-pipe", `--user-data-dir=${profile}`, `--proxy-server=http://127.0.0.1:${way.port}`, "--proxy-bypass-list=<-loopback>", "--no-first-run", "--no-default-browser-check", "--disable-background-networking", "--disable-component-update", "--disable-sync", "--mute-audio", "--hide-scrollbars", "about:blank"],
    { stdio: ["ignore", "ignore", "ignore", "pipe", "pipe"] },
  );
  const [, , , toBrowser, fromBrowser] = child.stdio;
  let ended = false;
  const end = () => {
    if (ended) return;
    ended = true;
    process.off("exit", end);
    way.close();
    toBrowser.destroy();
    // The probe's own child and nothing else.
    child.kill();
    try {
      rmSync(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 100 });
    } catch {
      // A profile left in the temporary folder harms nothing.
    }
  };
  // The probe told to end — by its own word or by a signal it hears — takes its browser with it.
  process.on("exit", end);
  try {
    let id = 0;
    let gone = null;
    const waiting = new Map();
    const heard = new Map();
    let kept = [];
    const take = (text) => {
      const d = JSON.parse(text);
      if (!d.id) return void (d.sessionId === session && heard.get(d.method)?.(d.params));
      const w = waiting.get(d.id);
      waiting.delete(d.id);
      if (w) (clearTimeout(w.timer), d.error ? w.no(new Error(d.error.message)) : w.ok(d.result));
    };
    // One message ends with a zero byte.
    fromBrowser.on("data", (chunk) => {
      for (let from = 0; ; ) {
        const zero = chunk.indexOf(0, from);
        if (zero < 0) {
          kept.push(chunk.subarray(from));
          break;
        }
        kept.push(chunk.subarray(from, zero));
        const text = Buffer.concat(kept).toString("utf8");
        kept = [];
        from = zero + 1;
        try {
          take(text);
        } catch {
          // A message that cannot be read is nobody's answer.
        }
      }
    });
    const lost = (why) => {
      gone ??= why;
      for (const w of waiting.values()) (clearTimeout(w.timer), w.no(new Error(gone)));
      waiting.clear();
    };
    fromBrowser.on("close", () => lost("the headless browser went away"));
    toBrowser.on("error", () => lost("the headless browser went away"));
    child.on("error", () => lost("the headless browser did not come up"));
    child.on("exit", () => lost("the headless browser went away"));
    let session;
    const word = (method, params, sessionId) =>
      new Promise((ok, no) => {
        if (gone) return no(new Error(gone));
        const most = Math.min(WORD_MS, deadline - Date.now());
        if (most <= 0) return no(new Error("the time was up"));
        const n = ++id;
        const timer = setTimeout(() => (waiting.delete(n), no(new Error(most < WORD_MS ? "the time was up" : "a page did not let the browser answer"))), most);
        waiting.set(n, { ok, no, timer });
        toBrowser.write(`${JSON.stringify({ id: n, method, params, ...(sessionId ? { sessionId } : {}) })}\0`);
      });
    const found = (await word("Target.getTargets", {})).targetInfos.find((t) => t.type === "page");
    const targetId = found?.targetId ?? (await word("Target.createTarget", { url: "about:blank" })).targetId;
    session = (await word("Target.attachToTarget", { targetId, flatten: true })).sessionId;
    // What is said of the whole browser goes to it; everything else to the one page.
    const send = (method, params = {}) => word(method, params, /^(Browser|Target)\./.test(method) ? undefined : session);
    return { send, on: (name, fn) => heard.set(name, fn), close: end };
  } catch (e) {
    end();
    throw e;
  }
}

// Put into every page before its own scripts: what a press can do that changes nothing one can
// see in the page's tree — a copy, a new window, a sound — is marked, so that a button that
// works is never said to do nothing; and long tasks are kept for the time until the page can be used.
const WATCH = `(() => {
  const w = (window.__probeWatch = { did: [], long: [], shut: 0 });
  const mark = (obj, name, tag, instead) => {
    try {
      const f = obj && obj[name];
      if (typeof f !== "function") return;
      obj[name] = function (...a) { w.did.push(tag); return instead ? instead() : f.apply(this, a); };
    } catch {}
  };
  mark(window, "open", "opens a window", () => null);
  mark(window, "print", "prints", () => undefined);
  mark(window, "scrollTo", "scrolls"); mark(window, "scrollBy", "scrolls"); mark(window, "scroll", "scrolls");
  mark(Element.prototype, "scrollIntoView", "scrolls");
  mark(Element.prototype, "requestFullscreen", "goes full screen");
  mark(history, "pushState", "changes the address"); mark(history, "replaceState", "changes the address");
  mark(Storage.prototype, "setItem", "remembers something"); mark(Storage.prototype, "removeItem", "remembers something");
  mark(document, "execCommand", "copies");
  try { mark(Object.getPrototypeOf(navigator.clipboard), "writeText", "copies"); mark(Object.getPrototypeOf(navigator.clipboard), "write", "copies"); } catch {}
  mark(navigator, "share", "shares", () => Promise.resolve());
  mark(HTMLMediaElement.prototype, "play", "plays"); mark(HTMLMediaElement.prototype, "pause", "plays");
  for (const e of ["toggle", "beforetoggle"]) document.addEventListener(e, () => w.did.push("opens something"), true);
  // A socket carries words both ways and no rule can read them; a worker of any kind asks the network where the rules for the page's own requests do not see it. None is given to the page; what it then misses is not its fault.
  const shut = (what) => { w.shut++; w.did.push(what); };
  try {
    if (window.WebSocket) {
      const Shut = class WebSocket extends EventTarget {
        constructor(url) {
          super(); shut("opens a socket");
          this.url = String(url); this.readyState = 3; this.protocol = ""; this.extensions = ""; this.bufferedAmount = 0; this.binaryType = "blob";
          this.onopen = this.onmessage = this.onerror = this.onclose = null;
          setTimeout(() => { for (const t of ["error", "close"]) { const e = new Event(t); try { this.dispatchEvent(e); if (typeof this["on" + t] === "function") this["on" + t](e); } catch {} } }, 0);
        }
        send() {} close() {}
      };
      for (const [k, v] of [["CONNECTING", 0], ["OPEN", 1], ["CLOSING", 2], ["CLOSED", 3]]) { Shut[k] = v; Shut.prototype[k] = v; }
      window.WebSocket = Shut;
    }
    window.WebTransport = undefined;
  } catch {}
  try {
    for (const name of ["Worker", "SharedWorker"]) {
      if (!window[name]) continue;
      const Still = { [name]: class extends EventTarget {
        constructor() { super(); shut("runs a worker"); this.onmessage = this.onerror = this.onmessageerror = null; if (name === "SharedWorker") this.port = { postMessage() {}, start() {}, close() {}, addEventListener() {}, removeEventListener() {}, onmessage: null }; }
        postMessage() {} terminate() {}
      } }[name];
      window[name] = Still;
    }
  } catch {}
  try {
    const keeper = navigator.serviceWorker && Object.getPrototypeOf(navigator.serviceWorker);
    if (keeper) keeper.register = function () { shut("keeps a worker"); return Promise.reject(new DOMException("a check keeps no service worker", "SecurityError")); };
  } catch {}
  try { new PerformanceObserver((l) => { for (const e of l.getEntries()) w.long.push(e.startTime + e.duration); }).observe({ type: "longtask", buffered: true }); } catch {}
})()`;

const HELPERS = `
  const sel = (e, deep = 0) => {
    if (e.id) return "#" + CSS.escape(e.id);
    let s = e.tagName.toLowerCase() + [...e.classList].slice(0, 2).map((c) => "." + CSS.escape(c)).join("");
    const p = e.parentElement;
    if (!p || p === document.documentElement) return s;
    const kin = [...p.children].filter((x) => x.tagName === e.tagName);
    if (kin.length > 1) s += ":nth-of-type(" + (kin.indexOf(e) + 1) + ")";
    return p === document.body || deep > 2 ? s : sel(p, deep + 1) + " > " + s;
  };
  const seen = (e) => { const r = e.getBoundingClientRect(); const c = getComputedStyle(e); return r.width > 1 && r.height > 1 && c.visibility !== "hidden" && c.display !== "none" && Number(c.opacity) > 0; };
  const look = () => { let h = 0, n = 0; for (const e of document.body.querySelectorAll("*")) { if (++n > 4000) break; const r = e.getBoundingClientRect(); const c = getComputedStyle(e); const s = [Math.round(r.left), Math.round(r.top), Math.round(r.width), Math.round(r.height), c.visibility, c.opacity, c.display].join(); for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0; } return h; };
`;

/** What the page is at a phone's size: its width, its small letters, the time until it could be used, its buttons. */
const MEASURE = `(() => {${HELPERS}
  // The width the page is laid out for: a phone's where the page has a line for phones, a desk's where it has none.
  const out = { inner: document.documentElement.clientWidth, width: Math.max(document.documentElement.scrollWidth, document.body ? document.body.scrollWidth : 0), wideWhere: [], small: 0, letters: 0, smallWhere: [], buttons: [], danger: 0, shut: window.__probeWatch.shut };
  // A page with no line for phones is laid out for a wide screen and shrunk: its letters are smaller than their styles say.
  const shrink = Math.min(1, ${LIMITS.phone} / out.inner);
  if (out.width > out.inner + 1)
    for (const e of document.body.querySelectorAll("*")) {
      if (out.wideWhere.length >= 3) break;
      const r = e.getBoundingClientRect();
      if (r.width <= 0 || r.right <= out.inner + 1 || !seen(e)) continue;
      let clipped = false;
      for (let p = e.parentElement; p && p !== document.body; p = p.parentElement) if (getComputedStyle(p).overflowX !== "visible") clipped = true;
      if (!clipped && !(e.parentElement && e.parentElement !== document.body && e.parentElement.getBoundingClientRect().right > out.inner + 1)) out.wideWhere.push(sel(e) + " (reaches " + Math.round(r.right) + ")");
    }
  const walk = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  const smallOnes = new Set();
  for (let n; (n = walk.nextNode()); ) {
    const text = n.textContent.trim();
    const e = n.parentElement;
    if (text.length < 3 || !e || ["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE", "OPTION"].includes(e.tagName) || !seen(e)) continue;
    out.letters += text.length;
    if (parseFloat(getComputedStyle(e).fontSize) * shrink < ${LIMITS.smallText} - 0.01) { out.small += text.length; smallOnes.add(e); }
  }
  out.smallWhere = [...smallOnes].slice(0, 3).map((e) => sel(e) + " (" + Math.round(parseFloat(getComputedStyle(e).fontSize) * shrink * 10) / 10 + " pt)");
  const nav = performance.getEntriesByType("navigation")[0];
  const paint = performance.getEntriesByName("first-contentful-paint")[0];
  out.usable = Math.round(Math.max(paint ? paint.startTime : 0, nav ? nav.domContentLoadedEventEnd : 0, ...window.__probeWatch.long));
  const danger = new RegExp(${JSON.stringify(DANGER.source)}, "i");
  window.__probeButtons = [];
  for (const b of document.querySelectorAll("button, [role=button], input[type=button]")) {
    if (!seen(b) || b.disabled || b.getAttribute("aria-disabled") === "true" || b.closest("form") || b.hasAttribute("form") || b.closest("a[href]") || b.tagName === "A") continue;
    const words = [b.textContent, b.value, b.getAttribute("aria-label"), b.title, b.id, b.getAttribute("name"), typeof b.className === "string" ? b.className : ""].filter(Boolean).join(" ");
    if (danger.test(words)) { out.danger++; continue; }
    window.__probeButtons.push(b);
    out.buttons.push({ where: sel(b), label: (b.textContent || b.value || b.getAttribute("aria-label") || "").trim().replace(/\\s+/g, " ").slice(0, 60) });
  }
  return JSON.stringify(out);
})()`;

const READY = (i) => `(async () => {${HELPERS}
  const b = window.__probeButtons && window.__probeButtons[${i}];
  if (!b || !b.isConnected) return JSON.stringify({ gone: true });
  b.scrollIntoView({ block: "center", inline: "center" });
  await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
  const r = b.getBoundingClientRect();
  const x = r.left + r.width / 2, y = r.top + r.height / 2;
  const hit = document.elementFromPoint(x, y);
  if (!hit || !(b === hit || b.contains(hit))) return JSON.stringify({ covered: true });
  window.__probeWatch.button = b;
  return JSON.stringify({ x, y });
})()`;

// Taken with the pointer already over the button: what the page does to a button merely pointed at is not a press.
const ARM = `(() => {${HELPERS}
  const w = window.__probeWatch;
  w.did = [];
  w.before = { url: location.href, x: scrollX, y: scrollY, focus: document.activeElement, look: look(), button: w.button };
  w.eye = new MutationObserver(() => w.did.push("changes the page"));
  w.eye.observe(document, { subtree: true, childList: true, attributes: true, characterData: true });
  return "true";
})()`;

const AFTER = `(() => {${HELPERS}
  const w = window.__probeWatch;
  if (!w || !w.before) return JSON.stringify({ did: ["goes to another page"] });
  w.eye.disconnect();
  const b = w.before;
  if (location.href !== b.url) w.did.push("changes the address");
  if (scrollX !== b.x || scrollY !== b.y) w.did.push("scrolls");
  if (document.activeElement !== b.focus && document.activeElement !== b.button) w.did.push("moves the focus");
  if (look() !== b.look) w.did.push("changes the look");
  return JSON.stringify({ did: [...new Set(w.did)], shut: w.shut });
})()`;

/** The pass over `urls`. `baseFacts` are the base pass's, so that a picture already said to be gone is not said twice. */
export async function browserPass(urls, { deadline, site, baseFacts = [], wall: through, open = false }) {
  const doubts = {};
  const doubt = (why, url) => {
    const d = (doubts[why] ??= { count: 0, first: [] });
    d.count++;
    if (d.first.length < 5) d.first.push(url);
  };
  const shell = findBrowser();
  if (!shell) return { ran: false, why: "no headless browser on this machine (Playwright's cache holds none); nothing was fetched for it", engine: null, pages: [], facts: [] };
  const facts = [];
  const pages = [];
  const flying = new Map();
  const ours = new Set();
  let cur = null;
  let frame = null;
  // A host behind the wall: not asked, said once as a doubt, and what the page then lacks is not its fault.
  const walled = new Set();
  const behindWall = (host) => {
    if (cur) cur.starved++;
    if (walled.has(bare(host))) return;
    walled.add(bare(host));
    doubt(PRIVATE, host);
  };
  const isWalled = (url) => {
    try {
      return walled.has(bare(new URL(url).hostname));
    } catch {
      return false;
    }
  };
  let cdp;
  try {
    cdp = await connect(shell, { through, open, refused: behindWall, deadline });
  } catch (e) {
    return { ran: false, why: String(e.message), engine: null, pages: [], facts: [] };
  }
  try {
    const version = await cdp.send("Browser.getVersion");
    for (const domain of ["Page", "Runtime", "Network", "Log"]) await cdp.send(`${domain}.enable`);
    frame = (await cdp.send("Page.getFrameTree")).frameTree.frame.id;
    await cdp.send("Emulation.setDeviceMetricsOverride", { width: LIMITS.phone, height: LIMITS.phoneHeight, deviceScaleFactor: 2, mobile: true });
    await cdp.send("Emulation.setUserAgentOverride", { userAgent: `Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1 ${TOKEN}/1` });
    await cdp.send("Browser.setDownloadBehavior", { behavior: "deny" }).catch(() => {});
    await cdp.send("Page.addScriptToEvaluateOnNewDocument", { source: WATCH });
    await cdp.send("Fetch.enable", { patterns: [{ urlPattern: "*" }] });
    // What a page asks for passes the rules below, never a worker that would answer in their place.
    await cdp.send("Network.setBypassServiceWorker", { bypass: true });

    // The pass is not a visit (FM-SWARM-91). Of a host that is not the site checked, only what a
    // page is drawn with is let through — style sheets, fonts, scripts, and pictures and films
    // with no question in their address — and none of it from a host that counts visitors, shows
    // advertisements or opens a chat, by the list or by its looks. What carries a visit — a
    // request for data, a ping, a frame, a picture with a question in its address — is refused.
    const DRAWN = new Set(["Stylesheet", "Font", "Script"]);
    const SEEN = new Set(["Image", "Media"]);
    const DATA = new Set(["XHR", "Fetch", "EventSource", "Other"]);
    cdp.on("Fetch.requestPaused", (p) => {
      const go = () => void cdp.send("Fetch.continueRequest", { requestId: p.requestId }).catch(() => {});
      const refuse = () => {
        if (p.networkId) ours.add(p.networkId);
        cdp.send("Fetch.failRequest", { requestId: p.requestId, errorReason: "BlockedByClient" }).catch(() => {});
      };
      let u = null;
      try {
        u = new URL(p.request.url);
      } catch {
        // Not an address of the web.
      }
      if (p.request.method !== "GET" && p.request.method !== "HEAD") {
        if (cur && !(u && siteKey(u) !== site && countsVisitors(u))) cur.held.push(`${p.request.method} ${p.request.url}`);
        return refuse();
      }
      if (!u || !/^https?:$/.test(u.protocol)) return go();
      if (siteKey(u) === site) {
        // A move a press leads to, or a request a script makes, to a link the base pass would never open: an action by its own words (FM-SWARM-123). What a page is drawn with is a file, whatever its name.
        if (cur && p.request.url !== cur.url && !DRAWN.has(p.resourceType) && !SEEN.has(p.resourceType) && ACTION.test(u.pathname + u.search)) {
          cur.held.push(`GET ${p.request.url}`);
          return refuse();
        }
        return go();
      }
      // Nothing on this machine or in its network, on no odd port, for a site that is elsewhere — the base pass's own rule; a name is judged at the door.
      if (through.refuses(u.hostname, open) || (!open && (loopback(u.hostname) || u.port))) {
        behindWall(u.hostname);
        return refuse();
      }
      if (countsVisitors(u)) {
        // Refused by its looks alone, a script may have been one the page stands on.
        if (cur && p.resourceType === "Script" && !QUIET.test(u.hostname)) cur.starved++;
        return refuse();
      }
      if (DRAWN.has(p.resourceType) || (SEEN.has(p.resourceType) && !u.search)) return go();
      // A page that asks another site for what it shows may then err or stand still because of this refusal, not by its own fault.
      if (cur && DATA.has(p.resourceType)) cur.starved++;
      refuse();
    });
    cdp.on("Network.requestWillBeSent", (p) => {
      flying.set(p.requestId, p.request.url);
      if (cur) (cur.requests++, (cur.lastNet = Date.now()));
    });
    cdp.on("Network.responseReceived", (p) => {
      if (cur && p.response.status >= 400 && !(p.type === "Document" && p.frameId === frame) && !isWalled(p.response.url)) cur.failed.push({ url: p.response.url, seen: `status ${p.response.status}` });
    });
    cdp.on("Network.loadingFinished", (p) => {
      flying.delete(p.requestId);
      if (cur) cur.lastNet = Date.now();
    });
    cdp.on("Network.loadingFailed", (p) => {
      const url = flying.get(p.requestId);
      flying.delete(p.requestId);
      if (!cur) return;
      cur.lastNet = Date.now();
      if (url && !p.canceled && !ours.has(p.requestId) && !isWalled(url) && !/BLOCKED_BY_CLIENT|ERR_ABORTED/.test(p.errorText ?? "") && !(p.type === "Document" && url === cur.url)) cur.failed.push({ url, seen: p.errorText || "failed" });
    });
    cdp.on("Runtime.exceptionThrown", (p) => {
      const d = p.exceptionDetails;
      cur?.errors.push({ text: (d.exception?.description ?? d.text ?? "an error").split("\n")[0].slice(0, 200), where: d.url ? `${d.url}:${d.lineNumber + 1}` : `line ${d.lineNumber + 1}` });
    });
    cdp.on("Runtime.consoleAPICalled", (p) => {
      if (p.type !== "error") return;
      const top = p.stackTrace?.callFrames?.[0];
      cur?.errors.push({ text: p.args.map((a) => a.value ?? a.description ?? "").join(" ").split("\n")[0].slice(0, 200), where: top?.url ? `${top.url}:${top.lineNumber + 1}` : "the console" });
    });
    cdp.on("Log.entryAdded", (p) => {
      // What the network could not load is told by the requests themselves.
      if (p.entry.level === "error" && p.entry.source !== "network") cur?.errors.push({ text: p.entry.text.split("\n")[0].slice(0, 200), where: p.entry.url ? `${p.entry.url}:${(p.entry.lineNumber ?? 0) + 1}` : "the console" });
    });
    cdp.on("Page.javascriptDialogOpening", () => {
      if (cur) cur.dialogs++;
      cdp.send("Page.handleJavaScriptDialog", { accept: false }).catch(() => {});
    });
    cdp.on("Page.loadEventFired", () => cur && (cur.loaded = true));
    cdp.on("Page.frameNavigated", (p) => cur && !p.frame.parentId && cur.navs++);
    cdp.on("Page.navigatedWithinDocument", () => cur && cur.navs++);

    const until = async (ready, most) => {
      for (const end = Math.min(Date.now() + most, deadline); Date.now() < end && !ready(); ) await sleep(50);
    };
    const value = async (expression) => {
      const r = await cdp.send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true });
      if (r.exceptionDetails) throw new Error(r.exceptionDetails.text);
      return JSON.parse(r.result.value);
    };
    async function open(url) {
      cur = { url, errors: [], failed: [], held: [], starved: starved(), requests: 0, dialogs: 0, navs: 0, loaded: false, lastNet: Date.now() };
      flying.clear();
      const nav = await cdp.send("Page.navigate", { url });
      if (nav.errorText) return false;
      await until(() => cur.loaded, 20000);
      await until(() => flying.size === 0 && Date.now() - cur.lastNet > 500, 10000);
      return cur.loaded;
    }

    // Kept over a page opened a second time after a press led away.
    let hungry = 0;
    const starved = () => (hungry += cur?.url === now ? cur.starved : 0);
    let now = null;
    for (const url of urls) {
      if (Date.now() >= deadline) break;
      hungry = 0;
      cur = null;
      now = url;
      if (!(await open(url))) {
        pages.push({ url, opened: false });
        continue;
      }
      const seenHere = cur;
      const m = await value(MEASURE);
      cur.starved += m.shut;
      const page = { url, opened: true, width: m.width, screen: LIMITS.phone, laidOutFor: m.inner, usableMs: m.usable, letters: m.letters, smallLetters: m.small, buttons: { found: m.buttons.length + m.danger, leftAlone: m.danger, pressed: 0, covered: 0 }, held: [] };
      pages.push(page);
      const STARVED = "the page asks another site for data, which the check refuses so as not to be a visit; its errors and silent buttons may come of that";
      const push = (kind, ...a) => ((kind === "consoleerror" || kind === "deadbutton") && cur.starved > 0 ? doubt(STARVED, url) : facts.push(fact(url, kind, ...a)));

      const texts = new Set();
      for (const e of seenHere.errors) {
        if (texts.has(e.text) || texts.size >= 5) continue;
        texts.add(e.text);
        push("consoleerror", e.where, e.text, {});
      }
      const gone = new Set(baseFacts.filter((f) => f.kind === "image").map((f) => f.data.target));
      const failed = new Set();
      for (const f of seenHere.failed) {
        if (failed.has(f.url) || gone.has(f.url) || failed.size >= 10) continue;
        failed.add(f.url);
        push("failedrequest", f.url, `${f.url}: ${f.seen}`, { target: f.url });
      }
      if (m.inner > LIMITS.phone + 1) push("wide", "head", `the page is laid out ${m.inner} points wide and shrunk to a ${LIMITS.phone}-point screen: it has no line for phones (meta viewport)`, { width: m.inner, screen: LIMITS.phone });
      else if (m.width > m.inner + 1) push("wide", m.wideWhere[0] ?? "html", `the page is ${m.width} points wide on a ${m.inner}-point screen`, { width: m.width, screen: m.inner, where: m.wideWhere });
      if (m.small > 0) push(m.small / m.letters >= LIMITS.smallShare ? "smalltext" : "somesmalltext", m.smallWhere[0], `${m.small} of ${m.letters} letters are under ${LIMITS.smallText} points`, { small: m.small, letters: m.letters, where: m.smallWhere });
      const use = tier(m.usable, LIMITS.usable, LIMITS.veryUsable, "slowuse", "veryslowuse");
      if (use) push(use, "the whole page", `it could be used after ${m.usable} ms`, { ms: m.usable });

      for (let i = 0; i < Math.min(m.buttons.length, 8) && Date.now() < deadline; i++) {
        const at = await value(READY(i)).catch(() => ({ gone: true }));
        if (at.gone) continue;
        if (at.covered) {
          page.buttons.covered++;
          continue;
        }
        await cdp.send("Input.dispatchMouseEvent", { type: "mouseMoved", x: at.x, y: at.y });
        await sleep(200);
        if (!(await value(ARM).catch(() => false))) continue;
        const before = { requests: cur.requests, dialogs: cur.dialogs, navs: cur.navs, held: cur.held.length };
        for (const type of ["mousePressed", "mouseReleased"]) await cdp.send("Input.dispatchMouseEvent", { type, x: at.x, y: at.y, button: "left", clickCount: 1 });
        await sleep(700);
        const after = await value(AFTER).catch(() => ({ did: ["goes to another page"] }));
        page.buttons.pressed++;
        const did = [...after.did];
        if (after.shut) cur.starved += after.shut;
        if (cur.requests > before.requests) did.push("asks the network");
        if (cur.dialogs > before.dialogs) did.push("opens a dialog");
        if (cur.navs > before.navs) did.push("goes to another page");
        page.held.push(...cur.held.slice(before.held));
        if (!did.length) push("deadbutton", m.buttons[i].where, `«${m.buttons[i].label}» was pressed and nothing happened`, { label: m.buttons[i].label });
        // A press that led away: the page is opened again, and its buttons found again in the same order.
        if (cur.navs > before.navs || did.includes("goes to another page")) {
          if (!(await open(url))) break;
          await value(MEASURE);
        }
      }
    }
    return { ran: true, why: null, engine: version.product, pages, facts, doubts };
  } catch (e) {
    return { ran: pages.length > 0, why: `the browser pass stopped: ${e.message}`, engine: null, pages, facts, doubts };
  } finally {
    cdp.close();
  }
}
