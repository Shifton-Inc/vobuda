// The base pass: a site walked from its start address by plain requests, and the facts of it.
// One request at a time, at a polite pace, by the rules the site gives robots; pages of the same
// site only; capped in pages and in time. A doubt is not a fact (FM-SWARM-81): what could not be
// asked, what answered "not for you", what the walk did not reach — counted apart, never stated.

import { formName, place, read } from "./html.mjs";
import { KEEP_OUT, NO_RULES, PRIVATE, ROBOTS_BYTES, TIME, parseRobots, parseSitemap } from "./plain.mjs";
import { ACTION, FILE, LIMITS, NO_ANSWER_INSIDE, QUIET, TOKEN, TONGUES, countsVisitors, deadInside, deadOutside, fact, folded, loopback, ownGround, siteKey as key, tier } from "./rules.mjs";

const sleep = (ms) => new Promise((done) => setTimeout(done, ms));
const norm = (href) => {
  const u = new URL(folded(href));
  return key(u) + u.pathname + u.search;
};
/** An address as written on a page, made whole; null where it is none. */
const abs = (href, base) => {
  try {
    return new URL(href, base);
  } catch {
    return null;
  }
};
const chainText = (f) => [...f.chain.map((c) => `${c.url} (${c.status})`), f.end].join(" → ");

export async function basePass(start, o) {
  const deadline = o.began + o.seconds * 1000;
  const left = () => Date.now() < deadline;
  // Only a start address the person wrote as this machine, or as an address of a private net,
  // opens the wall; a start that then leads to a site elsewhere shuts it again (FM-SWARM-121).
  let local = ownGround(start.hostname);
  // On the machine itself the pace is the caller's; anywhere else never under a fifth of a second.
  let paceMs = local ? o.pace : Math.max(o.pace, 200);
  const facts = [];
  const doubts = new Map();
  const doubt = (why, url) => {
    const d = doubts.get(why) ?? doubts.set(why, { count: 0, first: [] }).get(why);
    d.count++;
    if (d.first.length < 5) d.first.push(url);
  };
  let asked = 0;
  let site = null;
  /** Why an address was not asked for: its own words say that opening it does something. */
  const ACT = "a link that looks like an action is never opened";
  /** Why nothing is stated of a link out: it was asked for with HEAD alone. */
  const LIGHTLY = "a link to another site with a question in its address is asked for lightly only, and the light answer settled nothing";
  /** Why another site's address was not asked for at all, in a run that asks only the one it was given. */
  const ONLY_THE_SITE = "an address of another site: this check asks only the site it was given";
  /** A reason nothing is stated for, in the words the file keeps. */
  const said = (why) => (why === "robots" ? "the site's rules for robots keep it shut" : why === TIME ? "not asked for before the time was up" : why);

  // Every request of the walk leaves through here — by the one who asks for this run (`o.follow`:
  // the probe's own requests, or a panel's through the window) — with the run's wall, the run's
  // last moment, and the count of what was really sent — a step the wall refused was let through by the gate and
  // never made.
  async function follow(url, options, gate) {
    const f = await o.follow(url, { ...options, wall: o.wall, open: local, until: deadline }, gate);
    if (f.unsent) asked--;
    return f;
  }

  // A turn that would come after the run's last moment is not waited for: a site's rules may ask
  // for an hour between two requests, and the run still ends when it was told to (FM-SWARM-122).
  const due = new Map();
  async function pace(host, ms) {
    const now = Date.now();
    const at = Math.max(now, due.get(host) ?? 0);
    if (at >= deadline) return false;
    due.set(host, at + ms);
    if (at > now) await sleep(at - now);
    return true;
  }

  // The rules are another address of the web like any other: asked at the pace, not after the
  // time is up, and through the wall — wherever their redirects lead (FM-SWARM-121). Rules that
  // were not had because the time was up are nobody's fact, and are not kept.
  const robots = new Map();
  async function rulesOf(origin) {
    if (robots.has(origin)) return robots.get(origin);
    const f = await follow(`${origin}/robots.txt`, { text: true, max: ROBOTS_BYTES }, async (u) => (left() && (await pace(new URL(u).host, paceMs)) ? (asked++, true) : TIME));
    const r = f.res;
    let out;
    if (f.why === TIME) return { rules: KEEP_OUT, state: "time", seen: "the time was up" };
    if (f.why === PRIVATE && !f.chain.length) out = { rules: KEEP_OUT, state: "broken", walled: true, seen: "the address is of a private network, and this check asks nothing there" };
    else if (f.why || r.error || r.status >= 500) out = { rules: KEEP_OUT, state: "broken", seen: f.why === PRIVATE ? "its redirects lead into a private network" : f.why ? "its redirects do not end" : r.error ? `no answer (${r.error})` : `status ${r.status}` };
    else if (r.status >= 400 || r.text === null) out = { rules: NO_RULES, state: "none", seen: `status ${r.status}` };
    else if (/html/.test(r.type) || /^\s*<(!doctype|html)/i.test(r.text)) out = { rules: NO_RULES, state: "page", seen: `a web page (${r.type || "no type"})` };
    else out = { rules: parseRobots(r.text, TOKEN), state: "ok", seen: `status ${r.status}` };
    robots.set(origin, out);
    return out;
  }

  /** Before any request: the time, the site's rules for robots, the pace. */
  async function gate(url) {
    if (!left()) return TIME;
    const u = new URL(url);
    // A run that may ask only the site it was given — a panel's, whose window fetches for the one
    // site the person named — asks nothing of any other, and says so (FM-SWARM-481).
    if (site !== null && key(u) !== site) return o.siteOnly ? ONLY_THE_SITE : gateOutside(u);
    const r = await rulesOf(u.origin);
    if (r.state === "time") return TIME;
    if (r.walled) return PRIVATE;
    if (!r.rules.allowed(u.pathname + u.search)) return "robots";
    if (!(await pace(u.host, Math.max(paceMs, (r.rules.delay ?? 0) * 1000)))) return TIME;
    asked++;
    return true;
  }

  // Another site is asked only where a public page could fairly send a visitor: no counter of
  // visitors, and — unless the site checked is on this machine itself — nothing on this machine
  // or in its own network, on no odd port (FM-SWARM-85). What a name leads to is judged where the
  // connection is made, by the wall (FM-SWARM-121). And an address whose opening reads as an act
  // is asked for on nobody's site: a link with a reader's own token in it unsubscribes, confirms,
  // deletes — whoever opens it, and wherever a redirect came from (FM-SWARM-205).
  async function gateOutside(u) {
    if (QUIET.test(u.hostname)) return "counts visitors";
    if (ACTION.test(u.pathname + u.search)) return ACT;
    if (!local && (u.port || loopback(u.hostname))) return PRIVATE;
    if (!(await pace(u.host, local ? paceMs : Math.max(paceMs, 1000)))) return TIME;
    asked++;
    return true;
  }

  const inside = (href) => key(new URL(href)) === site;
  // A link to another site is asked for in full only where its address carries no question: what
  // stands after a `?` there is the other site's to read, and a full request may be the act
  // itself where a light one was refused. So such a link is asked for lightly, and a light answer
  // that settles nothing is a doubt, never a fact (FM-SWARM-205). A picture is not a link: every
  // visitor's browser asks for it in full.
  const leavesWithQuery = (url) => {
    const u = new URL(url);
    return site !== null && key(u) !== site && u.search !== "";
  };
  const inFull = (url) => (leavesWithQuery(url) ? LIGHTLY : gate(url));
  function verdict(f) {
    if (f.why === "loop") return { bad: "loop" };
    if (f.why) return { doubt: f.why };
    const own = site === null || inside(f.end);
    if (f.res.error) return (own ? NO_ANSWER_INSIDE.test(f.res.error) : f.res.error === "ENOTFOUND") ? { bad: "noanswer", code: f.res.error } : { doubt: `no answer (${f.res.error})` };
    if (f.res.status >= 400) return (own ? deadInside : deadOutside)(f.res.status) ? { bad: "status", status: f.res.status } : { doubt: `answered ${f.res.status}` };
    return { ok: true };
  }
  const structural = (f) => typeof f.why === "string" && f.why !== "loop";

  /** A page asked for whole; a fault is asked for a second time before it is believed. */
  async function openPage(url) {
    let f = await follow(url, { text: true }, gate);
    let v = verdict(f);
    if (v.bad || (v.doubt && !structural(f) && f.res?.error)) {
      f = await follow(url, { text: true }, gate);
      v = verdict(f);
    }
    return { f, v };
  }

  /** An address asked for lightly: HEAD, then GET where HEAD is refused or says it is gone, and GET once more before a fault is believed — but for a link out with a question in its address, which is never asked for with GET. */
  async function light(url, picture = false) {
    let f = await follow(url, { method: "HEAD" }, gate);
    let v = verdict(f);
    if (structural(f)) return { f, v };
    const page = () => picture && v.ok && f.res.type === "text/html";
    const full = picture ? gate : inFull;
    if (!v.ok || page()) {
      f = await follow(url, { method: "GET" }, full);
      v = verdict(f);
    }
    if (v.bad || page()) {
      f = await follow(url, { method: "GET" }, full);
      v = verdict(f);
      if (v.ok && !page()) v = { doubt: "answered on the second try" };
    }
    if (page()) v = { bad: "page" };
    return { f, v };
  }

  // ── the start, the rules for robots, the site map ──
  const first = await openPage(start.href);
  // Where the wall stood, the site is the last address that answered, never the one behind the wall.
  const walled = first.f.why === PRIVATE;
  const reached = walled ? (first.f.chain.at(-1)?.url ?? start.href) : first.f.end;
  site = key(new URL(reached));
  const home = new URL(reached).origin;
  if (local && !ownGround(new URL(reached).hostname)) {
    local = false;
    paceMs = Math.max(o.pace, 200);
  }
  const rules = await rulesOf(home);
  const robotsUrl = `${home}/robots.txt`;
  if (rules.walled || rules.state === "time") {
    // Nothing was asked of it, so nothing is said of it.
  } else if (rules.state === "none") facts.push(fact(robotsUrl, "norobots", "the whole file", `robots.txt answers with ${rules.seen}`, { status: rules.seen }));
  else if (rules.state === "broken") facts.push(fact(robotsUrl, "robotsbroken", "the whole file", `robots.txt: ${rules.seen}; a robot keeps out of the site, and so did this check`, { reason: rules.seen }));
  else if (rules.state === "page") facts.push(fact(robotsUrl, "robotsbroken", "the whole file", `robots.txt answers with ${rules.seen}, not with rules`, { reason: rules.seen }));

  const entries = [];
  const opened = new Map();
  const parsed = new Map();
  const refs = new Map();
  const pictures = new Map();
  const linkQ = [];
  const mapQ = [];
  // A page is one page under every address that differs only in what tracks a visitor: the walk
  // knows it by the address without that, asks for it once, and counts it once (FM-SWARM-181).
  const queued = new Set([start.href, folded(start.href)]);
  let htmlPages = 0;
  let stopped = null;
  let timeUp = false;
  // A page the time ran out on while it was read: the walk is then not whole.
  let cutShort = false;

  const refer = (map, url, r) => {
    const known = map.get(url) ?? map.set(url, { ...r, pages: new Set() }).get(url);
    known.pages.add(r.first.page);
  };

  // A site that says the same in many languages is checked in one — the start address's — and
  // of every other language only its home page is asked for, lightly: forty languages would
  // otherwise take the whole cap of pages and say the same thing forty times (FM-SWARM-90).
  let tongues = null;
  const folder = (path) => (path.endsWith("/") ? path : `${path}/`);
  function findLanguages(p, base, at) {
    const roots = new Map();
    const add = (lang, u, line, what, href) => {
      if (!u || !/^https?:$/.test(u.protocol)) return;
      u.hash = "";
      const own = key(u) === site;
      const root = own ? folder(u.pathname) : u.href;
      const known = roots.get(root);
      if (known) known.lang = known.lang === "x-default" ? lang : known.lang;
      else roots.set(root, { lang, root, url: u.href, inside: own, first: { page: at, line, href, what } });
    };
    for (const a of p.alternates) add(a.lang, abs(a.href, base), a.line, `link[hreflang="${a.lang}"]`, a.href);
    let how = "hreflang";
    if (roots.size < 2) {
      roots.clear();
      how = "folders";
      for (const l of p.links) {
        const u = abs(l.href, base);
        const m = u && key(u) === site ? /^\/(([a-z]{2})(-[a-z]{2,4})?)\/?$/i.exec(u.pathname) : null;
        if (m && TONGUES.has(m[2].toLowerCase())) add(m[1].toLowerCase(), u, l.line, `a[href="${l.href}"]`, l.href);
      }
      if (roots.size < 2) return;
    }
    const mine = folder(new URL(at).pathname);
    const own = [...roots.values()].filter((r) => r.inside && mine.startsWith(r.root)).sort((a, b) => b.root.length - a.root.length)[0] ?? { lang: p.lang, root: "/", url: at, inside: true };
    const others = [...roots.values()].filter((r) => r !== own);
    if (!others.length) return;
    tongues = { how, own, others, roots: [own, ...others].filter((r) => r.inside) };
    // Each other language's home is a link of the start page, asked for like any other — unless the person chose this language only:
    // then nothing of another language is asked for, and the file says so.
    if (o.homes !== false) for (const t of others) refer(refs, t.url, { inside: t.inside, action: false, home: true, first: t.first });
  }
  /** Whether an address of the site belongs to another language than the one checked. */
  function foreign(u) {
    if (!tongues || key(u) !== site) return false;
    const path = folder(u.pathname);
    const best = tongues.roots.filter((r) => path.startsWith(r.root)).sort((a, b) => b.root.length - a.root.length)[0];
    return best !== undefined && best !== tongues.own;
  }
  const OTHER_TONGUE = o.homes !== false ? "a page of another language: one language is checked in full, of the others only the home page" : "a page of another language: one language is checked in full, and nothing of the others is asked for, by the person's choice";

  function record(r, item) {
    const { f, v } = r;
    const res = f.res;
    const same = f.end !== item.url && (opened.has(f.end) || opened.has(folded(f.end))) ? f.end : null;
    const entry = { url: item.url, status: res && !res.error ? res.status : null, error: res?.error ?? null, end: f.end, chain: f.chain, ms: res?.ms ?? null, bytes: null, type: res?.type ?? null, kind: v.ok ? "file" : "none", from: item.from, depth: item.depth, inSitemap: false, title: null, description: null, lang: null, h1: null };
    entries.push(entry);
    opened.set(item.url, { entry, f, v });
    // The address the redirects end at answered by itself: a link straight to it passes through none of them (FM-SWARM-125).
    if (!opened.has(f.end)) opened.set(f.end, { entry, f: f.chain.length ? { ...f, chain: [] } : f, v });
    // And so did the page without what tracks a visitor: a link to it is a link to what was opened (FM-SWARM-181).
    for (const plain of [folded(item.url), folded(f.end)]) if (!opened.has(plain)) opened.set(plain, { entry, f: f.chain.length && plain !== folded(item.url) ? { ...f, chain: [] } : f, v });
    if (same) entry.kind = "same";
    if (!v.ok || same || res.text === null || !/html/.test(res.type)) return;
    entry.kind = "page";
    entry.bytes = res.bytes;
    htmlPages++;
    if (res.cut) {
      doubt("the page is longer than 3 MB and was not read to its end", f.end);
      facts.push(fact(f.end, "heavy", "the whole page", `more than ${res.bytes} bytes of HTML`, { bytes: res.bytes }));
      return;
    }
    const p = read(res.text, deadline);
    if (p.cut) {
      // Half a page read says nothing of the page: no title found is not "no title" (FM-SWARM-180).
      cutShort = true;
      doubt("the page was not read to its end before the time was up", f.end);
      return;
    }
    const here = new URL(f.end);
    const self = new Set([folded(f.end), folded(item.url)]);
    const base = (p.base && abs(p.base, here)) || here;
    const canonical = (p.canonical && abs(p.canonical, base)?.href) || null;
    Object.assign(entry, { title: p.title || null, description: p.description || null, lang: p.lang, h1: p.h1.length, noindex: p.noindex, canonical, links: p.links.length, images: p.images.length, forms: p.forms.length });
    parsed.set(entry, { p, base, here });
    if (item.from === null) findLanguages(p, base, f.end);
    for (const l of p.links) {
      if (!l.href || l.href.startsWith("#")) continue;
      const u = abs(l.href, base);
      if (!u || !/^https?:$/.test(u.protocol) || u.username || u.password) continue;
      u.hash = "";
      const own = key(u) === site;
      // A link of the site is asked for at the address without what tracks a visitor; a link out is asked for as it is written.
      const to = own ? folded(u.href) : u.href;
      if (self.has(folded(u.href))) continue;
      // Whose site it is on makes no difference to what opening it does (FM-SWARM-205).
      const action = ACTION.test(u.pathname + u.search);
      const other = foreign(u);
      refer(refs, to, { inside: own, action, other, first: { page: f.end, line: l.line, href: l.href } });
      if (own && !action && !other && !FILE.test(u.pathname) && !queued.has(to)) {
        queued.add(to);
        linkQ.push({ url: to, from: f.end, depth: item.depth + 1 });
      }
    }
    for (const i of p.images) {
      const u = abs(i.src, base);
      if (!u || !/^https?:$/.test(u.protocol)) continue;
      u.hash = "";
      refer(pictures, u.href, { first: { page: f.end, line: i.line, href: i.src } });
    }
  }

  const startBad = (kind, seen, data) => facts.push(fact(start.href, kind, "the start address", seen, data));
  if (walled) {
    // A doubt, not a fact: from where the visitors are the same name may lead to a site (FM-SWARM-81).
    stopped = "private";
    doubt("the address leads into a private network, and this check asks nothing there", first.f.end);
  } else if (first.f.why === "robots") {
    stopped = "robots";
    if (rules.state === "ok") startBad("closed", `robots.txt of ${home} tells robots to keep out of ${new URL(first.f.end).pathname}`, { robots: robotsUrl });
  } else if (first.f.why === TIME) stopped = "time";
  else if (first.v.bad === "loop") startBad("redirectloop", chainText(first.f), { chain: first.f.chain });
  else if (first.f.res?.error || first.f.why) startBad("notopened", `no answer (${first.f.res?.error ?? first.f.why})`, { error: first.f.res?.error ?? first.f.why });
  else if (first.v.bad) startBad(first.f.chain.length ? "redirectnowhere" : "errorpage", `${chainText(first.f)} answers ${first.f.res.status}`, { status: first.f.res.status, chain: first.f.chain });
  else if (first.v.doubt) startBad("refused", `status ${first.f.res.status}`, { status: first.f.res.status });
  if (first.f.res) record(first, { url: start.href, from: null, depth: 0 });
  if (first.v.ok && first.f.chain.length >= 2) startBad("redirectchain", chainText(first.f), { chain: first.f.chain });
  const walking = first.v.ok === true;

  const inMap = new Set();
  const map = { found: false, whole: true, files: [], addresses: 0 };
  const elsewhere = [];
  if (walking && rules.state !== "broken") {
    const named = rules.rules.sitemaps.map((s) => abs(s, home)?.href).filter(Boolean);
    const todo = named.length ? named.map((url) => ({ url, guess: false })) : [`${home}/sitemap.xml`, `${home}/sitemap_index.xml`].map((url) => ({ url, guess: true }));
    const seenMaps = new Set();
    while (todo.length && left()) {
      const { url, guess } = todo.shift();
      if (seenMaps.has(url) || (guess && map.found)) continue;
      seenMaps.add(url);
      if (seenMaps.size > 60 || /\.gz($|\?)/i.test(url)) {
        map.whole = false;
        doubt("a part of the site map was not read (packed, or past sixty files)", url);
        continue;
      }
      const f = await follow(url, { text: true, max: 10_000_000 }, gate);
      const got = f.res && !f.res.error && f.res.status < 300 && f.res.text !== null ? parseSitemap(f.res.text, f.res.type) : null;
      if (!got) {
        if (structural(f)) doubt(`the site map was not asked for (${f.why})`, url);
        else if (!guess) facts.push(fact(url, "sitemapbroken", "the whole file", f.res?.error ? `no answer (${f.res.error})` : f.res?.status >= 300 ? `status ${f.res.status}` : "what answers is not a site map", { status: f.res?.status ?? null }));
        if (!guess) map.whole = false;
        continue;
      }
      map.found = true;
      map.files.push(url);
      if (f.res.cut) map.whole = false;
      for (const loc of got.urls) {
        const u = abs(loc, url);
        if (!u) continue;
        u.hash = "";
        if (got.index) todo.push({ url: u.href, guess: false });
        else if (key(u) !== site) elsewhere.push(u.href);
        else if (inMap.size < 5000) inMap.add(folded(u.href));
        else map.whole = false;
      }
    }
    if (todo.length) map.whole = false;
    map.addresses = inMap.size;
    if (!map.found && !named.length && left()) facts.push(fact(`${home}/sitemap.xml`, "nositemap", "the whole site", "robots.txt names no site map, and /sitemap.xml and /sitemap_index.xml answer with none", {}));
    if (elsewhere.length) facts.push(fact(map.files[0], "sitemapforeign", "the site map", `${elsewhere.length} of its addresses are of another site, the first ${elsewhere[0]}`, { count: elsewhere.length, first: elsewhere.slice(0, 5) }));
    for (const url of inMap) if (!queued.has(url) && !foreign(new URL(url))) (queued.add(url), mapQ.push({ url, from: "sitemap", depth: 1 }));
  }

  // ── the walk: what pages link to first, then what only the site map names ──
  while (walking && (linkQ.length || mapQ.length)) {
    if (!left()) break;
    if (htmlPages >= o.pages) break;
    const item = linkQ.shift() ?? mapQ.shift();
    if (opened.has(item.url)) continue;
    const r = await openPage(item.url);
    if (structural(r.f)) {
      if (r.f.why === TIME) {
        (item.from === "sitemap" ? mapQ : linkQ).unshift(item);
        timeUp = true;
        break;
      }
      doubt(said(r.f.why), item.url);
      // Said once: the link that led here finds it said already, and one address is one doubt.
      opened.set(item.url, { entry: null, f: r.f, v: r.v, said: true });
      continue;
    }
    record(r, item);
  }
  const shut = (url) => {
    const u = new URL(url);
    return robots.get(u.origin)?.rules.allowed(u.pathname + u.search) === false;
  };
  const unread = [...linkQ, ...mapQ].filter((i) => !opened.has(i.url) && !shut(i.url)).length;
  if (walking && (unread || cutShort)) stopped = left() && !timeUp && !cutShort ? "pages" : "time";
  const whole = walking && stopped === null;

  // ── what every page says of itself ──
  const push = (...a) => facts.push(fact(...a));
  const titles = new Map();
  const descriptions = new Map();
  const group = (m, k, e) => m.set(k, [...(m.get(k) ?? []), e]);
  const once = new Set();
  for (const e of entries) {
    const got = parsed.get(e);
    if (!got) continue;
    const { p, base, here } = got;
    const at = e.end;
    const speed = tier(e.ms, LIMITS.slow, LIMITS.verySlow, "slow", "veryslow");
    if (speed) push(at, speed, "the whole page", `the answer began after ${e.ms} ms`, { ms: e.ms });
    if (e.bytes > LIMITS.heavy) push(at, "heavy", "the whole page", `${e.bytes} bytes of HTML`, { bytes: e.bytes });
    if (!p.lang) push(at, "nolang", "line 1: html", p.hasHtml ? "<html> has no lang" : "the page has no <html> tag", {});
    if (!p.title) push(at, "notitle", "head", "no title", {});
    else if ([...p.title].length > LIMITS.title) push(at, "longtitle", "head: title", `${[...p.title].length} letters: «${p.title.slice(0, 80)}»`, { letters: [...p.title].length, title: p.title });
    if (!p.description) push(at, "nodescription", "head", "no description", {});
    else if ([...p.description].length > LIMITS.description) push(at, "longdescription", "head: meta[name=description]", `${[...p.description].length} letters`, { letters: [...p.description].length, description: p.description });
    if (!p.h1.length) push(at, "noheading", "the whole page", "no <h1>", {});
    else if (p.h1.length > 1) push(at, "manyheadings", place(p.h1[1], "h1"), `${p.h1.length} <h1>, on lines ${p.h1.join(", ")}`, { lines: p.h1 });
    for (const f of p.forms) {
      const where = place(f.line, formName(f));
      if (f.action === null || f.action === "" || f.action === "#" || /^javascript:/i.test(f.action)) push(at, "formnotarget", where, f.action === null ? "the form has no action" : `the form's action is «${f.action.slice(0, 40)}»`, { action: f.action });
      if (!f.button) push(at, "formnobutton", where, "the form has no submit button", {});
      if (here.protocol === "https:" && f.action && abs(f.action, base)?.protocol === "http:") push(at, "insecureform", where, `the form sends to ${f.action}`, { action: f.action });
    }
    if (here.protocol === "https:")
      for (const l of p.loads) {
        const u = abs(l.url, base);
        if (u?.protocol !== "http:") continue;
        push(at, l.active ? "mixedactive" : "mixedpassive", place(l.line, `${l.tag}[${l.tag === "link" ? "href" : l.tag === "object" ? "data" : "src"}="${l.url}"]`), `loads ${u.href}`, { target: u.href, tag: l.tag });
      }
    // Two addresses that name one page as the real one are one page.
    const self = e.canonical ?? at;
    if (once.has(self)) continue;
    once.add(self);
    if (p.title) group(titles, p.title.toLowerCase(), e);
    if (p.description) group(descriptions, p.description.toLowerCase(), e);
  }
  for (const [kind, groups, word] of [["sametitle", titles, "title"], ["samedescription", descriptions, "description"]])
    for (const same of groups.values())
      if (same.length > 1)
        for (const e of same) {
          const others = same.filter((x) => x !== e).map((x) => x.end);
          push(e.end, kind, `head: ${word}`, `the same ${word} as ${others.length === 1 ? others[0] : `${others.length} other pages, the first ${others[0]}`}: «${e[word].slice(0, 80)}»`, { with: others.slice(0, 20), [word]: e[word] });
        }

  // ── where the links lead ──
  // Each kind of address has a cap of its own: a site with many links must not leave its pictures unasked (FM-SWARM-85).
  let lightLeft = o.links;
  // The home pages of the other languages stand outside the cap of links, so they have one of their own, and a pace no site's own pace undoes: a start page that names thousands of languages is not thousands of requests (FM-SWARM-183).
  let homesLeft = LIMITS.homes;
  const PAST_HOMES = "a home page of another language, not asked for: past the cap of language homes";
  async function stateOf(url, picture = false, counted = true) {
    const known = opened.get(url);
    if (known && !picture) return known;
    if (!left()) return doubt("not asked for before the time was up", url), null;
    if (counted && lightLeft-- <= 0) return doubt("not asked for: past the cap of links", url), null;
    const r = await light(url, picture);
    if (!picture) opened.set(url, { entry: null, ...r });
    return r;
  }
  const linkData = (url, r, f, v) => ({ target: url, end: f.end, chain: f.chain, status: f.res && !f.res.error ? f.res.status : null, error: v.code ?? null, pages: r.pages.size, alsoOn: [...r.pages].filter((x) => x !== r.first.page).slice(0, 20) });
  const answer = (f, v) => (v.status ? `answers ${v.status}` : `gives no answer (${v.code})`);

  for (const [url, r] of refs) {
    if (!r.inside) continue;
    if (r.action) {
      doubt(ACT, url);
      continue;
    }
    if (r.other && !r.home) {
      doubt(OTHER_TONGUE, url);
      continue;
    }
    if (r.home && !opened.has(url)) {
      if (homesLeft-- <= 0) {
        doubt(PAST_HOMES, url);
        continue;
      }
      if (!(await pace(new URL(url).host, Math.max(paceMs, LIMITS.homePace)))) {
        doubt("not asked for before the time was up", url);
        continue;
      }
    }
    const s = await stateOf(url, false, !r.home);
    if (!s) continue;
    const { f, v } = s;
    const where = place(r.first.line, r.first.what ?? `a[href="${r.first.href}"]`);
    if (v.doubt) s.said || doubt(said(v.doubt), url);
    else if (v.bad === "loop") push(r.first.page, "redirectloop", where, chainText(f), linkData(url, r, f, v));
    else if (v.bad) push(r.first.page, f.chain.length ? "redirectnowhere" : "deadlink", where, f.chain.length ? `${chainText(f)} ${answer(f, v)}` : `${url} ${answer(f, v)}`, linkData(url, r, f, v));
    else if (f.chain.length) push(r.first.page, f.chain.length > 1 ? "redirectchain" : "redirect", where, chainText(f), linkData(url, r, f, v));
  }

  for (const url of inMap) {
    if (foreign(new URL(url))) {
      if (!refs.has(url)) doubt(OTHER_TONGUE, url);
      continue;
    }
    const s = opened.get(url) ?? (refs.has(url) ? null : await stateOf(url));
    if (s?.v.bad && !refs.has(url)) push(url, "sitemapdead", "the site map", s.v.bad === "loop" ? chainText(s.f) : `${url} ${answer(s.f, s.v)}`, { status: s.v.status ?? null, error: s.v.code ?? null });
  }

  let picturesLeft = o.images;
  for (const [url, r] of pictures) {
    if (!inside(url) && countsVisitors(new URL(url))) {
      doubt("counts visitors", url);
      continue;
    }
    if (picturesLeft-- <= 0) {
      doubt("not asked for: past the cap of pictures", url);
      continue;
    }
    const s = await stateOf(url, true, false);
    if (!s) continue;
    const { f, v } = s;
    if (v.doubt) doubt(said(v.doubt), url);
    else if (v.bad) push(r.first.page, "image", place(r.first.line, `img[src="${r.first.href}"]`), v.bad === "page" ? `${url} answers with a web page, not a picture` : v.bad === "loop" ? chainText(f) : `${url} ${answer(f, v)}`, linkData(url, r, f, v));
  }

  let outsideLeft = o.outside;
  for (const [url, r] of refs) {
    if (r.inside) continue;
    if (r.action) {
      doubt(ACT, url);
      continue;
    }
    if (outsideLeft-- <= 0) {
      doubt("a link to another site, past the cap of those checked", url);
      continue;
    }
    const s = await stateOf(url, false, false);
    if (!s) continue;
    const { f, v } = s;
    if (v.doubt) doubt(said(v.doubt), url);
    else if (v.bad) push(r.first.page, "deadoutside", place(r.first.line, `a[href="${r.first.href}"]`), v.bad === "loop" ? chainText(f) : `${url} ${answer(f, v)}`, linkData(url, r, f, v));
  }

  // ── pages reachable from nowhere, and pages the site map forgot ──
  const linked = new Set([norm(start.href)]);
  if (first.f.res) linked.add(norm(first.f.end));
  for (const [url, r] of refs) {
    if (!r.inside) continue;
    linked.add(norm(url));
    const s = opened.get(url);
    if (s) linked.add(norm(s.f.end));
  }
  const mapped = new Set([...inMap].map(norm));
  for (const e of entries) e.inSitemap = mapped.has(norm(e.url)) || mapped.has(norm(e.end));
  for (const url of inMap) {
    const s = opened.get(url);
    if (foreign(new URL(url))) continue;
    if (!s?.v.ok || linked.has(norm(url)) || linked.has(norm(s.f.end))) continue;
    if (whole) push(s.f.end, "unlinked", "the site map", "the site map lists it and no page links to it", { sitemap: map.files[0] });
    else doubt("in the site map and no page read links to it — but the walk stopped early", url);
  }
  if (map.found && map.whole)
    for (const e of entries) {
      if (e.kind !== "page" || e.inSitemap || e.noindex || (e.canonical && norm(e.canonical) !== norm(e.end))) continue;
      push(e.end, "notinsitemap", "the site map", "the page is linked to and the site map does not list it", { sitemap: map.files[0], from: e.from });
    }

  return {
    facts,
    entries,
    site,
    home,
    stopped,
    local,
    asked,
    htmlPages,
    doubts: Object.fromEntries(doubts),
    robots: { url: robotsUrl, state: rules.state === "time" ? "broken" : rules.state, seen: rules.seen, rules: rules.rules.rules, crawlDelay: rules.rules.delay, sitemaps: rules.rules.sitemaps },
    sitemap: map,
    languages: tongues && {
      found: tongues.others.length + 1,
      how: tongues.how,
      checkedInFull: { lang: tongues.own.lang, under: tongues.own.inside ? tongues.own.root : tongues.own.url },
      // Only the homes that were asked for are listed: the rest are counted, and said among what was not stated.
      sampled: tongues.others
        .filter((t) => opened.has(t.url))
        .slice(0, LIMITS.homes)
        .map((t) => {
          const s = opened.get(t.url);
          return { lang: t.lang, home: t.url, opens: s?.v.ok ? true : s?.v.bad ? false : null };
        }),
      notAsked: doubts.get(PAST_HOMES)?.count ?? 0,
      othersAsked: o.homes !== false,
      note: o.homes !== false ? "one language was checked in full; of every other only its home page was asked for, to see that it opens" : "one language was checked in full; nothing of the other languages was asked for, by the person's choice",
    },
  };
}
