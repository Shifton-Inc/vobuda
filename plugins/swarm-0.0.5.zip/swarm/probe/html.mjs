// A page's HTML read for what the probe states facts about: its title, its links, its pictures,
// its forms — each with the line it stands on. A reader of tags, not a browser: no script runs,
// and what a script would add is not here. Written for pages as they are, half-closed tags and all.

const ENTITIES = { amp: "&", lt: "<", gt: ">", quot: '"', apos: "'", nbsp: " " };

/** Text as a person reads it: entities turned back into letters. */
export const plain = (s) =>
  s.replace(/&(#x?[0-9a-f]+|[a-z]+);/gi, (whole, e) => {
    if (e[0] !== "#") return ENTITIES[e.toLowerCase()] ?? whole;
    const n = e[1].toLowerCase() === "x" ? parseInt(e.slice(2), 16) : parseInt(e.slice(1), 10);
    return n > 0 && n < 0x110000 ? String.fromCodePoint(n) : whole;
  });

const squash = (s) => plain(s).replace(/\s+/g, " ").trim();

const NAME = /[a-zA-Z][a-zA-Z0-9:-]*/y;
const ATTR = /([^\s"'=<>/]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+)))?/g;

// What stands inside these is not tags of the page. A <noscript> and a <template> are passed by
// whole: a counting picture lives in the first, and the second is not on the page until a script puts it there.
const HOLDS_TEXT = new Set(["script", "style", "textarea", "title", "noscript", "template"]);

function attributes(text) {
  const out = {};
  for (const m of text.matchAll(ATTR)) {
    const name = m[1].toLowerCase();
    if (!(name in out)) out[name] = plain(m[2] ?? m[3] ?? m[4] ?? "");
  }
  return out;
}

/**
 * A page's tags, one after another, found in one pass however the page is written. A tag is
 * `<name …>` whose `>` stands outside any quoted value; a comment and a CDATA block are passed
 * by whole. Where each tag ends is worked out once for the whole page, from its end backwards,
 * so a page made of a million tags that never close costs what any page of its size costs and
 * cannot hold the probe (FM-SWARM-122). `next(from)` gives the first tag at or after `from`:
 * `{ index, end, closing, name, attrs }`, with `name` null for a comment; null when there is none.
 */
export function tags(html) {
  const n = html.length;
  // For every place outside a quote: where the `>` that closes a tag open there stands, or -1.
  const close = new Int32Array(n + 1).fill(-1);
  let double = -1;
  let single = -1;
  for (let i = n - 1; i >= 0; i--) {
    const c = html.charCodeAt(i);
    if (c === 62) close[i] = i;
    else if (c === 34) (close[i] = double < 0 ? -1 : close[double + 1]), (double = i);
    else if (c === 39) (close[i] = single < 0 ? -1 : close[single + 1]), (single = i);
    else close[i] = close[i + 1];
  }
  // Once a comment or a CDATA block was found to have no end, none after it has one either.
  let comments = true;
  let blocks = true;
  return function next(from) {
    for (let i = html.indexOf("<", from); i >= 0; i = html.indexOf("<", i + 1)) {
      if (comments && html.startsWith("<!--", i)) {
        const end = html.indexOf("-->", i + 4);
        if (end >= 0) return { index: i, end: end + 3, closing: false, name: null, attrs: "" };
        comments = false;
      }
      if (blocks && html.startsWith("<![CDATA[", i)) {
        const end = html.indexOf("]]>", i + 9);
        if (end >= 0) return { index: i, end: end + 3, closing: false, name: null, attrs: "" };
        blocks = false;
      }
      const closing = html.charCodeAt(i + 1) === 47;
      NAME.lastIndex = i + (closing ? 2 : 1);
      const name = NAME.exec(html);
      if (!name) continue;
      const end = close[NAME.lastIndex];
      if (end >= 0) return { index: i, end: end + 1, closing, name: name[0], attrs: html.slice(NAME.lastIndex, end) };
    }
    return null;
  };
}

/** After how many tags the reader looks at the clock. */
const LOOK = 256;

/**
 * What the probe reads of one page. One walk from the page's start to its end, whatever the page
 * holds: the line a tag stands on is counted on from the tag before it, never looked for afresh,
 * so a page of a million tags on one line costs what any page of its size costs (FM-SWARM-180).
 * And the walk keeps the run's time: past `until` it stops where it stands and says so with
 * `cut` — what it then holds is the page's beginning, and nothing may be stated of the whole.
 */
export function read(html, until = Infinity) {
  const page = { cut: false, hasHtml: false, lang: null, title: null, description: null, noindex: false, canonical: null, base: null, alternates: [], h1: [], links: [], images: [], loads: [], forms: [] };
  const lower = html.toLowerCase();
  const byId = new Map();
  const outer = [];
  let line = 1;
  // The first line's end not yet counted; -1 once the page has no more.
  let nl = html.indexOf("\n");
  let svg = 0;
  let form = null;
  let seen = 0;
  if (Date.now() >= until) return (page.cut = true), page;
  const next = tags(html);
  let from = 0;
  for (let m; (m = next(from)); ) {
    if (++seen % LOOK === 0 && Date.now() >= until) {
      page.cut = true;
      break;
    }
    from = m.end;
    for (; nl >= 0 && nl < m.index; nl = html.indexOf("\n", nl + 1)) line++;
    if (!m.name) continue;
    const name = m.name.toLowerCase();
    if (m.closing) {
      if (name === "svg") svg = Math.max(0, svg - 1);
      if (name === "form") form = null;
      continue;
    }
    const a = attributes(m.attrs);
    let inner = "";
    if (HOLDS_TEXT.has(name)) {
      const end = lower.indexOf(`</${name}`, from);
      inner = html.slice(from, end < 0 ? html.length : end);
      from = end < 0 ? html.length : end;
    }
    const load = (url, active) => url && page.loads.push({ tag: name, url: url.trim(), line, active });
    switch (name) {
      case "html":
        page.hasHtml = true;
        page.lang = (a.lang ?? a["xml:lang"] ?? "").trim() || null;
        break;
      case "svg":
        if (!m.attrs.trimEnd().endsWith("/")) svg++;
        break;
      case "title":
        // A drawing has titles of its own; the page's is the first outside one.
        if (!svg && page.title === null) page.title = squash(inner);
        break;
      case "meta": {
        const what = (a.name ?? "").toLowerCase();
        if (what === "description" && page.description === null) page.description = squash(a.content ?? "");
        if ((what === "robots" || what === "googlebot") && /noindex/i.test(a.content ?? "")) page.noindex = true;
        break;
      }
      case "link": {
        const rel = (a.rel ?? "").toLowerCase().split(/\s+/);
        if (rel.includes("canonical") && a.href && !page.canonical) page.canonical = a.href.trim();
        if (rel.includes("stylesheet")) load(a.href, true);
        if (rel.includes("alternate") && a.hreflang && a.href) page.alternates.push({ lang: a.hreflang.trim().toLowerCase(), href: a.href.trim(), line });
        break;
      }
      case "base":
        if (a.href && !page.base) page.base = a.href.trim();
        break;
      case "h1":
        if (!svg) page.h1.push(line);
        break;
      case "a":
      case "area":
        if (!svg && "href" in a) page.links.push({ href: a.href.trim(), line });
        break;
      case "img":
        if (a.src) page.images.push({ src: a.src.trim(), line });
        load(a.src, false);
        break;
      case "script":
      case "iframe":
      case "embed":
        load(a.src, true);
        break;
      case "object":
        load(a.data, true);
        break;
      case "video":
      case "audio":
      case "source":
      case "track":
        load(a.src, false);
        break;
      case "form":
        form = { n: page.forms.length + 1, id: a.id || null, action: "action" in a ? a.action.trim() : null, method: (a.method || "get").toLowerCase(), line, button: false };
        page.forms.push(form);
        if (form.id) byId.set(form.id, form);
        break;
      case "button":
      case "input": {
        const type = (a.type || (name === "button" ? "submit" : "text")).toLowerCase();
        if (type !== "submit" && type !== "image") break;
        if (a.form) outer.push(a.form);
        else if (form) form.button = true;
        break;
      }
    }
  }
  // A button may stand outside its form and name it.
  for (const id of outer) if (byId.has(id)) byId.get(id).button = true;
  return page;
}

/** Where on the page: the line, and the tag as a person would look for it. */
export const place = (line, what) => `line ${line}: ${what}`.slice(0, 240);
export const formName = (f) => (f.id ? `form#${f.id}` : `form (no. ${f.n} on the page)`);
