// How the probe asks a site for anything: GET or HEAD, one address, no cookie, no login, no body
// sent — and nothing else is possible through here, which is the whole of "the checker never
// writes anything to the site" for the base pass (FM-SWARM-83). Every connection either pass
// opens is opened here, through one look-up that refuses an address of this machine or of its
// own network (FM-SWARM-121). Also the rules a site gives robots, and its site map.

import { lookup as systemLookup } from "node:dns";
import http from "node:http";
import https from "node:https";
import { isIP } from "node:net";
import { createBrotliDecompress, createUnzip } from "node:zlib";
import { PRIVATE, TIME, followWith } from "./plain.mjs";
import { UA, bare, privateAddress } from "./rules.mjs";

// The rules a site gives robots, its site map, and the words for why an address was not asked
// stand with what needs no network (plain.mjs); they are named here as they always were.
export { KEEP_OUT, NO_RULES, PRIVATE, ROBOTS_BYTES, TIME, fits, parseRobots, parseSitemap } from "./plain.mjs";

/**
 * The wall between the probe and the machine's own network, for one run. `shut` is the way out
 * for a site that is somewhere else: the name is looked up and the connection is made to that
 * very answer, so there is no moment between the two in which the name can come to mean another
 * address; any private answer among several refuses them all. `open` is the way for a site the
 * person named on this machine itself. Each keeps its own connections, so one made on the open
 * side is never used again on the shut one. `lookup` and `inner` are given only by a check.
 */
export function wall({ lookup = systemLookup, inner = privateAddress } = {}) {
  const guarded = (host, options, done) =>
    lookup(host, options, (error, address, family) => {
      if (error) return done(error);
      const found = Array.isArray(address) ? address : [{ address, family }];
      if (!found.length || found.some((a) => inner(a.address))) return done(Object.assign(new Error(PRIVATE), { code: "EPRIVATE" }));
      done(null, address, family);
    });
  const side = (look) => ({ lookup: look, "http:": new http.Agent({ keepAlive: true }), "https:": new https.Agent({ keepAlive: true }) });
  const sides = { shut: side(guarded), open: side(lookup) };
  return {
    /** Whether a host written as numbers is refused before anything is looked up. */
    refuses: (host, open) => !open && isIP(bare(host)) !== 0 && inner(bare(host)),
    side: (open) => (open ? sides.open : sides.shut),
    end() {
      for (const s of Object.values(sides)) (s["http:"].destroy(), s["https:"].destroy());
    },
  };
}

let own = null;
/** The wall of a run that was given none: the system's own look-up and the written rule. */
const ownWall = () => (own ??= wall());

/**
 * One request. Redirects are not followed here: the answer is the status and where it points.
 * `ms` is the time to the first byte of the answer; the text is read only of a page that came.
 * `until` is the moment the whole run ends: an answer not come by then is "time", which is
 * nobody's fault, where one not come in `timeout` is the site's silence.
 */
export function ask(url, { method = "GET", timeout = 15000, max = 3_000_000, text = false, open = false, until = Infinity, wall: through = ownWall() } = {}) {
  if (method !== "GET" && method !== "HEAD") throw new Error("the probe asks with GET and HEAD only");
  const began = performance.now();
  const ms = () => Math.round(performance.now() - began);
  return new Promise((done) => {
    let u;
    try {
      u = new URL(url);
    } catch {
      return done({ error: "ERR_INVALID_URL", ms: 0 });
    }
    if (through.refuses(u.hostname, open)) return done({ error: PRIVATE, ms: 0 });
    const runLeft = until - Date.now();
    if (runLeft <= 0) return done({ error: TIME, ms: 0 });
    const side = through.side(open);
    let over = null;
    let req;
    const finish = (out) => {
      clearTimeout(timer);
      done(out);
    };
    const failed = (e) => finish({ error: over ?? (e?.code === "EPRIVATE" ? PRIVATE : String(e?.code ?? e?.cause?.code ?? e?.name ?? "failed")), ms: ms() });
    const timer = setTimeout(() => {
      over = runLeft < timeout ? TIME : "timeout";
      req?.destroy(new Error(over));
    }, Math.min(timeout, runLeft));
    try {
      req = (u.protocol === "https:" ? https : http).request(u, { method, agent: side[u.protocol], lookup: side.lookup, headers: { "user-agent": UA, accept: "text/html,application/xhtml+xml,*/*;q=0.8", "accept-encoding": "gzip, deflate, br" } });
    } catch (e) {
      return failed(e);
    }
    req.on("error", failed);
    req.on("response", (res) => {
      const whole = String(res.headers["content-type"] ?? "");
      const type = whole.split(";")[0].trim().toLowerCase();
      const out = { status: res.statusCode, type, location: res.headers.location ?? null, ms: ms(), bytes: 0, text: null, cut: false };
      const packed = String(res.headers["content-encoding"] ?? "").trim().toLowerCase();
      const unpack = packed === "" || packed === "identity" ? null : packed === "gzip" || packed === "x-gzip" || packed === "deflate" ? createUnzip : packed === "br" ? createBrotliDecompress : undefined;
      if (!(text && method === "GET" && out.status >= 200 && out.status < 300 && /html|xml|text\/plain/.test(type)) || unpack === undefined) {
        // A HEAD has no body and its connection is kept; any other body is not waited for.
        if (method === "HEAD") res.resume();
        else res.destroy();
        return finish(out);
      }
      res.on("error", failed);
      const body = unpack ? res.pipe(unpack()) : res;
      const parts = [];
      body.on("error", failed);
      body.on("data", (chunk) => {
        if (out.cut) return;
        out.bytes += chunk.length;
        if (out.bytes > max) {
          out.cut = true;
          res.destroy();
          return read();
        }
        parts.push(chunk);
      });
      body.on("end", () => out.cut || read());
      function read() {
        const charset = /charset=["']?([\w-]+)/i.exec(whole)?.[1] ?? "utf-8";
        let decoder;
        try {
          decoder = new TextDecoder(charset);
        } catch {
          decoder = new TextDecoder("utf-8");
        }
        out.text = decoder.decode(Buffer.concat(parts));
        finish(out);
      }
    });
    req.end();
  });
}

/** An address followed to its end through the probe's own requests (plain.mjs, `followWith`). */
export const follow = followWith(ask);
