// The pages of a site as text, written beside the probe's facts: what the Swarm's residents are
// to read of a site that is given by its address.
//
// It reads a page with a reader of its own (text.mjs), which walks a page once from its start to
// its end whatever the page holds.
//
// Why here: the one who reads a stranger's page must not be a model with a shell in the same turn.
// So no helper opens the web. This program asks the site — plain Node, GET only, the same site
// only, by the probe's own rules — and writes each page's words into one file of the run's folder;
// the panel puts them into an ask's `data`, as it does the pages of a folder (FM-SWARM-161).
//
// It asks only for pages the base pass has just opened, at the address each one ended on, and
// follows nothing: an answer that now points elsewhere, or is not a page, is passed by.

import { renameSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { ask } from "./net.mjs";
import { gatherPages } from "./plain.mjs";
import { folded } from "./rules.mjs";

// A page's words, and whether an address reads as an act, stand with what needs no network (plain.mjs).
export { PAGES_SHAPE, acts, pageOf } from "./plain.mjs";

// An address without what only tracks is one page (FM-SWARM-167): the rule is the walk's too, and stands with the other rules.
export { folded };

/** A file's name and nothing of a path: it is written beside the run and nowhere else. */
export const plainName = (name) => /^[\w][\w.-]*\.json$/.test(name);

/**
 * Ask again for every page the base pass opened and write their words (plain.mjs, `gatherPages`).
 * The file is put in place whole: a reader never meets half of one.
 */
export async function writePages(base, o) {
  const out = await gatherPages(base, o, ask);
  const path = resolve(process.cwd(), o.texts);
  writeFileSync(`${path}.tmp`, JSON.stringify(out));
  renameSync(`${path}.tmp`, path);
  return out.read.length;
}
