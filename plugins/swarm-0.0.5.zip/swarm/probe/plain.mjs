// What the probe knows of a site without a network of its own: how an address is followed to its
// end by whoever asks, the rules a site gives robots, its site map, a page's words, and the two
// files a run leaves. Nothing here needs Node, so the same walk is made by the probe, through its
// own requests (net.mjs), and by the Swarm's panel, through the window's `fetchPage` — one set of
// rules and lists, not two (FM-SWARM-480).

import { ACTION, SHAPE, UA, folded, siteKey } from "./rules.mjs";
import { baseOf, describedOf, hrefsOf, textOf, titleOf } from "./text.mjs";

/** Why an address was not asked: it is on this machine or in its own network. */
export const PRIVATE = "private address";
/** Why an address was not asked, or its answer not waited for: the run's own time was up. */
export const TIME = "time";

/**
 * An address followed to its end, by whoever asks: `ask` is the one request — the probe's own (net.mjs), or a panel's
 * through the window (FM-SWARM-480). `gate` is asked before every step and answers true or the
 * reason the step may not be taken (the robots' rules, a cap); it is also where the pace is kept.
 * `why` is null where an answer came, else "loop", or the gate's reason, or the wall's or the
 * clock's — and then `unsent` says the step the gate had let through was never made.
 */
export const followWith = (ask) => async function follow(url, options, gate) {
  const chain = [];
  const passed = new Set([url]);
  let at = url;
  for (let hop = 0; ; hop++) {
    const may = await gate(at);
    if (may !== true) return { chain, end: at, res: null, why: may };
    const res = await ask(at, options);
    if (res.error === PRIVATE || res.error === TIME) return { chain, end: at, res: null, why: res.error, unsent: res.error === PRIVATE };
    if (res.error || res.status < 300 || res.status >= 400 || !res.location) return { chain, end: at, res, why: null };
    let next;
    try {
      next = new URL(res.location, at);
    } catch {
      return { chain, end: at, res, why: null };
    }
    next.hash = "";
    chain.push({ url: at, status: res.status });
    if (!/^https?:$/.test(next.protocol)) return { chain, end: next.href, res: null, why: "leaves the web" };
    if (passed.has(next.href) || hop >= 9) return { chain, end: next.href, res: null, why: "loop" };
    passed.add(next.href);
    at = next.href;
  }
};

/** The most of a robots file that is read: what a robot must be able to take (RFC 9309), and no more. */
export const ROBOTS_BYTES = 512_000;

/**
 * Whether a rule's path fits an address: `*` is any letters, a `$` at the end is the end, and a
 * rule fits from the address's first letter. Matched piece by piece, each found once and never
 * looked for again — the time grows with the lengths and not with the number of stars, so no
 * rule a site can write holds the probe (FM-SWARM-122).
 */
export function fits(rule, path) {
  const toEnd = rule.endsWith("$");
  const pieces = (toEnd ? rule.slice(0, -1) : rule).split("*");
  if (!path.startsWith(pieces[0])) return false;
  if (pieces.length === 1) return !toEnd || path.length === pieces[0].length;
  let at = pieces[0].length;
  for (let i = 1; i < pieces.length - 1; i++) {
    const found = path.indexOf(pieces[i], at);
    if (found < 0) return false;
    at = found + pieces[i].length;
  }
  const last = pieces[pieces.length - 1];
  if (!toEnd) return path.indexOf(last, at) >= 0;
  return path.length - last.length >= at && path.endsWith(last);
}

/** A robots file read for one robot: its own group where there is one, else everybody's. */
export function parseRobots(text, token) {
  const groups = [];
  const sitemaps = [];
  let group = null;
  let naming = false;
  for (const raw of text.split(/\r\n?|\n/)) {
    const hash = raw.indexOf("#");
    const lineText = (hash < 0 ? raw : raw.slice(0, hash)).trim();
    const colon = lineText.indexOf(":");
    if (colon < 0) continue;
    const key = lineText.slice(0, colon).trim().toLowerCase();
    const value = lineText.slice(colon + 1).trim();
    if (key === "sitemap") sitemaps.push(value);
    else if (key === "user-agent") {
      if (!naming) groups.push((group = { agents: [], rules: [], delay: null }));
      naming = true;
      group.agents.push(value.toLowerCase());
    } else if (group) {
      naming = false;
      if ((key === "allow" || key === "disallow") && value) group.rules.push({ allow: key === "allow", path: value });
      else if (key === "crawl-delay" && Number(value) >= 0) group.delay = Number(value);
    }
  }
  const own = groups.filter((g) => g.agents.some((a) => a !== "*" && a && token.includes(a)));
  const mine = own.length ? own : groups.filter((g) => g.agents.includes("*"));
  const rules = mine.flatMap((g) => g.rules);
  const delays = mine.map((g) => g.delay).filter((d) => d !== null);
  return {
    sitemaps,
    rules: rules.length,
    delay: delays.length ? Math.max(...delays) : null,
    /** The longest rule that fits decides; of two as long, the one that allows. */
    allowed(pathAndQuery) {
      if (pathAndQuery === "/robots.txt") return true;
      let best = null;
      for (const r of rules) if ((!best || r.path.length > best.path.length || (r.path.length === best.path.length && r.allow && !best.allow)) && fits(r.path, pathAndQuery)) best = r;
      return !best || best.allow;
    },
  };
}

/** Rules for a site that gives none: everything may be read. */
export const NO_RULES = { sitemaps: [], rules: 0, delay: null, allowed: () => true };
/** Rules for a site whose rules cannot be had: a robot keeps out (RFC 9309). */
export const KEEP_OUT = { sitemaps: [], rules: 0, delay: null, allowed: (p) => p === "/robots.txt" };

/** The addresses between every <loc> and its </loc>, found by looking for the two and nothing cleverer: one pass, whatever stands between (FM-SWARM-122). */
function locs(text) {
  const lower = text.toLowerCase();
  const out = [];
  for (let at = 0; ; ) {
    const from = lower.indexOf("<loc>", at);
    if (from < 0) break;
    const to = lower.indexOf("</loc>", from + 5);
    if (to < 0) break;
    at = to + 6;
    let inside = text.slice(from + 5, to).trim();
    if (inside.toUpperCase().startsWith("<![CDATA[")) inside = inside.slice(9).trim();
    if (inside.endsWith("]]>")) inside = inside.slice(0, -3).trim();
    if (inside && !inside.includes("<") && !inside.includes("]")) out.push(inside.replace(/&amp;/g, "&"));
  }
  return out;
}

/** The addresses a site map's text lists, and whether it is a list of site maps. Null where it is no site map. */
export function parseSitemap(text, type) {
  if (/<(urlset|sitemapindex)[\s>]/i.test(text)) return { index: /<sitemapindex[\s>]/i.test(text), urls: locs(text) };
  if (type === "text/plain") {
    const urls = text.split(/\s+/).filter((l) => /^https?:\/\//i.test(l));
    if (urls.length) return { index: false, urls };
  }
  return null;
}

/** The shape of the file, so a reader can tell one it does not know. */
export const PAGES_SHAPE = 1;
/** How many links of a page to other pages of the site are kept, and how long a title and a description may be. */
const LINKS_MOST = 30;
const TITLE_MOST = 200;
const DESCRIPTION_MOST = 400;

const wait = (ms) => new Promise((done) => setTimeout(done, ms));

/** Whether opening an address reads as doing something — signing out, deleting, unsubscribing, confirming: such a one is never asked for, and never kept as a link (FM-SWARM-167). */
export const acts = (u) => ACTION.test(u.pathname + u.search);

/** One page's words, title and links to other pages of the same site, from its HTML. */
export function pageOf(at, html, site) {
  const here = new URL(at);
  let base = here;
  try {
    const own = baseOf(html);
    if (own) base = new URL(own, here);
  } catch {
    base = here;
  }
  const links = [];
  for (const href of hrefsOf(html)) {
    let u;
    try {
      u = new URL(href, base);
    } catch {
      continue;
    }
    if (!/^https?:$/.test(u.protocol) || siteKey(u) !== site || u.username || u.password || acts(u)) continue;
    const to = folded(u.href);
    if (to !== folded(here.href) && !links.includes(to) && links.length < LINKS_MOST) links.push(to);
  }
  return { at, title: titleOf(html).slice(0, TITLE_MOST), description: describedOf(html).slice(0, DESCRIPTION_MOST), text: textOf(html), links };
}

/**
 * Ask again for every page the base pass opened, at the pace and within the time the run was
 * given, and give their words as the file of pages has them. `ask` is the one request, as in
 * `followWith`. The file closes with `end`, as the probe's own does.
 */
export async function gatherPages(base, o, ask) {
  const opened = base.entries.filter((e) => e.kind === "page" && typeof e.end === "string").slice(0, o.pages);
  const deadline = o.began + o.seconds * 1000;
  const pages = [];
  const taken = new Set();
  let stopped = null;
  for (const e of opened) {
    if (Date.now() >= deadline) {
      stopped = "time";
      break;
    }
    // Only the site that was checked is asked: an address of another one is passed by before any request.
    // One page under two addresses that differ only in what tracks a visitor is one page, and an address that reads as an act is not asked at all.
    let own = false;
    let page = "";
    try {
      const u = new URL(e.end);
      own = siteKey(u) === base.site && !acts(u);
      page = folded(e.end);
    } catch {
      own = false;
    }
    if (!own || taken.has(page)) continue;
    taken.add(page);
    if (o.pace > 0) await wait(o.pace);
    // Through the run's own wall, as the walk asked, and not past the run's last moment (FM-SWARM-182).
    const r = await ask(e.end, { text: true, wall: o.wall, open: base.local === true, until: deadline });
    if (r.error === TIME) {
      stopped = "time";
      break;
    }
    if (r.error || r.status !== 200 || r.text === null || !/html/.test(r.type)) continue;
    pages.push(pageOf(e.end, r.text, base.site));
  }
  return { pages: PAGES_SHAPE, key: o.key ?? null, site: base.home, opened: opened.length, stopped, read: pages, end: true };
}

/**
 * The file of facts of one run, as the probe writes it and a panel reads it: the heaviest facts
 * first, counted, with what the walk found of the rules for robots, the site map and the
 * languages. `as` is who the site was told is asking.
 */
export function factsFile(o, base, browser, facts) {
  const order = { broken: 0, hurts: 1, note: 2 };
  facts.sort((a, b) => order[a.weight] - order[b.weight]);
  const counts = { broken: 0, hurts: 0, note: 0 };
  for (const f of facts) counts[f.weight]++;
  return { counts, out: {
    probe: SHAPE,
    // The word of the job that started this run, said back: null for a run started by hand.
    key: o.key,
    start: o.start.href,
    site: base.home,
    began: new Date(o.began).toISOString(),
    tookMs: Date.now() - o.began,
    as: o.as ?? UA,
    limits: { pages: o.pages, seconds: o.seconds, paceMs: o.pace, outside: o.outside, links: o.links, images: o.images, browserPages: o.browserPages },
    stopped: base.stopped,
    passes: { base: { pages: base.htmlPages, addresses: base.entries.length, requests: base.asked }, browser: { ran: browser.ran, why: browser.why, engine: browser.engine, pages: browser.pages.filter((p) => p.opened).length } },
    robots: base.robots,
    sitemap: base.sitemap,
    languages: base.languages,
    counts,
    facts,
    pages: base.entries,
    notStated: base.doubts,
    // Last, as in an ask: a file that does not close with it is still being written.
    end: true,
  } };
}
