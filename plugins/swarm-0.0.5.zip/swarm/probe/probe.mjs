#!/usr/bin/env node
// The Swarm's probe: the technical check of a live site by its address — facts only, no model.
// One command, one strict JSON file of facts in the folder it is run in:
//
//   node probe.mjs https://example.com --out probe.json --pages 30
//
// With `--texts pages.json` it also writes the words of the pages it opened into a second file of
// the same folder: what the Swarm's residents read of the site, so that no model has to open the
// web for it (pages.mjs).
//
//   node probe.mjs --job probe-job.json
//
// is how the Swarm's helper starts it: everything it needs — the address first of all — is read
// from a file the panel wrote, so nothing of an address, which is a stranger's text, ever stands
// in a line a shell reads. The job carries a word, and both files say it back: it is how the
// panel knows a file for the one this very run of the program wrote (FM-SWARM-168, FM-SWARM-169).
//
// It reads and never writes: GET and HEAD only, no login, no form sent, no cookie kept. What it
// prints is one line, because the one who runs it is a model and every line it reads is paid for.

import { readFileSync, renameSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { Worker } from "node:worker_threads";
import { browserPass } from "./browser.mjs";
import { basePass } from "./crawl.mjs";
import { follow, wall } from "./net.mjs";
import { plainName, writePages } from "./pages.mjs";
import { factsFile } from "./plain.mjs";

const HELP = `node probe.mjs <address> [--out probe.json] [--pages 30] [--seconds 300] [--pace 500]
                [--outside 40] [--links 200] [--images 300] [--browser auto|off] [--browser-pages 10]
                [--texts pages.json] [--homes on|off]
       node probe.mjs --job probe-job.json`;

/** A number between two bounds, or the default. */
const between = (text, low, high, otherwise) => (text === undefined ? otherwise : Number.isFinite(Number(text)) ? Math.min(high, Math.max(low, Math.round(Number(text)))) : NaN);

/**
 * A job as the panel writes it, turned into the words of the command line and held to the same
 * rules: `{"job": 1, "address", "out", "pages", "browser", "texts", "key", "end": true}`, and
 * `"languages": "one"` where the person chose this language only (`--homes off`). With a
 * job nothing else may stand on the line.
 */
function jobOf(argv) {
  if (!argv.includes("--job")) return { argv, key: null };
  const name = argv[1] ?? "";
  // The job may lie one folder down — the Swarm's own folder in a project, when the program is run from the project and not from that folder — and then everything the program writes goes beside it: the program moves there before it reads (FM-SWARM-422).
  const cut = name.lastIndexOf("/");
  const [folder, file] = cut < 0 ? ["", name] : [name.slice(0, cut), name.slice(cut + 1)];
  if (argv.length !== 2 || argv[0] !== "--job" || !plainName(file) || (cut >= 0 && !/^[\w][\w.-]*$/.test(folder))) return "--job takes one file's name ending in .json, by itself or in one folder, and nothing beside it";
  let job;
  try {
    if (folder) process.chdir(resolve(process.cwd(), folder));
    job = JSON.parse(readFileSync(resolve(process.cwd(), file), "utf8"));
  } catch {
    return `the job could not be read: ${name}`;
  }
  if (!job || typeof job !== "object" || job.job !== 1 || job.end !== true || typeof job.address !== "string" || typeof job.out !== "string" || !/^[0-9a-f]{24}$/.test(String(job.key))) return `not a job of this program: ${name}`;
  return { argv: [job.address, "--out", job.out, "--pages", String(job.pages), "--browser", String(job.browser), ...(job.texts === undefined ? [] : ["--texts", String(job.texts)]), ...(job.languages === "one" ? ["--homes", "off"] : [])], key: job.key };
}

function options(given) {
  const job = jobOf(given);
  if (typeof job === "string") return job;
  const argv = job.argv;
  // An address read from a job is an address and never a word of the command, whatever it begins with.
  if (job.key !== null && argv[0].startsWith("--")) return `not an address: ${argv[0]}`;
  const o = { key: job.key, address: null, texts: null, out: "probe.json", pages: 30, seconds: 300, pace: 500, outside: 40, links: 200, images: 300, browser: "auto", browserPages: 10, homes: true };
  const bounds = { pages: [1, 500], seconds: [1, 3600], pace: [0, 60000], outside: [0, 200], links: [0, 2000], images: [0, 2000], "browser-pages": [0, 100] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (!a.startsWith("--")) {
      if (o.address !== null) return `one address, not two: ${a}`;
      o.address = a;
    } else if (a === "--out") o.out = argv[++i] ?? "";
    else if (a === "--browser") o.browser = argv[++i] ?? "";
    else if (a === "--texts") o.texts = argv[++i] ?? "";
    // The person chose this language only: the home pages of the site's other languages are not asked for at all.
    else if (a === "--homes") {
      const v = argv[++i] ?? "";
      if (v !== "on" && v !== "off") return "--homes takes on or off";
      o.homes = v === "on";
    }
    else if (a.slice(2) in bounds) {
      const name = a.slice(2);
      const n = between(argv[++i], ...bounds[name], NaN);
      if (Number.isNaN(n)) return `${a} takes a number`;
      o[name === "browser-pages" ? "browserPages" : name] = n;
    } else return `not a word this command knows: ${a}`;
  }
  if (!o.address) return "no address was given";
  // The file is written beside the run and nowhere else: a name, not a path.
  if (!/^[\w][\w.-]*\.json$/.test(o.out)) return "--out takes a file's name ending in .json, with no folder in it";
  if (o.browser !== "auto" && o.browser !== "off") return "--browser takes auto or off";
  if (o.texts !== null && (!plainName(o.texts) || o.texts === o.out)) return "--texts takes a file's name ending in .json, with no folder in it, and not the name of --out";
  let start;
  try {
    start = new URL(/^[a-z][a-z0-9+.-]*:/i.test(o.address) ? o.address : `https://${o.address}`);
  } catch {
    return `not an address: ${o.address}`;
  }
  if (!/^https?:$/.test(start.protocol)) return "only an http or https address is checked";
  // The checker never logs in, so it takes no address that carries a name and a password.
  if (start.username || start.password) return "an address with a name or a password in it is not opened";
  start.hash = "";
  o.start = start;
  return o;
}

/** How long past its limit a run may still be busy ending — writing its file, closing its browser — before it is ended for it. */
const GRACE_MS = 10_000;

/**
 * The limit of time, held from outside the run. Every step of the run looks at the clock, and a
 * step that never returns — a page, a rule or a file that keeps the one thread busy without end,
 * by a fault nobody has found yet — would look at nothing. So a second thread only counts: when
 * the limit and the grace are past and the run is still here, it says so and ends the whole
 * process. Then no file is written, and whoever ran the command reads the one line (FM-SWARM-122).
 * The browser, if one is up, ends with the pipe that held it.
 */
function hold(ms) {
  const guard = new Worker(
    `const { workerData } = require("node:worker_threads");
     setTimeout(() => {
       try { require("node:fs").writeSync(2, "probe: stopped: it was still busy " + Math.round(workerData / 1000) + " s after it began, past its limit of time, and wrote nothing\\n"); } catch {}
       process.kill(process.pid, "SIGKILL");
     }, workerData);`,
    { eval: true, workerData: ms, execArgv: [], stdout: false, stderr: false },
  );
  guard.unref();
}

async function main() {
  const o = options(process.argv.slice(2));
  if (typeof o === "string") {
    console.error(`probe: ${o}\n${HELP}`);
    return 2;
  }
  o.began = Date.now();
  hold(o.seconds * 1000 + GRACE_MS);
  // Told to end, the probe ends at once and in order: its browser and what that kept go with it.
  for (const signal of ["SIGINT", "SIGTERM", "SIGHUP"]) process.on(signal, () => process.exit(1));
  o.wall = wall();
  // The walk asks through the probe's own requests; a panel gives it the window's (plain.mjs).
  o.follow = follow;
  const base = await basePass(o.start, o);
  const facts = base.facts;

  let browser = { ran: false, why: "not asked for", engine: null, pages: [], facts: [] };
  if (o.browser === "auto" && o.browserPages > 0) {
    const urls = base.entries.filter((e) => e.kind === "page").map((e) => e.end);
    const deadline = o.began + o.seconds * 1000;
    if (!urls.length) browser.why = "no page was opened";
    else if (Date.now() >= deadline) browser.why = "the time was up before it could begin";
    else browser = await browserPass(urls.slice(0, o.browserPages), { deadline, site: base.site, baseFacts: facts, wall: o.wall, open: base.local });
    for (const [why, d] of Object.entries(browser.doubts ?? {})) base.doubts[why] = d;
    facts.push(...browser.facts);
    for (const seen of browser.pages) {
      const entry = base.entries.find((e) => e.end === seen.url);
      if (entry) entry.browser = seen;
    }
  }

  // The pages' words, for the residents: asked for once more, each at the address it ended on.
  const texts = o.texts ? await writePages(base, o) : null;

  const { counts, out } = factsFile(o, base, browser, facts);
  const path = resolve(process.cwd(), o.out);
  writeFileSync(`${path}.tmp`, JSON.stringify(out, null, 1));
  renameSync(`${path}.tmp`, path);
  console.log(`probe: ${base.htmlPages} pages${base.stopped ? ` (stopped: ${base.stopped})` : ""}, ${counts.broken} broken, ${counts.hurts} hurt, ${counts.note} notes, browser pass ${browser.ran ? `on ${out.passes.browser.pages}` : "not run"} -> ${o.out}${texts === null ? "" : `, the words of ${texts} pages -> ${o.texts}`}`);
  return 0;
}

main().then(
  (code) => process.exit(code),
  (e) => {
    console.error(`probe: ${e?.stack ?? e}`);
    process.exit(1);
  },
);
