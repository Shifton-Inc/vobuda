// The probe's fixed rules: every kind of fact it can state, what each weighs and how it is
// measured. A weight is read from this table and from nowhere else — never from an opinion of
// the page (FM-SWARM-82). Plain Node, no package: the helper runs it as it stands.

/** The shape of the file written; a reader refuses a number it does not know. */
export const SHAPE = 1;

/** Who the probe says it is, to the site and to its robots file. */
export const TOKEN = "vobuda-swarm-probe";
export const UA = `${TOKEN}/1 (a site check asked for by the site's owner; reads only)`;

/** The numbers the rules stand on. */
export const LIMITS = {
  /** Home pages of other languages asked for, and milliseconds between two of them at the least: a start page may name thousands (FM-SWARM-183). */
  homes: 60,
  homePace: 100,
  /** Letters of a title and of a description past which a search page cuts them. */
  title: 70,
  description: 170,
  /** Milliseconds from asking to the first byte of the answer. */
  slow: 1000,
  verySlow: 3000,
  /** Bytes of a page's own HTML, as read. */
  heavy: 500_000,
  /** Milliseconds until a page can be used, in the browser. */
  usable: 2500,
  veryUsable: 5000,
  /** A phone's screen, in points, and the smallest letters read on it without zooming. */
  phone: 390,
  phoneHeight: 844,
  smallText: 12,
  /** The share of a page's letters that must be small before it hurts rather than is noted. */
  smallShare: 0.1,
};

// broken — what a visitor asks for does not come; hurts — it comes, worse, for a visitor or a
// search engine; note — worth knowing, costs nobody anything today.
const B = "broken";
const H = "hurts";
const N = "note";

/** kind → [weight, pass, how it was measured]. */
export const KINDS = {
  notopened: [B, "base", "the start address was asked for twice with GET and gave no answer"],
  errorpage: [B, "base", "the start address was asked for twice with GET and answered with an error status"],
  refused: [N, "base", "the start address answered this checker with a status that means 'not for you' (401, 403, 429, 503); a person's browser may fare better"],
  deadlink: [B, "base", "the link's address on this site was asked for (HEAD, then GET) twice and answered 404, 410, a 5xx other than 503, or nothing"],
  deadoutside: [H, "base", "the link's address on another site was asked for (HEAD, then GET) twice and answered 404 or 410, or its name is not known to the network"],
  redirect: [N, "base", "the link's address answers with one redirect before the page comes"],
  redirectchain: [H, "base", "the address answers with two or more redirects in a row before the page comes"],
  redirectloop: [B, "base", "the address's redirects come back to an address already passed, or do not end in ten steps"],
  redirectnowhere: [B, "base", "the address redirects, and the end of the redirects answers 404, 410, a 5xx other than 503, or nothing"],
  slow: [N, "base", `the first byte of the answer came more than ${LIMITS.slow} ms after the request, connecting included`],
  veryslow: [H, "base", `the first byte of the answer came more than ${LIMITS.verySlow} ms after the request, connecting included`],
  heavy: [N, "base", `the page's own HTML, unpacked, is more than ${LIMITS.heavy} bytes`],
  notitle: [H, "base", "the HTML has no <title>, or an empty one"],
  sametitle: [H, "base", "the same <title>, letter for letter after trimming, is on two or more pages that do not name one another as the same page"],
  longtitle: [N, "base", `the <title> is longer than ${LIMITS.title} letters`],
  nodescription: [H, "base", "the HTML has no <meta name=description>, or an empty one"],
  samedescription: [N, "base", "the same description, letter for letter after trimming, is on two or more pages"],
  longdescription: [N, "base", `the description is longer than ${LIMITS.description} letters`],
  noheading: [H, "base", "the HTML has no <h1>"],
  manyheadings: [N, "base", "the HTML has more than one <h1>"],
  image: [B, "base", "the picture's address was asked for (HEAD, then GET) twice and answered 404, 410, a 5xx other than 503, nothing, or a web page instead of a picture"],
  formnotarget: [N, "base", "the <form> has no action, an empty one, '#', or a javascript: one: only a script can send it anywhere"],
  formnobutton: [H, "base", "the <form> holds no submit button: no <button> of the submit kind and no <input type=submit|image>"],
  mixedactive: [B, "base", "a page served over https names a script, a style sheet or a frame by an http:// address; browsers refuse to load it"],
  mixedpassive: [H, "base", "a page served over https names a picture, a sound or a film by an http:// address; browsers warn or refuse"],
  insecureform: [H, "base", "a page served over https has a <form> whose action is an http:// address; browsers warn before sending"],
  nolang: [H, "base", "the <html> tag has no lang, or the page has no <html> tag"],
  unlinked: [H, "base", "the address is in the site map and answers, and no page opened in a walk that reached every page links to it"],
  notinsitemap: [N, "base", "the page was reached by a link, answers, does not ask to be left out of search, and the site map — read whole — does not list it"],
  sitemapdead: [H, "base", "the site map lists the address, and it answered 404, 410, a 5xx other than 503, or nothing, twice"],
  sitemapforeign: [N, "base", "the site map lists addresses of another site"],
  nositemap: [N, "base", "robots.txt names no site map and neither /sitemap.xml nor /sitemap_index.xml answers with one"],
  sitemapbroken: [H, "base", "an address given as the site map does not answer, or what answers is not a site map"],
  norobots: [N, "base", "/robots.txt answered with a 4xx status: there are no rules for robots"],
  robotsbroken: [H, "base", "/robots.txt answered with a 5xx status or nothing, which robots read as 'keep out of the whole site' — or it answered with a web page instead of rules"],
  closed: [H, "base", "/robots.txt tells every robot to keep out of the start address"],
  consoleerror: [H, "browser", "the page was opened in a headless browser at a phone's size and an error was written to its console, or a script threw and nothing caught it"],
  failedrequest: [H, "browser", "the page was opened in a headless browser and a request it made failed or answered with an error status"],
  wide: [H, "browser", `at ${LIMITS.phone} points wide the page is wider than the screen: it scrolls sideways, or it is laid out for a wider screen and shrunk`],
  smalltext: [H, "browser", `at ${LIMITS.phone} points wide at least a tenth of the page's letters are smaller than ${LIMITS.smallText} points`],
  somesmalltext: [N, "browser", `at ${LIMITS.phone} points wide some of the page's letters, under a tenth, are smaller than ${LIMITS.smallText} points`],
  deadbutton: [H, "browser", "a button outside any form was pressed with the browser's own pointer and in the next 700 ms nothing changed: no request, no change of the page, its address, its look, its scroll or its focus, no dialog"],
  slowuse: [N, "browser", `the page could be used more than ${LIMITS.usable} ms after it was asked for: the latest of first paint, the HTML being ready, and the last long task before the network went quiet`],
  veryslowuse: [H, "browser", `the page could be used more than ${LIMITS.veryUsable} ms after it was asked for, measured the same way`],
};

/** One fact. `seen` is what was found, in a few words; `data` is the same as plain values, for a panel that words it itself. */
export function fact(page, kind, place, seen, data = {}) {
  const [weight, pass, how] = KINDS[kind];
  return { page, place: String(place).slice(0, 240), kind, weight, seen: String(seen).slice(0, 300), how, pass, data };
}

/** Which of two kinds a measured number is: the heavier past the second line, the lighter past the first, none under it. */
export function tier(value, first, second, light, heavy) {
  return value > second ? heavy : value > first ? light : null;
}

/** A status that is certainly a fault of a page on the site itself. 401, 403, 429 and 503 are a door, not a fault. */
export const deadInside = (status) => status === 404 || status === 410 || (status >= 500 && status !== 503);
/** Another site answers robots as it likes: only "not here" is certain. */
export const deadOutside = (status) => status === 404 || status === 410;
/** No answer that is certainly the site's own: the name unknown, the door shut, the certificate bad, silence. */
export const NO_ANSWER_INSIDE = /^(ENOTFOUND|ECONNREFUSED|ECONNRESET|EPIPE|timeout|CERT_|DEPTH_ZERO|SELF_SIGNED|UNABLE_TO_VERIFY|ERR_TLS|ERR_SSL)/;

/** An address that is a file to take away and not a page, by its ending: asked for with HEAD, so that a check is not a download. */
export const FILE = /\.(pkg|dmg|exe|msi|deb|rpm|apk|ipa|zip|gz|tgz|bz2|xz|7z|rar|tar|iso|pdf|docx?|xlsx?|pptx?|csv|png|jpe?g|gif|webp|avif|svg|ico|mp3|mp4|m4a|mov|webm|ogg|wav|woff2?|ttf|otf|txt|json|xml|css|js)$/i;

/** A link that does something when opened, by its own words: never asked for, even with GET. */
export const ACTION = /(^|[/?&=_.-])(logout|log-out|signout|sign-out|delete|remove|destroy|unsubscribe|add-to-cart|addtocart|checkout|confirm|activate|approve|cancel|pay)([/?&=_.-]|$)/i;

// A button with any of these in what it says or is named is never pressed. The list is wide on
// purpose: a button left alone costs one fact, a button pressed wrongly costs the owner (FM-SWARM-84).
export const DANGER = /pay|buy|purchas|checkout|order|delet|remov|eras|destroy|send|submit|sign|log\s?out|subscri|regist|confirm|cancel|save|publish|post|upload|invit|share|reset|book|donat|accept|agree|apply|allow|оплат|плат|куп|заказ|оформ|удал|стер|отправ|подпис|войти|вход|выйти|выход|регистр|подтверд|отмен|сохран|опублик|загруз|приглас|подел|сброс|бронир|пожертв|принять|принима|соглас|примен|разреш/i;

// Hosts that count visitors or open a chat with them: never asked, so that a check is not a
// visit in the owner's own figures. Not the whole world's list; what is left is held by the
// rule that nothing but GET leaves the browser.
export const QUIET = /(^|\.)(google-analytics\.com|googletagmanager\.com|analytics\.google\.com|doubleclick\.net|googleadservices\.com|googlesyndication\.com|facebook\.net|facebook\.com|clarity\.ms|hotjar\.com|hotjar\.io|mc\.yandex\.ru|plausible\.io|cloudflareinsights\.com|segment\.com|segment\.io|mixpanel\.com|amplitude\.com|analytics\.ahrefs\.com|ads-twitter\.com|analytics\.tiktok\.com|bat\.bing\.com|sentry\.io|crisp\.chat|intercom\.io|intercomcdn\.com|hs-analytics\.net|hs-scripts\.com|fullstory\.com|posthog\.com|umami\.is|matomo\.cloud|snap\.licdn\.com|px\.ads\.linkedin\.com)$/i;

// The same by what an address looks like, for a host that is not the site checked and is not on
// the list: a counter, an advertisement, a chat. Said of the host's name and the path, never of the site's own pages.
export const LOOKS = /analytic|metric|track|pixel|telemetry|tagmanager|gtag|gtm\.js|collect|beacon|adservice|adsystem|(^|[^a-z])ads?([^a-z]|$)|livechat|chat|widget|intercom|crisp|hotjar|clarity|matomo|plausible|umami|posthog|segment|mixpanel|amplitude|sentry|stats?([^a-z]|$)/i;
/** Whether asking another site for this address could count as a visit or open a talk. */
export const countsVisitors = (u) => QUIET.test(u.hostname) || LOOKS.test(u.hostname + u.pathname);

/** One site, whatever the www and the scheme. */
/** What a mail, an advertisement or a counter adds to an address to know where a visitor came from: the page is the same page without it. */
export const TRACKING = /^(utm_[a-z0-9_]+|ref|ref_src|fbclid|gclid|dclid|yclid|msclkid|mc_cid|mc_eid|igshid|_ga|_gl)$/i;

/**
 * An address without what only tracks: two addresses that differ in that alone are one page, to
 * the walk and to the pages' words alike (FM-SWARM-167, FM-SWARM-181).
 */
export function folded(address) {
  const u = new URL(address);
  for (const name of [...u.searchParams.keys()]) if (TRACKING.test(name)) u.searchParams.delete(name);
  u.hash = "";
  return u.href.replace(/\?$/, "");
}

export const siteKey = (u) => `${u.hostname.replace(/^www\./i, "").toLowerCase()}:${u.port}`;

/** The two-letter names of languages, for a site that keeps each language in a folder of its name. */
export const TONGUES = new Set("aa ab af ak am an ar as av ay az ba be bg bh bi bm bn bo br bs ca ce ch co cr cs cu cv cy da de dv dz ee el en eo es et eu fa ff fi fj fo fr fy ga gd gl gn gu gv ha he hi ho hr ht hu hy hz ia id ie ig ii ik io is it iu ja jv ka kg ki kj kk kl km kn ko kr ks ku kv kw ky la lb lg li ln lo lt lu lv mg mh mi mk ml mn mr ms mt my na nb nd ne ng nl nn no nr nv ny oc oj om or os pa pi pl ps pt qu rm rn ro ru rw sa sc sd se sg si sk sl sm sn so sq sr ss st su sv sw ta te tg th ti tk tl tn to tr ts tt tw ty ug uk ur uz ve vi vo wa wo xh yi yo za zh zu".split(" "));

// The four numbers of an address of the old kind: this machine, a private net, a link's own
// addresses, a carrier's shared ones, the ranges kept for tests and for writing about, and
// everything from 224 up, which is no one host.
const inner4 = (a, b, c) =>
  a === 0 || a === 10 || a === 127 || (a === 100 && b >= 64 && b <= 127) || (a === 169 && b === 254) || (a === 172 && b >= 16 && b <= 31) || (a === 192 && b === 168) || (a === 192 && b === 0 && (c === 0 || c === 2)) || (a === 198 && (b === 18 || b === 19)) || (a === 198 && b === 51 && c === 100) || (a === 203 && b === 0 && c === 113) || a >= 224;

/** An address of the new kind as its eight numbers; null where the text is none. Its last two may be written the old way. */
function groups(ip) {
  let text = ip.split("%")[0].toLowerCase();
  const old = /^(.*:)(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(text);
  if (old) {
    const [a, b, c, d] = old.slice(2).map(Number);
    if (a > 255 || b > 255 || c > 255 || d > 255) return null;
    text = `${old[1]}${((a << 8) | b).toString(16)}:${((c << 8) | d).toString(16)}`;
  }
  const halves = text.split("::");
  if (halves.length > 2) return null;
  const head = halves[0] ? halves[0].split(":") : [];
  const tail = halves.length === 2 ? (halves[1] ? halves[1].split(":") : []) : null;
  if (tail && head.length + tail.length > 7) return null;
  const all = tail ? [...head, ...Array(8 - head.length - tail.length).fill("0"), ...tail] : head;
  return all.length === 8 && all.every((g) => /^[0-9a-f]{1,4}$/.test(g)) ? all.map((g) => parseInt(g, 16)) : null;
}

/**
 * An address of the machine itself or of the net it sits in: nothing a public page names there is
 * asked for. An address of the new kind that only carries one of the old kind inside it — mapped,
 * however it is spelled, or through a carrier's translator (64:ff9b::/96), or the old tunnel
 * (2002::/16) — is judged by the one it carries. What cannot be read as an address is private:
 * the rule shuts where it does not understand (FM-SWARM-121).
 */
export function privateAddress(ip) {
  const v4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/.exec(String(ip));
  if (v4) return inner4(Number(v4[1]), Number(v4[2]), Number(v4[3]));
  const g = groups(String(ip));
  if (!g) return true;
  const carried = (hi, lo) => inner4(hi >> 8, hi & 255, lo >> 8);
  // ::, ::1, and an address of the old kind written as one of the new, mapped or bare.
  if (g.slice(0, 5).every((x) => x === 0) && (g[5] === 0 || g[5] === 0xffff)) return carried(g[6], g[7]);
  if (g.slice(0, 4).every((x) => x === 0) && g[4] === 0xffff && g[5] === 0) return carried(g[6], g[7]);
  if (g[0] === 0x64 && g[1] === 0xff9b) return g.slice(2, 6).every((x) => x === 0) ? carried(g[6], g[7]) : true;
  if (g[0] === 0x2002) return carried(g[1], g[2]);
  // Teredo and the range kept for writing about; a private net, a link's own, a site's own of old, and what is no one host.
  if (g[0] === 0x2001 && (g[1] === 0 || g[1] === 0xdb8)) return true;
  return (g[0] & 0xfe00) === 0xfc00 || (g[0] & 0xff80) === 0xfe80 || (g[0] & 0xff00) === 0xff00;
}

/** A host as an address has it: without the brackets an address of the new kind is written in. */
export const bare = (host) => host.replace(/^\[|\]$/g, "");
const literal = (host) => /^\d+\.\d+\.\d+\.\d+$/.test(host) || bare(host).includes(":");

/** The machine's own names: a site checked there is somebody's work in hand, and its neighbours may be asked. */
export const loopback = (host) => /^(localhost|127(\.\d+){3}|\[::1\])$/i.test(host);

/**
 * Whether the start address, as the person wrote it, is itself on this machine or in a private
 * net: its own name, or such an address in numbers. Only then is anything there asked at all —
 * a name that merely leads there is not the person's word for it (FM-SWARM-121).
 */
export const ownGround = (host) => loopback(host) || (literal(host) && privateAddress(bare(host)));
