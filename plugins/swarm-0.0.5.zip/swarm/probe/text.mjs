// A page's words as a visitor reads them, taken out of its HTML: what the Swarm studies of a site
// that is given by its address. Plain Node, no model, and nothing of the page is run: a script, a
// style and the head are passed by whole, and a tag is never anything but a tag.
//
// Every pass over the page is one walk from its start to its end: a page is a stranger's text,
// and one written to make a reader of tags work for an hour must not manage it (FM-SWARM-161).

import { plain } from "./html.mjs";

/** What stands inside these is not the page's words. */
const PASSED_BY = /<(script|style|noscript|template|svg|iframe|head|title|select|textarea|object|canvas)\b/gi;
/** A tag that ends a line of the page, and one that begins a paragraph. */
const LINE = new Set(["br", "hr", "tr", "option"]);
const BLOCK = new Set(["p", "div", "section", "article", "main", "header", "footer", "nav", "aside", "ul", "ol", "table", "blockquote", "pre", "form", "figure", "figcaption", "dl", "dt", "dd", "details", "summary", "address", "fieldset", "h1", "h2", "h3", "h4", "h5", "h6"]);

/** The page without what is not its words: comments, and the blocks passed by. A block or a comment never closed takes the rest of the page with it. */
export function shown(html) {
  const lower = html.toLowerCase();
  let out = "";
  let at = 0;
  // Comments first, by their two marks.
  for (;;) {
    const open = lower.indexOf("<!--", at);
    if (open < 0) break;
    out += html.slice(at, open);
    const close = lower.indexOf("-->", open + 4);
    if (close < 0) return blocks(out);
    at = close + 3;
  }
  return blocks(out + html.slice(at));
}

function blocks(html) {
  const lower = html.toLowerCase();
  let out = "";
  let at = 0;
  PASSED_BY.lastIndex = 0;
  for (let m; (m = PASSED_BY.exec(html)); ) {
    out += `${html.slice(at, m.index)} `;
    const close = lower.indexOf(`</${m[1].toLowerCase()}`, PASSED_BY.lastIndex);
    const end = close < 0 ? -1 : lower.indexOf(">", close);
    if (end < 0) return out;
    at = end + 1;
    PASSED_BY.lastIndex = at;
  }
  return out + html.slice(at);
}

/**
 * The page's text: headings marked as headings, list items as items, a paragraph a line, every
 * other tag gone, entities turned back into letters, at most `most` letters — as many as the panel
 * reads of one page (study.ts, `PARTS_MOST` parts of `PAGE_LETTERS`): a page is read to its end,
 * and the bound is for what is no page of prose at all (FM-SWARM-454).
 */
export function textOf(html, most = 120_000) {
  const s = shown(String(html));
  let out = "";
  let at = 0;
  while (at < s.length) {
    const lt = s.indexOf("<", at);
    if (lt < 0) {
      out += s.slice(at);
      break;
    }
    out += s.slice(at, lt);
    const tag = /^<(\/?)([a-zA-Z][a-zA-Z0-9]*)/.exec(s.slice(lt, lt + 32));
    // A "<" that begins no tag is a letter of the text.
    if (!tag && !/^<[!?]/.test(s.slice(lt, lt + 2))) {
      out += "<";
      at = lt + 1;
      continue;
    }
    const gt = s.indexOf(">", lt + 1);
    // A tag never closed: what follows is not text.
    if (gt < 0) break;
    const name = tag ? tag[2].toLowerCase() : "";
    if (tag && !tag[1] && /^h[1-6]$/.test(name)) out += `\n\n${"#".repeat(Number(name[1]))} `;
    else if (tag && !tag[1] && name === "li") out += "\n- ";
    else if (LINE.has(name)) out += "\n";
    else if (BLOCK.has(name)) out += "\n\n";
    else if (name === "td" || name === "th") out += tag[1] ? " | " : "";
    at = gt + 1;
  }
  const text = plain(out)
    .replace(/[ \t\r\f\v\u00a0]+/g, " ")
    .replace(/ ?\n ?/g, "\n")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
  return text.length > most ? text.slice(0, most) : text;
}

/** The tags of one name, each as its own short piece: found by its two marks, one after another, and one longer than a tag ever is passed by. */
export function tagsOf(html, name, most = 2000) {
  const lower = html.toLowerCase();
  const open = `<${name}`;
  const out = [];
  let at = 0;
  while (out.length < 5000) {
    const lt = lower.indexOf(open, at);
    if (lt < 0) break;
    at = lt + open.length;
    // "<abbr" is not "<a".
    if (at < lower.length && !/[\s/>]/.test(lower[at])) continue;
    const gt = lower.indexOf(">", at);
    if (gt < 0) break;
    if (gt - lt <= most) out.push(html.slice(lt, gt + 1));
    at = gt + 1;
  }
  return out;
}

/** What a tag says for one of its names, or null. */
export function said(tag, name) {
  const m = new RegExp(`\\s${name}\\s*=\\s*(?:"([^"]*)"|'([^']*)'|([^\\s"'>]+))`, "i").exec(tag);
  return m ? plain(m[1] ?? m[2] ?? m[3] ?? "").trim() : null;
}

/** The page's title, as its head gives it. */
export function titleOf(html) {
  const lower = html.toLowerCase();
  const open = lower.indexOf("<title");
  const from = open < 0 ? -1 : lower.indexOf(">", open);
  const to = from < 0 ? -1 : lower.indexOf("</title", from);
  return to < 0 ? "" : plain(html.slice(from + 1, Math.min(to, from + 1001))).replace(/\s+/g, " ").trim();
}

/** The page's own description, the address its links start from, and the addresses its links name — as written, in order. */
export const describedOf = (html) => said(tagsOf(html, "meta").find((tag) => (said(tag, "name") ?? "").toLowerCase() === "description") ?? "", "content") ?? "";
export const baseOf = (html) => said(tagsOf(html, "base")[0] ?? "", "href");
export const hrefsOf = (html) => tagsOf(shown(html), "a").map((tag) => said(tag, "href")).filter((href) => href !== null && href !== "");
